# Policy Engine Integration Plan for Credit Nexus

## Executive Summary

This document outlines a comprehensive plan to integrate a **deterministic policy-as-code compliance engine** into Credit Nexus. The engine will enforce financial regulations (MiCA, Basel III, FATF, syndicated loan covenants) in real-time, moving compliance from ex-post reconciliation to ex-ante enforcement.

**Key Principles:**
- **CDM Compliance**: All policy evaluations operate on FINOS Common Domain Model structures
- **Deterministic Evaluation**: Policy-as-code using AST-based rule compilation (not stochastic AI)
- **Ex-Ante Enforcement**: Real-time blocking/flagging before settlement
- **Full Auditability**: Cryptographic traces for every decision
- **Vendor Agnostic**: Abstract interface allows any policy engine implementation

**Implementation Overview:**
- **10 Projects** organized into logical phases
- **21 Activities** with specific file-level tasks
- **100+ Line-level subtasks** for precise implementation
- **180 hours** estimated total effort
- **6-week timeline** with parallel workstreams

**Quick Start:**
1. Start with **PROJECT 1** (Core Infrastructure) - Foundation for all other work
2. Complete **PROJECT 2** (Database Schema) - Required for audit trail
3. Implement integration points **PROJECT 3-6** in priority order
4. Add monitoring and UI components **PROJECT 7-8**
5. Complete testing and documentation **PROJECT 9-10**

---

## 1. Architecture Overview

### 1.1 System Components

```
┌─────────────────────────────────────────────────────────────┐
│                    Credit Nexus Platform                     │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │ Document     │    │ Trade        │    │ Loan Asset   │  │
│  │ Extraction   │───▶│ Blotter      │───▶│ Verification │  │
│  │ (CDM)        │    │ (CDM Events) │    │ (CDM Events) │  │
│  └──────────────┘    └──────────────┘    └──────────────┘  │
│         │                   │                   │            │
│         └───────────────────┼───────────────────┘            │
│                             │                                 │
│                    ┌─────────▼─────────┐                      │
│                    │  Policy Engine    │                      │
│                    │  Service Layer    │                      │
│                    │  (CDM Adapter)    │                      │
│                    └─────────┬─────────┘                      │
│                             │                                 │
│                    ┌─────────▼─────────┐                      │
│                    │  Policy Engine    │                      │
│                    │  Core (Vendor)    │                      │
│                    │  - Rule Compiler  │                      │
│                    │  - AST Evaluator  │                      │
│                    │  - Conflict Res.  │                      │
│                    └───────────────────┘                      │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

### 1.2 Integration Layers

1. **CDM Adapter Layer**: Converts CDM models to policy engine transaction format
2. **Policy Service Layer**: Business logic for policy enforcement in Credit Nexus context
3. **Policy Engine Core**: Vendor-agnostic interface to actual policy engine
4. **Audit Integration**: Policy decisions logged to Credit Nexus audit trail

---

## 2. CDM Domain Model Mapping

### 2.1 Policy Evaluation Context

The policy engine evaluates **transactions** and **events** that occur in Credit Nexus. These map to CDM structures:

#### **Transaction Types:**

1. **Loan Facility Creation** (`CreditAgreement` → Policy Transaction)
   - Trigger: When a new `CreditAgreement` is extracted/approved
   - Evaluates: Facility terms, parties, ESG compliance, regulatory jurisdiction

2. **Trade Execution** (`TradeExecution` CDM Event → Policy Transaction)
   - Trigger: When a trade is executed in Trade Blotter
   - Evaluates: Counterparty KYC, amount limits, currency restrictions, sanctions

3. **Loan Asset Securitization** (`LoanAsset` creation → Policy Transaction)
   - Trigger: When a loan asset is created and verified
   - Evaluates: Collateral compliance, SPT thresholds, geographic restrictions

4. **Terms Change** (`TermsChange` CDM Event → Policy Transaction)
   - Trigger: When ESG observation triggers interest rate adjustment
   - Evaluates: Rate change limits, regulatory caps, sustainability compliance

### 2.2 CDM-to-Policy Transaction Schema

```python
# Policy Transaction Structure (Generic)
{
    "transaction_id": str,           # Unique identifier
    "transaction_type": str,         # "facility_creation", "trade_execution", etc.
    "timestamp": datetime,
    
    # CDM Party Information
    "originator": {
        "id": str,                   # Party.id or LEI
        "name": str,                  # Party.name
        "role": str,                  # Party.role (Borrower, Lender, etc.)
        "lei": Optional[str],         # Legal Entity Identifier
        "kyc_status": bool,           # Derived from party data
        "jurisdiction": str,          # From governing_law
        "centrality": float           # Network I/O centrality (if available)
    },
    
    "beneficiary": {                 # For trades/transfers
        "id": str,
        "name": str,
        "role": str,
        "lei": Optional[str],
        "kyc_status": bool,
        "jurisdiction": str
    },
    
    # Financial Terms
    "amount": Decimal,                # Commitment amount or trade amount
    "currency": Currency,             # CDM Currency enum
    "interest_rate": Optional[float], # Spread in bps or percentage
    "maturity_date": Optional[date],
    
    # Facility-Specific
    "facility_name": Optional[str],
    "facility_type": Optional[str],   # "Term Loan", "Revolving Credit", etc.
    
    # ESG/Sustainability
    "sustainability_linked": bool,
    "esg_kpi_targets": List[dict],
    "spt_threshold": Optional[float],
    "ndvi_score": Optional[float],    # Current verification score
    
    # Regulatory Context
    "governing_law": str,             # "NY", "English", etc.
    "regulatory_framework": List[str], # ["MiCA", "Basel_III", "FATF"]
    "context": str,                   # Transaction context tag
    
    # Loan Asset Specific
    "collateral_address": Optional[str],
    "geo_lat": Optional[float],
    "geo_lon": Optional[float],
    "risk_status": Optional[str]      # "COMPLIANT", "BREACH", etc.
}
```

---

## 3. Integration Points in Credit Nexus

### 3.1 Document Extraction Workflow

**Location**: `app/api/routes.py` → `/extract` endpoint

**Integration Point**: After CDM extraction, before workflow approval

```python
# Pseudo-code flow
extraction_result = extract_data(document_text)
credit_agreement = extraction_result.agreement

# NEW: Policy evaluation
policy_result = policy_service.evaluate_facility_creation(
    credit_agreement=credit_agreement,
    document_id=document.id
)

if policy_result.decision == "BLOCK":
    # Prevent workflow progression
    raise HTTPException(
        status_code=403,
        detail={
            "status": "blocked",
            "reason": policy_result.rule_applied,
            "trace": policy_result.trace
        }
    )
elif policy_result.decision == "FLAG":
    # Allow but flag for review
    workflow.priority = "high"
    workflow.state = WorkflowState.REQUIRES_REVIEW
```

**Policy Rules Applied**:
- `block_sanctioned_parties`: Check LEI against sanctions list
- `flag_high_risk_jurisdiction`: Flag facilities in high-risk countries
- `block_invalid_esg_claims`: Block if sustainability_linked but no KPI targets
- `flag_excessive_commitment`: Flag if total commitment exceeds regulatory limits

### 3.2 Trade Execution (Trade Blotter)

**Location**: `client/src/apps/trade-blotter/TradeBlotter.tsx` → `handleConfirmTrade()`

**Integration Point**: Before trade confirmation, during settlement workflow

```python
# Backend: app/api/routes.py → POST /trades/execute
@router.post("/trades/execute")
async def execute_trade(
    trade_request: TradeExecutionRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Generate CDM TradeExecution event
    cdm_event = generate_cdm_trade_execution(
        trade_id=trade_request.trade_id,
        borrower=trade_request.borrower,
        amount=trade_request.amount,
        rate=trade_request.rate
    )
    
    # NEW: Policy evaluation
    policy_result = policy_service.evaluate_trade_execution(
        cdm_event=cdm_event,
        credit_agreement=trade_request.credit_agreement
    )
    
    if policy_result.decision == "BLOCK":
        return {
            "status": "blocked",
            "decision": "BLOCK",
            "rule": policy_result.rule_applied,
            "trace_id": policy_result.trace_id,
            "message": "Trade blocked by compliance policy"
        }
    
    # Continue with trade execution...
```

**Policy Rules Applied**:
- `block_unhosted_wallets`: Block if originator KYC is false
- `flag_high_value_transfer`: Flag transfers above threshold
- `block_sanctioned_counterparty`: Block trades with sanctioned entities
- `flag_virtual_asset_transfer`: Flag crypto/stablecoin transfers

### 3.3 Loan Asset Creation & Verification

**Location**: `app/api/routes.py` → `/loan-assets` endpoint  
**Location**: `app/agents/audit_workflow.py` → `run_full_audit()`

**Integration Point**: After satellite verification, before asset finalization

```python
# In run_full_audit() after Stage 4 (Satellite Verification)
if verification.get("success"):
    ndvi_score = verification["ndvi_score"]
    loan_asset.update_verification(ndvi_score)
    
    # NEW: Policy evaluation for securitization
    policy_result = policy_service.evaluate_loan_asset(
        loan_asset=loan_asset,
        credit_agreement=credit_agreement  # From document
    )
    
    if policy_result.decision == "BLOCK":
        loan_asset.risk_status = RiskStatus.ERROR
        loan_asset.verification_error = f"Policy violation: {policy_result.rule_applied}"
    elif policy_result.decision == "FLAG":
        # Mark for manual review
        loan_asset.risk_status = RiskStatus.WARNING
```

**Policy Rules Applied**:
- `block_breach_securitization`: Block securitization if NDVI < threshold
- `flag_geographic_restriction`: Flag assets in restricted jurisdictions
- `block_missing_collateral_verification`: Block if satellite verification failed
- `flag_high_risk_collateral`: Flag if collateral is in high-risk category

### 3.4 Terms Change (ESG Observation)

**Location**: `app/models/cdm_events.py` → `generate_cdm_terms_change()`

**Integration Point**: Before applying interest rate penalty/adjustment

```python
# When ESG observation triggers terms change
def apply_terms_change(trade_id: str, ndvi_status: str, current_rate: float):
    new_rate = calculate_new_rate(current_rate, ndvi_status)
    
    # NEW: Policy evaluation
    policy_result = policy_service.evaluate_terms_change(
        trade_id=trade_id,
        current_rate=current_rate,
        proposed_rate=new_rate,
        reason="SustainabilityPerformanceTarget_Breach"
    )
    
    if policy_result.decision == "BLOCK":
        # Prevent rate change, maintain current rate
        logger.warning(f"Rate change blocked: {policy_result.rule_applied}")
        return current_rate
    
    # Generate CDM TermsChange event
    return generate_cdm_terms_change(trade_id, new_rate, ndvi_status)
```

**Policy Rules Applied**:
- `block_excessive_rate_increase`: Block if penalty exceeds regulatory cap
- `flag_rapid_rate_changes`: Flag if multiple rate changes in short period
- `block_unauthorized_terms_modification`: Block if terms change not authorized

---

## 4. Service Layer Architecture

### 4.1 Policy Service Interface

**File**: `app/services/policy_service.py`

```python
from typing import Dict, Any, Optional, List
from app.models.cdm import CreditAgreement, Currency
from app.models.cdm_events import Dict as CDMEventDict
from app.models.loan_asset import LoanAsset
from dataclasses import dataclass
from datetime import datetime

@dataclass
class PolicyDecision:
    """Result of policy evaluation."""
    decision: str  # "ALLOW", "BLOCK", "FLAG"
    rule_applied: Optional[str]
    trace_id: str
    trace: List[Dict[str, Any]]
    matched_rules: List[str]
    metadata: Dict[str, Any]

class PolicyService:
    """
    Service layer for policy engine integration.
    
    Provides CDM-compliant interfaces to the policy engine,
    handling transaction mapping and result interpretation.
    """
    
    def __init__(self, policy_engine):
        """
        Initialize with policy engine instance.
        
        Args:
            policy_engine: Vendor-agnostic policy engine interface
        """
        self.engine = policy_engine
    
    def evaluate_facility_creation(
        self,
        credit_agreement: CreditAgreement,
        document_id: Optional[int] = None
    ) -> PolicyDecision:
        """
        Evaluate a new loan facility for compliance.
        
        Args:
            credit_agreement: Extracted CDM CreditAgreement
            document_id: Optional document ID for audit trail
            
        Returns:
            PolicyDecision with ALLOW/BLOCK/FLAG
        """
        # Convert CDM to policy transaction
        tx = self._cdm_to_policy_transaction(
            credit_agreement=credit_agreement,
            transaction_type="facility_creation"
        )
        
        # Evaluate
        result = self.engine.evaluate(tx)
        
        return PolicyDecision(
            decision=result["decision"],
            rule_applied=result.get("rule"),
            trace_id=f"facility_{document_id}_{datetime.utcnow().isoformat()}",
            trace=result.get("trace", []),
            matched_rules=result.get("matched_rules", []),
            metadata={"document_id": document_id}
        )
    
    def evaluate_trade_execution(
        self,
        cdm_event: CDMEventDict,
        credit_agreement: Optional[CreditAgreement] = None
    ) -> PolicyDecision:
        """
        Evaluate a trade execution for compliance.
        
        Args:
            cdm_event: CDM TradeExecution event
            credit_agreement: Optional source credit agreement
            
        Returns:
            PolicyDecision
        """
        tx = self._cdm_trade_event_to_policy_transaction(cdm_event, credit_agreement)
        result = self.engine.evaluate(tx)
        
        return PolicyDecision(
            decision=result["decision"],
            rule_applied=result.get("rule"),
            trace_id=f"trade_{cdm_event['trade']['tradeIdentifier']['assignedIdentifier'][0]['identifier']['value']}",
            trace=result.get("trace", []),
            matched_rules=result.get("matched_rules", []),
            metadata={"cdm_event_type": "TradeExecution"}
        )
    
    def evaluate_loan_asset(
        self,
        loan_asset: LoanAsset,
        credit_agreement: Optional[CreditAgreement] = None
    ) -> PolicyDecision:
        """
        Evaluate loan asset securitization for compliance.
        
        Args:
            loan_asset: LoanAsset model instance
            credit_agreement: Optional source credit agreement
            
        Returns:
            PolicyDecision
        """
        tx = self._loan_asset_to_policy_transaction(loan_asset, credit_agreement)
        result = self.engine.evaluate(tx)
        
        return PolicyDecision(
            decision=result["decision"],
            rule_applied=result.get("rule"),
            trace_id=f"asset_{loan_asset.loan_id}_{datetime.utcnow().isoformat()}",
            trace=result.get("trace", []),
            matched_rules=result.get("matched_rules", []),
            metadata={"loan_asset_id": loan_asset.id}
        )
    
    def evaluate_terms_change(
        self,
        trade_id: str,
        current_rate: float,
        proposed_rate: float,
        reason: str
    ) -> PolicyDecision:
        """
        Evaluate interest rate change for compliance.
        
        Args:
            trade_id: Trade identifier
            current_rate: Current interest rate
            proposed_rate: Proposed new rate
            reason: Reason for change
            
        Returns:
            PolicyDecision
        """
        tx = {
            "transaction_id": f"terms_change_{trade_id}",
            "transaction_type": "terms_change",
            "timestamp": datetime.utcnow().isoformat(),
            "current_rate": current_rate,
            "proposed_rate": proposed_rate,
            "rate_delta": proposed_rate - current_rate,
            "reason": reason,
            "context": "InterestRateAdjustment"
        }
        
        result = self.engine.evaluate(tx)
        
        return PolicyDecision(
            decision=result["decision"],
            rule_applied=result.get("rule"),
            trace_id=f"terms_{trade_id}_{datetime.utcnow().isoformat()}",
            trace=result.get("trace", []),
            matched_rules=result.get("matched_rules", []),
            metadata={"trade_id": trade_id}
        )
    
    # Private helper methods for CDM mapping
    def _cdm_to_policy_transaction(
        self,
        credit_agreement: CreditAgreement,
        transaction_type: str
    ) -> Dict[str, Any]:
        """Convert CDM CreditAgreement to policy transaction format."""
        borrower = next(
            (p for p in (credit_agreement.parties or []) if "borrower" in p.role.lower()),
            None
        )
        
        total_commitment = sum(
            float(f.commitment_amount.amount)
            for f in (credit_agreement.facilities or [])
        ) if credit_agreement.facilities else 0
        
        currency = (
            credit_agreement.facilities[0].commitment_amount.currency.value
            if credit_agreement.facilities
            else "USD"
        )
        
        return {
            "transaction_id": credit_agreement.deal_id or credit_agreement.loan_identification_number or "unknown",
            "transaction_type": transaction_type,
            "timestamp": datetime.utcnow().isoformat(),
            "originator": {
                "id": borrower.id if borrower else "unknown",
                "name": borrower.name if borrower else "unknown",
                "role": borrower.role if borrower else "Borrower",
                "lei": borrower.lei,
                "kyc_status": True,  # Assume KYC'd if in CDM
                "jurisdiction": credit_agreement.governing_law or "Unknown"
            },
            "amount": total_commitment,
            "currency": currency,
            "facility_name": credit_agreement.facilities[0].facility_name if credit_agreement.facilities else None,
            "facility_type": "SyndicatedLoan",
            "sustainability_linked": credit_agreement.sustainability_linked,
            "esg_kpi_targets": [
                {
                    "kpi_type": kpi.kpi_type.value,
                    "target_value": kpi.target_value,
                    "unit": kpi.unit
                }
                for kpi in (credit_agreement.esg_kpi_targets or [])
            ],
            "governing_law": credit_agreement.governing_law or "Unknown",
            "regulatory_framework": self._infer_regulatory_framework(credit_agreement),
            "context": "CreditAgreement_Creation"
        }
    
    def _cdm_trade_event_to_policy_transaction(
        self,
        cdm_event: CDMEventDict,
        credit_agreement: Optional[CreditAgreement] = None
    ) -> Dict[str, Any]:
        """Convert CDM TradeExecution event to policy transaction."""
        trade = cdm_event["trade"]
        counterparties = trade["tradableProduct"]["counterparty"]
        
        return {
            "transaction_id": trade["tradeIdentifier"]["assignedIdentifier"][0]["identifier"]["value"],
            "transaction_type": "trade_execution",
            "timestamp": cdm_event["eventDate"],
            "originator": {
                "id": counterparties[0]["partyReference"]["globalReference"],
                "kyc_status": True,  # Assume KYC'd for CDM events
                "jurisdiction": "Unknown"
            },
            "beneficiary": {
                "id": counterparties[1]["partyReference"]["globalReference"] if len(counterparties) > 1 else None,
                "kyc_status": True
            },
            "amount": float(trade["tradableProduct"]["economicTerms"]["notional"]["amount"]["value"]),
            "currency": trade["tradableProduct"]["economicTerms"]["notional"]["currency"]["value"],
            "interest_rate": self._extract_rate_from_cdm(cdm_event),
            "context": "TradeExecution"
        }
    
    def _loan_asset_to_policy_transaction(
        self,
        loan_asset: LoanAsset,
        credit_agreement: Optional[CreditAgreement] = None
    ) -> Dict[str, Any]:
        """Convert LoanAsset to policy transaction."""
        return {
            "transaction_id": loan_asset.loan_id,
            "transaction_type": "loan_asset_securitization",
            "timestamp": loan_asset.created_at.isoformat() if loan_asset.created_at else datetime.utcnow().isoformat(),
            "amount": 0,  # Not applicable for asset verification
            "currency": "USD",  # Default
            "spt_threshold": loan_asset.spt_threshold,
            "ndvi_score": loan_asset.last_verified_score,
            "risk_status": loan_asset.risk_status,
            "collateral_address": loan_asset.collateral_address,
            "geo_lat": loan_asset.geo_lat,
            "geo_lon": loan_asset.geo_lon,
            "context": "LoanAsset_Securitization"
        }
    
    def _infer_regulatory_framework(self, credit_agreement: CreditAgreement) -> List[str]:
        """Infer applicable regulatory frameworks from credit agreement."""
        frameworks = []
        
        if credit_agreement.sustainability_linked:
            frameworks.append("ESG_Compliance")
        
        # Add based on jurisdiction
        if credit_agreement.governing_law in ["NY", "Delaware", "California"]:
            frameworks.append("US_Regulations")
        
        if any("EUR" in str(f.commitment_amount.currency) for f in (credit_agreement.facilities or [])):
            frameworks.append("MiCA")
        
        return frameworks
```

### 4.2 Policy Engine Interface (Vendor Agnostic)

**File**: `app/services/policy_engine_interface.py`

```python
from abc import ABC, abstractmethod
from typing import Dict, Any, List

class PolicyEngineInterface(ABC):
    """
    Abstract interface for policy engine implementations.
    
    This allows Credit Nexus to work with any policy engine vendor
    that implements this interface.
    """
    
    @abstractmethod
    def evaluate(self, transaction: Dict[str, Any]) -> Dict[str, Any]:
        """
        Evaluate a transaction against policy rules.
        
        Args:
            transaction: Policy transaction dictionary
            
        Returns:
            {
                "decision": "ALLOW" | "BLOCK" | "FLAG",
                "rule": Optional[str],  # Name of rule that triggered decision
                "matched_rules": List[str],  # All matching rules
                "trace": List[Dict[str, Any]]  # Evaluation trace
            }
        """
        pass
    
    @abstractmethod
    def load_rules(self, rules_yaml: str) -> None:
        """
        Load policy rules from YAML string.
        
        Args:
            rules_yaml: YAML-formatted policy rules
        """
        pass
    
    @abstractmethod
    def get_stats(self) -> Dict[str, Any]:
        """
        Get engine statistics.
        
        Returns:
            {
                "total_processed": int,
                "decisions": {
                    "ALLOW": int,
                    "BLOCK": int,
                    "FLAG": int
                }
            }
        """
        pass
```

---

## 5. Policy Rules for Syndicated Loans

### 5.1 Regulatory Compliance Rules

**File**: `app/policies/syndicated_loan_rules.yaml`

```yaml
# ==========================================
# REGULATORY COMPLIANCE RULES
# ==========================================

# Block facilities with sanctioned parties
- name: block_sanctioned_parties
  when:
    any:
      - field: originator.lei
        op: in
        value: ["SANCTIONED_LEI_LIST"]  # External data source
      - field: beneficiary.lei
        op: in
        value: ["SANCTIONED_LEI_LIST"]
  action: block
  priority: 100
  description: "Block any transaction involving sanctioned entities"

# Flag high-risk jurisdictions
- name: flag_high_risk_jurisdiction
  when:
    any:
      - field: originator.jurisdiction
        op: in
        value: ["HighRiskCountryList"]  # FATF blacklist, etc.
      - field: beneficiary.jurisdiction
        op: in
        value: ["HighRiskCountryList"]
  action: flag
  priority: 50
  description: "Flag transactions involving high-risk jurisdictions"

# Block invalid ESG claims
- name: block_invalid_esg_claims
  when:
    all:
      - field: sustainability_linked
        op: eq
        value: true
      - field: esg_kpi_targets
        op: eq
        value: []  # Empty list
  action: block
  priority: 80
  description: "Block sustainability-linked loans without KPI targets"

# Flag excessive commitment amounts
- name: flag_excessive_commitment
  when:
    all:
      - field: transaction_type
        op: eq
        value: "facility_creation"
      - field: amount
        op: gt
        value: 1000000000  # $1B threshold
  action: flag
  priority: 30
  description: "Flag facilities exceeding $1B commitment"

# ==========================================
# TRADE EXECUTION RULES
# ==========================================

# Block unhosted wallet transfers
- name: block_unhosted_wallets
  when:
    all:
      - field: transaction_type
        op: eq
        value: "trade_execution"
      - field: originator.kyc_status
        op: eq
        value: false
  action: block
  priority: 90
  description: "Block trades from unhosted (non-KYC) wallets"

# Flag high-value transfers
- name: flag_high_value_transfer
  when:
    all:
      - field: transaction_type
        op: eq
        value: "trade_execution"
      - field: amount
        op: gt
        value: 100000
      - field: currency
        op: eq
        value: "EUR"
  action: flag
  priority: 40
  description: "Flag high-value EUR transfers for review"

# Block virtual asset transfers without proper context
- name: block_virtual_asset_transfer
  when:
    all:
      - field: transaction_type
        op: eq
        value: "trade_execution"
      - field: context
        op: eq
        value: "Virtual_Asset_Transfer"
      - field: originator.kyc_status
        op: eq
        value: false
  action: block
  priority: 85
  description: "Block virtual asset transfers from non-KYC entities"

# ==========================================
# LOAN ASSET SECURITIZATION RULES
# ==========================================

# Block securitization of non-compliant assets
- name: block_breach_securitization
  when:
    all:
      - field: transaction_type
        op: eq
        value: "loan_asset_securitization"
      - field: risk_status
        op: eq
        value: "BREACH"
  action: block
  priority: 95
  description: "Block securitization of assets in breach status"

# Flag assets in restricted geographic areas
- name: flag_geographic_restriction
  when:
    all:
      - field: transaction_type
        op: eq
        value: "loan_asset_securitization"
      - field: geo_lat
        op: ne
        value: null
      - field: geo_lon
        op: ne
        value: null
      # Check if coordinates fall in restricted zone
      # (Would need custom operator or external service)
  action: flag
  priority: 35
  description: "Flag assets in geographically restricted areas"

# Block assets without verification
- name: block_missing_collateral_verification
  when:
    all:
      - field: transaction_type
        op: eq
        value: "loan_asset_securitization"
      - field: ndvi_score
        op: eq
        value: null
  action: block
  priority: 75
  description: "Block securitization without satellite verification"

# ==========================================
# TERMS CHANGE RULES
# ==========================================

# Block excessive rate increases
- name: block_excessive_rate_increase
  when:
    all:
      - field: transaction_type
        op: eq
        value: "terms_change"
      - field: rate_delta
        op: gt
        value: 2.0  # 200 bps max increase
  action: block
  priority: 70
  description: "Block interest rate increases exceeding 200 bps"

# Flag rapid rate changes
- name: flag_rapid_rate_changes
  when:
    all:
      - field: transaction_type
        op: eq
        value: "terms_change"
      - field: rate_delta
        op: gt
        value: 0.5  # 50 bps threshold
  action: flag
  priority: 25
  description: "Flag significant rate changes for review"

# ==========================================
# DEFAULT RULE
# ==========================================

# Default allow (lowest priority)
- name: default_allow
  when: {}
  action: allow
  priority: 0
  description: "Default allow for all transactions not caught by other rules"
```

---

## 6. Implementation Plan - Detailed Breakdown

### PROJECT 1: Core Infrastructure & Service Layer (Week 1-2)

#### Activity 1.1: Create Policy Engine Interface

**File**: `app/services/__init__.py`
- **Task**: Ensure services directory exists and is importable
- **Subtasks**:
  - Verify `app/services/` directory exists
  - Add `__init__.py` if missing (empty file is fine)

**File**: `app/services/policy_engine_interface.py` (NEW FILE)
- **Task**: Create abstract interface for vendor-agnostic policy engine
- **Subtasks**:
  - Line 1-10: Import statements (`abc`, `ABC`, `abstractmethod`, `Dict`, `Any`, `List`)
  - Line 12-20: Class docstring explaining interface purpose
  - Line 22-40: `evaluate()` abstract method with full docstring
  - Line 42-50: `load_rules()` abstract method with YAML parameter
  - Line 52-60: `get_stats()` abstract method returning statistics dict
  - Line 62-65: Add type hints and return type annotations

**File**: `app/services/policy_engine_interface.py`
- **Task**: Add concrete implementation example (optional, for testing)
- **Subtasks**:
  - Line 67-100: Create `MockPolicyEngine` class implementing interface
  - Line 102-120: Implement `evaluate()` with mock logic
  - Line 122-130: Implement `load_rules()` with YAML parsing
  - Line 132-140: Implement `get_stats()` with counter tracking

#### Activity 1.2: Create Policy Service Layer

**File**: `app/services/policy_service.py` (NEW FILE)
- **Task**: Create main service layer with CDM adapters
- **Subtasks**:
  - Line 1-15: Import statements (CDM models, LoanAsset, datetime, Dict, List, Optional)
  - Line 17-25: Create `PolicyDecision` dataclass with all fields
  - Line 27-35: `PolicyService` class initialization with `__init__()`
  - Line 37-80: `evaluate_facility_creation()` method
    - Line 39-45: Method signature with type hints
    - Line 47-50: Call `_cdm_to_policy_transaction()` adapter
    - Line 52-55: Call `self.engine.evaluate(tx)`
    - Line 57-70: Construct and return `PolicyDecision` object
  - Line 82-120: `evaluate_trade_execution()` method
    - Line 84-90: Method signature
    - Line 92-95: Call `_cdm_trade_event_to_policy_transaction()` adapter
    - Line 97-100: Evaluate and return decision
  - Line 122-160: `evaluate_loan_asset()` method
    - Line 124-130: Method signature
    - Line 132-135: Call `_loan_asset_to_policy_transaction()` adapter
    - Line 137-140: Evaluate and return decision
  - Line 162-200: `evaluate_terms_change()` method
    - Line 164-170: Method signature
    - Line 172-180: Build transaction dict with rate delta
    - Line 182-185: Evaluate and return decision
  - Line 202-280: `_cdm_to_policy_transaction()` private method
    - Line 204-210: Extract borrower from parties list
    - Line 212-220: Calculate total commitment from facilities
    - Line 222-230: Extract currency from first facility
    - Line 232-270: Build complete transaction dict with all CDM fields
  - Line 282-330: `_cdm_trade_event_to_policy_transaction()` private method
    - Line 284-290: Extract trade identifier
    - Line 292-300: Extract counterparties
    - Line 302-320: Build transaction dict from CDM event
  - Line 332-370: `_loan_asset_to_policy_transaction()` private method
    - Line 334-350: Map LoanAsset fields to transaction dict
  - Line 372-400: `_infer_regulatory_framework()` private method
    - Line 374-380: Check sustainability_linked flag
    - Line 382-390: Check jurisdiction for US regulations
    - Line 392-400: Check currency for MiCA compliance
  - Line 402-420: `_extract_rate_from_cdm()` helper method (if needed)

#### Activity 1.3: Create Policy Rules Configuration

**File**: `app/policies/__init__.py` (NEW FILE)
- **Task**: Create policies directory structure
- **Subtasks**:
  - Line 1: Empty `__init__.py` file

**File**: `app/policies/syndicated_loan_rules.yaml` (NEW FILE)
- **Task**: Define all policy rules in YAML format
- **Subtasks**:
  - Line 1-20: Header comments explaining rule structure
  - Line 22-50: `block_sanctioned_parties` rule (priority 100)
  - Line 52-70: `flag_high_risk_jurisdiction` rule (priority 50)
  - Line 72-90: `block_invalid_esg_claims` rule (priority 80)
  - Line 92-110: `flag_excessive_commitment` rule (priority 30)
  - Line 112-130: `block_unhosted_wallets` rule (priority 90)
  - Line 132-150: `flag_high_value_transfer` rule (priority 40)
  - Line 152-170: `block_virtual_asset_transfer` rule (priority 85)
  - Line 172-190: `block_breach_securitization` rule (priority 95)
  - Line 192-210: `flag_geographic_restriction` rule (priority 35)
  - Line 212-230: `block_missing_collateral_verification` rule (priority 75)
  - Line 232-250: `block_excessive_rate_increase` rule (priority 70)
  - Line 252-270: `flag_rapid_rate_changes` rule (priority 25)
  - Line 272-280: `default_allow` rule (priority 0)

**File**: `app/core/config.py`
- **Task**: Add policy engine configuration settings
- **Subtasks**:
  - Line 32-35: Add `POLICY_RULES_PATH: str = "app/policies/syndicated_loan_rules.yaml"`
  - Line 36-40: Add `POLICY_ENGINE_VENDOR: Optional[str] = None` (for vendor selection)
  - Line 41-45: Add `POLICY_ENABLED: bool = True` (feature flag)

#### Activity 1.4: Policy Engine Vendor Integration

**File**: `app/services/policy_engine_factory.py` (NEW FILE)
- **Task**: Factory pattern for creating policy engine instances
- **Subtasks**:
  - Line 1-10: Import statements
  - Line 12-30: `create_policy_engine()` factory function
    - Line 14-20: Read vendor from config
    - Line 22-30: Instantiate appropriate engine implementation
  - Line 32-50: `load_policy_rules()` helper function
    - Line 34-40: Read YAML file from path
    - Line 42-50: Parse and validate YAML structure

**File**: `server.py`
- **Task**: Initialize policy service on application startup
- **Subtasks**:
  - Line 22-33: In `lifespan()` function, after database init
    - Line 25-28: Import policy service factory
    - Line 30-33: Create global policy service instance
  - Line 35-40: Store in `app.state.policy_service` for dependency injection

### PROJECT 2: Database Schema & Models (Week 2)

#### Activity 2.1: Create Policy Decision Database Model

**File**: `app/db/models.py`
- **Task**: Add PolicyDecision SQLAlchemy model
- **Subtasks**:
  - Line 400-450: Add `PolicyDecision` class after existing models
    - Line 402-405: Class definition with `__tablename__ = "policy_decisions"`
    - Line 407-410: `id` primary key column
    - Line 412-415: `transaction_id` VARCHAR(255) NOT NULL
    - Line 417-420: `transaction_type` VARCHAR(50) NOT NULL
    - Line 422-425: `decision` VARCHAR(10) NOT NULL (ALLOW/BLOCK/FLAG)
    - Line 427-430: `rule_applied` VARCHAR(255) nullable
    - Line 432-435: `trace_id` VARCHAR(255) UNIQUE
    - Line 437-440: `trace` JSONB column
    - Line 442-445: `matched_rules` TEXT[] array column
    - Line 447-450: `metadata` JSONB column
    - Line 452-455: `created_at` TIMESTAMP with default
    - Line 457-460: `document_id` ForeignKey to documents
    - Line 462-465: `loan_asset_id` ForeignKey to loan_assets
    - Line 467-470: `user_id` ForeignKey to users
    - Line 472-500: `to_dict()` method for API serialization

#### Activity 2.2: Create Database Migration

**File**: `alembic/versions/XXXXX_add_policy_decisions_table.py` (NEW FILE)
- **Task**: Alembic migration for policy_decisions table
- **Subtasks**:
  - Line 1-10: Standard Alembic imports
  - Line 12-15: Revision identifiers
  - Line 17-40: `upgrade()` function
    - Line 19-35: Create `policy_decisions` table with all columns
    - Line 37-40: Create indexes on `transaction_id`, `decision`, `created_at`
  - Line 42-50: `downgrade()` function
    - Line 44-48: Drop indexes
    - Line 50: Drop table

**File**: `alembic.ini`
- **Task**: Verify Alembic configuration (no changes needed, just verify)

### PROJECT 3: Integration Points - Document Extraction (Week 3)

#### Activity 3.1: Integrate Policy Evaluation in Extract Endpoint

**File**: `app/api/routes.py`
- **Task**: Add policy evaluation after CDM extraction
- **Subtasks**:
  - Line 1-30: Add import statements at top
    - Line 15: Add `from app.services.policy_service import PolicyService`
    - Line 16: Add `from app.db.models import PolicyDecision as PolicyDecisionModel`
  - Line 236-272: In `@router.post("/extract")` endpoint
    - Line 250-255: After `result = extract_data_smart(...)` and before return
      - Line 252: Check if `result.agreement` exists
      - Line 254: Get policy service from app state or dependency
      - Line 256-260: Call `policy_service.evaluate_facility_creation()`
      - Line 262-270: Handle BLOCK decision
        - Line 264-268: Raise HTTPException with 403 status
        - Line 270: Include policy_result in error detail
      - Line 272-278: Handle FLAG decision
        - Line 274: Set workflow priority to "high" if workflow exists
        - Line 276: Add policy decision to response metadata
      - Line 280-285: Log policy decision to audit trail
        - Line 282: Create PolicyDecisionModel record
        - Line 284: Save to database if session available
  - Line 267-272: Modify return statement
    - Line 269: Add `policy_decision` field to response dict
    - Line 271: Include decision, rule_applied, trace_id

**File**: `app/api/routes.py`
- **Task**: Add dependency injection for policy service
- **Subtasks**:
  - Line 30-50: Add dependency function
    - Line 32-40: `get_policy_service()` function
      - Line 34: Get from `app.state.policy_service`
      - Line 36: Return PolicyService instance
      - Line 38: Handle case where service not initialized

**File**: `app/api/routes.py`
- **Task**: Update `/extract` endpoint signature
- **Subtasks**:
  - Line 122: Add `policy_service: PolicyService = Depends(get_policy_service)` parameter

#### Activity 3.2: Update Workflow State Based on Policy

**File**: `app/api/routes.py`
- **Task**: Modify workflow creation/update logic
- **Subtasks**:
  - Line 300-350: In workflow creation endpoint (if exists)
    - Line 310-320: Check if policy decision exists in request metadata
    - Line 322-330: Set workflow.priority based on policy decision
    - Line 332-340: Set workflow.state to REQUIRES_REVIEW if FLAG

### PROJECT 4: Integration Points - Trade Execution (Week 3-4)

#### Activity 4.1: Create Trade Execution Endpoint

**File**: `app/api/routes.py`
- **Task**: Create new endpoint for trade execution with policy evaluation
- **Subtasks**:
  - Line 2800-2900: Add new endpoint (after existing endpoints)
    - Line 2802-2810: `class TradeExecutionRequest(BaseModel)` Pydantic model
      - Line 2804: `trade_id: str`
      - Line 2806: `borrower: str`
      - Line 2808: `amount: float`
      - Line 2810: `rate: float`
      - Line 2812: `credit_agreement_id: Optional[int]`
    - Line 2814-2850: `@router.post("/trades/execute")` endpoint
      - Line 2816-2820: Function signature with dependencies
      - Line 2822-2830: Generate CDM TradeExecution event
        - Line 2824: Import `generate_cdm_trade_execution`
        - Line 2826-2830: Call function with trade parameters
      - Line 2832-2840: Policy evaluation
        - Line 2834: Get credit agreement from database if ID provided
        - Line 2836-2840: Call `policy_service.evaluate_trade_execution()`
      - Line 2842-2855: Handle BLOCK decision
        - Line 2844-2850: Return error response with policy details
        - Line 2852: Log to audit trail
        - Line 2854: Do not proceed with trade
      - Line 2857-2870: Handle FLAG decision
        - Line 2859-2865: Continue with trade but mark for review
        - Line 2867: Add policy metadata to trade record
      - Line 2872-2885: Handle ALLOW decision
        - Line 2874-2880: Proceed with normal trade execution
        - Line 2882: Log policy decision
      - Line 2887-2900: Return trade execution result

#### Activity 4.2: Update Trade Blotter Frontend

**File**: `client/src/apps/trade-blotter/TradeBlotter.tsx`
- **Task**: Add policy status display and blocking logic
- **Subtasks**:
  - Line 67-90: In `handleConfirmTrade()` function
    - Line 69-75: Add API call to `/api/trades/execute` endpoint
    - Line 77-85: Check response for `decision: "BLOCK"`
      - Line 79-83: Show error message with policy reason
      - Line 85: Prevent trade confirmation
    - Line 87-95: Check response for `decision: "FLAG"`
      - Line 89-93: Show warning banner
      - Line 95: Allow trade but mark for review
  - Line 200-250: Add policy status UI component
    - Line 202-210: Policy decision badge component
    - Line 212-220: Policy trace display (collapsible)
    - Line 222-230: Rule applied information

**File**: `client/src/apps/trade-blotter/TradeBlotter.tsx`
- **Task**: Add policy decision state management
- **Subtasks**:
  - Line 20-30: Add to `TradeBlotterState` interface
    - Line 22: `policyDecision?: { decision: string, rule: string, trace: any[] }`
  - Line 40-50: Initialize policy decision state
  - Line 100-120: Update state after policy evaluation

### PROJECT 5: Integration Points - Loan Asset Verification (Week 4)

#### Activity 5.1: Integrate Policy in Audit Workflow

**File**: `app/agents/audit_workflow.py`
- **Task**: Add policy evaluation after satellite verification
- **Subtasks**:
  - Line 1-20: Add import statements
    - Line 15: `from app.services.policy_service import PolicyService`
    - Line 16: `from app.models.cdm import CreditAgreement`
  - Line 155-190: After `loan_asset.update_verification(ndvi_score)` (line 157)
    - Line 159-165: Policy evaluation
      - Line 161: Get policy service (from app state or parameter)
      - Line 163: Get credit agreement from database if available
      - Line 165: Call `policy_service.evaluate_loan_asset()`
    - Line 167-175: Handle BLOCK decision
      - Line 169: Set `loan_asset.risk_status = RiskStatus.ERROR`
      - Line 171: Set `loan_asset.verification_error` with policy reason
      - Line 173: Add to `result.stages_failed`
    - Line 177-185: Handle FLAG decision
      - Line 179: Set `loan_asset.risk_status = RiskStatus.WARNING`
      - Line 181: Add policy metadata to loan asset
      - Line 183: Continue with workflow
    - Line 187-190: Log policy decision to database

**File**: `app/agents/audit_workflow.py`
- **Task**: Update function signature to accept policy service
- **Subtasks**:
  - Line 40-44: Modify `run_full_audit()` signature
    - Line 42: Add `policy_service: Optional[PolicyService] = None` parameter

**File**: `app/api/routes.py`
- **Task**: Pass policy service to audit workflow
- **Subtasks**:
  - Line 2331-2335: In `create_loan_asset()` endpoint
    - Line 2333: Get policy service from dependency
    - Line 2335: Pass to `run_full_audit()` call

### PROJECT 6: Integration Points - Terms Change (Week 5)

#### Activity 6.1: Integrate Policy in Terms Change Logic

**File**: `app/models/cdm_events.py`
- **Task**: Add policy evaluation before rate change
- **Subtasks**:
  - Line 1-10: Add import statements
    - Line 8: `from app.services.policy_service import PolicyService`
  - Line 92-136: In `generate_cdm_terms_change()` function
    - Line 100-110: Before calculating `new_spread`
      - Line 102: Get policy service instance
      - Line 104-108: Call `policy_service.evaluate_terms_change()`
      - Line 110-115: Handle BLOCK decision
        - Line 112: Log warning
        - Line 114: Return current rate unchanged (prevent change)
    - Line 117-125: Continue with rate change if ALLOW or FLAG
      - Line 119: Calculate new spread
      - Line 121: Generate CDM event
      - Line 123: Log policy decision if FLAG

**File**: `app/api/routes.py`
- **Task**: Create endpoint for terms change with policy
- **Subtasks**:
  - Line 2900-3000: Add `@router.post("/trades/{trade_id}/terms-change")` endpoint
    - Line 2902-2910: Request model with current_rate, proposed_rate, reason
    - Line 2912-2950: Endpoint implementation
      - Line 2914-2920: Get trade from database
      - Line 2922-2930: Policy evaluation
      - Line 2932-2945: Handle BLOCK (prevent change)
      - Line 2947-2950: Handle ALLOW/FLAG (proceed with change)

### PROJECT 7: Audit Trail & Logging (Week 5)

#### Activity 7.1: Create Policy Decision Logging Service

**File**: `app/services/policy_audit.py` (NEW FILE)
- **Task**: Centralized logging for policy decisions
- **Subtasks**:
  - Line 1-15: Import statements
  - Line 17-30: `log_policy_decision()` function
    - Line 19-25: Create PolicyDecisionModel instance
    - Line 27-30: Save to database
  - Line 32-50: `get_policy_decisions()` query function
  - Line 52-70: `get_policy_statistics()` aggregation function

**File**: `app/api/routes.py`
- **Task**: Add audit logging after each policy evaluation
- **Subtasks**:
  - Line 280-285: After policy evaluation in `/extract`
    - Line 282: Call `log_policy_decision()` with decision and document_id
  - Line 2852: After policy evaluation in `/trades/execute`
  - Line 187-190: After policy evaluation in `run_full_audit()`

#### Activity 7.2: Create Policy Statistics Endpoint

**File**: `app/api/routes.py`
- **Task**: Add endpoint for policy decision statistics
- **Subtasks**:
  - Line 3000-3050: `@router.get("/policy/statistics")` endpoint
    - Line 3002-3010: Query parameters (date_range, transaction_type)
    - Line 3012-3040: Aggregate policy decisions
      - Line 3014-3020: Count by decision type (ALLOW/BLOCK/FLAG)
      - Line 3022-3030: Count by rule_applied
      - Line 3032-3040: Time series data for charts
    - Line 3042-3050: Return JSON response with statistics

### PROJECT 8: UI Components & Monitoring (Week 6)

#### Activity 8.1: Policy Decision Display Components

**File**: `client/src/components/PolicyDecisionBadge.tsx` (NEW FILE)
- **Task**: React component for displaying policy decisions
- **Subtasks**:
  - Line 1-20: Imports and interface definitions
  - Line 22-50: Component implementation
    - Line 24-30: Color coding based on decision (BLOCK=red, FLAG=yellow, ALLOW=green)
    - Line 32-40: Display rule_applied name
    - Line 42-50: Collapsible trace display

**File**: `client/src/components/Dashboard.tsx`
- **Task**: Add policy statistics to dashboard
- **Subtasks**:
  - Line 500-550: Add policy statistics section
    - Line 502-510: API call to `/api/policy/statistics`
    - Line 512-530: Display charts for decision distribution
    - Line 532-550: Display top blocked rules

#### Activity 8.2: Policy Rule Management UI

**File**: `client/src/apps/policy-manager/PolicyManager.tsx` (NEW FILE)
- **Task**: Admin interface for managing policy rules
- **Subtasks**:
  - Line 1-50: Component structure and state
  - Line 52-100: YAML editor for rules
  - Line 102-150: Rule validation and preview
  - Line 152-200: Save/load rules functionality

**File**: `app/api/routes.py`
- **Task**: Add endpoints for rule management
- **Subtasks**:
  - Line 3050-3100: `@router.get("/policy/rules")` - Get current rules
  - Line 3102-3150: `@router.post("/policy/rules")` - Update rules (admin only)
  - Line 3152-3200: `@router.get("/policy/rules/validate")` - Validate rule YAML

### PROJECT 9: Testing & Validation (Week 6)

#### Activity 9.1: Unit Tests

**File**: `tests/test_policy_service.py` (NEW FILE)
- **Task**: Unit tests for policy service layer
- **Subtasks**:
  - Line 1-30: Test setup and fixtures
  - Line 32-60: Test `evaluate_facility_creation()` with various CDM inputs
  - Line 62-90: Test `evaluate_trade_execution()` with CDM events
  - Line 92-120: Test `evaluate_loan_asset()` with LoanAsset models
  - Line 122-150: Test `evaluate_terms_change()` with rate changes
  - Line 152-180: Test CDM-to-transaction adapter methods
  - Line 182-210: Test conflict resolution (BLOCK > FLAG > ALLOW)

**File**: `tests/test_policy_engine_interface.py` (NEW FILE)
- **Task**: Tests for policy engine interface
- **Subtasks**:
  - Line 1-30: Mock policy engine implementation
  - Line 32-60: Test rule loading from YAML
  - Line 62-90: Test evaluation with various transactions
  - Line 92-120: Test statistics tracking

#### Activity 9.2: Integration Tests

**File**: `tests/test_policy_integration.py` (NEW FILE)
- **Task**: End-to-end integration tests
- **Subtasks**:
  - Line 1-50: Test document extraction with policy evaluation
  - Line 52-100: Test trade execution blocking
  - Line 102-150: Test loan asset securitization blocking
  - Line 152-200: Test terms change prevention
  - Line 202-250: Test audit trail persistence

#### Activity 9.3: Performance Tests

**File**: `tests/test_policy_performance.py` (NEW FILE)
- **Task**: Performance benchmarks
- **Subtasks**:
  - Line 1-30: Test evaluation latency (<100ms requirement)
  - Line 32-60: Test throughput (transactions per second)
  - Line 62-90: Test with large rule sets (100+ rules)

### PROJECT 10: Documentation & Deployment (Week 6)

#### Activity 10.1: API Documentation

**File**: `docs/API_POLICY_ENGINE.md` (NEW FILE)
- **Task**: API documentation for policy endpoints
- **Subtasks**:
  - Line 1-50: Overview and authentication
  - Line 52-100: Endpoint documentation with examples
  - Line 102-150: Policy rule YAML schema
  - Line 152-200: Error codes and handling

#### Activity 10.2: Deployment Configuration

**File**: `docker-compose.yml` (if exists, or create)
- **Task**: Add policy engine service configuration
- **Subtasks**:
  - Line 1-50: Environment variables for policy engine
  - Line 52-100: Volume mounts for policy rules YAML

**File**: `.env.example`
- **Task**: Add policy engine environment variables
- **Subtasks**:
  - Line 1-5: `POLICY_ENABLED=true`
  - Line 2-5: `POLICY_RULES_PATH=app/policies/syndicated_loan_rules.yaml`
  - Line 3-5: `POLICY_ENGINE_VENDOR=` (optional)

---

## 7. Task Dependencies & Critical Path

### Critical Path (Must Complete in Order):
1. **PROJECT 1** → **PROJECT 2** → **PROJECT 3** → **PROJECT 4** → **PROJECT 5** → **PROJECT 6**
2. **PROJECT 7** can run in parallel with **PROJECT 3-6**
3. **PROJECT 8** depends on **PROJECT 3-6** completion
4. **PROJECT 9** depends on **PROJECT 1-6** completion
5. **PROJECT 10** can run in parallel with all projects

### Blocking Dependencies:
- Policy Service Layer (PROJECT 1) blocks all integration points
- Database Schema (PROJECT 2) blocks audit logging
- Each integration point (PROJECT 3-6) is independent after PROJECT 1-2

---

## 8. Estimated Effort by Project

| Project | Activities | Estimated Hours | Priority |
|---------|-----------|----------------|----------|
| PROJECT 1: Core Infrastructure | 4 | 40 hours | P0 (Critical) |
| PROJECT 2: Database Schema | 2 | 8 hours | P0 (Critical) |
| PROJECT 3: Document Extraction | 2 | 16 hours | P1 (High) |
| PROJECT 4: Trade Execution | 2 | 20 hours | P1 (High) |
| PROJECT 5: Loan Asset | 1 | 12 hours | P1 (High) |
| PROJECT 6: Terms Change | 1 | 8 hours | P2 (Medium) |
| PROJECT 7: Audit Trail | 2 | 12 hours | P1 (High) |
| PROJECT 8: UI Components | 2 | 24 hours | P2 (Medium) |
| PROJECT 9: Testing | 3 | 32 hours | P1 (High) |
| PROJECT 10: Documentation | 2 | 8 hours | P2 (Medium) |
| **TOTAL** | **21** | **180 hours** | |

---

## 9. Risk Mitigation

### High-Risk Items:
1. **Policy Engine Vendor Selection** (PROJECT 1)
   - **Mitigation**: Create mock implementation first, swap vendor later
   
2. **Performance Requirements** (<100ms)
   - **Mitigation**: Benchmark early, optimize rule evaluation logic
   
3. **CDM Mapping Complexity** (PROJECT 1)
   - **Mitigation**: Start with simple mappings, iterate based on testing

### Medium-Risk Items:
1. **Rule YAML Schema Changes**
   - **Mitigation**: Version rules, maintain backward compatibility
   
2. **Database Migration Issues**
   - **Mitigation**: Test migrations on staging environment first

---

## 7. Database Schema Extensions

### 7.1 Policy Decision Audit Table

```sql
CREATE TABLE policy_decisions (
    id SERIAL PRIMARY KEY,
    transaction_id VARCHAR(255) NOT NULL,
    transaction_type VARCHAR(50) NOT NULL,
    decision VARCHAR(10) NOT NULL,  -- 'ALLOW', 'BLOCK', 'FLAG'
    rule_applied VARCHAR(255),
    trace_id VARCHAR(255) UNIQUE,
    trace JSONB,
    matched_rules TEXT[],
    metadata JSONB,
    created_at TIMESTAMP DEFAULT NOW(),
    
    -- Foreign keys to Credit Nexus entities
    document_id INTEGER REFERENCES documents(id),
    loan_asset_id INTEGER REFERENCES loan_assets(id),
    user_id INTEGER REFERENCES users(id)
);

CREATE INDEX idx_policy_decisions_transaction ON policy_decisions(transaction_id);
CREATE INDEX idx_policy_decisions_decision ON policy_decisions(decision);
CREATE INDEX idx_policy_decisions_created_at ON policy_decisions(created_at);
```

---

## 8. Testing Strategy

### 8.1 Unit Tests

- CDM-to-transaction adapter mapping
- Policy service methods
- Rule evaluation logic
- Conflict resolution

### 8.2 Integration Tests

- End-to-end policy evaluation in workflows
- Database audit trail persistence
- API endpoint integration

### 8.3 Compliance Tests

- Regulatory rule validation
- Sanctions list matching
- Jurisdiction restrictions
- ESG compliance checks

---

## 9. Security & Compliance Considerations

1. **Audit Trail**: All policy decisions must be cryptographically signed and immutable
2. **Rule Versioning**: Policy rules must be versioned and tracked
3. **Access Control**: Only authorized users can modify policy rules
4. **Data Privacy**: Policy evaluation must not expose sensitive party data
5. **Performance**: Policy evaluation must complete in <100ms for real-time enforcement

---

## 10. Future Enhancements

1. **Machine Learning Integration**: Use ML to suggest policy rule improvements
2. **Network Analysis**: Integrate network centrality for risk scoring
3. **Real-Time Rule Updates**: Hot-reload policy rules without service restart
4. **Multi-Jurisdiction Support**: Handle conflicting regulations across jurisdictions
5. **Policy Simulation**: Test policy changes against historical transactions

---

## Appendix A: CDM Field Mapping Reference

| CDM Field | Policy Transaction Field | Notes |
|-----------|------------------------|-------|
| `CreditAgreement.deal_id` | `transaction_id` | Primary identifier |
| `Party.id` | `originator.id` | Borrower party |
| `Party.lei` | `originator.lei` | Legal Entity Identifier |
| `Party.role` | `originator.role` | "Borrower", "Lender", etc. |
| `LoanFacility.commitment_amount.amount` | `amount` | Total commitment |
| `LoanFacility.commitment_amount.currency` | `currency` | Currency enum |
| `CreditAgreement.sustainability_linked` | `sustainability_linked` | Boolean flag |
| `ESGKPITarget[]` | `esg_kpi_targets` | List of KPI targets |
| `CreditAgreement.governing_law` | `governing_law` | Jurisdiction |
| `LoanAsset.last_verified_score` | `ndvi_score` | Satellite verification |
| `LoanAsset.risk_status` | `risk_status` | Compliance status |

---

## Appendix B: Policy Decision Flow Diagram

```
Transaction/Event
    │
    ▼
CDM Adapter
    │
    ▼
Policy Transaction
    │
    ▼
Policy Engine
    │
    ├─▶ Rule 1: Evaluate
    ├─▶ Rule 2: Evaluate
    ├─▶ Rule N: Evaluate
    │
    ▼
Conflict Resolution
    │
    ├─▶ BLOCK (highest priority)
    ├─▶ FLAG (medium priority)
    └─▶ ALLOW (default)
    │
    ▼
Policy Decision
    │
    ├─▶ Audit Log
    ├─▶ Workflow Update
    └─▶ User Notification
```

---

**Document Version**: 1.0  
**Last Updated**: 2024-12-XX  
**Author**: Credit Nexus Architecture Team

