# Policy Engine Integration - Task Breakdown

## Visual Task Hierarchy

```
POLICY ENGINE INTEGRATION
│
├── PROJECT 1: Core Infrastructure (Week 1-2) [40h]
│   ├── Activity 1.1: Create Policy Engine Interface [8h]
│   │   ├── File: app/services/__init__.py
│   │   │   └── Task: Ensure services directory exists
│   │   ├── File: app/services/policy_engine_interface.py [NEW]
│   │   │   ├── Line 1-10: Import statements
│   │   │   ├── Line 12-20: Class docstring
│   │   │   ├── Line 22-40: evaluate() abstract method
│   │   │   ├── Line 42-50: load_rules() abstract method
│   │   │   ├── Line 52-60: get_stats() abstract method
│   │   │   └── Line 67-140: MockPolicyEngine implementation
│   │   └── File: app/services/policy_engine_factory.py [NEW]
│   │       ├── Line 1-10: Imports
│   │       ├── Line 12-30: create_policy_engine() factory
│   │       └── Line 32-50: load_policy_rules() helper
│   │
│   ├── Activity 1.2: Create Policy Service Layer [16h]
│   │   └── File: app/services/policy_service.py [NEW]
│   │       ├── Line 1-15: Imports (CDM models, datetime, etc.)
│   │       ├── Line 17-25: PolicyDecision dataclass
│   │       ├── Line 27-35: PolicyService.__init__()
│   │       ├── Line 37-80: evaluate_facility_creation()
│   │       ├── Line 82-120: evaluate_trade_execution()
│   │       ├── Line 122-160: evaluate_loan_asset()
│   │       ├── Line 162-200: evaluate_terms_change()
│   │       ├── Line 202-280: _cdm_to_policy_transaction()
│   │       ├── Line 282-330: _cdm_trade_event_to_policy_transaction()
│   │       ├── Line 332-370: _loan_asset_to_policy_transaction()
│   │       ├── Line 372-400: _infer_regulatory_framework()
│   │       └── Line 402-420: _extract_rate_from_cdm()
│   │
│   ├── Activity 1.3: Create Policy Rules Configuration [8h]
│   │   ├── File: app/policies/__init__.py [NEW]
│   │   └── File: app/policies/syndicated_loan_rules.yaml [NEW]
│   │       ├── Line 1-20: Header comments
│   │       ├── Line 22-50: block_sanctioned_parties rule
│   │       ├── Line 52-70: flag_high_risk_jurisdiction rule
│   │       ├── Line 72-90: block_invalid_esg_claims rule
│   │       ├── Line 92-110: flag_excessive_commitment rule
│   │       ├── Line 112-130: block_unhosted_wallets rule
│   │       ├── Line 132-150: flag_high_value_transfer rule
│   │       ├── Line 152-170: block_virtual_asset_transfer rule
│   │       ├── Line 172-190: block_breach_securitization rule
│   │       ├── Line 192-210: flag_geographic_restriction rule
│   │       ├── Line 212-230: block_missing_collateral_verification rule
│   │       ├── Line 232-250: block_excessive_rate_increase rule
│   │       ├── Line 252-270: flag_rapid_rate_changes rule
│   │       └── Line 272-280: default_allow rule
│   │
│   └── Activity 1.4: Policy Engine Vendor Integration [8h]
│       ├── File: app/core/config.py
│       │   ├── Line 32-35: POLICY_RULES_PATH setting
│       │   ├── Line 36-40: POLICY_ENGINE_VENDOR setting
│       │   └── Line 41-45: POLICY_ENABLED feature flag
│       └── File: server.py
│           ├── Line 25-28: Import policy service factory
│           └── Line 30-33: Initialize in lifespan()
│
├── PROJECT 2: Database Schema & Models (Week 2) [8h]
│   ├── Activity 2.1: Create Policy Decision Database Model [4h]
│   │   └── File: app/db/models.py
│   │       └── Line 400-500: PolicyDecision SQLAlchemy model
│   │           ├── Line 402-405: Class definition
│   │           ├── Line 407-470: Column definitions (id, transaction_id, etc.)
│   │           └── Line 472-500: to_dict() method
│   │
│   └── Activity 2.2: Create Database Migration [4h]
│       └── File: alembic/versions/XXXXX_add_policy_decisions_table.py [NEW]
│           ├── Line 1-10: Alembic imports
│           ├── Line 17-40: upgrade() function
│           └── Line 42-50: downgrade() function
│
├── PROJECT 3: Integration - Document Extraction (Week 3) [16h]
│   ├── Activity 3.1: Integrate Policy Evaluation in Extract Endpoint [12h]
│   │   └── File: app/api/routes.py
│   │       ├── Line 15-16: Add imports (PolicyService, PolicyDecisionModel)
│   │       ├── Line 30-50: get_policy_service() dependency
│   │       ├── Line 122: Add policy_service parameter to /extract
│   │       └── Line 250-285: Policy evaluation logic
│   │           ├── Line 252-260: Call evaluate_facility_creation()
│   │           ├── Line 262-270: Handle BLOCK decision
│   │           ├── Line 272-278: Handle FLAG decision
│   │           └── Line 280-285: Log to audit trail
│   │
│   └── Activity 3.2: Update Workflow State Based on Policy [4h]
│       └── File: app/api/routes.py
│           └── Line 300-350: Workflow priority/state updates
│
├── PROJECT 4: Integration - Trade Execution (Week 3-4) [20h]
│   ├── Activity 4.1: Create Trade Execution Endpoint [12h]
│   │   └── File: app/api/routes.py
│   │       ├── Line 2800-2810: TradeExecutionRequest model
│   │       └── Line 2814-2900: /trades/execute endpoint
│   │           ├── Line 2822-2830: Generate CDM event
│   │           ├── Line 2832-2840: Policy evaluation
│   │           ├── Line 2842-2855: Handle BLOCK
│   │           ├── Line 2857-2870: Handle FLAG
│   │           └── Line 2872-2900: Handle ALLOW
│   │
│   └── Activity 4.2: Update Trade Blotter Frontend [8h]
│       └── File: client/src/apps/trade-blotter/TradeBlotter.tsx
│           ├── Line 67-95: handleConfirmTrade() updates
│           ├── Line 200-250: Policy status UI component
│           └── Line 20-50: State management updates
│
├── PROJECT 5: Integration - Loan Asset Verification (Week 4) [12h]
│   └── Activity 5.1: Integrate Policy in Audit Workflow [12h]
│       ├── File: app/agents/audit_workflow.py
│       │   ├── Line 15-16: Add imports
│       │   ├── Line 40-44: Update function signature
│       │   └── Line 159-190: Policy evaluation after satellite verification
│       │       ├── Line 161-165: Call evaluate_loan_asset()
│       │       ├── Line 167-175: Handle BLOCK
│       │       └── Line 177-185: Handle FLAG
│       │
│       └── File: app/api/routes.py
│           └── Line 2333-2335: Pass policy service to run_full_audit()
│
├── PROJECT 6: Integration - Terms Change (Week 5) [8h]
│   └── Activity 6.1: Integrate Policy in Terms Change Logic [8h]
│       ├── File: app/models/cdm_events.py
│       │   ├── Line 8: Add PolicyService import
│       │   └── Line 100-125: Policy evaluation before rate change
│       │
│       └── File: app/api/routes.py
│           └── Line 2900-3000: /trades/{trade_id}/terms-change endpoint
│
├── PROJECT 7: Audit Trail & Logging (Week 5) [12h]
│   ├── Activity 7.1: Create Policy Decision Logging Service [8h]
│   │   └── File: app/services/policy_audit.py [NEW]
│   │       ├── Line 17-30: log_policy_decision() function
│   │       ├── Line 32-50: get_policy_decisions() query
│   │       └── Line 52-70: get_policy_statistics() aggregation
│   │
│   └── Activity 7.2: Create Policy Statistics Endpoint [4h]
│       └── File: app/api/routes.py
│           └── Line 3000-3050: /policy/statistics endpoint
│
├── PROJECT 8: UI Components & Monitoring (Week 6) [24h]
│   ├── Activity 8.1: Policy Decision Display Components [16h]
│   │   ├── File: client/src/components/PolicyDecisionBadge.tsx [NEW]
│   │   │   └── Line 1-50: Component implementation
│   │   │
│   │   └── File: client/src/components/Dashboard.tsx
│   │       └── Line 500-550: Policy statistics section
│   │
│   └── Activity 8.2: Policy Rule Management UI [8h]
│       ├── File: client/src/apps/policy-manager/PolicyManager.tsx [NEW]
│       │   └── Line 1-200: Admin interface
│       │
│       └── File: app/api/routes.py
│           ├── Line 3050-3100: GET /policy/rules
│           ├── Line 3102-3150: POST /policy/rules
│           └── Line 3152-3200: GET /policy/rules/validate
│
├── PROJECT 9: Testing & Validation (Week 6) [32h]
│   ├── Activity 9.1: Unit Tests [12h]
│   │   ├── File: tests/test_policy_service.py [NEW]
│   │   │   └── Line 1-210: Service layer tests
│   │   │
│   │   └── File: tests/test_policy_engine_interface.py [NEW]
│   │       └── Line 1-120: Interface tests
│   │
│   ├── Activity 9.2: Integration Tests [12h]
│   │   └── File: tests/test_policy_integration.py [NEW]
│   │       └── Line 1-250: End-to-end tests
│   │
│   └── Activity 9.3: Performance Tests [8h]
│       └── File: tests/test_policy_performance.py [NEW]
│           └── Line 1-90: Performance benchmarks
│
└── PROJECT 10: Documentation & Deployment (Week 6) [8h]
    ├── Activity 10.1: API Documentation [4h]
    │   └── File: docs/API_POLICY_ENGINE.md [NEW]
    │       └── Line 1-200: Complete API documentation
    │
    └── Activity 10.2: Deployment Configuration [4h]
        ├── File: docker-compose.yml
        │   └── Line 1-100: Policy engine configuration
        │
        └── File: .env.example
            └── Line 1-5: Environment variables
```

## File Creation Summary

### New Files to Create (15 files):
1. `app/services/policy_engine_interface.py`
2. `app/services/policy_service.py`
3. `app/services/policy_engine_factory.py`
4. `app/services/policy_audit.py`
5. `app/policies/__init__.py`
6. `app/policies/syndicated_loan_rules.yaml`
7. `alembic/versions/XXXXX_add_policy_decisions_table.py`
8. `client/src/components/PolicyDecisionBadge.tsx`
9. `client/src/apps/policy-manager/PolicyManager.tsx`
10. `tests/test_policy_service.py`
11. `tests/test_policy_engine_interface.py`
12. `tests/test_policy_integration.py`
13. `tests/test_policy_performance.py`
14. `docs/API_POLICY_ENGINE.md`
15. `dev/POLICY_ENGINE_TASK_BREAKDOWN.md` (this file)

### Files to Modify (8 files):
1. `app/core/config.py` - Add policy settings
2. `app/db/models.py` - Add PolicyDecision model
3. `server.py` - Initialize policy service
4. `app/api/routes.py` - Add 5+ endpoints and integration logic
5. `app/agents/audit_workflow.py` - Add policy evaluation
6. `app/models/cdm_events.py` - Add policy to terms change
7. `client/src/apps/trade-blotter/TradeBlotter.tsx` - Add policy UI
8. `client/src/components/Dashboard.tsx` - Add policy statistics

## Line-by-Line Implementation Checklist

### PROJECT 1 Checklist:
- [ ] Create `app/services/` directory structure
- [ ] Implement `PolicyEngineInterface` abstract class (60 lines)
- [ ] Implement `PolicyService` class with all methods (420 lines)
- [ ] Create policy rules YAML file (280 lines)
- [ ] Add configuration settings (15 lines)
- [ ] Create factory pattern for engine instantiation (50 lines)
- [ ] Initialize service in `server.py` (10 lines)

### PROJECT 2 Checklist:
- [ ] Add `PolicyDecision` SQLAlchemy model (100 lines)
- [ ] Create Alembic migration script (50 lines)
- [ ] Run migration and verify table creation

### PROJECT 3 Checklist:
- [ ] Add imports to `routes.py` (2 lines)
- [ ] Create dependency injection function (20 lines)
- [ ] Add policy evaluation to `/extract` endpoint (35 lines)
- [ ] Update workflow state logic (50 lines)

### PROJECT 4 Checklist:
- [ ] Create `TradeExecutionRequest` model (10 lines)
- [ ] Implement `/trades/execute` endpoint (100 lines)
- [ ] Update Trade Blotter component (80 lines)

### PROJECT 5 Checklist:
- [ ] Update `audit_workflow.py` imports (2 lines)
- [ ] Modify function signature (4 lines)
- [ ] Add policy evaluation logic (30 lines)
- [ ] Update route to pass service (3 lines)

### PROJECT 6 Checklist:
- [ ] Update `cdm_events.py` imports (1 line)
- [ ] Add policy evaluation to terms change (25 lines)
- [ ] Create terms change endpoint (50 lines)

### PROJECT 7 Checklist:
- [ ] Create `policy_audit.py` service (70 lines)
- [ ] Add statistics endpoint (50 lines)
- [ ] Integrate logging in all evaluation points (15 lines)

### PROJECT 8 Checklist:
- [ ] Create `PolicyDecisionBadge` component (50 lines)
- [ ] Update Dashboard with statistics (50 lines)
- [ ] Create Policy Manager app (200 lines)
- [ ] Add rule management endpoints (150 lines)

### PROJECT 9 Checklist:
- [ ] Write unit tests for service layer (210 lines)
- [ ] Write interface tests (120 lines)
- [ ] Write integration tests (250 lines)
- [ ] Write performance tests (90 lines)

### PROJECT 10 Checklist:
- [ ] Write API documentation (200 lines)
- [ ] Update deployment configuration (100 lines)
- [ ] Add environment variable examples (5 lines)

## Progress Tracking

Use this format to track progress:

```markdown
## Week 1 Progress
- [x] PROJECT 1: Activity 1.1 - Policy Engine Interface (8h) ✓
- [x] PROJECT 1: Activity 1.2 - Policy Service Layer (16h) ✓
- [ ] PROJECT 1: Activity 1.3 - Policy Rules (8h) - In Progress
- [ ] PROJECT 1: Activity 1.4 - Vendor Integration (8h) - Pending
```

## Dependencies Graph

```
PROJECT 1 (Core) 
    ↓
PROJECT 2 (Database)
    ↓
    ├──→ PROJECT 3 (Document Extraction)
    ├──→ PROJECT 4 (Trade Execution)
    ├──→ PROJECT 5 (Loan Asset)
    └──→ PROJECT 6 (Terms Change)
            ↓
    PROJECT 7 (Audit) ← Can run in parallel
            ↓
    PROJECT 8 (UI) ← Depends on 3-6
            ↓
    PROJECT 9 (Testing) ← Depends on 1-6
            ↓
    PROJECT 10 (Docs) ← Can run anytime
```

## Critical Path

**Must complete in this order:**
1. PROJECT 1 → PROJECT 2 → PROJECT 3 → PROJECT 4 → PROJECT 5 → PROJECT 6
2. PROJECT 7 can start after PROJECT 2
3. PROJECT 8 requires PROJECT 3-6
4. PROJECT 9 requires PROJECT 1-6
5. PROJECT 10 is independent

**Total Critical Path:** 104 hours (PROJECT 1 + 2 + 3 + 4 + 5 + 6)

