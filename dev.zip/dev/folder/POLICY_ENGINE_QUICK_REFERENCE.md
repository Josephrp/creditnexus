# Policy Engine Integration - Quick Reference

## Integration Points Summary

### 1. Document Extraction → Policy Evaluation

**File**: `app/api/routes.py`  
**Endpoint**: `POST /extract`  
**Trigger**: After CDM extraction, before workflow approval

```python
# Add after extraction_result creation
policy_result = policy_service.evaluate_facility_creation(
    credit_agreement=extraction_result.agreement,
    document_id=document.id
)

if policy_result.decision == "BLOCK":
    raise HTTPException(403, detail=policy_result)
elif policy_result.decision == "FLAG":
    workflow.priority = "high"
```

**Rules Applied**:
- `block_sanctioned_parties`
- `flag_high_risk_jurisdiction`
- `block_invalid_esg_claims`
- `flag_excessive_commitment`

---

### 2. Trade Execution → Policy Evaluation

**File**: `app/api/routes.py`  
**Endpoint**: `POST /trades/execute` (new)  
**Trigger**: Before trade confirmation in Trade Blotter

```python
# After CDM event generation
policy_result = policy_service.evaluate_trade_execution(
    cdm_event=cdm_event,
    credit_agreement=credit_agreement
)

if policy_result.decision == "BLOCK":
    return {"status": "blocked", "decision": "BLOCK", ...}
```

**Rules Applied**:
- `block_unhosted_wallets`
- `flag_high_value_transfer`
- `block_sanctioned_counterparty`
- `block_virtual_asset_transfer`

---

### 3. Loan Asset Creation → Policy Evaluation

**File**: `app/agents/audit_workflow.py`  
**Function**: `run_full_audit()`  
**Trigger**: After satellite verification (Stage 4)

```python
# After loan_asset.update_verification(ndvi_score)
policy_result = policy_service.evaluate_loan_asset(
    loan_asset=loan_asset,
    credit_agreement=credit_agreement
)

if policy_result.decision == "BLOCK":
    loan_asset.risk_status = RiskStatus.ERROR
    loan_asset.verification_error = f"Policy: {policy_result.rule_applied}"
```

**Rules Applied**:
- `block_breach_securitization`
- `flag_geographic_restriction`
- `block_missing_collateral_verification`
- `flag_high_risk_collateral`

---

### 4. Terms Change → Policy Evaluation

**File**: `app/models/cdm_events.py`  
**Function**: `generate_cdm_terms_change()` (enhanced)  
**Trigger**: Before applying interest rate penalty

```python
# Before rate change
policy_result = policy_service.evaluate_terms_change(
    trade_id=trade_id,
    current_rate=current_rate,
    proposed_rate=new_rate,
    reason="SustainabilityPerformanceTarget_Breach"
)

if policy_result.decision == "BLOCK":
    return current_rate  # Prevent change
```

**Rules Applied**:
- `block_excessive_rate_increase`
- `flag_rapid_rate_changes`
- `block_unauthorized_terms_modification`

---

## Service Layer API

### PolicyService Methods

```python
# 1. Facility Creation
policy_service.evaluate_facility_creation(
    credit_agreement: CreditAgreement,
    document_id: Optional[int] = None
) -> PolicyDecision

# 2. Trade Execution
policy_service.evaluate_trade_execution(
    cdm_event: Dict[str, Any],
    credit_agreement: Optional[CreditAgreement] = None
) -> PolicyDecision

# 3. Loan Asset
policy_service.evaluate_loan_asset(
    loan_asset: LoanAsset,
    credit_agreement: Optional[CreditAgreement] = None
) -> PolicyDecision

# 4. Terms Change
policy_service.evaluate_terms_change(
    trade_id: str,
    current_rate: float,
    proposed_rate: float,
    reason: str
) -> PolicyDecision
```

### PolicyDecision Structure

```python
@dataclass
class PolicyDecision:
    decision: str              # "ALLOW", "BLOCK", "FLAG"
    rule_applied: Optional[str] # Rule name that triggered decision
    trace_id: str              # Unique trace identifier
    trace: List[Dict]          # Full evaluation trace
    matched_rules: List[str]   # All matching rules
    metadata: Dict[str, Any]    # Additional context
```

---

## CDM Field Mapping

| CDM Model | Policy Transaction Field | Example |
|-----------|--------------------------|---------|
| `CreditAgreement.deal_id` | `transaction_id` | "DEAL_2024_001" |
| `Party.lei` | `originator.lei` | "5493000KJT9GC9ILW8X" |
| `LoanFacility.commitment_amount.amount` | `amount` | 100000000 |
| `CreditAgreement.sustainability_linked` | `sustainability_linked` | true |
| `LoanAsset.last_verified_score` | `ndvi_score` | 0.85 |
| `LoanAsset.risk_status` | `risk_status` | "COMPLIANT" |

---

## Policy Rule Priority Hierarchy

1. **BLOCK** (Rank 2) - Highest severity
   - Sanctions violations
   - Regulatory breaches
   - Invalid ESG claims

2. **FLAG** (Rank 1) - Medium severity
   - High-value transactions
   - Geographic restrictions
   - Rapid rate changes

3. **ALLOW** (Rank 0) - Default
   - All other transactions

**Conflict Resolution**: Within same severity, higher `priority` integer wins.

---

## File Structure

```
app/
├── services/
│   ├── policy_service.py           # Main service layer
│   └── policy_engine_interface.py   # Vendor-agnostic interface
├── policies/
│   └── syndicated_loan_rules.yaml   # Policy rules
└── db/
    └── models.py                    # Add PolicyDecision table
```

---

## Database Schema

```sql
CREATE TABLE policy_decisions (
    id SERIAL PRIMARY KEY,
    transaction_id VARCHAR(255) NOT NULL,
    transaction_type VARCHAR(50) NOT NULL,
    decision VARCHAR(10) NOT NULL,
    rule_applied VARCHAR(255),
    trace_id VARCHAR(255) UNIQUE,
    trace JSONB,
    matched_rules TEXT[],
    metadata JSONB,
    created_at TIMESTAMP DEFAULT NOW(),
    document_id INTEGER REFERENCES documents(id),
    loan_asset_id INTEGER REFERENCES loan_assets(id)
);
```

---

## Decision Flow

```
CDM Event/Model
    ↓
CDM Adapter (maps to policy transaction)
    ↓
Policy Engine (evaluates rules)
    ↓
PolicyDecision
    ↓
    ├─▶ BLOCK → Stop workflow, raise error
    ├─▶ FLAG → Continue with high priority/review
    └─▶ ALLOW → Continue normally
    ↓
Audit Log (persist decision)
```

---

## Testing Checklist

- [ ] CDM-to-transaction adapter correctly maps all fields
- [ ] Policy service methods return correct PolicyDecision
- [ ] BLOCK decisions prevent workflow progression
- [ ] FLAG decisions update workflow priority
- [ ] Policy decisions are logged to audit trail
- [ ] Trade execution blocked when policy violation
- [ ] Loan asset securitization blocked for non-compliant assets
- [ ] Terms change blocked for excessive rate increases
- [ ] Conflict resolution works correctly (BLOCK > FLAG > ALLOW)
- [ ] Performance: <100ms evaluation time

---

## Next Steps

1. **Select Policy Engine Vendor** - Choose implementation
2. **Implement PolicyEngineInterface** - Wrap vendor SDK
3. **Create PolicyService** - Implement service layer
4. **Add Integration Points** - Hook into existing workflows
5. **Load Policy Rules** - Deploy YAML rules
6. **Test & Validate** - Run compliance tests
7. **Deploy & Monitor** - Go live with monitoring

---

**See**: `POLICY_ENGINE_INTEGRATION_PLAN.md` for complete details.

