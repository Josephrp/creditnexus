# CDM Compliance Improvements for Policy Engine Integration

## Summary of Required Changes

Based on FINOS Common Domain Model principles, the following improvements are needed to ensure full CDM compliance:

---

## Critical Improvements

### 1. **Use CDM Event Model for Policy Decisions**

**Current Issue**: Policy decisions are stored as simple dictionaries, not CDM events.

**Required Change**: Create `PolicyEvaluation` CDM event type that follows CDM event structure.

**Implementation**:
- Add `generate_cdm_policy_evaluation()` function to `app/models/cdm_events.py`
- Use CDM event structure: `eventType`, `eventDate`, `meta.globalKey`, `relatedEventIdentifier`
- Link policy evaluations to related CDM events (TradeExecution, Observation, TermsChange)

**File Changes**:
- `app/models/cdm_events.py`: Add PolicyEvaluation event generator (50 lines)
- `app/services/policy_service.py`: Return CDM events instead of raw decisions (modify 4 methods)

---

### 2. **Embed Validation in CDM Models**

**Current Issue**: Policy validation happens after CDM model creation.

**Required Change**: Add policy validation constraints to CDM Pydantic models using `@model_validator`.

**Implementation**:
- Add `validate_policy_compliance()` validator to `CreditAgreement` model
- Validate sanctions, ESG compliance, jurisdiction at model instantiation
- Follow CDM principle: "Validation constraints at point of creation"

**File Changes**:
- `app/models/cdm.py`: Add policy validators to CreditAgreement (30 lines)

---

### 3. **Follow CDM Process Model**

**Current Issue**: Policy evaluation is a separate step, not following CDM process pattern.

**Required Change**: Implement CDM process model: **Validation → Calculation → Event Creation**

**Implementation**:
- Create `evaluate_with_cdm_process()` method in PolicyService
- Step 1: Validate CDM event structure
- Step 2: Calculate policy evaluation
- Step 3: Create PolicyEvaluation CDM event

**File Changes**:
- `app/services/policy_service.py`: Add `evaluate_with_cdm_process()` method (80 lines)
- Update all integration points to use CDM process model

---

### 4. **Implement CDM State-Transition Logic**

**Current Issue**: Policy decisions don't use state machine pattern.

**Required Change**: Create CDM-compliant state machine for policy decisions.

**Implementation**:
- Create `CDMPolicyStateMachine` class
- Define valid state transitions (PENDING → ALLOWED/BLOCKED/FLAGGED)
- Validate transitions before applying

**File Changes**:
- `app/models/cdm_state_machine.py`: New file (100 lines)

---

### 5. **Store CDM Events, Not Just Decisions**

**Current Issue**: Database stores policy decisions, not full CDM events.

**Required Change**: Store complete CDM events in database for machine-readability.

**Implementation**:
- Add `cdm_events` JSONB column to `policy_decisions` table
- Store full PolicyEvaluation event structure
- Enable querying by event relationships

**File Changes**:
- `alembic/versions/XXXXX_add_policy_decisions_table.py`: Add `cdm_events` column
- `app/db/models.py`: Update PolicyDecision model

---

## Updated Integration Points (CDM-Compliant)

### Integration Point 1: Document Extraction

**Before (Non-CDM)**:
```python
policy_result = policy_service.evaluate_facility_creation(credit_agreement)
if policy_result.decision == "BLOCK":
    raise HTTPException(403)
```

**After (CDM-Compliant)**:
```python
# CDM Validation (embedded in model)
validated_agreement = result.agreement  # Already validated with policy checks

# CDM Process Model
policy_result = policy_service.evaluate_with_cdm_process(
    cdm_event=policy_event,
    credit_agreement=validated_agreement
)

# Return CDM events
return {
    "agreement": validated_agreement.model_dump(),
    "cdm_events": [policy_result["policy_evaluation_event"]]
}
```

### Integration Point 2: Trade Execution

**Before (Non-CDM)**:
```python
policy_result = policy_service.evaluate_trade_execution(cdm_event)
if policy_result.decision == "BLOCK":
    return {"status": "blocked"}
```

**After (CDM-Compliant)**:
```python
# Create TradeExecution CDM event (with validation)
trade_event = generate_cdm_trade_execution(...)

# CDM Process Model
policy_result = policy_service.evaluate_with_cdm_process(
    cdm_event=trade_event
)

# State transition
if policy_result["decision"] == "BLOCK":
    return {
        "status": "blocked",
        "cdm_event": policy_result["policy_evaluation_event"],
        "state": "BLOCKED"
    }

# Return both events
return {
    "trade_event": trade_event,
    "policy_evaluation_event": policy_result["policy_evaluation_event"],
    "cdm_events": [trade_event, policy_result["policy_evaluation_event"]]
}
```

### Integration Point 3: Loan Asset Verification

**Before (Non-CDM)**:
```python
policy_result = policy_service.evaluate_loan_asset(loan_asset)
if policy_result.decision == "BLOCK":
    loan_asset.risk_status = RiskStatus.ERROR
```

**After (CDM-Compliant)**:
```python
# Create Observation CDM event
observation_event = generate_cdm_observation(...)

# CDM Process Model
policy_result = policy_service.evaluate_with_cdm_process(
    cdm_event=observation_event
)

# Store CDM events
result.cdm_events = [observation_event, policy_result["policy_evaluation_event"]]
```

---

## File Modification Summary

### New Files (2):
1. `app/models/cdm_state_machine.py` - State transition logic (100 lines)
2. `dev/CDM_COMPLIANCE_REVIEW.md` - This review document

### Modified Files (5):
1. `app/models/cdm_events.py` - Add PolicyEvaluation event (50 lines)
2. `app/models/cdm.py` - Add policy validators (30 lines)
3. `app/services/policy_service.py` - CDM process model (80 lines added)
4. `app/db/models.py` - Add cdm_events column (10 lines)
5. `alembic/versions/XXXXX_add_policy_decisions_table.py` - Add cdm_events column (5 lines)

### Updated Integration Points (3):
1. `app/api/routes.py` - `/extract` endpoint (20 lines modified)
2. `app/api/routes.py` - `/trades/execute` endpoint (30 lines modified)
3. `app/agents/audit_workflow.py` - `run_full_audit()` (25 lines modified)

**Total Lines Changed**: ~370 lines

---

## CDM Compliance Checklist

### Architecture
- [x] CDM event model for policy decisions
- [x] Embedded validation in CDM models
- [x] CDM process model (Validation → Calculation → Event Creation)
- [x] State-transition logic
- [x] Machine-readable format

### Event Model
- [x] PolicyEvaluation event type
- [x] Event relationships (relatedEventIdentifier)
- [x] Event metadata (globalKey, sourceSystem, version)
- [x] Event timestamps

### Validation
- [x] Validation at point of creation
- [x] Embedded logic in models
- [x] Validation constraints

### Process Model
- [x] Validation phase
- [x] Calculation phase
- [x] Event creation phase

### Storage
- [x] Store CDM events (not just decisions)
- [x] Event relationships in database
- [x] Query by event type

---

## Migration Steps

1. **Add CDM Event Type** (1 hour)
   - Create `generate_cdm_policy_evaluation()` function
   - Test event structure

2. **Add Model Validators** (2 hours)
   - Add policy validators to CreditAgreement
   - Test validation at creation

3. **Update Service Layer** (4 hours)
   - Implement `evaluate_with_cdm_process()`
   - Update all evaluation methods

4. **Add State Machine** (2 hours)
   - Create CDMPolicyStateMachine
   - Integrate with service layer

5. **Update Integration Points** (6 hours)
   - Modify 3 integration points
   - Test CDM event creation

6. **Update Database Schema** (2 hours)
   - Add cdm_events column
   - Migrate existing data

**Total Migration Time**: ~17 hours

---

## Benefits of CDM Compliance

1. **Interoperability**: Events can be consumed by other CDM systems
2. **Auditability**: Full event history in standard format
3. **Validation**: Data quality at creation point
4. **State Management**: Clear state transitions
5. **Process Clarity**: Standardized process model
6. **Machine Execution**: Events are executable, not just readable

---

**Next Steps**:
1. Review this document with team
2. Prioritize CDM compliance improvements
3. Update integration plan with CDM-compliant approach
4. Implement changes in priority order

