# CDM Compliance Review - Policy Engine Integration

## Executive Summary

This document reviews the Policy Engine Integration Plan against FINOS Common Domain Model (CDM) principles and provides improvements to ensure full CDM compliance.

**Key CDM Principles:**
1. **Embedded Logic**: Fully specified processing model with machine-readable and machine-executable format
2. **Event Model**: Functional event model with state-transition logic
3. **Validation Constraints**: Data validation at point of creation
4. **Process Model**: Validation → Calculation → Event Creation
5. **Granularity**: Focus on critical data and processes

---

## CDM Compliance Issues Identified

### Issue 1: Policy Evaluation Not Using CDM Event Model

**Current Approach:**
- Policy engine evaluates raw transaction dictionaries
- No integration with CDM event lifecycle
- Policy decisions not represented as CDM events

**CDM-Compliant Approach:**
- Policy evaluation should create/validate CDM events
- Policy decisions should be CDM-compliant events
- Use CDM state-transition logic for policy enforcement

### Issue 2: Validation Not at Point of Creation

**Current Approach:**
- Policy evaluation happens after CDM extraction
- Validation is separate from CDM model creation

**CDM-Compliant Approach:**
- Policy validation should be embedded in CDM model validation
- Use Pydantic validators in CDM models
- Validation constraints at model instantiation

### Issue 3: Missing CDM Event Types for Policy

**Current Approach:**
- Policy decisions are separate from CDM events
- No CDM event type for policy evaluation results

**CDM-Compliant Approach:**
- Create `PolicyEvaluation` CDM event type
- Integrate with existing CDM events (TradeExecution, Observation, TermsChange)
- Use CDM event relationships

### Issue 4: Process Model Not Following CDM Pattern

**Current Approach:**
- Policy evaluation is separate step
- Not following CDM: Validation → Calculation → Event Creation

**CDM-Compliant Approach:**
- Embed policy validation in CDM process model
- Policy calculation as part of CDM calculation phase
- Policy decisions as CDM events

---

## CDM-Compliant Architecture

### 1. CDM Event Model for Policy

```python
# app/models/cdm_events.py - Add PolicyEvaluation event

def generate_cdm_policy_evaluation(
    transaction_id: str,
    transaction_type: str,
    decision: str,  # "ALLOW", "BLOCK", "FLAG"
    rule_applied: Optional[str],
    related_event_identifiers: List[Dict[str, str]],
    evaluation_trace: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Generate CDM-compliant PolicyEvaluation event.
    
    This event represents a policy engine decision and follows CDM event model:
    - eventType: "PolicyEvaluation"
    - eventDate: Timestamp
    - policyEvaluation: Policy evaluation details
    - relatedEventIdentifier: Links to TradeExecution, Observation, etc.
    """
    return {
        "eventType": "PolicyEvaluation",
        "eventDate": datetime.datetime.now().isoformat(),
        "policyEvaluation": {
            "transactionIdentifier": {
                "issuer": "CreditNexus_PolicyEngine",
                "assignedIdentifier": [{"identifier": {"value": transaction_id}}]
            },
            "transactionType": transaction_type,
            "decision": {
                "value": decision,
                "unit": "POLICY_DECISION"
            },
            "ruleApplied": rule_applied,
            "evaluationTrace": evaluation_trace,
            "evaluationDate": {"date": datetime.date.today().isoformat()}
        },
        "relatedEventIdentifier": related_event_identifiers,
        "meta": {
            "globalKey": str(uuid.uuid4()),
            "sourceSystem": "CreditNexus_PolicyEngine_v1",
            "version": 1
        }
    }
```

### 2. CDM Model Validation with Policy Constraints

```python
# app/models/cdm.py - Add policy validation to CreditAgreement

from pydantic import field_validator, model_validator

class CreditAgreement(BaseModel):
    # ... existing fields ...
    
    @model_validator(mode='after')
    def validate_policy_compliance(self) -> 'CreditAgreement':
        """
        CDM-compliant validation: Policy checks at point of creation.
        
        This follows CDM principle: "Validation constraints at point of creation"
        """
        # Check sanctioned parties (embedded logic)
        if self.parties:
            for party in self.parties:
                if party.lei and self._is_sanctioned(party.lei):
                    raise ValueError(
                        f"Party {party.name} (LEI: {party.lei}) is on sanctions list"
                    )
        
        # Check ESG compliance (embedded logic)
        if self.sustainability_linked and not self.esg_kpi_targets:
            raise ValueError(
                "Sustainability-linked loans must have ESG KPI targets"
            )
        
        # Check jurisdiction restrictions (embedded logic)
        if self.governing_law in self._get_high_risk_jurisdictions():
            # Don't block, but mark for review (FLAG behavior)
            # This would be handled by policy engine, but validation ensures data quality
            pass
        
        return self
    
    def _is_sanctioned(self, lei: str) -> bool:
        """Check if LEI is on sanctions list (external data source)."""
        # Implementation would query sanctions database
        return False
    
    def _get_high_risk_jurisdictions(self) -> List[str]:
        """Get list of high-risk jurisdictions."""
        return ["HighRiskCountry1", "HighRiskCountry2"]
```

### 3. CDM Process Model Integration

```python
# app/services/policy_service.py - CDM-compliant process

class PolicyService:
    """
    CDM-compliant policy service following process model:
    Validation → Calculation → Event Creation
    """
    
    def evaluate_with_cdm_process(
        self,
        cdm_event: Dict[str, Any],
        credit_agreement: Optional[CreditAgreement] = None
    ) -> Dict[str, Any]:
        """
        CDM Process Model:
        1. VALIDATION: Validate CDM event structure
        2. CALCULATION: Evaluate policy rules
        3. EVENT CREATION: Create PolicyEvaluation CDM event
        """
        # STEP 1: VALIDATION (CDM principle)
        self._validate_cdm_event(cdm_event)
        
        # STEP 2: CALCULATION (Policy evaluation)
        policy_transaction = self._cdm_to_policy_transaction(cdm_event, credit_agreement)
        evaluation_result = self.engine.evaluate(policy_transaction)
        
        # STEP 3: EVENT CREATION (CDM event model)
        policy_event = generate_cdm_policy_evaluation(
            transaction_id=cdm_event.get("trade", {}).get("tradeIdentifier", {}).get("assignedIdentifier", [{}])[0].get("identifier", {}).get("value", "unknown"),
            transaction_type=self._infer_transaction_type(cdm_event),
            decision=evaluation_result["decision"],
            rule_applied=evaluation_result.get("rule"),
            related_event_identifiers=[
                {
                    "eventIdentifier": {
                        "issuer": "CreditNexus",
                        "assignedIdentifier": [{"identifier": {"value": cdm_event.get("meta", {}).get("globalKey", "")}}]
                    }
                }
            ],
            evaluation_trace=evaluation_result.get("trace", [])
        )
        
        return {
            "policy_evaluation_event": policy_event,
            "decision": evaluation_result["decision"],
            "rule_applied": evaluation_result.get("rule"),
            "trace_id": policy_event["meta"]["globalKey"]
        }
    
    def _validate_cdm_event(self, cdm_event: Dict[str, Any]) -> None:
        """Validate CDM event structure (CDM validation phase)."""
        required_fields = ["eventType", "eventDate", "meta"]
        for field in required_fields:
            if field not in cdm_event:
                raise ValueError(f"CDM event missing required field: {field}")
        
        if "globalKey" not in cdm_event.get("meta", {}):
            raise ValueError("CDM event missing meta.globalKey")
```

### 4. CDM State-Transition Logic

```python
# app/models/cdm_state_machine.py (NEW FILE)

from enum import Enum
from typing import Dict, Any, Optional

class PolicyDecisionState(str, Enum):
    """CDM-compliant state enumeration for policy decisions."""
    PENDING = "PENDING"
    ALLOWED = "ALLOWED"
    BLOCKED = "BLOCKED"
    FLAGGED = "FLAGGED"

class CDMPolicyStateMachine:
    """
    CDM state-transition logic for policy decisions.
    
    Follows CDM principle: "Fully functional event model with state-transition logic"
    """
    
    TRANSITIONS = {
        PolicyDecisionState.PENDING: [PolicyDecisionState.ALLOWED, PolicyDecisionState.BLOCKED, PolicyDecisionState.FLAGGED],
        PolicyDecisionState.FLAGGED: [PolicyDecisionState.ALLOWED, PolicyDecisionState.BLOCKED],  # Can be reviewed
        PolicyDecisionState.ALLOWED: [],  # Terminal state
        PolicyDecisionState.BLOCKED: [],  # Terminal state
    }
    
    @classmethod
    def can_transition(
        cls,
        from_state: PolicyDecisionState,
        to_state: PolicyDecisionState
    ) -> bool:
        """Check if state transition is valid (CDM validation)."""
        return to_state in cls.TRANSITIONS.get(from_state, [])
    
    @classmethod
    def apply_decision(
        cls,
        current_state: PolicyDecisionState,
        decision: str  # "ALLOW", "BLOCK", "FLAG"
    ) -> PolicyDecisionState:
        """
        Apply policy decision with state-transition validation.
        
        CDM Process: Validation → State Transition → Event Creation
        """
        # Map decision to state
        decision_state_map = {
            "ALLOW": PolicyDecisionState.ALLOWED,
            "BLOCK": PolicyDecisionState.BLOCKED,
            "FLAG": PolicyDecisionState.FLAGGED
        }
        
        target_state = decision_state_map.get(decision.upper())
        if not target_state:
            raise ValueError(f"Invalid decision: {decision}")
        
        # Validate transition (CDM validation)
        if not cls.can_transition(current_state, target_state):
            raise ValueError(
                f"Invalid state transition: {current_state} → {target_state}"
            )
        
        return target_state
```

---

## Improved Integration Points (CDM-Compliant)

### 1. Document Extraction with CDM Validation

```python
# app/api/routes.py - CDM-compliant integration

@router.post("/extract")
async def extract_document(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    policy_service: PolicyService = Depends(get_policy_service)
):
    """
    CDM-compliant extraction with embedded policy validation.
    
    Process Model:
    1. Extract CDM CreditAgreement (with validation)
    2. Policy validation (embedded in CDM model)
    3. Create PolicyEvaluation event if needed
    """
    # ... existing extraction code ...
    
    result = extract_data_smart(text=text, force_map_reduce=False)
    
    if result.agreement:
        # CDM Validation (at point of creation)
        # This will trigger policy checks via model_validator
        try:
            # Pydantic validation includes policy checks
            validated_agreement = result.agreement  # Already validated
            
            # Create PolicyEvaluation CDM event
            policy_event = generate_cdm_policy_evaluation(
                transaction_id=validated_agreement.deal_id or "unknown",
                transaction_type="facility_creation",
                decision="ALLOW",  # Default, will be updated by policy engine
                rule_applied=None,
                related_event_identifiers=[],
                evaluation_trace=[]
            )
            
            # Evaluate with CDM process model
            policy_result = policy_service.evaluate_with_cdm_process(
                cdm_event=policy_event,
                credit_agreement=validated_agreement
            )
            
            # Update policy event with actual decision
            policy_event["policyEvaluation"]["decision"]["value"] = policy_result["decision"]
            policy_event["policyEvaluation"]["ruleApplied"] = policy_result["rule_applied"]
            
            # Store CDM event (not just decision)
            # This follows CDM: "Machine-readable and machine-executable format"
            
        except ValueError as e:
            # CDM validation failed (policy or data validation)
            raise HTTPException(
                status_code=422,
                detail={
                    "status": "validation_error",
                    "message": str(e),
                    "cdm_compliant": True
                }
            )
    
    return {
        "status": result.status.value,
        "agreement": result.agreement.model_dump() if result.agreement else None,
        "policy_evaluation": policy_event if 'policy_event' in locals() else None,
        "cdm_events": [policy_event] if 'policy_event' in locals() else []
    }
```

### 2. Trade Execution with CDM Event Model

```python
# app/api/routes.py - CDM-compliant trade execution

@router.post("/trades/execute")
async def execute_trade(
    trade_request: TradeExecutionRequest,
    db: Session = Depends(get_db),
    policy_service: PolicyService = Depends(get_policy_service)
):
    """
    CDM Process Model:
    1. Create TradeExecution CDM event (VALIDATION)
    2. Policy evaluation (CALCULATION)
    3. Create PolicyEvaluation CDM event (EVENT CREATION)
    4. State transition based on policy decision
    """
    # STEP 1: Create TradeExecution CDM event (with validation)
    trade_event = generate_cdm_trade_execution(
        trade_id=trade_request.trade_id,
        borrower=trade_request.borrower,
        amount=trade_request.amount,
        rate=trade_request.rate
    )
    
    # STEP 2: Policy evaluation using CDM process model
    policy_result = policy_service.evaluate_with_cdm_process(
        cdm_event=trade_event,
        credit_agreement=None  # Could fetch from DB if needed
    )
    
    # STEP 3: State transition (CDM state machine)
    if policy_result["decision"] == "BLOCK":
        # Terminal state: BLOCKED
        return {
            "status": "blocked",
            "cdm_event": policy_result["policy_evaluation_event"],
            "state": "BLOCKED",
            "cdm_compliant": True
        }
    
    # STEP 4: Continue with trade (state: ALLOWED or FLAGGED)
    # Store both TradeExecution and PolicyEvaluation events
    return {
        "status": "executed",
        "trade_event": trade_event,
        "policy_evaluation_event": policy_result["policy_evaluation_event"],
        "state": policy_result["decision"],
        "cdm_events": [trade_event, policy_result["policy_evaluation_event"]],
        "cdm_compliant": True
    }
```

### 3. Loan Asset with CDM Observation Integration

```python
# app/agents/audit_workflow.py - CDM-compliant integration

async def run_full_audit(
    loan_id: str,
    document_text: str,
    db_session=None,
    policy_service: Optional[PolicyService] = None
) -> AuditResult:
    """
    CDM Process Model for loan asset verification:
    1. Create Observation CDM event (satellite verification)
    2. Policy evaluation (CALCULATION)
    3. Create PolicyEvaluation CDM event (EVENT CREATION)
    4. Create TermsChange event if policy allows
    """
    # ... existing audit stages ...
    
    # Stage 4: Satellite Verification → Observation CDM Event
    if verification.get("success"):
        ndvi_score = verification["ndvi_score"]
        loan_asset.update_verification(ndvi_score)
        
        # Create Observation CDM event (CDM event model)
        observation_event = generate_cdm_observation(
            trade_id=loan_id,
            satellite_hash=verification.get("hash", ""),
            ndvi_score=ndvi_score,
            status=loan_asset.risk_status
        )
        
        # Policy evaluation with CDM process model
        if policy_service:
            policy_result = policy_service.evaluate_with_cdm_process(
                cdm_event=observation_event,
                credit_agreement=None
            )
            
            # Create PolicyEvaluation CDM event
            policy_event = policy_result["policy_evaluation_event"]
            
            # State transition
            if policy_result["decision"] == "BLOCK":
                loan_asset.risk_status = RiskStatus.ERROR
                loan_asset.verification_error = f"Policy: {policy_result['rule_applied']}"
            
            # Store CDM events (machine-readable format)
            # This follows CDM: "Fully specified processing model"
            result.cdm_events = [observation_event, policy_event]
    
    return result
```

---

## CDM Compliance Checklist

### Architecture Compliance
- [x] Use CDM event model for policy decisions
- [x] Embed validation in CDM model creation
- [x] Follow CDM process model (Validation → Calculation → Event Creation)
- [x] Use CDM state-transition logic
- [x] Machine-readable and machine-executable format

### Event Model Compliance
- [x] PolicyEvaluation event type defined
- [x] Event relationships (relatedEventIdentifier)
- [x] Event metadata (globalKey, sourceSystem, version)
- [x] Event date and timestamps

### Validation Compliance
- [x] Validation at point of creation (Pydantic validators)
- [x] Embedded logic in CDM models
- [x] Validation constraints in model definitions

### Process Model Compliance
- [x] Validation phase before calculation
- [x] Calculation phase (policy evaluation)
- [x] Event creation phase (CDM events)

### Granularity Compliance
- [x] Focus on critical data (transaction identifiers, decisions)
- [x] Functional objects (events, not just decisions)
- [x] Required data only (no unnecessary fields)

---

## Migration Path

### Phase 1: Add CDM Event Types
1. Create `PolicyEvaluation` CDM event generator
2. Add to `app/models/cdm_events.py`
3. Update event type enumeration

### Phase 2: Embed Validation in CDM Models
1. Add policy validators to `CreditAgreement` model
2. Add validation to `TradeExecution` event creation
3. Add validation to `Observation` event creation

### Phase 3: Update Service Layer
1. Modify `PolicyService` to use CDM process model
2. Return CDM events instead of raw decisions
3. Integrate state-transition logic

### Phase 4: Update Integration Points
1. Modify `/extract` endpoint to return CDM events
2. Modify `/trades/execute` to use CDM events
3. Modify `run_full_audit()` to create CDM events

### Phase 5: Database Schema
1. Store CDM events (not just decisions)
2. Use CDM event relationships
3. Query by event type and relationships

---

## Benefits of CDM Compliance

1. **Interoperability**: CDM events can be consumed by other CDM-compliant systems
2. **Auditability**: Full event history in machine-readable format
3. **Validation**: Data quality ensured at point of creation
4. **State Management**: Clear state-transition logic
5. **Process Clarity**: Validation → Calculation → Event Creation pattern
6. **Machine Execution**: Events are machine-executable, not just human-readable

---

**Document Version**: 1.0  
**Last Updated**: 2024-12-XX  
**CDM Version**: FINOS CDM v15.0+

