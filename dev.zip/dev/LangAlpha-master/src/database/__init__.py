"""
Database module for MongoDB interaction.
"""

from .utils.mongo_client import get_mongodb_client 