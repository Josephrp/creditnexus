"""
Web API package for the Market Intelligence Agent application.
""" 