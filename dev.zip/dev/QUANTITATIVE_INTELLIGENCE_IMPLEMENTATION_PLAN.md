# Quantitative Intelligence & Business Intelligence Workflows Implementation Plan

## Executive Summary

This plan outlines the integration of three vendor repositories into CreditNexus to enhance quantitative document processing, business intelligence, and loan application workflows:

1. **node-DeepResearch**: Orchestrator-based research agent for iterative deep investigation
2. **pepolehub**: People/business intelligence with psychometric profiling and audit reports
3. **LangAlpha**: Multi-agent quantitative analysis system for financial intelligence

**Priority**: High - Core functionality for loan application processing
**Estimated Timeline**: 8-10 weeks
**Dependencies**: Existing document digitizer, CDM models, policy engine

---

## ⚠️ IMPORTANT: See Improved Plan

**A detailed improved implementation plan has been created** with:
- ✅ Verified design patterns against existing repository
- ✅ Specific LangChain prompts, agents, and tools (Python)
- ✅ CDM event integration points for all workflows
- ✅ Deal flow timeline triggers and state transitions
- ✅ Data write operations following existing patterns
- ✅ TypeScript code vendoring strategy

**See**: `dev/QUANTITATIVE_INTELLIGENCE_IMPLEMENTATION_PLAN_IMPROVED.md`

The improved plan includes:
- Complete LangChain chain implementations with code examples
- CDM event generation patterns for each workflow
- Deal timeline trigger integration points
- Database write operation patterns
- TypeScript vendoring strategy (direct integration vs Python port)

---

## Table of Contents

1. [Project Overview](#project-overview)
2. [Architecture Integration](#architecture-integration)
3. [Project 1: Accounting Document Extraction Chain](#project-1-accounting-document-extraction-chain)
4. [Project 2: DeepResearch Orchestrator Integration](#project-2-deepresearch-orchestrator-integration)
5. [Project 3: PeopleHub Business Intelligence](#project-3-peoplehub-business-intelligence)
6. [Project 4: LangAlpha Quantitative Analysis](#project-4-langalpha-quantitative-analysis)
7. [Project 5: Modal Chatbot for Document Digitizer](#project-5-modal-chatbot-for-document-digitizer)
8. [Implementation Phases](#implementation-phases)
9. [Testing Strategy](#testing-strategy)
10. [Deployment Plan](#deployment-plan)

---

## Project Overview

### Goals

1. **Enhanced Quantitative Processing**: Specialized extraction chain for accounting documents (balance sheets, income statements, cash flow statements)
2. **Intelligent Research Orchestration**: DeepResearch-style iterative research agent for loan intelligence
3. **Business Intelligence**: PeopleHub integration for individual/business profiling with psychometric analysis
4. **Quantitative Analysis**: LangAlpha multi-agent system for financial data analysis
5. **User Experience**: Modal chatbot on document digitizer for workflow orchestration

### Key Requirements

- ✅ All features must follow existing repository design principles
- ✅ CDM compliance for all extracted data
- ✅ Policy engine integration for compliance checks
- ✅ FDC3 compatibility for desktop integration
- ✅ Audit logging for all operations
- ✅ Integration with existing dealflows and CDM events

---

## Architecture Integration

### Component Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Document Digitizer UI                      │
│  ┌──────────────────────────────────────────────────────┐   │
│  │         Modal Chatbot (DeepResearch Orchestrator)    │   │
│  │  - Workflow orchestration                             │   │
│  │  - Deal/CDM event integration                        │   │
│  │  - Multi-workflow launcher                           │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              Document Processing Layer                       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │ Credit       │  │ Accounting   │  │ Profile       │    │
│  │ Agreement    │  │ Documents    │  │ Extraction    │    │
│  │ Extraction   │  │ Extraction   │  │ (PeopleHub)  │    │
│  └──────────────┘  └──────────────┘  └──────────────┘    │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              Intelligence Workflows Layer                    │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │ PeopleHub    │  │ LangAlpha    │  │ DeepResearch  │    │
│  │ Research     │  │ Quantitative │  │ Orchestrator  │    │
│  │ Workflow     │  │ Analysis     │  │               │    │
│  └──────────────┘  └──────────────┘  └──────────────┘    │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              Data & Integration Layer                        │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │ CDM Models   │  │ Policy       │  │ Audit        │    │
│  │ & Events     │  │ Engine       │  │ Logging      │    │
│  └──────────────┘  └──────────────┘  └──────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

---

## Project 1: Accounting Document Extraction Chain

**Priority**: P0 (Critical)
**Estimated Duration**: 1.5 weeks
**Dependencies**: Existing extraction chain infrastructure

### Overview

Create a specialized extraction chain for accounting documents (balance sheets, income statements, cash flow statements, tax returns) with quantitative data focus. Follows existing LangChain chain patterns from `app/chains/extraction_chain.py`.

### Activities

#### Activity 1.1: Create Accounting Document Models

**File**: `app/models/accounting_document.py`

**Tasks**:
- [ ] Define `AccountingDocument` Pydantic model with CDM compliance
- [ ] Create `BalanceSheet` model (assets, liabilities, equity)
- [ ] Create `IncomeStatement` model (revenue, expenses, net income)
- [ ] Create `CashFlowStatement` model (operating, investing, financing activities)
- [ ] Create `TaxReturn` model (filing type, income, deductions, tax owed)
- [ ] Add `@model_validator` for business logic validation (following CDM principle: validate at creation point)
- [ ] Ensure all monetary values use `Decimal` type (never `float`)
- [ ] Add ISO 8601 date validation for reporting periods
- [ ] Use `Money` structure from `app.models.cdm` for all amounts
- [ ] Add `extraction_status` enum (success, partial_data_missing, irrelevant_document) matching existing pattern

**Line-level subtasks**:
```python
# Line 1-50: Base models and imports
# Line 51-100: BalanceSheet model with CDM Money types
# Line 101-150: IncomeStatement model
# Line 151-200: CashFlowStatement model
# Line 201-250: TaxReturn model
# Line 251-300: Validators and business logic
```

#### Activity 1.2: Create Accounting Extraction Chain

**File**: `app/chains/accounting_extraction_chain.py`

**Tasks**:
- [ ] Create `create_accounting_extraction_chain()` function
- [ ] Use `get_chat_model()` from LLM client abstraction
- [ ] Create specialized prompt for accounting documents
- [ ] Support document type detection (balance sheet vs income statement)
- [ ] Implement map-reduce for large financial statements
- [ ] Add quantitative data validation (debits = credits, etc.)
- [ ] Support multi-period extraction (quarterly, annual)

**Line-level subtasks**:
```python
# Line 1-50: Imports and logging setup
# Line 51-100: create_accounting_extraction_chain()
# Line 101-200: create_accounting_extraction_prompt()
# Line 201-300: extract_accounting_data() main function
# Line 301-400: extract_accounting_data_map_reduce() for large docs
# Line 401-500: Document type detection logic
# Line 501-600: Quantitative validation helpers
```

#### Activity 1.3: Create Accounting Extraction Prompt

**File**: `app/chains/accounting_extraction_chain.py` (continued)

**Tasks**:
- [ ] Design system prompt for accounting document extraction
- [ ] Include instructions for balance sheet extraction
- [ ] Include instructions for income statement extraction
- [ ] Include instructions for cash flow statement extraction
- [ ] Add tax return extraction guidance
- [ ] Emphasize quantitative accuracy (no guessing)
- [ ] Add period identification (fiscal year, quarter)
- [ ] Include currency normalization

**Prompt sections**:
- Balance Sheet: Assets (current, non-current), Liabilities (current, non-current), Equity
- Income Statement: Revenue, COGS, Operating Expenses, Net Income
- Cash Flow: Operating Activities, Investing Activities, Financing Activities
- Tax Return: Filing Status, Adjusted Gross Income, Deductions, Tax Liability

#### Activity 1.4: Add Accounting Document API Endpoint

**File**: `app/api/routes.py`

**Tasks**:
- [ ] Add `POST /api/extract/accounting` endpoint
- [ ] Accept file upload (PDF, image, text)
- [ ] Use accounting extraction chain
- [ ] Integrate with policy engine for compliance
- [ ] Create CDM events for extraction
- [ ] Add audit logging
- [ ] Return structured accounting data
- [ ] Support document type parameter (balance_sheet, income_statement, etc.)

**Line-level subtasks**:
```python
# Line 446-500: Add accounting extraction endpoint
# Line 501-550: File upload handling
# Line 551-600: Extraction chain invocation
# Line 601-650: Policy evaluation integration
# Line 651-700: CDM event generation
# Line 701-750: Audit logging
# Line 751-800: Response formatting
```

#### Activity 1.5: Database Schema Updates

**File**: `alembic/versions/XXXX_add_accounting_documents.py`

**Tasks**:
- [ ] Create `accounting_documents` table
- [ ] Add foreign key to `documents` table
- [ ] Add JSONB column for extracted data
- [ ] Add document type enum (balance_sheet, income_statement, cash_flow, tax_return)
- [ ] Add reporting period fields (start_date, end_date, period_type)
- [ ] Add indexes for efficient querying
- [ ] Create Alembic migration

**Schema fields**:
- `id`: Primary key
- `document_id`: Foreign key to documents
- `document_type`: Enum (balance_sheet, income_statement, cash_flow, tax_return)
- `extracted_data`: JSONB (full accounting document structure)
- `reporting_period_start`: Date
- `reporting_period_end`: Date
- `period_type`: Enum (quarterly, annual, monthly)
- `currency`: String (ISO currency code)
- `created_at`: Timestamp
- `updated_at`: Timestamp

#### Activity 1.6: Frontend Integration

**File**: `client/src/apps/docu-digitizer/DocumentParser.tsx`

**Tasks**:
- [ ] Add accounting document type selector
- [ ] Add accounting-specific extraction UI
- [ ] Display extracted quantitative data in structured format
- [ ] Add validation indicators (debits = credits, etc.)
- [ ] Support multi-period display
- [ ] Add export functionality for accounting data

**Line-level subtasks**:
```typescript
// Line 1-50: Add accounting document type state
// Line 51-100: Add accounting extraction handler
// Line 101-150: Add accounting data display component
// Line 151-200: Add validation UI
// Line 201-250: Add export functionality
```

---

## Project 2: DeepResearch Orchestrator Integration

**Priority**: P0 (Critical)
**Estimated Duration**: 2 weeks
**Dependencies**: Project 1, existing document digitizer

### Overview

Integrate node-DeepResearch orchestrator pattern as the core research agent for the modal chatbot. This provides iterative search/read/reason loops for deep investigation.

### Activities

#### Activity 2.1: Port DeepResearch Agent Core

**File**: `app/agents/deep_research_agent.py`

**Tasks**:
- [ ] Port `getResponse()` function from node-DeepResearch
- [ ] Convert TypeScript to Python
- [ ] Adapt to use LangChain instead of AI SDK
- [ ] Integrate with existing LLM client abstraction
- [ ] Implement token budget tracking
- [ ] Implement action tracking (search, read, answer, reflect)
- [ ] Add knowledge accumulation system
- [ ] Implement URL ranking and filtering

**Line-level subtasks**:
```python
# Line 1-100: Imports and type definitions
# Line 101-200: TokenTracker class (port from TypeScript)
# Line 201-300: ActionTracker class (port from TypeScript)
# Line 301-400: KnowledgeItem and state management
# Line 401-600: getResponse() main orchestrator function
# Line 601-800: Action handlers (search, read, answer, reflect)
# Line 801-1000: URL processing and ranking
# Line 1001-1200: Answer evaluation and refinement
```

#### Activity 2.2: Create DeepResearch Tools

**File**: `app/agents/deep_research_tools.py`

**Tasks**:
- [ ] Port search tools (Jina Search, DuckDuckGo, Brave)
- [ ] Port URL reading tool (Jina Reader)
- [ ] Port answer evaluator tool
- [ ] Port query rewriter tool
- [ ] Port URL deduplication tool
- [ ] Integrate with existing search infrastructure
- [ ] Add error handling and retries

**Tools to port**:
- `tools/jina-search.ts` → `deep_research_tools.py::jina_search()`
- `tools/read.ts` → `deep_research_tools.py::read_url()`
- `tools/evaluator.ts` → `deep_research_tools.py::evaluate_answer()`
- `tools/query-rewriter.ts` → `deep_research_tools.py::rewrite_query()`

#### Activity 2.3: Create DeepResearch Service

**File**: `app/services/deep_research_service.py`

**Tasks**:
- [ ] Create `DeepResearchService` class
- [ ] Implement `research()` method for general queries
- [ ] Implement `research_loan_application()` for loan-specific research
- [ ] Integrate with CDM events
- [ ] Add deal/workflow context passing
- [ ] Add result storage
- [ ] Implement caching for repeated queries

**Line-level subtasks**:
```python
# Line 1-50: Imports and class definition
# Line 51-150: __init__() with dependency injection
# Line 151-300: research() method
# Line 301-450: research_loan_application() method
# Line 451-600: CDM event integration
# Line 601-750: Caching implementation
# Line 751-900: Result storage and retrieval
```

#### Activity 2.4: Create DeepResearch API Endpoints

**File**: `app/api/routes.py`

**Tasks**:
- [ ] Add `POST /api/deep-research/query` endpoint
- [ ] Add `POST /api/deep-research/loan-application` endpoint
- [ ] Add `GET /api/deep-research/results/{research_id}` endpoint
- [ ] Support streaming responses
- [ ] Add authentication and authorization
- [ ] Integrate with policy engine
- [ ] Add audit logging
- [ ] Support deal_id and workflow_id parameters

**Line-level subtasks**:
```python
# Line 800-850: Deep research query endpoint
# Line 851-900: Loan application research endpoint
# Line 901-950: Research results retrieval endpoint
# Line 951-1000: Streaming support
# Line 1001-1050: Authentication integration
# Line 1051-1100: Policy engine integration
# Line 1101-1150: Audit logging
```

#### Activity 2.5: Database Schema for Research Results

**File**: `alembic/versions/XXXX_add_deep_research_results.py`

**Tasks**:
- [ ] Create `deep_research_results` table
- [ ] Add fields: research_id, query, answer, knowledge_items (JSONB)
- [ ] Add visited_urls, searched_queries arrays
- [ ] Add token_usage tracking
- [ ] Add deal_id, workflow_id foreign keys
- [ ] Add created_at, completed_at timestamps
- [ ] Add status enum (pending, processing, completed, failed)
- [ ] Create indexes

**Schema**:
```sql
CREATE TABLE deep_research_results (
    id SERIAL PRIMARY KEY,
    research_id UUID UNIQUE NOT NULL,
    query TEXT NOT NULL,
    answer TEXT,
    knowledge_items JSONB,
    visited_urls TEXT[],
    searched_queries TEXT[],
    token_usage JSONB,
    deal_id INTEGER REFERENCES deals(id),
    workflow_id INTEGER REFERENCES workflows(id),
    status VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    completed_at TIMESTAMP,
    error_message TEXT
);
```

---

## Project 3: PeopleHub Business Intelligence

**Priority**: P1 (High)
**Estimated Duration**: 2.5 weeks
**Dependencies**: Project 2, existing profile extraction

### Overview

Integrate PeopleHub research workflow for individual and business intelligence, including psychometric profiling, buying behaviors, savings behaviors, and credit check data points.

### Activities

#### Activity 3.1: Port PeopleHub Research Graph

**File**: `app/workflows/peoplehub_research_graph.py`

**Tasks**:
- [ ] Port LangGraph research workflow from PeopleHub
- [ ] Convert TypeScript to Python
- [ ] Adapt to use LangChain LangGraph
- [ ] Create node handlers: fetchLinkedIn, generateSearchQuery, executeSearch, scrapeWebPage, summarizeContent, aggregateData, writeReport
- [ ] Implement state management with ResearchStateAnnotation
- [ ] Add parallel processing for multiple URLs
- [ ] Integrate with existing LLM client

**Line-level subtasks**:
```python
# Line 1-100: Imports and type definitions
# Line 101-200: ResearchStateAnnotation definition
# Line 201-350: fetchLinkedInNode handler
# Line 351-500: generateSearchQueryNode handler
# Line 501-650: executeSearchNode handler
# Line 651-800: scrapeWebPageNode handler
# Line 801-950: summarizeContentNode handler
# Line 951-1100: aggregateDataNode handler
# Line 1101-1250: writeReportNode handler
# Line 1251-1400: Graph builder and compilation
```

#### Activity 3.2: Create Business Intelligence Models

**File**: `app/models/business_intelligence.py`

**Tasks**:
- [ ] Create `BusinessProfile` model
- [ ] Create `IndividualProfile` model
- [ ] Create `PsychometricProfile` model (Big Five, risk tolerance, etc.)
- [ ] Create `BuyingBehaviorProfile` model (purchase patterns, preferences)
- [ ] Create `SavingsBehaviorProfile` model (savings rate, investment patterns)
- [ ] Create `CreditCheckData` model (credit score, payment history, etc.)
- [ ] Create `AuditReport` model for comprehensive reports
- [ ] Ensure CDM compliance

**Models**:
```python
class PsychometricProfile(BaseModel):
    big_five_traits: Optional[Dict[str, float]]  # Openness, Conscientiousness, etc.
    risk_tolerance: Optional[str]  # conservative, moderate, aggressive
    decision_making_style: Optional[str]
    # ... more traits

class BuyingBehaviorProfile(BaseModel):
    purchase_frequency: Optional[str]
    average_transaction_value: Optional[Decimal]
    preferred_categories: Optional[List[str]]
    # ... more behaviors

class SavingsBehaviorProfile(BaseModel):
    savings_rate: Optional[Decimal]
    investment_preferences: Optional[List[str]]
    financial_goals: Optional[List[str]]
    # ... more behaviors
```

#### Activity 3.3: Create Psychometric Analysis Service

**File**: `app/services/psychometric_analysis_service.py`

**Tasks**:
- [ ] Create `PsychometricAnalysisService` class
- [ ] Implement `analyze_individual()` method
- [ ] Use LLM to infer psychometric traits from LinkedIn/web data
- [ ] Generate Big Five personality scores
- [ ] Assess risk tolerance
- [ ] Analyze decision-making patterns
- [ ] Generate buying behavior insights
- [ ] Generate savings behavior insights
- [ ] Create comprehensive audit report

**Line-level subtasks**:
```python
# Line 1-100: Imports and class definition
# Line 101-250: analyze_individual() method
# Line 251-400: extract_psychometric_traits() helper
# Line 401-550: analyze_buying_behavior() helper
# Line 551-700: analyze_savings_behavior() helper
# Line 701-850: generate_audit_report() method
# Line 851-1000: Credit check data extraction
```

#### Activity 3.4: Create Business Intelligence API

**File**: `app/api/routes.py`

**Tasks**:
- [ ] Add `POST /api/business-intelligence/research-person` endpoint
- [ ] Add `POST /api/business-intelligence/research-business` endpoint
- [ ] Add `GET /api/business-intelligence/profile/{profile_id}` endpoint
- [ ] Add `GET /api/business-intelligence/audit-report/{report_id}` endpoint
- [ ] Support LinkedIn URL or person name input
- [ ] Integrate with policy engine
- [ ] Add audit logging
- [ ] Support deal_id and workflow_id

**Line-level subtasks**:
```python
# Line 1151-1200: Research person endpoint
# Line 1201-1250: Research business endpoint
# Line 1251-1300: Get profile endpoint
# Line 1301-1350: Get audit report endpoint
# Line 1351-1400: Policy integration
# Line 1401-1450: Audit logging
```

#### Activity 3.5: Database Schema for Business Intelligence

**File**: `alembic/versions/XXXX_add_business_intelligence.py`

**Tasks**:
- [ ] Create `business_profiles` table
- [ ] Create `individual_profiles` table
- [ ] Create `psychometric_profiles` table
- [ ] Create `audit_reports` table
- [ ] Add foreign keys to deals, workflows
- [ ] Add JSONB columns for profile data
- [ ] Create indexes

**Schema**:
```sql
CREATE TABLE business_profiles (
    id SERIAL PRIMARY KEY,
    business_name VARCHAR(255),
    lei VARCHAR(20),
    linkedin_url TEXT,
    profile_data JSONB,
    deal_id INTEGER REFERENCES deals(id),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE individual_profiles (
    id SERIAL PRIMARY KEY,
    person_name VARCHAR(255),
    linkedin_url TEXT,
    profile_data JSONB,
    deal_id INTEGER REFERENCES deals(id),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE psychometric_profiles (
    id SERIAL PRIMARY KEY,
    individual_profile_id INTEGER REFERENCES individual_profiles(id),
    psychometric_data JSONB,
    buying_behavior JSONB,
    savings_behavior JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE audit_reports (
    id SERIAL PRIMARY KEY,
    report_type VARCHAR(50),  -- individual, business
    profile_id INTEGER,
    report_data JSONB,
    deal_id INTEGER REFERENCES deals(id),
    created_at TIMESTAMP DEFAULT NOW()
);
```

---

## Project 4: LangAlpha Quantitative Analysis

**Priority**: P1 (High)
**Estimated Duration**: 2.5 weeks
**Dependencies**: Project 1, Project 2

### Overview

Integrate LangAlpha multi-agent system for quantitative financial analysis, including market intelligence, fundamental analysis, and risk assessment.

### Activities

#### Activity 4.1: Port LangAlpha Agent System

**File**: `app/agents/langalpha_agents.py`

**Tasks**:
- [ ] Port supervisor agent from LangAlpha
- [ ] Port planner agent
- [ ] Port researcher agent
- [ ] Port market agent (for financial data)
- [ ] Port analyst agent (financial expert)
- [ ] Port reporter agent
- [ ] Convert Python 3.x to match existing codebase style
- [ ] Integrate with existing LLM client abstraction

**Agents to port**:
- `agents/agents.py::supervisor_agent`
- `agents/agents.py::planner_agent`
- `agents/agents.py::researcher_agent`
- `agents/agents.py::market_agent`
- `agents/agents.py::analyst_agent`
- `agents/agents.py::reporter_agent`

#### Activity 4.2: Port LangAlpha Tools

**File**: `app/agents/langalpha_tools.py`

**Tasks**:
- [ ] Port market data tools (Polygon, Yahoo Finance)
- [ ] Port fundamental data tools (Alpha Vantage)
- [ ] Port news/search tools (Tavily, Tickertick)
- [ ] Port browser tool (Playwright)
- [ ] Port Python REPL tool for calculations
- [ ] Adapt to use existing data providers where possible
- [ ] Add error handling and retries

**Tools to port**:
- `tools/market_data.py` → `langalpha_tools.py::get_market_data()`
- `tools/fundamental_data.py` → `langalpha_tools.py::get_fundamental_data()`
- `tools/tavily.py` → `langalpha_tools.py::tavily_search()`
- `tools/tickertick.py` → `langalpha_tools.py::tickertick_news()`

#### Activity 4.3: Create LangAlpha Graph

**File**: `app/workflows/langalpha_graph.py`

**Tasks**:
- [ ] Port LangGraph workflow from LangAlpha
- [ ] Create coordinator node
- [ ] Create supervisor node
- [ ] Create planner node
- [ ] Create agent routing logic
- [ ] Implement state management
- [ ] Add checkpointing for long-running analyses
- [ ] Integrate with existing workflow system

**Line-level subtasks**:
```python
# Line 1-100: Imports and type definitions
# Line 101-250: State definition (port from types.py)
# Line 251-400: Coordinator node
# Line 401-550: Supervisor node
# Line 551-700: Planner node
# Line 701-850: Agent routing logic
# Line 851-1000: Graph builder
# Line 1001-1150: Checkpointing integration
```

#### Activity 4.4: Create Quantitative Analysis Service

**File**: `app/services/quantitative_analysis_service.py`

**Tasks**:
- [ ] Create `QuantitativeAnalysisService` class
- [ ] Implement `analyze_company()` method
- [ ] Implement `analyze_market()` method
- [ ] Implement `analyze_loan_application()` method
- [ ] Integrate with CDM events
- [ ] Generate comprehensive analysis reports
- [ ] Add caching for repeated analyses

**Line-level subtasks**:
```python
# Line 1-100: Imports and class definition
# Line 101-300: analyze_company() method
# Line 301-500: analyze_market() method
# Line 501-700: analyze_loan_application() method
# Line 701-900: CDM event integration
# Line 901-1100: Report generation
# Line 1101-1300: Caching implementation
```

#### Activity 4.5: Create Quantitative Analysis API

**File**: `app/api/routes.py`

**Tasks**:
- [ ] Add `POST /api/quantitative-analysis/company` endpoint
- [ ] Add `POST /api/quantitative-analysis/market` endpoint
- [ ] Add `POST /api/quantitative-analysis/loan-application` endpoint
- [ ] Add `GET /api/quantitative-analysis/results/{analysis_id}` endpoint
- [ ] Support streaming responses
- [ ] Integrate with policy engine
- [ ] Add audit logging

**Line-level subtasks**:
```python
# Line 1451-1500: Company analysis endpoint
# Line 1501-1550: Market analysis endpoint
# Line 1551-1600: Loan application analysis endpoint
# Line 1601-1650: Results retrieval endpoint
# Line 1651-1700: Streaming support
# Line 1701-1750: Policy integration
```

#### Activity 4.6: Database Schema for Quantitative Analysis

**File**: `alembic/versions/XXXX_add_quantitative_analysis.py`

**Tasks**:
- [ ] Create `quantitative_analysis_results` table
- [ ] Add fields: analysis_id, analysis_type, query, report (JSONB)
- [ ] Add market_data, fundamental_data JSONB columns
- [ ] Add deal_id, workflow_id foreign keys
- [ ] Add status and timestamps
- [ ] Create indexes

**Schema**:
```sql
CREATE TABLE quantitative_analysis_results (
    id SERIAL PRIMARY KEY,
    analysis_id UUID UNIQUE NOT NULL,
    analysis_type VARCHAR(50),  -- company, market, loan_application
    query TEXT,
    report JSONB,
    market_data JSONB,
    fundamental_data JSONB,
    deal_id INTEGER REFERENCES deals(id),
    workflow_id INTEGER REFERENCES workflows(id),
    status VARCHAR(20),
    created_at TIMESTAMP DEFAULT NOW(),
    completed_at TIMESTAMP
);
```

---

## Project 5: Modal Chatbot for Document Digitizer

**Priority**: P0 (Critical)
**Estimated Duration**: 1.5 weeks
**Dependencies**: Projects 2, 3, 4

### Overview

Create a modal chatbot component that appears only on the document digitizer screen. It uses the DeepResearch orchestrator to launch workflows and is integrated with dealflows, CDM events, and FDC3.

### Activities

#### Activity 5.1: Create Chatbot Backend Service

**File**: `app/services/digitizer_chatbot_service.py`

**Tasks**:
- [ ] Create `DigitizerChatbotService` class
- [ ] Implement `process_message()` method
- [ ] Integrate with DeepResearch orchestrator
- [ ] Support workflow launching (PeopleHub, LangAlpha)
- [ ] Integrate with deal context
- [ ] Generate CDM events for chatbot interactions
- [ ] Support document context passing
- [ ] Implement conversation history

**Line-level subtasks**:
```python
# Line 1-100: Imports and class definition
# Line 101-300: process_message() method
# Line 301-500: launch_workflow() helper
# Line 501-700: integrate_deal_context() helper
# Line 701-900: generate_cdm_events() helper
# Line 901-1100: Conversation history management
```

#### Activity 5.2: Create Chatbot API Endpoints

**File**: `app/api/routes.py`

**Tasks**:
- [ ] Add `POST /api/digitizer-chatbot/chat` endpoint
- [ ] Add `POST /api/digitizer-chatbot/launch-workflow` endpoint
- [ ] Add `GET /api/digitizer-chatbot/history/{session_id}` endpoint
- [ ] Support streaming responses
- [ ] Add authentication
- [ ] Integrate with policy engine
- [ ] Add audit logging

**Line-level subtasks**:
```python
# Line 1751-1800: Chat endpoint
# Line 1801-1850: Launch workflow endpoint
# Line 1851-1900: History endpoint
# Line 1901-1950: Streaming support
# Line 1951-2000: Authentication
```

#### Activity 5.3: Create Chatbot Frontend Component

**File**: `client/src/apps/docu-digitizer/DigitizerChatbot.tsx`

**Tasks**:
- [ ] Create modal chatbot component
- [ ] Implement chat interface (messages, input, send)
- [ ] Add workflow launcher UI
- [ ] Display workflow status
- [ ] Integrate with FDC3 for context broadcasting
- [ ] Show deal/workflow context
- [ ] Add document context display
- [ ] Implement conversation history

**Line-level subtasks**:
```typescript
// Line 1-100: Imports and component definition
// Line 101-200: State management
// Line 201-350: Chat interface UI
// Line 351-500: Message rendering
// Line 501-650: Input handling
// Line 651-800: Workflow launcher UI
// Line 801-950: FDC3 integration
// Line 951-1100: Context display
```

#### Activity 5.4: Integrate Chatbot into Document Parser

**File**: `client/src/apps/docu-digitizer/DocumentParser.tsx`

**Tasks**:
- [ ] Add chatbot state (isOpen)
- [ ] Add chatbot toggle button
- [ ] Render DigitizerChatbot component
- [ ] Pass document context to chatbot
- [ ] Pass deal context to chatbot
- [ ] Handle workflow results from chatbot
- [ ] Update UI based on chatbot actions

**Line-level subtasks**:
```typescript
// Line 250-300: Add chatbot state
// Line 301-350: Add toggle button
// Line 351-400: Render chatbot component
// Line 401-450: Context passing
// Line 451-500: Workflow result handling
```

#### Activity 5.5: Database Schema for Chatbot Sessions

**File**: `alembic/versions/XXXX_add_chatbot_sessions.py`

**Tasks**:
- [ ] Create `chatbot_sessions` table
- [ ] Create `chatbot_messages` table
- [ ] Add foreign keys to deals, workflows, documents
- [ ] Add session_id UUID
- [ ] Store message history
- [ ] Add timestamps
- [ ] Create indexes

**Schema**:
```sql
CREATE TABLE chatbot_sessions (
    id SERIAL PRIMARY KEY,
    session_id UUID UNIQUE NOT NULL,
    user_id INTEGER REFERENCES users(id),
    deal_id INTEGER REFERENCES deals(id),
    document_id INTEGER REFERENCES documents(id),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP
);

CREATE TABLE chatbot_messages (
    id SERIAL PRIMARY KEY,
    session_id UUID REFERENCES chatbot_sessions(session_id),
    role VARCHAR(20),  -- user, assistant
    content TEXT,
    workflow_launched VARCHAR(100),
    cdm_events JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);
```

---

## Implementation Phases

### Phase 1: Foundation (Weeks 1-2)
- ✅ Project 1: Accounting Document Extraction Chain
- ✅ Project 2: DeepResearch Orchestrator Integration (core)

**Deliverables**:
- Accounting extraction chain functional
- DeepResearch agent core ported and integrated
- Basic API endpoints working

### Phase 2: Intelligence Workflows (Weeks 3-5)
- ✅ Project 3: PeopleHub Business Intelligence
- ✅ Project 4: LangAlpha Quantitative Analysis

**Deliverables**:
- PeopleHub research workflow integrated
- LangAlpha multi-agent system integrated
- Business intelligence APIs functional
- Quantitative analysis APIs functional

### Phase 3: User Experience (Weeks 6-7)
- ✅ Project 5: Modal Chatbot for Document Digitizer

**Deliverables**:
- Chatbot modal component functional
- Workflow launching from chatbot
- FDC3 integration complete
- Full integration with document digitizer

### Phase 4: Integration & Testing (Weeks 8-9)
- ✅ End-to-end testing
- ✅ Performance optimization
- ✅ Documentation
- ✅ Security review

**Deliverables**:
- All features tested and documented
- Performance benchmarks met
- Security review passed

### Phase 5: Deployment (Week 10)
- ✅ Production deployment
- ✅ Monitoring setup
- ✅ User training

**Deliverables**:
- Features deployed to production
- Monitoring dashboards active
- User documentation complete

---

## Testing Strategy

### Unit Tests

**Files to create**:
- `tests/test_accounting_extraction_chain.py`
- `tests/test_deep_research_agent.py`
- `tests/test_peoplehub_research_graph.py`
- `tests/test_langalpha_agents.py`
- `tests/test_digitizer_chatbot_service.py`

**Coverage targets**:
- Accounting extraction: 90%+
- DeepResearch agent: 85%+
- PeopleHub workflow: 85%+
- LangAlpha agents: 85%+
- Chatbot service: 90%+

### Integration Tests

**Files to create**:
- `tests/integration/test_accounting_extraction_api.py`
- `tests/integration/test_deep_research_api.py`
- `tests/integration/test_business_intelligence_api.py`
- `tests/integration/test_quantitative_analysis_api.py`
- `tests/integration/test_chatbot_api.py`

**Test scenarios**:
- End-to-end accounting document extraction
- DeepResearch query processing
- PeopleHub profile research
- LangAlpha company analysis
- Chatbot workflow launching

### Performance Tests

**Metrics to track**:
- Accounting extraction: < 30s for standard documents
- DeepResearch query: < 2min for complex queries
- PeopleHub research: < 3min for full profile
- LangAlpha analysis: < 5min for comprehensive analysis
- Chatbot response: < 5s for simple queries

---

## Deployment Plan

### Pre-Deployment Checklist

- [ ] All unit tests passing
- [ ] All integration tests passing
- [ ] Performance benchmarks met
- [ ] Security review completed
- [ ] Documentation updated
- [ ] Database migrations tested
- [ ] API documentation updated
- [ ] Frontend components tested

### Deployment Steps

1. **Database Migrations**
   - Run Alembic migrations for all new tables
   - Verify schema changes
   - Test rollback procedures

2. **Backend Deployment**
   - Deploy new services
   - Update API routes
   - Configure environment variables
   - Test API endpoints

3. **Frontend Deployment**
   - Build and deploy frontend
   - Test chatbot modal
   - Verify FDC3 integration
   - Test workflow launching

4. **Monitoring Setup**
   - Configure logging
   - Set up metrics collection
   - Create alerting rules
   - Test monitoring dashboards

### Rollback Plan

- Database: Alembic rollback to previous migration
- Backend: Revert to previous deployment
- Frontend: Revert to previous build
- Configuration: Restore previous environment variables

---

## Success Criteria

### Functional Requirements

- ✅ Accounting documents can be extracted with quantitative data
- ✅ DeepResearch orchestrator can process complex queries
- ✅ PeopleHub can generate business intelligence reports
- ✅ LangAlpha can perform quantitative analysis
- ✅ Chatbot can launch workflows from document digitizer
- ✅ All features integrate with CDM events
- ✅ All features integrate with policy engine
- ✅ All features support audit logging

### Non-Functional Requirements

- ✅ Response times meet performance targets
- ✅ Error handling is comprehensive
- ✅ Security best practices followed
- ✅ Code follows repository design principles
- ✅ Documentation is complete
- ✅ Tests provide adequate coverage

---

## Risk Mitigation

### Technical Risks

1. **Performance**: Large documents may cause timeouts
   - **Mitigation**: Implement async processing, progress tracking

2. **API Rate Limits**: External APIs may have rate limits
   - **Mitigation**: Implement caching, request queuing

3. **Data Quality**: Extracted data may be inaccurate
   - **Mitigation**: Implement validation, human review workflows

### Integration Risks

1. **CDM Compliance**: New models may not be fully CDM-compliant
   - **Mitigation**: Review with CDM experts, use existing patterns

2. **Policy Engine**: New features may not integrate properly
   - **Mitigation**: Follow existing integration patterns, test thoroughly

### Operational Risks

1. **User Adoption**: Users may not understand new features
   - **Mitigation**: Provide training, documentation, in-app guidance

2. **Support Burden**: New features may increase support requests
   - **Mitigation**: Comprehensive documentation, error messages

---

## Appendix

### A. File Structure

```
app/
├── agents/
│   ├── deep_research_agent.py          # NEW
│   ├── deep_research_tools.py          # NEW
│   ├── langalpha_agents.py              # NEW
│   ├── langalpha_tools.py               # NEW
│   └── ...
├── chains/
│   ├── accounting_extraction_chain.py  # NEW
│   └── ...
├── models/
│   ├── accounting_document.py          # NEW
│   ├── business_intelligence.py        # NEW
│   └── ...
├── services/
│   ├── deep_research_service.py        # NEW
│   ├── psychometric_analysis_service.py # NEW
│   ├── quantitative_analysis_service.py  # NEW
│   ├── digitizer_chatbot_service.py    # NEW
│   └── ...
├── workflows/
│   ├── peoplehub_research_graph.py     # NEW
│   ├── langalpha_graph.py               # NEW
│   └── ...
└── api/
    └── routes.py                        # MODIFIED

client/src/
├── apps/
│   └── docu-digitizer/
│       ├── DigitizerChatbot.tsx        # NEW
│       └── DocumentParser.tsx           # MODIFIED
└── ...
```

### B. Environment Variables

```env
# DeepResearch
DEEPRESEARCH_TOKEN_BUDGET=1000000
DEEPRESEARCH_SEARCH_PROVIDER=jina
JINA_API_KEY=...

# PeopleHub
PEOPLEHUB_BRIGHTDATA_API_TOKEN=...
PEOPLEHUB_REDIS_URL=...

# LangAlpha
LANGALPHA_POLYGON_API_KEY=...
LANGALPHA_ALPHA_VANTAGE_API_KEY=...
LANGALPHA_TAVILY_API_KEY=...
```

### C. Dependencies

**New Python packages**:
- `langgraph` (for workflow orchestration)
- `playwright` (for browser automation)
- `redis` (for caching)
- `httpx` (for async HTTP requests)

**New Frontend packages**:
- None (use existing React/TypeScript stack)

---

## Conclusion

This implementation plan provides a comprehensive roadmap for integrating quantitative intelligence and business intelligence workflows into CreditNexus. The phased approach ensures incremental delivery while maintaining code quality and system stability.

**Next Steps**:
1. Review and approve this plan
2. Assign development resources
3. Begin Phase 1 implementation
4. Set up project tracking and milestones
