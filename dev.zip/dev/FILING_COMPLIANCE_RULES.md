# CreditNexus Filing Compliance Rules by Jurisdiction

## Executive Summary

This document defines which agreement types must be filed in which jurisdictions, compliance requirements, deadlines, and penalties for non-compliance. It serves as the foundation for policy engine rules and automated filing workflows.

**Last Updated**: 2024-12-XX  
**Status**: Research Complete - Ready for Policy Implementation

---

## Table of Contents

1. [United States Compliance Rules](#united-states-compliance-rules)
2. [United Kingdom Compliance Rules](#united-kingdom-compliance-rules)
3. [France Compliance Rules](#france-compliance-rules)
4. [Germany Compliance Rules](#germany-compliance-rules)
5. [Agreement Type Classification Matrix](#agreement-type-classification-matrix)
6. [Compliance Policy Rules](#compliance-policy-rules)

---

## United States Compliance Rules

### SEC EDGAR Filing Requirements

#### Agreement Types Requiring Filing

| Agreement Type | Form Type | Deadline | Trigger Amount |
|----------------|-----------|----------|----------------|
| **Material Credit Agreement** | 8-K Item 1.01 | 4 business days | Any material agreement |
| **Facility Agreement** | 8-K Item 1.01 | 4 business days | If material to company |
| **Loan Agreement** | 8-K Item 1.01 | 4 business days | If material to company |
| **Guarantee Agreement** | 8-K Item 1.01 | 4 business days | If material to company |
| **Security Agreement** | 8-K Item 1.01 | 4 business days | If material to company |
| **Intercreditor Agreement** | 8-K Item 1.01 | 4 business days | If material to company |
| **Quarterly Disclosures** | 10-Q | Quarterly | All public companies |
| **Annual Disclosures** | 10-K | Annually | All public companies |

#### Filing Criteria

**Materiality Threshold**:
- Agreement value > 10% of total assets, OR
- Agreement value > $1 million (for smaller companies), OR
- Agreement creates material obligations or restrictions

**Required Information**:
- Borrower name and LEI
- Agreement date
- Total commitment amount
- Maturity date
- Interest rate terms
- Material covenants and restrictions
- Governing law

#### Compliance Rules

```yaml
US_SEC_FILING_REQUIREMENT:
  jurisdiction: "US"
  authority: "SEC"
  filing_system: "EDGAR"
  agreement_types:
    - "facility_agreement"
    - "loan_agreement"
    - "credit_agreement"
    - "guarantee_agreement"
    - "security_agreement"
    - "intercreditor_agreement"
  triggers:
    - condition: "agreement_value > (total_assets * 0.10)"
      description: "Materiality threshold (10% of assets)"
    - condition: "agreement_value > 1000000"
      description: "Absolute threshold ($1M)"
    - condition: "material_restrictions == true"
      description: "Material covenants or restrictions"
  deadline: "4 business days from agreement_date"
  penalty: "Up to $250,000 or transaction value (whichever greater)"
  required_fields:
    - "borrower_name"
    - "borrower_lei"
    - "agreement_date"
    - "total_commitment"
    - "currency"
    - "maturity_date"
    - "governing_law"
```

#### CFIUS Filing Requirements (Foreign Investment)

**Trigger Conditions**:
- Foreign investor acquiring > 10% of US business
- Investment in sensitive sectors (defense, critical infrastructure, etc.)
- Transaction value > threshold (varies by sector)

**Filing Deadline**: 30 days before transaction closing

**Penalties**: Transaction can be unwound, fines up to transaction value

```yaml
US_CFIUS_FILING_REQUIREMENT:
  jurisdiction: "US"
  authority: "CFIUS"
  filing_system: "manual"
  agreement_types:
    - "facility_agreement"
    - "loan_agreement"
    - "investment_agreement"
  triggers:
    - condition: "foreign_investor == true AND ownership_percentage > 10"
      description: "Foreign investment threshold"
    - condition: "sector IN ['defense', 'critical_infrastructure', 'telecommunications']"
      description: "Sensitive sector"
  deadline: "30 days before transaction_closing_date"
  penalty: "Transaction unwinding, fines up to transaction value"
```

---

## United Kingdom Compliance Rules

### Companies House Filing Requirements

#### Agreement Types Requiring Filing

| Agreement Type | Form Type | Deadline | Trigger |
|----------------|-----------|----------|---------|
| **Charge/Mortgage** | MR01 | 21 days | Any charge created |
| **Charge Satisfaction** | MR04 | 21 days | Charge released |
| **Annual Return** | AR01 | Annually | All companies |
| **Accounts Filing** | Various | 9 months | All companies |

#### Filing Criteria

**Charge Filing Required When**:
- Company creates a charge/mortgage over assets
- Company grants security interest
- Any secured lending arrangement

**Required Information**:
- Company number (borrower)
- Charge creation date
- Charge description
- Secured amount
- Charge holder details

#### Compliance Rules

```yaml
UK_COMPANIES_HOUSE_CHARGE_FILING:
  jurisdiction: "UK"
  authority: "Companies House"
  filing_system: "companies_house_api"
  agreement_types:
    - "facility_agreement"
    - "loan_agreement"
    - "security_agreement"
    - "charge_agreement"
    - "mortgage_agreement"
  triggers:
    - condition: "security_type IN ['charge', 'mortgage', 'security_interest']"
      description: "Any charge or security interest"
    - condition: "governing_law == 'English' OR governing_law == 'UK'"
      description: "UK-governed agreements"
  deadline: "21 days from charge_creation_date"
  penalty: "Up to 5% of worldwide turnover or £10 million (whichever greater), imprisonment up to 5 years"
  required_fields:
    - "borrower_name"
    - "company_number"  # UK company registration number
    - "charge_creation_date"
    - "charge_description"
    - "secured_amount"
    - "charge_holder_name"
  api_available: true
  api_endpoint: "POST /company/{company_number}/charges"
```

#### National Security and Investment Act (NSIA)

**Trigger Conditions**:
- Acquisition of > 25% of UK company
- Acquisition in sensitive sectors (defense, AI, energy, etc.)
- Transaction value > threshold (varies by sector)

**Filing Deadline**: Before transaction completion

**Penalties**: Fines up to 5% of worldwide turnover or £10 million, imprisonment up to 5 years

```yaml
UK_NSIA_FILING_REQUIREMENT:
  jurisdiction: "UK"
  authority: "UK Government (NSIA)"
  filing_system: "manual"
  agreement_types:
    - "facility_agreement"
    - "investment_agreement"
    - "acquisition_agreement"
  triggers:
    - condition: "acquisition_percentage > 25"
      description: "Control threshold"
    - condition: "sector IN ['defense', 'ai', 'energy', 'communications']"
      description: "Sensitive sector"
  deadline: "Before transaction_completion_date"
  penalty: "Fines up to 5% of worldwide turnover or £10 million, imprisonment up to 5 years"
```

---

## France Compliance Rules

### AMF (Autorité des Marchés Financiers) Filing Requirements

#### Agreement Types Requiring Filing

| Agreement Type | Authority | Deadline | Language |
|----------------|-----------|----------|----------|
| **Foreign Investment** | AMF | Before closing | French |
| **Material Credit Agreement** | AMF | 4 business days | French |
| **Securities Disclosure** | AMF | Immediate | French |

#### Filing Criteria

**Foreign Investment Filing Required When**:
- Foreign investor acquiring > 25% of French company
- Investment in strategic sectors (defense, energy, water, etc.)
- Transaction value > threshold

**Required Information** (French language):
- Borrower name and SIREN (French company number)
- Agreement date
- Total commitment amount
- Investment percentage
- Sector classification

#### Compliance Rules

```yaml
FR_AMF_FOREIGN_INVESTMENT_FILING:
  jurisdiction: "FR"
  authority: "AMF"
  filing_system: "manual"
  agreement_types:
    - "facility_agreement"
    - "investment_agreement"
    - "acquisition_agreement"
  triggers:
    - condition: "foreign_investor == true AND ownership_percentage > 25"
      description: "Foreign investment threshold"
    - condition: "sector IN ['defense', 'energy', 'water', 'transport']"
      description: "Strategic sector"
  deadline: "Before transaction_closing_date"
  penalty: "Up to twice investment amount, 10% of target turnover, or €5 million"
  required_fields:
    - "borrower_name"
    - "borrower_siren"  # French company registration number
    - "agreement_date"
    - "total_commitment"
    - "currency"
    - "investment_percentage"
    - "sector_classification"
  language_requirement: "French"
  document_translation_required: true
```

### Commercial Court (Tribunal de Commerce) Filing Requirements

#### Charge Registration

**Filing Required When**:
- Company creates a charge/mortgage (nantissement)
- Security interest over assets
- Any secured lending arrangement

**Deadline**: 15 days from charge creation

**Penalties**: Transaction may be void if not filed

```yaml
FR_COMMERCIAL_COURT_CHARGE_FILING:
  jurisdiction: "FR"
  authority: "Tribunal de Commerce"
  filing_system: "manual"
  agreement_types:
    - "facility_agreement"
    - "security_agreement"
    - "charge_agreement"
    - "nantissement"
  triggers:
    - condition: "security_type IN ['charge', 'nantissement', 'security_interest']"
      description: "Any charge or security interest"
    - condition: "governing_law == 'French' OR jurisdiction == 'FR'"
      description: "French-governed agreements"
  deadline: "15 days from charge_creation_date"
  penalty: "Transaction may be void if not filed"
  required_fields:
    - "borrower_name"
    - "borrower_siren"
    - "charge_creation_date"
    - "charge_description"
    - "secured_amount"
  language_requirement: "French"
  document_translation_required: true
```

---

## Germany Compliance Rules

### BaFin (Bundesanstalt für Finanzdienstleistungsaufsicht) Filing Requirements

#### Agreement Types Requiring Filing

| Agreement Type | Authority | Deadline | Language |
|----------------|-----------|----------|----------|
| **Foreign Investment** | BaFin | Before closing | German |
| **Material Credit Agreement** | BaFin | 4 business days | German |
| **Securities Disclosure** | BaFin | Immediate | German |

#### Filing Criteria

**Foreign Investment Filing Required When**:
- Foreign investor acquiring > 25% of German company
- Investment in sensitive sectors (defense, critical infrastructure, etc.)
- Transaction value > threshold

**Required Information** (German language):
- Borrower name and HRB (German company number)
- Agreement date
- Total commitment amount
- Investment percentage
- Sector classification

#### Compliance Rules

```yaml
DE_BAFIN_FOREIGN_INVESTMENT_FILING:
  jurisdiction: "DE"
  authority: "BaFin"
  filing_system: "manual"
  agreement_types:
    - "facility_agreement"
    - "investment_agreement"
    - "acquisition_agreement"
  triggers:
    - condition: "foreign_investor == true AND ownership_percentage > 25"
      description: "Foreign investment threshold"
    - condition: "sector IN ['defense', 'critical_infrastructure', 'telecommunications']"
      description: "Sensitive sector"
  deadline: "Before transaction_closing_date"
  penalty: "Up to €500,000 or 5 years imprisonment"
  required_fields:
    - "borrower_name"
    - "borrower_hrb"  # German company registration number
    - "agreement_date"
    - "total_commitment"
    - "currency"
    - "investment_percentage"
    - "sector_classification"
  language_requirement: "German"
  document_translation_required: true
```

### Commercial Register (Handelsregister) Filing Requirements

#### Charge Registration

**Filing Required When**:
- Company creates a charge/mortgage (Grundschuld)
- Security interest over assets
- Any secured lending arrangement

**Deadline**: 15 days from charge creation

**Penalties**: Transaction may be void if not filed

```yaml
DE_COMMERCIAL_REGISTER_CHARGE_FILING:
  jurisdiction: "DE"
  authority: "Handelsregister"
  filing_system: "manual"
  agreement_types:
    - "facility_agreement"
    - "security_agreement"
    - "charge_agreement"
    - "grundschuld"
  triggers:
    - condition: "security_type IN ['charge', 'grundschuld', 'security_interest']"
      description: "Any charge or security interest"
    - condition: "governing_law == 'German' OR jurisdiction == 'DE'"
      description: "German-governed agreements"
  deadline: "15 days from charge_creation_date"
  penalty: "Transaction may be void if not filed"
  required_fields:
    - "borrower_name"
    - "borrower_hrb"
    - "charge_creation_date"
    - "charge_description"
    - "secured_amount"
  language_requirement: "German"
  document_translation_required: true
```

---

## Agreement Type Classification Matrix

### Agreement Types and Filing Requirements

| Agreement Type | US (SEC) | UK (Companies House) | FR (AMF/Court) | DE (BaFin/Register) |
|----------------|----------|----------------------|----------------|---------------------|
| **Facility Agreement** | ✅ 8-K (if material) | ✅ MR01 (if charge) | ✅ AMF (if foreign) | ✅ BaFin (if foreign) |
| **Loan Agreement** | ✅ 8-K (if material) | ✅ MR01 (if charge) | ✅ AMF (if foreign) | ✅ BaFin (if foreign) |
| **Credit Agreement** | ✅ 8-K (if material) | ✅ MR01 (if charge) | ✅ AMF (if foreign) | ✅ BaFin (if foreign) |
| **Security Agreement** | ✅ 8-K (if material) | ✅ MR01 (charge) | ✅ Court (charge) | ✅ Register (charge) |
| **Charge Agreement** | ❌ N/A | ✅ MR01 (charge) | ✅ Court (charge) | ✅ Register (charge) |
| **Mortgage Agreement** | ❌ N/A | ✅ MR01 (charge) | ✅ Court (charge) | ✅ Register (charge) |
| **Guarantee Agreement** | ✅ 8-K (if material) | ❌ N/A | ❌ N/A | ❌ N/A |
| **Intercreditor Agreement** | ✅ 8-K (if material) | ❌ N/A | ❌ N/A | ❌ N/A |
| **Investment Agreement** | ✅ CFIUS (if foreign) | ✅ NSIA (if foreign) | ✅ AMF (if foreign) | ✅ BaFin (if foreign) |
| **Disclosure Document** | ✅ 10-Q/10-K | ❌ N/A | ✅ AMF | ✅ BaFin |

### Filing Priority by Agreement Type

**High Priority** (Must File):
- Security Agreement (UK, FR, DE) - Charge registration
- Charge Agreement (UK, FR, DE) - Charge registration
- Foreign Investment (All) - National security review

**Medium Priority** (File if Material):
- Facility Agreement (US) - SEC 8-K
- Loan Agreement (US) - SEC 8-K
- Credit Agreement (US) - SEC 8-K

**Low Priority** (Optional/Periodic):
- Quarterly Disclosures (US) - SEC 10-Q
- Annual Disclosures (US) - SEC 10-K

---

## Compliance Policy Rules

### Policy Rule Structure

Each compliance rule follows this structure:

```yaml
RULE_NAME:
  jurisdiction: "XX"  # US, UK, FR, DE
  authority: "Authority Name"
  filing_system: "system_name"  # edgar, companies_house_api, manual
  agreement_types: ["type1", "type2"]
  triggers:
    - condition: "field operator value"
      description: "Human-readable description"
  deadline: "X days from event_date"
  penalty: "Penalty description"
  required_fields: ["field1", "field2"]
  language_requirement: "Language"  # Optional
  document_translation_required: true/false  # Optional
  api_available: true/false
  api_endpoint: "POST /endpoint"  # If API available
```

### Policy Evaluation Logic

```python
def evaluate_filing_requirement(
    agreement: CreditAgreement,
    jurisdiction: str,
    agreement_type: str
) -> List[FilingRequirement]:
    """
    Evaluate which filing requirements apply to an agreement.
    
    Returns:
        List of FilingRequirement objects with:
        - authority
        - filing_system
        - deadline
        - required_fields
        - api_available
    """
    requirements = []
    
    # Load compliance rules for jurisdiction
    rules = load_compliance_rules(jurisdiction)
    
    # Check each rule
    for rule in rules:
        if agreement_type in rule.agreement_types:
            # Evaluate trigger conditions
            if evaluate_triggers(rule.triggers, agreement):
                requirements.append(FilingRequirement(
                    authority=rule.authority,
                    filing_system=rule.filing_system,
                    deadline=calculate_deadline(rule.deadline, agreement),
                    required_fields=rule.required_fields,
                    api_available=rule.api_available,
                    api_endpoint=rule.api_endpoint if rule.api_available else None
                ))
    
    return requirements
```

---

## Next Steps

1. ✅ **Compliance Rules Documented** - This document
2. ⏳ **Policy Engine Extensions** - Implement rules in policy engine
3. ⏳ **Filing Service Implementation** - Automated filing workflows
4. ⏳ **Deadline Tracking** - Automated deadline monitoring
5. ⏳ **Translation Service** - Multi-language document generation

---

**Document Status**: ✅ Complete  
**Ready for**: Policy Engine Implementation
