# Verifier Design Patterns for Filing & Signature Verification

## Executive Summary

This document defines the verifier design patterns for CreditNexus, following the existing verifier architecture (as seen in `app/agents/verifier.py`). It outlines how to implement verifiers for filing compliance, signature validation, and deadline tracking.

**Last Updated**: 2024-12-XX  
**Status**: Design Complete - Ready for Implementation

---

## Table of Contents

1. [Existing Verifier Pattern](#existing-verifier-pattern)
2. [Filing Compliance Verifier](#filing-compliance-verifier)
3. [Signature Verification Verifier](#signature-verification-verifier)
4. [Deadline Tracking Verifier](#deadline-tracking-verifier)
5. [Verifier Integration Patterns](#verifier-integration-patterns)

---

## Existing Verifier Pattern

### Current Verifier Architecture

The existing `app/agents/verifier.py` follows this pattern:

```python
# app/agents/verifier.py

async def verify_asset_location(
    lat: float,
    lon: float,
    threshold: float = 0.8,
    include_enhanced: bool = True
) -> dict:
    """
    Complete verification workflow for an asset location.
    
    Returns:
        Dictionary with verification results:
        {
            "success": bool,
            "ndvi_score": float,
            "risk_status": str,
            "verified_at": str,
            "data_source": str
        }
    """
    # 1. Fetch data (satellite, OSM, etc.)
    # 2. Calculate metrics (NDVI, risk status)
    # 3. Return structured result
    pass
```

### Verifier Pattern Principles

1. **Async Functions**: All verifiers are async functions
2. **Structured Returns**: Return dictionaries with consistent structure
3. **Error Handling**: Graceful error handling with fallbacks
4. **Logging**: Comprehensive logging for audit trails
5. **Configuration**: Use settings for configuration
6. **CDM Compliance**: Generate CDM events for verification results

---

## Filing Compliance Verifier

### Purpose

Verify that a document/agreement meets filing requirements before submission.

### Implementation

```python
# app/agents/filing_verifier.py

import logging
from typing import Dict, Any, Optional, List
from datetime import datetime
from sqlalchemy.orm import Session

from app.models.cdm import CreditAgreement
from app.services.policy_service import PolicyService
from app.db.models import Document, DocumentFiling

logger = logging.getLogger(__name__)


async def verify_filing_compliance(
    document_id: int,
    db: Session,
    policy_service: Optional[PolicyService] = None
) -> Dict[str, Any]:
    """
    Verify that a document meets all filing compliance requirements.
    
    Args:
        document_id: Document ID to verify
        db: Database session
        policy_service: Optional PolicyService instance
        
    Returns:
        Dictionary with verification results:
        {
            "success": bool,
            "compliance_status": str,  # "compliant", "non_compliant", "pending"
            "required_filings": List[Dict],
            "missing_fields": List[str],
            "deadline_alerts": List[Dict],
            "verified_at": str,
            "warnings": List[str],
            "errors": List[str]
        }
    """
    logger.info(f"Starting filing compliance verification for document {document_id}")
    
    try:
        # 1. Load document and CDM data
        document = db.query(Document).filter(Document.id == document_id).first()
        if not document:
            return {
                "success": False,
                "compliance_status": "error",
                "errors": [f"Document {document_id} not found"],
                "verified_at": datetime.utcnow().isoformat()
            }
        
        # Load CDM data from document version
        cdm_data = None
        if document.current_version_id:
            version = db.query(DocumentVersion).filter(
                DocumentVersion.id == document.current_version_id
            ).first()
            if version and version.cdm_data:
                from app.models.cdm import CreditAgreement
                cdm_data = CreditAgreement.model_validate(version.cdm_data)
        
        if not cdm_data:
            return {
                "success": False,
                "compliance_status": "error",
                "errors": ["CDM data not found for document"],
                "verified_at": datetime.utcnow().isoformat()
            }
        
        # 2. Initialize policy service if not provided
        if not policy_service:
            from app.services.policy_engine_factory import get_policy_engine
            from app.services.policy_service import PolicyService
            policy_engine = get_policy_engine()
            policy_service = PolicyService(policy_engine)
        
        # 3. Evaluate filing requirements
        filing_decision = policy_service.evaluate_filing_requirements(
            credit_agreement=cdm_data,
            document_id=document_id,
            deal_id=document.deal_id
        )
        
        # 4. Check existing filings
        existing_filings = db.query(DocumentFiling).filter(
            DocumentFiling.document_id == document_id
        ).all()
        
        # 5. Compare required vs. existing filings
        filing_status = _compare_filings(
            required=filing_decision.required_filings,
            existing=existing_filings
        )
        
        # 6. Determine compliance status
        compliance_status = _determine_compliance_status(
            filing_decision=filing_decision,
            filing_status=filing_status
        )
        
        # 7. Generate warnings
        warnings = []
        if filing_decision.missing_fields:
            warnings.append(f"Missing required fields: {', '.join(filing_decision.missing_fields)}")
        
        if filing_decision.deadline_alerts:
            critical_alerts = [a for a in filing_decision.deadline_alerts if a.urgency == "critical"]
            if critical_alerts:
                warnings.append(f"{len(critical_alerts)} critical deadline(s) approaching")
        
        # 8. Return verification result
        result = {
            "success": True,
            "compliance_status": compliance_status,
            "required_filings": [
                {
                    "authority": req.authority,
                    "filing_system": req.filing_system,
                    "deadline": req.deadline.isoformat(),
                    "api_available": req.api_available,
                    "status": filing_status.get(req.authority, "pending")
                }
                for req in filing_decision.required_filings
            ],
            "missing_fields": filing_decision.missing_fields,
            "deadline_alerts": [
                {
                    "authority": alert.authority,
                    "deadline": alert.deadline.isoformat(),
                    "days_remaining": alert.days_remaining,
                    "urgency": alert.urgency
                }
                for alert in filing_decision.deadline_alerts
            ],
            "verified_at": datetime.utcnow().isoformat(),
            "warnings": warnings,
            "errors": []
        }
        
        logger.info(f"Filing compliance verification complete for document {document_id}: {compliance_status}")
        return result
        
    except Exception as e:
        logger.error(f"Error verifying filing compliance for document {document_id}: {e}", exc_info=True)
        return {
            "success": False,
            "compliance_status": "error",
            "errors": [str(e)],
            "verified_at": datetime.utcnow().isoformat()
        }


def _compare_filings(
    required: List[Any],
    existing: List[DocumentFiling]
) -> Dict[str, str]:
    """Compare required filings with existing filings."""
    status = {}
    
    for req in required:
        # Find matching existing filing
        matching = None
        for existing_filing in existing:
            if (existing_filing.filing_authority == req.authority and
                existing_filing.agreement_type == req.agreement_type):
                matching = existing_filing
                break
        
        if matching:
            status[req.authority] = matching.filing_status
        else:
            status[req.authority] = "pending"
    
    return status


def _determine_compliance_status(
    filing_decision: Any,
    filing_status: Dict[str, str]
) -> str:
    """Determine overall compliance status."""
    # Check if all required filings are submitted/accepted
    all_filed = all(
        status in ["submitted", "accepted"]
        for status in filing_status.values()
    )
    
    if all_filed:
        return "compliant"
    elif any(status == "rejected" for status in filing_status.values()):
        return "non_compliant"
    elif filing_decision.missing_fields:
        return "non_compliant"
    else:
        return "pending"
```

---

## Signature Verification Verifier

### Purpose

Verify that a document has been properly signed by all required parties.

### Implementation

```python
# app/agents/signature_verifier.py

import logging
from typing import Dict, Any, Optional, List
from datetime import datetime
from sqlalchemy.orm import Session

from app.db.models import Document, DocumentSignature

logger = logging.getLogger(__name__)


async def verify_signature_status(
    document_id: int,
    db: Session,
    required_signers: Optional[List[Dict[str, str]]] = None
) -> Dict[str, Any]:
    """
    Verify that a document has been signed by all required parties.
    
    Args:
        document_id: Document ID to verify
        db: Database session
        required_signers: Optional list of required signers
            [{"name": "...", "email": "...", "role": "..."}]
        
    Returns:
        Dictionary with verification results:
        {
            "success": bool,
            "signature_status": str,  # "complete", "pending", "incomplete", "expired"
            "required_signers": List[Dict],
            "signed_by": List[Dict],
            "missing_signatures": List[Dict],
            "verified_at": str,
            "warnings": List[str],
            "errors": List[str]
        }
    """
    logger.info(f"Starting signature verification for document {document_id}")
    
    try:
        # 1. Load document
        document = db.query(Document).filter(Document.id == document_id).first()
        if not document:
            return {
                "success": False,
                "signature_status": "error",
                "errors": [f"Document {document_id} not found"],
                "verified_at": datetime.utcnow().isoformat()
            }
        
        # 2. Load signature records
        signatures = db.query(DocumentSignature).filter(
            DocumentSignature.document_id == document_id
        ).all()
        
        # 3. Determine required signers if not provided
        if not required_signers:
            required_signers = _determine_required_signers(document)
        
        # 4. Check signature status for each required signer
        signed_by = []
        missing_signatures = []
        
        for signer in required_signers:
            # Find signature for this signer
            matching_signature = None
            for sig in signatures:
                signers_data = sig.signers or []
                for signed_signer in signers_data:
                    if (signed_signer.get("email") == signer.get("email") or
                        signed_signer.get("name") == signer.get("name")):
                        matching_signature = sig
                        break
                if matching_signature:
                    break
            
            if matching_signature and matching_signature.signature_status == "completed":
                signed_by.append({
                    "name": signer.get("name"),
                    "email": signer.get("email"),
                    "role": signer.get("role"),
                    "signed_at": matching_signature.completed_at.isoformat() if matching_signature.completed_at else None
                })
            else:
                missing_signatures.append(signer)
        
        # 5. Determine overall signature status
        signature_status = _determine_signature_status(
            signatures=signatures,
            required_signers=required_signers,
            signed_by=signed_by,
            missing_signatures=missing_signatures
        )
        
        # 6. Generate warnings
        warnings = []
        if missing_signatures:
            warnings.append(f"{len(missing_signatures)} signature(s) still pending")
        
        expired_signatures = [
            sig for sig in signatures
            if sig.expires_at and sig.expires_at < datetime.utcnow() and sig.signature_status == "pending"
        ]
        if expired_signatures:
            warnings.append(f"{len(expired_signatures)} signature request(s) expired")
        
        # 7. Return verification result
        result = {
            "success": True,
            "signature_status": signature_status,
            "required_signers": required_signers,
            "signed_by": signed_by,
            "missing_signatures": missing_signatures,
            "verified_at": datetime.utcnow().isoformat(),
            "warnings": warnings,
            "errors": []
        }
        
        logger.info(f"Signature verification complete for document {document_id}: {signature_status}")
        return result
        
    except Exception as e:
        logger.error(f"Error verifying signatures for document {document_id}: {e}", exc_info=True)
        return {
            "success": False,
            "signature_status": "error",
            "errors": [str(e)],
            "verified_at": datetime.utcnow().isoformat()
        }


def _determine_required_signers(document: Document) -> List[Dict[str, str]]:
    """Determine required signers from document CDM data."""
    # Extract signers from CDM data
    # This would parse the CreditAgreement to find parties with signing roles
    # For now, return empty list (to be implemented based on CDM structure)
    return []


def _determine_signature_status(
    signatures: List[DocumentSignature],
    required_signers: List[Dict[str, str]],
    signed_by: List[Dict[str, Any]],
    missing_signatures: List[Dict[str, str]]
) -> str:
    """Determine overall signature status."""
    if not required_signers:
        return "not_required"
    
    if len(signed_by) == len(required_signers):
        return "complete"
    elif len(signed_by) > 0:
        return "incomplete"
    else:
        # Check if any signatures are expired
        expired = any(
            sig.expires_at and sig.expires_at < datetime.utcnow()
            for sig in signatures
            if sig.signature_status == "pending"
        )
        return "expired" if expired else "pending"
```

---

## Deadline Tracking Verifier

### Purpose

Verify and alert on approaching filing deadlines.

### Implementation

```python
# app/agents/deadline_verifier.py

import logging
from typing import Dict, Any, List
from datetime import datetime, timedelta
from sqlalchemy.orm import Session

from app.services.policy_service import PolicyService
from app.db.models import DocumentFiling, Document, Deal

logger = logging.getLogger(__name__)


async def verify_filing_deadlines(
    db: Session,
    deal_id: Optional[int] = None,
    days_ahead: int = 7,
    policy_service: Optional[PolicyService] = None
) -> Dict[str, Any]:
    """
    Verify and alert on approaching filing deadlines.
    
    Args:
        db: Database session
        deal_id: Optional deal ID to check (None = all deals)
        days_ahead: Number of days ahead to check (default: 7)
        policy_service: Optional PolicyService instance
        
    Returns:
        Dictionary with verification results:
        {
            "success": bool,
            "alerts": List[Dict],
            "critical_count": int,
            "high_count": int,
            "medium_count": int,
            "verified_at": str,
            "warnings": List[str],
            "errors": List[str]
        }
    """
    logger.info(f"Starting deadline verification (days_ahead={days_ahead}, deal_id={deal_id})")
    
    try:
        # 1. Initialize policy service if not provided
        if not policy_service:
            from app.services.policy_engine_factory import get_policy_engine
            from app.services.policy_service import PolicyService
            policy_engine = get_policy_engine()
            policy_service = PolicyService(policy_engine)
        
        # 2. Get deadline alerts from policy service
        deadline_alerts = policy_service.check_filing_deadlines(
            deal_id=deal_id,
            days_ahead=days_ahead
        )
        
        # 3. Format alerts
        alerts = [
            {
                "filing_id": alert.filing_id,
                "document_id": alert.document_id,
                "deal_id": alert.deal_id,
                "authority": alert.authority,
                "deadline": alert.deadline.isoformat(),
                "days_remaining": alert.days_remaining,
                "urgency": alert.urgency,
                "penalty": alert.penalty
            }
            for alert in deadline_alerts
        ]
        
        # 4. Count by urgency
        critical_count = len([a for a in alerts if a["urgency"] == "critical"])
        high_count = len([a for a in alerts if a["urgency"] == "high"])
        medium_count = len([a for a in alerts if a["urgency"] == "medium"])
        
        # 5. Generate warnings
        warnings = []
        if critical_count > 0:
            warnings.append(f"{critical_count} critical deadline(s) require immediate action")
        if high_count > 0:
            warnings.append(f"{high_count} high-priority deadline(s) approaching")
        
        # 6. Return verification result
        result = {
            "success": True,
            "alerts": alerts,
            "critical_count": critical_count,
            "high_count": high_count,
            "medium_count": medium_count,
            "verified_at": datetime.utcnow().isoformat(),
            "warnings": warnings,
            "errors": []
        }
        
        logger.info(f"Deadline verification complete: {len(alerts)} alert(s) found")
        return result
        
    except Exception as e:
        logger.error(f"Error verifying deadlines: {e}", exc_info=True)
        return {
            "success": False,
            "alerts": [],
            "critical_count": 0,
            "high_count": 0,
            "medium_count": 0,
            "errors": [str(e)],
            "verified_at": datetime.utcnow().isoformat()
        }
```

---

## Verifier Integration Patterns

### 1. Background Task Integration

```python
# app/services/background_tasks.py

from app.agents import filing_verifier, signature_verifier, deadline_verifier

@background_task.scheduled(cron="0 9 * * *")  # Daily at 9 AM
async def daily_filing_compliance_check():
    """Daily check of filing compliance for all active documents."""
    db = next(get_db())
    
    # Get all approved documents
    documents = db.query(Document).join(Workflow).filter(
        Workflow.state == WorkflowState.APPROVED.value
    ).all()
    
    for document in documents:
        result = await filing_verifier.verify_filing_compliance(
            document_id=document.id,
            db=db
        )
        
        # Log results
        if result["compliance_status"] == "non_compliant":
            logger.warning(f"Document {document.id} is non-compliant: {result['warnings']}")

@background_task.scheduled(cron="0 * * * *")  # Every hour
async def hourly_deadline_check():
    """Hourly check of approaching filing deadlines."""
    db = next(get_db())
    
    result = await deadline_verifier.verify_filing_deadlines(
        db=db,
        days_ahead=7
    )
    
    # Send alerts for critical deadlines
    for alert in result["alerts"]:
        if alert["urgency"] == "critical":
            send_deadline_alert(alert)
```

### 2. API Endpoint Integration

```python
# app/api/routes.py

@router.get("/documents/{document_id}/verify/filing")
async def verify_document_filing(
    document_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_auth)
):
    """Verify filing compliance for a document."""
    from app.agents import filing_verifier
    
    result = await filing_verifier.verify_filing_compliance(
        document_id=document_id,
        db=db
    )
    
    return result

@router.get("/documents/{document_id}/verify/signature")
async def verify_document_signature(
    document_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_auth)
):
    """Verify signature status for a document."""
    from app.agents import signature_verifier
    
    result = await signature_verifier.verify_signature_status(
        document_id=document_id,
        db=db
    )
    
    return result

@router.get("/deals/{deal_id}/verify/deadlines")
async def verify_deal_deadlines(
    deal_id: int,
    days_ahead: int = Query(7, ge=1, le=30),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_auth)
):
    """Verify filing deadlines for a deal."""
    from app.agents import deadline_verifier
    
    result = await deadline_verifier.verify_filing_deadlines(
        db=db,
        deal_id=deal_id,
        days_ahead=days_ahead
    )
    
    return result
```

### 3. Workflow Integration

```python
# app/api/routes.py

@router.post("/documents/{document_id}/workflow/approve")
async def approve_document(...):
    # ... existing approval logic ...
    
    # After approval, verify filing compliance
    from app.agents import filing_verifier
    
    filing_result = await filing_verifier.verify_filing_compliance(
        document_id=document_id,
        db=db
    )
    
    # If non-compliant, flag for review
    if filing_result["compliance_status"] == "non_compliant":
        workflow.priority = "high"
        workflow.notes = f"Filing compliance issues: {', '.join(filing_result['warnings'])}"
    
    # ... rest of approval logic ...
```

---

## Next Steps

1. ✅ **Verifier Patterns Designed** - This document
2. ⏳ **Verifier Implementation** - Implement verifier functions
3. ⏳ **Background Tasks** - Schedule automated checks
4. ⏳ **API Integration** - Add verification endpoints
5. ⏳ **Testing** - Unit and integration tests

---

**Document Status**: ✅ Complete  
**Ready for**: Implementation
