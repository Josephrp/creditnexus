# CreditNexus Remote Verification & Notarization Implementation Plan

## Executive Summary

This document outlines a comprehensive plan to extend CreditNexus with:
1. **SSL-enabled remote API listener** with IP whitelisting and profile-based access control
2. **Link-based verification workflow** for cross-machine deal verification
3. **Messenger integration** for sharing verification links
4. **MetaMask notarization** for blockchain-based transaction signing

**Priority**: High  
**Estimated Timeline**: 8-10 weeks  
**Complexity**: High

---

## Current State Assessment

### Existing Infrastructure

#### ✅ What We Have
1. **Deal Lifecycle Management**
   - `Deal` model with status transitions (DRAFT → SUBMITTED → UNDER_REVIEW → APPROVED → ACTIVE → CLOSED)
   - `DealService` for deal creation and state management
   - CDM event generation for deal state changes
   - Application-to-Deal conversion workflow

2. **Workflow System**
   - `Workflow` model for document approval workflows
   - Workflow states: DRAFT → UNDER_REVIEW → APPROVED → PUBLISHED
   - Role-based permissions (AUDITOR, BANKER, LAW_OFFICER, ACCOUNTANT, APPLICANT)
   - Audit logging for all state transitions

3. **Authentication & Authorization**
   - JWT-based authentication (`app/auth/jwt_auth.py`)
   - Wallet address support in `User` model (`wallet_address` field)
   - Basic wallet authentication endpoint (`/api/auth/wallet`)
   - Role-based access control via `require_role` decorator

4. **FDC3 Integration**
   - OpenFin and Finsemble configurations for desktop interoperability
   - FDC3 context broadcasting for state changes
   - Intent-based actions for workflow orchestration

5. **CDM Compliance**
   - CDM event generation (`app/models/cdm_events.py`)
   - Policy evaluation with CDM events
   - CDM-compliant state machine patterns

#### ❌ What's Missing
1. **Remote API Listener**
   - No separate SSL-enabled port listener
   - No IP whitelisting mechanism
   - No profile-based access control for remote apps
   - No separate remote app configuration

2. **Verification Workflow**
   - No cross-machine verification flow
   - No link-based verification system
   - No verification role assignment mechanism
   - No verification accept/decline endpoints

3. **Link Sharing**
   - No messenger integration
   - No shareable verification links
   - No link expiration/security mechanism

4. **MetaMask Notarization**
   - No cryptographic signature verification (placeholder only)
   - No transaction notarization system
   - No blockchain-based signing for completed deals
   - No integration with MetaMask or Web3 libraries

---

## Architecture Design

### 1. Remote API Listener Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    CreditNexus Main API                      │
│                  (Port 8000, HTTP/HTTPS)                    │
│                                                              │
│  - Standard API endpoints                                   │
│  - Frontend serving                                          │
│  - Internal authentication                                  │
└─────────────────────────────────────────────────────────────┘
                            │
                            │
┌─────────────────────────────────────────────────────────────┐
│              Remote Verification API Listener                │
│              (Port 8443, HTTPS only, SSL/TLS)               │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  IP Whitelist Middleware                             │  │
│  │  - Validates client IP against whitelist             │  │
│  │  - Profile-based access control                      │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  Profile-Based Authentication                        │  │
│  │  - API key authentication                           │  │
│  │  - Profile permissions (read, verify, sign)          │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
│  Endpoints:                                                  │
│  - GET  /remote/verification/{verification_id}              │
│  - POST /remote/verification/{verification_id}/accept      │
│  - POST /remote/verification/{verification_id}/decline      │
│  - POST /remote/notarization/{deal_id}/sign                 │
└─────────────────────────────────────────────────────────────┘
```

### 2. Verification Workflow Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Deal Creation Flow                        │
│                                                              │
│  1. Application → Deal (via DealService)                    │
│  2. Deal status: DRAFT → SUBMITTED                          │
│  3. System creates VerificationRequest                     │
│  4. Verification link generated                            │
│  5. Link shared via messenger                               │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              Verification Request Model                      │
│                                                              │
│  - verification_id (UUID)                                   │
│  - deal_id (FK)                                             │
│  - verifier_user_id (FK, nullable)                         │
│  - verification_link (unique token)                          │
│  - status (pending, accepted, declined, expired)            │
│  - expires_at (datetime)                                    │
│  - created_at, updated_at                                   │
│  - verification_metadata (JSONB)                            │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              Remote Verification Flow                        │
│                                                              │
│  1. Verifier receives link via messenger                    │
│  2. Opens link in browser (different machine)               │
│  3. Link validates token & expiration                       │
│  4. Shows deal details & CDM payload                        │
│  5. Verifier accepts/declines                                │
│  6. System updates deal status                              │
│  7. CDM event generated (VerificationResult)                │
└─────────────────────────────────────────────────────────────┘
```

### 3. MetaMask Notarization Architecture

```
┌─────────────────────────────────────────────────────────────┐
│              Completed Deal (Status: ACTIVE)                │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│         Notarization Request Creation                       │
│                                                              │
│  - deal_id                                                  │
│  - notarization_hash (hash of CDM payload)                 │
│  - required_signers (list of wallet addresses)              │
│  - status (pending, signed, completed)                     │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│         MetaMask Signing Flow                                │
│                                                              │
│  1. User clicks "Notarize Deal"                             │
│  2. Frontend requests nonce from backend                    │
│  3. Backend generates message to sign                       │
│  4. Frontend prompts MetaMask signature                     │
│  5. User signs with MetaMask                                │
│  6. Frontend sends signature to backend                     │
│  7. Backend verifies signature cryptographically            │
│  8. Backend stores signature in NotarizationRecord          │
│  9. CDM event generated (NotarizationEvent)                 │
└─────────────────────────────────────────────────────────────┘
```

---

## Database Schema Changes

### New Tables

#### 1. `remote_app_profiles`
```sql
CREATE TABLE remote_app_profiles (
    id SERIAL PRIMARY KEY,
    profile_name VARCHAR(100) UNIQUE NOT NULL,
    api_key_hash VARCHAR(255) NOT NULL,  -- bcrypt hash
    allowed_ips JSONB,  -- Array of IP addresses/CIDR blocks
    permissions JSONB,  -- {"read": true, "verify": true, "sign": false}
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

#### 2. `verification_requests`
```sql
CREATE TABLE verification_requests (
    id SERIAL PRIMARY KEY,
    verification_id UUID UNIQUE NOT NULL DEFAULT gen_random_uuid(),
    deal_id INTEGER REFERENCES deals(id) ON DELETE CASCADE,
    verifier_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    verification_link_token VARCHAR(255) UNIQUE NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',  -- pending, accepted, declined, expired
    expires_at TIMESTAMP NOT NULL,
    accepted_at TIMESTAMP,
    declined_at TIMESTAMP,
    declined_reason TEXT,
    verification_metadata JSONB,
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_verification_link_token ON verification_requests(verification_link_token);
CREATE INDEX idx_verification_deal_id ON verification_requests(deal_id);
CREATE INDEX idx_verification_status ON verification_requests(status);
```

#### 3. `notarization_records`
```sql
CREATE TABLE notarization_records (
    id SERIAL PRIMARY KEY,
    deal_id INTEGER REFERENCES deals(id) ON DELETE CASCADE,
    notarization_hash VARCHAR(255) NOT NULL,  -- Hash of CDM payload
    required_signers JSONB NOT NULL,  -- Array of wallet addresses
    signatures JSONB,  -- Array of {"wallet_address": "...", "signature": "...", "signed_at": "..."}
    status VARCHAR(20) DEFAULT 'pending',  -- pending, signed, completed
    completed_at TIMESTAMP,
    cdm_event_id VARCHAR(255),  -- Reference to CDM event
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_notarization_deal_id ON notarization_records(deal_id);
CREATE INDEX idx_notarization_status ON notarization_records(status);
```

#### 4. `verification_audit_log`
```sql
CREATE TABLE verification_audit_log (
    id SERIAL PRIMARY KEY,
    verification_id INTEGER REFERENCES verification_requests(id) ON DELETE CASCADE,
    action VARCHAR(50) NOT NULL,  -- created, viewed, accepted, declined
    actor_user_id INTEGER REFERENCES users(id),
    actor_ip_address VARCHAR(45),
    metadata JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_verification_audit_verification_id ON verification_audit_log(verification_id);
```

### Modified Tables

#### `deals` table additions
```sql
ALTER TABLE deals ADD COLUMN verification_required BOOLEAN DEFAULT FALSE;
ALTER TABLE deals ADD COLUMN verification_completed_at TIMESTAMP;
ALTER TABLE deals ADD COLUMN notarization_required BOOLEAN DEFAULT FALSE;
ALTER TABLE deals ADD COLUMN notarization_completed_at TIMESTAMP;
```

---

## Implementation Plan

### Phase 1: Remote API Listener Infrastructure (Weeks 1-2)

#### Task 1.1: SSL Configuration & Certificate Management
**Priority**: P0 (Critical)  
**Estimated Time**: 3 days

**Tasks:**
1. Add SSL configuration to `app/core/config.py`:
   ```python
   # Remote API Configuration
   REMOTE_API_ENABLED: bool = False
   REMOTE_API_PORT: int = 8443
   REMOTE_API_SSL_CERT_PATH: Optional[Path] = None
   REMOTE_API_SSL_KEY_PATH: Optional[Path] = None
   REMOTE_API_SSL_CERT_CHAIN_PATH: Optional[Path] = None
   ```

2. Create SSL certificate loader utility:
   ```python
   # app/utils/ssl_config.py
   def load_ssl_context(cert_path: Path, key_path: Path, chain_path: Optional[Path] = None) -> ssl.SSLContext
   ```

3. Add certificate validation and error handling

**Files to Create:**
- `app/utils/ssl_config.py`
- `app/core/remote_config.py`

**Files to Modify:**
- `app/core/config.py`
- `server.py`

#### Task 1.2: IP Whitelisting Middleware
**Priority**: P0 (Critical)  
**Estimated Time**: 2 days

**Tasks:**
1. Create IP whitelist middleware:
   ```python
   # app/middleware/ip_whitelist.py
   class IPWhitelistMiddleware:
       def __init__(self, allowed_ips: List[str], allowed_cidrs: List[str])
       async def __call__(self, request: Request, call_next)
   ```

2. Support both individual IPs and CIDR blocks
3. Add IP extraction from X-Forwarded-For header (for proxies)
4. Add logging for blocked IPs

**Files to Create:**
- `app/middleware/ip_whitelist.py`

#### Task 1.3: Profile-Based Access Control
**Priority**: P0 (Critical)  
**Estimated Time**: 3 days

**Tasks:**
1. Create `RemoteAppProfile` model in `app/db/models.py`
2. Create Alembic migration for `remote_app_profiles` table
3. Create profile service:
   ```python
   # app/services/remote_profile_service.py
   class RemoteProfileService:
       def validate_api_key(self, api_key: str) -> Optional[RemoteAppProfile]
       def check_permission(self, profile: RemoteAppProfile, permission: str) -> bool
       def validate_ip(self, profile: RemoteAppProfile, client_ip: str) -> bool
   ```

4. Create API key authentication dependency:
   ```python
   # app/auth/remote_auth.py
   async def get_remote_profile(
       api_key: str = Header(..., alias="X-API-Key"),
       request: Request,
       db: Session = Depends(get_db)
   ) -> RemoteAppProfile
   ```

**Files to Create:**
- `app/services/remote_profile_service.py`
- `app/auth/remote_auth.py`

**Files to Modify:**
- `app/db/models.py`
- Create Alembic migration

#### Task 1.4: Remote API Router Setup
**Priority**: P0 (Critical)  
**Estimated Time**: 2 days

**Tasks:**
1. Create separate FastAPI app for remote API:
   ```python
   # app/api/remote_routes.py
   remote_router = APIRouter(prefix="/remote", tags=["remote"])
   ```

2. Create remote API server in `server.py`:
   ```python
   # Separate uvicorn server for remote API
   if settings.REMOTE_API_ENABLED:
       remote_app = FastAPI(...)
       # Configure SSL, middleware, routes
   ```

3. Add startup script to run both servers

**Files to Create:**
- `app/api/remote_routes.py`
- `scripts/start_remote_api.py`

**Files to Modify:**
- `server.py`

---

### Phase 2: Verification Workflow (Weeks 3-4)

#### Task 2.1: Verification Request Model & Service
**Priority**: P0 (Critical)  
**Estimated Time**: 3 days

**Tasks:**
1. Create `VerificationRequest` model in `app/db/models.py`
2. Create Alembic migration
3. Create verification service:
   ```python
   # app/services/verification_service.py
   class VerificationService:
       def create_verification_request(
           self, deal_id: int, verifier_user_id: Optional[int] = None,
           expires_in_hours: int = 72
       ) -> VerificationRequest
       
       def generate_verification_link(self, verification: VerificationRequest) -> str
       
       def validate_verification_link(self, token: str) -> Optional[VerificationRequest]
       
       def accept_verification(
           self, verification_id: int, verifier_user_id: int, metadata: Optional[Dict] = None
       ) -> VerificationRequest
       
       def decline_verification(
           self, verification_id: int, verifier_user_id: int, reason: str
       ) -> VerificationRequest
   ```

4. Integrate with `DealService` to auto-create verification requests

**Files to Create:**
- `app/services/verification_service.py`

**Files to Modify:**
- `app/db/models.py`
- `app/services/deal_service.py`
- Create Alembic migration

#### Task 2.2: Verification API Endpoints
**Priority**: P0 (Critical)  
**Estimated Time**: 2 days

**Tasks:**
1. Create verification endpoints in `app/api/remote_routes.py`:
   ```python
   @remote_router.get("/verification/{verification_id}")
   async def get_verification_details(...)
   
   @remote_router.post("/verification/{verification_id}/accept")
   async def accept_verification(...)
   
   @remote_router.post("/verification/{verification_id}/decline")
   async def decline_verification(...)
   ```

2. Add CDM event generation for verification results
3. Update deal status on verification completion

**Files to Modify:**
- `app/api/remote_routes.py`
- `app/models/cdm_events.py` (add `generate_cdm_verification_result`)

#### Task 2.3: Link Generation & Security
**Priority**: P0 (Critical)  
**Estimated Time**: 2 days

**Tasks:**
1. Create secure token generation:
   ```python
   # app/utils/verification_tokens.py
   def generate_verification_token() -> str  # UUID + timestamp + HMAC
   def validate_verification_token(token: str) -> bool
   ```

2. Add token expiration handling
3. Add rate limiting for link access
4. Add audit logging for link access

**Files to Create:**
- `app/utils/verification_tokens.py`

**Files to Modify:**
- `app/services/verification_service.py`

#### Task 2.4: Frontend Verification Interface
**Priority**: P1 (High)  
**Estimated Time**: 3 days

**Tasks:**
1. Create verification page component:
   ```typescript
   // client/src/apps/verification/VerificationPage.tsx
   export function VerificationPage({ token }: { token: string })
   ```

2. Display deal details and CDM payload
3. Accept/Decline buttons with confirmation
4. Handle expired links gracefully

**Files to Create:**
- `client/src/apps/verification/VerificationPage.tsx`
- `client/src/apps/verification/VerificationDetails.tsx`

**Files to Modify:**
- `client/src/router/Routes.tsx` (add verification route)

---

### Phase 3: Messenger Integration (Week 5)

#### Task 3.1: Messenger Abstraction Layer
**Priority**: P1 (High)  
**Estimated Time**: 2 days

**Tasks:**
1. Create messenger interface:
   ```python
   # app/services/messenger/base.py
   class MessengerInterface(ABC):
       @abstractmethod
       async def send_message(self, recipient: str, message: str, link: str) -> bool
   ```

2. Create implementations:
   - `EmailMessenger` (SMTP)
   - `SlackMessenger` (Slack API)
   - `TeamsMessenger` (Microsoft Teams webhook)
   - `WhatsAppMessenger` (Twilio API)

**Files to Create:**
- `app/services/messenger/base.py`
- `app/services/messenger/email.py`
- `app/services/messenger/slack.py`
- `app/services/messenger/teams.py`
- `app/services/messenger/whatsapp.py`

#### Task 3.2: Messenger Configuration
**Priority**: P1 (High)  
**Estimated Time**: 1 day

**Tasks:**
1. Add messenger config to `app/core/config.py`:
   ```python
   MESSENGER_PROVIDER: str = "email"  # email, slack, teams, whatsapp
   MESSENGER_EMAIL_SMTP_HOST: Optional[str] = None
   MESSENGER_EMAIL_SMTP_PORT: int = 587
   MESSENGER_SLACK_WEBHOOK_URL: Optional[SecretStr] = None
   # ... etc
   ```

2. Create messenger factory:
   ```python
   # app/services/messenger/factory.py
   def create_messenger(provider: str, config: Settings) -> MessengerInterface
   ```

**Files to Create:**
- `app/services/messenger/factory.py`

**Files to Modify:**
- `app/core/config.py`

#### Task 3.3: Link Sharing Integration
**Priority**: P1 (High)  
**Estimated Time**: 2 days

**Tasks:**
1. Integrate messenger with verification service:
   ```python
   # In VerificationService
   async def share_verification_link(
       self, verification: VerificationRequest, recipient: str, messenger: MessengerInterface
   ) -> bool
   ```

2. Create API endpoint for link sharing:
   ```python
   @router.post("/verification/{verification_id}/share")
   async def share_verification_link(...)
   ```

3. Add link sharing to frontend

**Files to Modify:**
- `app/services/verification_service.py`
- `app/api/routes.py`
- Frontend components

---

### Phase 4: MetaMask Notarization (Weeks 6-7)

#### Task 4.1: Cryptographic Signature Verification
**Priority**: P0 (Critical)  
**Estimated Time**: 3 days

**Tasks:**
1. Install Web3 library:
   ```bash
   uv add web3 eth-account
   ```

2. Create signature verification utility:
   ```python
   # app/utils/crypto_verification.py
   from eth_account import Account
   from eth_account.messages import encode_defunct
   
   def verify_ethereum_signature(
       message: str, signature: str, wallet_address: str
   ) -> bool:
       """Verify Ethereum signature using eth_account."""
       message_hash = encode_defunct(text=message)
       recovered_address = Account.recover_message(message_hash, signature=signature)
       return recovered_address.lower() == wallet_address.lower()
   ```

3. Update wallet authentication to use real verification

**Files to Create:**
- `app/utils/crypto_verification.py`

**Files to Modify:**
- `app/api/routes.py` (update `/api/auth/wallet` endpoint)
- `pyproject.toml` (add dependencies)

#### Task 4.2: Notarization Service
**Priority**: P0 (Critical)  
**Estimated Time**: 3 days

**Tasks:**
1. Create `NotarizationRecord` model in `app/db/models.py`
2. Create Alembic migration
3. Create notarization service:
   ```python
   # app/services/notarization_service.py
   class NotarizationService:
       def create_notarization_request(
           self, deal_id: int, required_signers: List[str]
       ) -> NotarizationRecord
       
       def generate_notarization_message(
           self, notarization: NotarizationRecord, signer_address: str
       ) -> str
       
       def verify_and_store_signature(
           self, notarization_id: int, wallet_address: str, signature: str, message: str
       ) -> NotarizationRecord
       
       def complete_notarization(self, notarization_id: int) -> NotarizationRecord
   ```

4. Generate hash of CDM payload for notarization

**Files to Create:**
- `app/services/notarization_service.py`

**Files to Modify:**
- `app/db/models.py`
- Create Alembic migration

#### Task 4.3: Notarization API Endpoints
**Priority**: P0 (Critical)  
**Estimated Time**: 2 days

**Tasks:**
1. Create notarization endpoints:
   ```python
   @router.post("/deals/{deal_id}/notarize")
   async def create_notarization_request(...)
   
   @router.get("/notarization/{notarization_id}/nonce")
   async def get_notarization_nonce(...)
   
   @router.post("/notarization/{notarization_id}/sign")
   async def sign_notarization(...)
   ```

2. Add CDM event generation for notarization

**Files to Modify:**
- `app/api/routes.py`
- `app/models/cdm_events.py` (add `generate_cdm_notarization_event`)

#### Task 4.4: Frontend MetaMask Integration
**Priority**: P1 (High)  
**Estimated Time**: 3 days

**Tasks:**
1. Install Web3 frontend library:
   ```bash
   cd client
   npm install ethers
   ```

2. Create MetaMask hook:
   ```typescript
   // client/src/hooks/useMetaMask.ts
   export function useMetaMask() {
     const connect = async () => Promise<string>  // wallet address
     const signMessage = async (message: string) => Promise<string>  // signature
   }
   ```

3. Create notarization component:
   ```typescript
   // client/src/components/NotarizationInterface.tsx
   export function NotarizationInterface({ dealId }: { dealId: number })
   ```

4. Integrate with deal completion flow

**Files to Create:**
- `client/src/hooks/useMetaMask.ts`
- `client/src/components/NotarizationInterface.tsx`

**Files to Modify:**
- `client/package.json`

---

### Phase 5: Integration & Testing (Week 8)

#### Task 5.1: End-to-End Integration
**Priority**: P0 (Critical)  
**Estimated Time**: 3 days

**Tasks:**
1. Integrate all components:
   - Deal creation → Verification request → Link sharing → Verification → Notarization
2. Test cross-machine verification flow
3. Test MetaMask signing flow
4. Verify CDM event generation

#### Task 5.2: Security Audit
**Priority**: P0 (Critical)  
**Estimated Time**: 2 days

**Tasks:**
1. Review IP whitelisting security
2. Review token generation security
3. Review signature verification
4. Review API key storage (bcrypt hashing)
5. Add rate limiting for verification links

#### Task 5.3: Documentation
**Priority**: P1 (High)  
**Estimated Time**: 2 days

**Tasks:**
1. API documentation for remote endpoints
2. Configuration guide for SSL certificates
3. Messenger setup guides
4. MetaMask integration guide
5. Deployment guide for remote API

---

## Configuration Examples

### Environment Variables

```bash
# Remote API Configuration
REMOTE_API_ENABLED=true
REMOTE_API_PORT=8443
REMOTE_API_SSL_CERT_PATH=/path/to/cert.pem
REMOTE_API_SSL_KEY_PATH=/path/to/key.pem
REMOTE_API_SSL_CERT_CHAIN_PATH=/path/to/chain.pem

# Messenger Configuration
MESSENGER_PROVIDER=email
MESSENGER_EMAIL_SMTP_HOST=smtp.gmail.com
MESSENGER_EMAIL_SMTP_PORT=587
MESSENGER_EMAIL_SMTP_USER=your-email@gmail.com
MESSENGER_EMAIL_SMTP_PASSWORD=your-app-password
MESSENGER_EMAIL_FROM=noreply@creditnexus.app

# Verification Configuration
VERIFICATION_LINK_EXPIRY_HOURS=72
VERIFICATION_BASE_URL=https://verify.creditnexus.app
```

### Remote App Profile Creation

```python
# Script to create remote app profile
from app.db import SessionLocal
from app.db.models import RemoteAppProfile
from app.auth.jwt_auth import get_password_hash
import secrets

db = SessionLocal()
profile = RemoteAppProfile(
    profile_name="external_verifier",
    api_key_hash=get_password_hash(secrets.token_urlsafe(32)),
    allowed_ips=["192.168.1.0/24", "10.0.0.100"],
    permissions={"read": True, "verify": True, "sign": False},
    is_active=True
)
db.add(profile)
db.commit()
```

---

## CDM Event Extensions

### New CDM Events

#### 1. VerificationResult Event
```python
def generate_cdm_verification_result(
    verification_id: str,
    deal_id: str,
    verifier_wallet_address: str,
    decision: str,  # "accepted" or "declined"
    verification_metadata: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """Generate CDM-compliant verification result event."""
    return {
        "eventType": "VerificationResult",
        "eventDate": datetime.utcnow().isoformat(),
        "meta": {
            "globalKey": {
                "issuer": "CreditNexus",
                "assignedIdentifier": [{
                    "identifier": {"value": f"VERIFICATION_{verification_id}"}
                }]
            }
        },
        "verificationResult": {
            "dealId": deal_id,
            "verifier": {
                "walletAddress": verifier_wallet_address
            },
            "decision": decision,
            "metadata": verification_metadata or {}
        }
    }
```

#### 2. NotarizationEvent
```python
def generate_cdm_notarization_event(
    notarization_id: str,
    deal_id: str,
    signers: List[Dict[str, str]],  # [{"wallet_address": "...", "signature": "..."}]
    notarization_hash: str
) -> Dict[str, Any]:
    """Generate CDM-compliant notarization event."""
    return {
        "eventType": "Notarization",
        "eventDate": datetime.utcnow().isoformat(),
        "meta": {
            "globalKey": {
                "issuer": "CreditNexus",
                "assignedIdentifier": [{
                    "identifier": {"value": f"NOTARIZATION_{notarization_id}"}
                }]
            }
        },
        "notarization": {
            "dealId": deal_id,
            "notarizationHash": notarization_hash,
            "signers": signers,
            "blockchainNetwork": "ethereum"  # or "base", etc.
        }
    }
```

---

## Security Considerations

### 1. IP Whitelisting
- Support CIDR notation for subnet whitelisting
- Log all blocked IP attempts
- Rate limit IP validation checks
- Support X-Forwarded-For header for proxy scenarios

### 2. Verification Links
- Use cryptographically secure tokens (UUID + HMAC)
- Implement token expiration (configurable, default 72 hours)
- Rate limit link access attempts
- Log all link access for audit trail
- One-time use links (optional, configurable)

### 3. API Keys
- Store API keys as bcrypt hashes (never plaintext)
- Rotate API keys periodically
- Revoke compromised keys immediately
- Use separate API keys per remote app profile

### 4. MetaMask Signing
- Verify signatures cryptographically (never trust client)
- Include nonce and timestamp in signed message
- Store signatures immutably in database
- Generate CDM events for all notarization actions

### 5. SSL/TLS
- Require TLS 1.2+ for remote API
- Validate certificate chain
- Support certificate rotation
- Monitor certificate expiration

---

## Testing Strategy

### Unit Tests
- IP whitelist middleware
- Profile authentication
- Signature verification
- Token generation/validation
- Verification service methods

### Integration Tests
- End-to-end verification flow
- MetaMask signing flow
- Messenger integration
- CDM event generation

### Security Tests
- IP whitelist bypass attempts
- Token tampering attempts
- Signature forgery attempts
- API key brute force attempts

---

## Deployment Checklist

### Pre-Deployment
- [ ] SSL certificates obtained and configured
- [ ] Remote app profiles created
- [ ] IP whitelists configured
- [ ] Messenger credentials configured
- [ ] Database migrations applied
- [ ] Environment variables set

### Deployment
- [ ] Remote API server started on SSL port
- [ ] Main API server running
- [ ] Both servers health-checked
- [ ] SSL certificate validation
- [ ] IP whitelisting tested
- [ ] Verification links tested
- [ ] MetaMask integration tested

### Post-Deployment
- [ ] Monitor remote API logs
- [ ] Monitor verification link usage
- [ ] Monitor notarization requests
- [ ] Set up alerts for security events

---

## Future Enhancements

1. **Multi-Signature Notarization**: Require multiple signers for high-value deals
2. **Blockchain Storage**: Store notarization hashes on-chain (IPFS, Ethereum)
3. **Verification Templates**: Customizable verification workflows per deal type
4. **Real-time Notifications**: WebSocket notifications for verification status
5. **Verification Analytics**: Dashboard for verification metrics
6. **Mobile App**: Native mobile app for verification on-the-go

---

## Risk Mitigation

### Risks
1. **SSL Certificate Expiration**: Automated certificate renewal monitoring
2. **IP Whitelist Bypass**: Regular security audits, rate limiting
3. **Token Leakage**: HTTPS-only links, short expiration times
4. **Signature Forgery**: Cryptographic verification, nonce-based messages
5. **Messenger Failures**: Fallback mechanisms, retry logic

### Mitigation Strategies
- Comprehensive logging and monitoring
- Regular security audits
- Automated testing in CI/CD
- Incident response plan
- Backup verification methods

---

## Conclusion

This implementation plan provides a comprehensive roadmap for adding remote verification and notarization capabilities to CreditNexus. The phased approach ensures incremental delivery with proper testing at each stage. The architecture maintains CDM compliance while adding enterprise-grade security features.

**Estimated Total Effort**: 8-10 weeks  
**Team Size**: 2-3 developers  
**Dependencies**: SSL certificates, messenger API credentials, MetaMask browser extension

---

**Last Updated**: 2024-12-XX  
**Version**: 1.0  
**Author**: CreditNexus Architecture Team
