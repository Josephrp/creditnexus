# Satellite Layer Visualization Implementation Plan

## Executive Summary

This document outlines a comprehensive implementation plan for enhancing the satellite verification user experience by adding real-time layer visualization, layer browsing capabilities, and interactive overlay controls. Currently, automatic satellite verification only shows a small loading animation on the button. This enhancement will provide users with visual feedback of the layers being processed and allow them to explore all available satellite data layers.

**Status**: Planning  
**Priority**: High  
**Estimated Effort**: 3-4 weeks  
**Last Updated**: 2024-12-XX

---

## Table of Contents

1. [Current State Analysis](#current-state-analysis)
2. [Feature Requirements](#feature-requirements)
3. [Architecture Overview](#architecture-overview)
4. [Projects & Activities](#projects--activities)
5. [File-Level Tasks](#file-level-tasks)
6. [Line-Level Subtasks](#line-level-subtasks)
7. [API Specifications](#api-specifications)
8. [UI/UX Design](#uiux-design)
9. [Testing Strategy](#testing-strategy)
10. [Deployment Plan](#deployment-plan)

---

## Current State Analysis

### Existing Components

1. **VerificationDashboard.tsx** (637 lines)
   - Main verification interface
   - Shows loading animation on button during verification
   - Displays MapView with satellite imagery after verification
   - Has tabs for Map, Green Finance, and CDM JSON

2. **VerificationWidget.tsx** (493 lines)
   - Embedded verification widget
   - Similar loading animation pattern
   - Compact map preview

3. **MapView.tsx** (217 lines)
   - Leaflet-based map component
   - Simple satellite/base map toggle (`showSatellite` prop)
   - Displays asset markers with risk status colors
   - No layer overlay controls

4. **AssetVerificationCard.tsx** (278 lines)
   - Card component for asset verification
   - Button with loading spinner during verification
   - No layer visualization

### Backend Capabilities

1. **app/agents/verifier.py**
   - Fetches Sentinel-2 NIR (B08) and Red (B04) bands
   - Calculates NDVI
   - Returns verification results with NDVI score

2. **app/agents/classifier.py**
   - Uses TorchGeo ResNet-50 for land use classification
   - Processes 13-band Sentinel-2 data
   - Returns classification with confidence

3. **app/services/deal_event_handler.py**
   - Stores false-color composite images (NIR=Red, Red=Green, NIR-Red=Blue)
   - Saves satellite images to storage

### Available Data Layers

1. **Sentinel-2 Spectral Bands** (13 bands):
   - B01: Coastal Aerosol (60m)
   - B02: Blue (10m)
   - B03: Green (10m)
   - B04: Red (10m)
   - B05: Red Edge 1 (20m)
   - B06: Red Edge 2 (20m)
   - B07: Red Edge 3 (20m)
   - B08: NIR (10m)
   - B8A: Narrow NIR (20m)
   - B09: Water Vapor (60m)
   - B10: SWIR Cirrus (60m)
   - B11: SWIR 1 (20m)
   - B12: SWIR 2 (20m)

2. **Derived Layers**:
   - NDVI (Normalized Difference Vegetation Index)
   - False-color composite (NIR-Red-Green)
   - Land use classification overlay
   - Risk status overlay

3. **Enhanced Metrics** (if enabled):
   - OSM building/road overlays
   - Air quality heatmaps
   - Sustainability score visualization

### Current Limitations

1. **No Real-Time Feedback**: Users only see a button spinner during verification
2. **No Layer Visualization**: Layers are processed but not displayed during verification
3. **No Layer Browser**: Users cannot explore available layers after verification
4. **No Overlay Controls**: Map only has satellite/base toggle, no layer overlays
5. **No Progressive Display**: All results appear at once after completion

---

## Feature Requirements

### Functional Requirements

#### FR1: Real-Time Layer Visualization During Verification
- **Priority**: High
- **Description**: Display layers as they are processed during automatic verification
- **Acceptance Criteria**:
  - Layers appear in sequence as they are fetched/processed
  - Each layer shows a label indicating what is being processed
  - Progress indicator shows current layer and total layers
  - Users can see NDVI calculation in real-time
  - Land use classification appears when complete

#### FR2: Layer Browser Interface
- **Priority**: High
- **Description**: Allow users to browse and view all available satellite layers
- **Acceptance Criteria**:
  - List of all available layers (13 Sentinel-2 bands + derived layers)
  - Layer metadata (resolution, wavelength, description)
  - Preview thumbnails for each layer
  - Click to view full layer on map
  - Layer opacity controls
  - Layer comparison mode (side-by-side)

#### FR3: Interactive Map Overlays
- **Priority**: High
- **Description**: Add overlay controls to MapView for layer visualization
- **Acceptance Criteria**:
  - Layer selector dropdown/panel
  - Opacity slider for each overlay
  - Toggle visibility for each layer
  - NDVI heatmap overlay
  - Land use classification overlay
  - Risk status overlay
  - Layer blending modes (normal, multiply, screen)

#### FR4: Layer Playback/Animation
- **Priority**: Medium
- **Description**: Allow users to watch layers scroll through automatically
- **Acceptance Criteria**:
  - Play/pause button for layer animation
  - Speed control (slow, normal, fast)
  - Loop option
  - Timeline scrubber for manual navigation
  - Shows layer name and timestamp during playback

#### FR5: Enhanced Verification Status Display
- **Priority**: Medium
- **Description**: Replace simple button spinner with detailed progress display
- **Acceptance Criteria**:
  - Progress bar showing verification stages
  - Current stage indicator (Geocoding, Satellite Fetch, NDVI Calculation, Classification, etc.)
  - Layer processing status for each layer
  - Estimated time remaining
  - Cancel button

### Non-Functional Requirements

#### NFR1: Performance
- Layer visualization should not block UI thread
- Map overlays should render smoothly (60fps)
- Layer data should be cached for quick switching
- Progressive loading for large layer datasets

#### NFR2: Responsiveness
- UI should remain responsive during verification
- Layer switching should be instant (<100ms)
- Smooth animations and transitions

#### NFR3: Scalability
- Support for multiple assets simultaneously
- Efficient memory usage for layer data
- Lazy loading of layer data

#### NFR4: Accessibility
- Keyboard navigation for layer controls
- Screen reader support
- High contrast mode support
- Tooltips and help text

---

## Architecture Overview

### System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Frontend (React/TypeScript)              │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────────┐  ┌──────────────────┐               │
│  │ VerificationUI   │  │  LayerBrowser     │               │
│  │  - Progress      │  │  - Layer List     │               │
│  │  - Status        │  │  - Preview       │               │
│  │  - Controls      │  │  - Metadata      │               │
│  └────────┬─────────┘  └────────┬─────────┘               │
│           │                     │                           │
│  ┌────────▼─────────────────────▼─────────┐              │
│  │         Enhanced MapView                 │              │
│  │  - Leaflet Map                           │              │
│  │  - Layer Overlay Manager                │              │
│  │  - NDVI Heatmap                          │              │
│  │  - Classification Overlay               │              │
│  │  - Risk Status Overlay                   │              │
│  └────────┬─────────────────────────────────┘              │
│           │                                                 │
│  ┌────────▼─────────────────────────────────┐             │
│  │      Layer Visualization Service          │             │
│  │  - Layer State Management                │             │
│  │  - WebSocket Connection                  │             │
│  │  - Layer Cache                           │             │
│  │  - Animation Controller                  │             │
│  └────────┬──────────────────────────────────┘             │
└───────────┼───────────────────────────────────────────────┘
            │
            │ HTTP/WebSocket
            │
┌───────────▼───────────────────────────────────────────────┐
│              Backend (FastAPI/Python)                    │
├───────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────────┐  ┌──────────────────┐              │
│  │ Verification API │  │  Layer API       │              │
│  │  - /api/audit/   │  │  - /api/layers/ │              │
│  │  - WebSocket     │  │  - /api/layers/ │              │
│  │    streaming     │  │    /{layer_id}  │              │
│  └────────┬─────────┘  └────────┬─────────┘              │
│           │                     │                          │
│  ┌────────▼─────────────────────▼─────────┐             │
│  │      Layer Processing Service            │             │
│  │  - Sentinel-2 Data Fetching            │             │
│  │  - NDVI Calculation                      │             │
│  │  - Layer Generation                       │             │
│  │  - Image Processing                       │             │
│  └────────┬─────────────────────────────────┘             │
│           │                                                 │
│  ┌────────▼─────────────────────────────────┐             │
│  │      Layer Storage Service                │             │
│  │  - File Storage (PNG/GeoTIFF)            │             │
│  │  - Database Metadata                      │             │
│  │  - Cache Management                        │             │
│  └──────────────────────────────────────────┘             │
└─────────────────────────────────────────────────────────────┘
```

### Data Flow

1. **Verification Initiation**:
   ```
   User clicks "Securitize & Verify"
   → Frontend sends POST /api/loan-assets
   → Backend starts verification workflow
   → WebSocket connection established
   → Backend streams layer processing updates
   ```

2. **Layer Processing**:
   ```
   Backend fetches Sentinel-2 data
   → Processes each band
   → Calculates NDVI
   → Runs land use classification
   → Sends layer updates via WebSocket
   → Frontend displays layers in real-time
   ```

3. **Layer Display**:
   ```
   Layer data received
   → Convert to map-compatible format (GeoTIFF/PNG)
   → Add to Leaflet layer group
   → Apply opacity and blending
   → Render on map
   ```

### Technology Stack

**Frontend**:
- React 18 with TypeScript
- Leaflet + React-Leaflet for maps
- WebSocket (native or socket.io-client) for real-time updates
- Zustand or React Context for state management
- Tailwind CSS for styling

**Backend**:
- FastAPI for REST API
- WebSocket support (FastAPI WebSocket or Socket.IO)
- Rasterio for GeoTIFF processing
- NumPy for array operations
- PIL/Pillow for image processing
- Redis (optional) for layer caching

---

## Projects & Activities

### Project 1: Backend Layer Processing & API

**Duration**: 1.5 weeks  
**Priority**: High  
**Dependencies**: None

#### Activity 1.1: Enhanced Layer Data Fetching
- Extend `verifier.py` to fetch all 13 Sentinel-2 bands
- Create layer metadata structure
- Implement layer caching mechanism
- Add layer validation and error handling

#### Activity 1.2: Layer Processing Service
- Create `app/services/layer_processing_service.py`
- Implement NDVI layer generation
- Implement false-color composite generation
- Implement land use classification overlay generation
- Add layer normalization and enhancement

#### Activity 1.3: Layer Storage & Retrieval
- Extend file storage to support layer files
- Create database models for layer metadata
- Implement layer retrieval API endpoints
- Add layer versioning support

#### Activity 1.4: WebSocket Streaming API
- Implement WebSocket endpoint for real-time updates
- Create layer update message format
- Add progress tracking
- Implement error handling and reconnection

### Project 2: Frontend Layer Visualization Components

**Duration**: 1.5 weeks  
**Priority**: High  
**Dependencies**: Project 1 (partial - can start with mock data)

#### Activity 2.1: Enhanced MapView with Overlays
- Extend `MapView.tsx` with layer overlay support
- Add Leaflet layer groups for overlays
- Implement opacity controls
- Add layer blending modes
- Create NDVI heatmap visualization

#### Activity 2.2: Layer Browser Component
- Create `LayerBrowser.tsx` component
- Implement layer list with metadata
- Add layer preview thumbnails
- Create layer selection and display logic
- Add layer comparison mode

#### Activity 2.3: Verification Progress Display
- Create `VerificationProgress.tsx` component
- Replace button spinner with detailed progress
- Add stage indicators
- Implement layer processing status display
- Add cancel functionality

#### Activity 2.4: Layer Animation Controller
- Create `LayerAnimationController.tsx`
- Implement play/pause functionality
- Add speed control
- Create timeline scrubber
- Add loop option

### Project 3: Real-Time Integration

**Duration**: 1 week  
**Priority**: High  
**Dependencies**: Project 1, Project 2

#### Activity 3.1: WebSocket Client Integration
- Create WebSocket hook `useVerificationWebSocket.ts`
- Implement connection management
- Handle layer update messages
- Add reconnection logic
- Implement error handling

#### Activity 3.2: Real-Time Layer Display
- Integrate WebSocket with MapView
- Update layers in real-time as received
- Add smooth transitions between layers
- Implement layer queue management

#### Activity 3.3: State Management
- Create layer state management (Zustand store or Context)
- Implement layer cache
- Add layer selection state
- Implement animation state

### Project 4: UI/UX Enhancements

**Duration**: 0.5 weeks  
**Priority**: Medium  
**Dependencies**: Project 2, Project 3

#### Activity 4.1: Layer Controls UI
- Design and implement layer control panel
- Add opacity sliders
- Create layer visibility toggles
- Add layer info tooltips
- Implement responsive design

#### Activity 4.2: Enhanced Verification Dashboard
- Update `VerificationDashboard.tsx` with new components
- Integrate layer browser
- Add verification progress display
- Update map view with overlay controls

#### Activity 4.3: Widget Updates
- Update `VerificationWidget.tsx` with progress display
- Add compact layer viewer
- Integrate with main dashboard

---

## File-Level Tasks

### Backend Files

#### 1. `app/services/layer_processing_service.py` (NEW)
**Purpose**: Service for processing and generating satellite layers

**Tasks**:
- Create `LayerProcessingService` class
- Implement `fetch_all_bands()` method
- Implement `generate_ndvi_layer()` method
- Implement `generate_false_color_composite()` method
- Implement `generate_classification_overlay()` method
- Implement `normalize_layer()` method
- Add layer metadata generation
- Add error handling and logging

**Estimated Lines**: ~400-500

#### 2. `app/services/layer_storage_service.py` (NEW)
**Purpose**: Service for storing and retrieving layer data

**Tasks**:
- Create `LayerStorageService` class
- Implement `store_layer()` method (PNG/GeoTIFF)
- Implement `retrieve_layer()` method
- Implement `get_layer_metadata()` method
- Add layer versioning support
- Add cache management
- Add cleanup for old layers

**Estimated Lines**: ~300-400

#### 3. `app/api/layer_routes.py` (NEW)
**Purpose**: API endpoints for layer data

**Tasks**:
- Create router with `/api/layers` prefix
- Implement `GET /api/layers/{asset_id}` - List all layers for asset
- Implement `GET /api/layers/{asset_id}/{layer_type}` - Get specific layer
- Implement `GET /api/layers/{asset_id}/{layer_type}/metadata` - Get layer metadata
- Implement `POST /api/layers/{asset_id}/generate` - Generate missing layers
- Add authentication and authorization
- Add error handling
- Add response models

**Estimated Lines**: ~200-300

#### 4. `app/api/websocket_routes.py` (NEW)
**Purpose**: WebSocket endpoints for real-time updates

**Tasks**:
- Create WebSocket router
- Implement `/ws/verification/{asset_id}` endpoint
- Create message format for layer updates
- Implement progress tracking
- Add connection management
- Add error handling and reconnection logic

**Estimated Lines**: ~200-250

#### 5. `app/db/models.py` (MODIFY)
**Purpose**: Add database models for layer metadata

**Tasks**:
- Add `SatelliteLayer` model
  - `id`, `loan_asset_id`, `layer_type`, `band_number` (if applicable)
  - `file_path`, `metadata` (JSONB), `created_at`
  - `resolution`, `bounds`, `crs`
- Add relationship to `LoanAsset`
- Create Alembic migration

**Estimated Lines**: +50-80

#### 6. `app/agents/verifier.py` (MODIFY)
**Purpose**: Extend to fetch all bands and support layer streaming

**Tasks**:
- Modify `fetch_sentinel_data()` to fetch all 13 bands
- Add `fetch_multispectral_data()` method
- Add callback parameter for progress updates
- Modify `verify_asset_location()` to support streaming
- Add layer generation calls
- Update return structure to include layer metadata

**Estimated Lines**: +150-200

#### 7. `app/agents/audit_workflow.py` (MODIFY)
**Purpose**: Integrate layer processing into audit workflow

**Tasks**:
- Add layer processing stage
- Integrate with `LayerProcessingService`
- Add WebSocket progress updates
- Store layer metadata in database
- Update audit result structure

**Estimated Lines**: +100-150

### Frontend Files

#### 8. `client/src/components/MapView.tsx` (MODIFY)
**Purpose**: Add layer overlay support to map

**Tasks**:
- Add `layers` prop for overlay data
- Create `LayerOverlayManager` component
- Add Leaflet layer groups for overlays
- Implement opacity controls
- Add layer blending modes
- Create NDVI heatmap layer
- Add classification overlay
- Add risk status overlay
- Update map controls UI

**Estimated Lines**: +300-400

#### 9. `client/src/components/LayerBrowser.tsx` (NEW)
**Purpose**: Component for browsing available layers

**Tasks**:
- Create component structure
- Implement layer list display
- Add layer metadata display
- Create preview thumbnails
- Add layer selection logic
- Implement layer comparison mode
- Add search/filter functionality
- Add responsive design

**Estimated Lines**: ~400-500

#### 10. `client/src/components/VerificationProgress.tsx` (NEW)
**Purpose**: Enhanced progress display for verification

**Tasks**:
- Create progress bar component
- Add stage indicators
- Display current layer being processed
- Show estimated time remaining
- Add cancel button
- Add error display
- Implement smooth animations

**Estimated Lines**: ~250-300

#### 11. `client/src/components/LayerAnimationController.tsx` (NEW)
**Purpose**: Controller for layer animation/playback

**Tasks**:
- Create play/pause controls
- Add speed control (slow, normal, fast)
- Implement timeline scrubber
- Add loop toggle
- Create layer transition animations
- Add keyboard shortcuts
- Display current layer info

**Estimated Lines**: ~300-350

#### 12. `client/src/components/LayerControls.tsx` (NEW)
**Purpose**: Control panel for layer overlays

**Tasks**:
- Create layer selector dropdown
- Add opacity sliders for each layer
- Add visibility toggles
- Add layer info tooltips
- Implement layer blending mode selector
- Add reset controls
- Create compact/collapsed view

**Estimated Lines**: ~200-250

#### 13. `client/src/hooks/useVerificationWebSocket.ts` (NEW)
**Purpose**: Hook for WebSocket connection and layer updates

**Tasks**:
- Create WebSocket connection logic
- Implement message handling
- Add reconnection logic
- Handle connection errors
- Provide layer update callbacks
- Add connection status
- Implement cleanup on unmount

**Estimated Lines**: ~200-250

#### 14. `client/src/stores/layerStore.ts` (NEW)
**Purpose**: State management for layers (Zustand)

**Tasks**:
- Create store structure
- Add layer cache state
- Add selected layer state
- Add animation state
- Add actions for layer operations
- Implement layer cache management
- Add persistence (optional)

**Estimated Lines**: ~150-200

#### 15. `client/src/components/VerificationDashboard.tsx` (MODIFY)
**Purpose**: Integrate new layer visualization components

**Tasks**:
- Replace button spinner with `VerificationProgress`
- Add `LayerBrowser` component
- Integrate `LayerControls` with MapView
- Add `LayerAnimationController`
- Update WebSocket integration
- Add layer tab to existing tabs
- Update state management

**Estimated Lines**: +200-300

#### 16. `client/src/components/VerificationWidget.tsx` (MODIFY)
**Purpose**: Add compact layer visualization

**Tasks**:
- Replace spinner with compact progress display
- Add mini layer viewer
- Integrate with main dashboard
- Update WebSocket connection
- Add layer count indicator

**Estimated Lines**: +100-150

#### 17. `client/src/components/AssetVerificationCard.tsx` (MODIFY)
**Purpose**: Add layer visualization link

**Tasks**:
- Add "View Layers" button/link
- Update progress display
- Add layer count badge
- Link to full layer browser

**Estimated Lines**: +50-80

#### 18. `client/src/types/layers.ts` (NEW)
**Purpose**: TypeScript types for layer data

**Tasks**:
- Define `LayerType` enum
- Define `LayerMetadata` interface
- Define `LayerData` interface
- Define `LayerUpdate` interface
- Define `VerificationProgress` interface
- Export all types

**Estimated Lines**: ~100-150

---

## Line-Level Subtasks

### Backend: `app/services/layer_processing_service.py`

#### Class Definition (Lines 1-50)
```python
# 1-10: Imports
from typing import Dict, List, Optional, Tuple, Callable
import numpy as np
import logging
from datetime import datetime
from app.agents.verifier import fetch_sentinel_data
from app.agents.classifier import LandUseClassifier

# 11-30: Constants
SENTINEL_BANDS = {
    'B01': {'name': 'Coastal Aerosol', 'resolution': 60, 'wavelength': 443},
    'B02': {'name': 'Blue', 'resolution': 10, 'wavelength': 490},
    # ... all 13 bands
}

# 31-50: Class definition
class LayerProcessingService:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.classifier = LandUseClassifier()
```

#### Fetch All Bands Method (Lines 51-150)
```python
# 51-70: Method signature and validation
async def fetch_all_bands(
    self,
    lat: float,
    lon: float,
    size_km: float = 1.0,
    progress_callback: Optional[Callable] = None
) -> Dict[str, np.ndarray]:
    """
    Fetch all 13 Sentinel-2 bands for a location.
    
    Args:
        lat: Latitude
        lon: Longitude
        size_km: Bounding box size
        progress_callback: Callback for progress updates
        
    Returns:
        Dictionary mapping band names to numpy arrays
    """
    
# 71-90: Initialize result dictionary
    bands = {}
    
# 91-110: Fetch bands in sequence (or parallel if supported)
    band_list = ['B01', 'B02', 'B03', 'B04', 'B05', 'B06', 'B07', 
                 'B08', 'B8A', 'B09', 'B10', 'B11', 'B12']
    
    for i, band_name in enumerate(band_list):
        if progress_callback:
            progress_callback({
                'stage': 'fetching_bands',
                'current': i + 1,
                'total': len(band_list),
                'band': band_name
            })
        
# 111-130: Fetch individual band (extend Sentinel Hub request)
        # Modify evalscript to fetch specific band
        band_data = await self._fetch_single_band(lat, lon, band_name, size_km)
        bands[band_name] = band_data
        
# 131-150: Return all bands
    return bands
```

#### Generate NDVI Layer (Lines 151-220)
```python
# 151-170: Method signature
async def generate_ndvi_layer(
    self,
    nir_band: np.ndarray,
    red_band: np.ndarray
) -> Tuple[np.ndarray, Dict]:
    """
    Generate NDVI layer from NIR and Red bands.
    
    Returns:
        Tuple of (ndvi_array, metadata)
    """
    
# 171-190: Calculate NDVI
    nir = nir_band.astype(float)
    red = red_band.astype(float)
    
    numerator = nir - red
    denominator = nir + red + 1e-10
    ndvi = numerator / denominator
    
    # Clamp to valid range
    ndvi = np.clip(ndvi, -1.0, 1.0)
    
# 191-210: Generate metadata
    metadata = {
        'layer_type': 'ndvi',
        'min_value': float(np.min(ndvi)),
        'max_value': float(np.max(ndvi)),
        'mean_value': float(np.mean(ndvi)),
        'resolution': 10,  # meters
        'created_at': datetime.utcnow().isoformat()
    }
    
# 211-220: Return result
    return ndvi, metadata
```

#### Generate False Color Composite (Lines 221-300)
```python
# 221-240: Method signature
async def generate_false_color_composite(
    self,
    nir_band: np.ndarray,
    red_band: np.ndarray,
    green_band: Optional[np.ndarray] = None
) -> Tuple[np.ndarray, Dict]:
    """
    Generate false-color composite image.
    Default: NIR=Red, Red=Green, (NIR-Red)=Blue
    """
    
# 241-260: Normalize bands
    def normalize_band(band):
        band_min = band.min()
        band_max = band.max()
        if band_max > band_min:
            return ((band - band_min) / (band_max - band_min) * 255).astype(np.uint8)
        return np.zeros_like(band, dtype=np.uint8)
    
    nir_norm = normalize_band(nir_band)
    red_norm = normalize_band(red_band)
    
# 261-280: Create blue channel
    blue_band = np.clip(
        nir_norm.astype(int) - red_norm.astype(int),
        0, 255
    ).astype(np.uint8)
    
# 281-300: Stack into RGB image
    rgb_image = np.dstack([nir_norm, red_norm, blue_band])
    
    metadata = {
        'layer_type': 'false_color',
        'composition': 'NIR-Red-Blue',
        'created_at': datetime.utcnow().isoformat()
    }
    
    return rgb_image, metadata
```

#### Generate Classification Overlay (Lines 301-400)
```python
# 301-320: Method signature
async def generate_classification_overlay(
    self,
    lat: float,
    lon: float,
    bands: Dict[str, np.ndarray]
) -> Tuple[np.ndarray, Dict]:
    """
    Generate land use classification overlay.
    """
    
# 321-340: Run classification
    classification_result = self.classifier.classify_lat_lon(lat, lon)
    
    # Create overlay image (colored by class)
    # Map classification to colors
    class_colors = {
        'Forest': [34, 139, 34],  # Green
        'AnnualCrop': [255, 215, 0],  # Yellow
        'PermanentCrop': [255, 140, 0],  # Orange
        # ... other classes
    }
    
# 341-360: Generate colored overlay
    overlay = np.zeros((bands['B04'].shape[0], bands['B04'].shape[1], 3), dtype=np.uint8)
    class_name = classification_result['classification']
    color = class_colors.get(class_name, [128, 128, 128])
    overlay[:, :] = color
    
    # Apply transparency based on confidence
    alpha = int(classification_result['confidence'] * 255)
    
# 361-380: Create metadata
    metadata = {
        'layer_type': 'classification',
        'classification': class_name,
        'confidence': classification_result['confidence'],
        'model': classification_result.get('model', 'unknown'),
        'created_at': datetime.utcnow().isoformat()
    }
    
# 381-400: Return result
    return overlay, metadata
```

### Frontend: `client/src/components/MapView.tsx`

#### Add Layer Overlay Support (Lines 91-150)
```typescript
// 91-110: Update interface
interface MapViewProps {
    assets: LoanAsset[];
    selectedAssetId?: number;
    onAssetSelect?: (asset: LoanAsset) => void;
    height?: string;
    showSatellite?: boolean;
    layers?: LayerData[];  // NEW
    selectedLayer?: string;  // NEW
    layerOpacity?: number;  // NEW
}

// 111-130: Add layer state
const [layerOverlays, setLayerOverlays] = useState<L.LayerGroup[]>([]);
const [currentOverlay, setCurrentOverlay] = useState<L.Layer | null>(null);

// 131-150: Create layer overlay manager
useEffect(() => {
    if (!layers || layers.length === 0) return;
    
    const selected = layers.find(l => l.id === selectedLayer);
    if (!selected) return;
    
    // Create Leaflet layer from layer data
    const overlay = createLeafletLayer(selected);
    setCurrentOverlay(overlay);
    
    return () => {
        if (overlay) {
            map.removeLayer(overlay);
        }
    };
}, [layers, selectedLayer, map]);
```

#### Create Leaflet Layer Helper (Lines 151-220)
```typescript
// 151-170: Helper function to create Leaflet layer
function createLeafletLayer(layerData: LayerData): L.Layer {
    const { type, data, bounds, metadata } = layerData;
    
    switch (type) {
        case 'ndvi':
            return createNDVIHeatmap(data, bounds, metadata);
        case 'false_color':
            return createImageOverlay(data, bounds);
        case 'classification':
            return createClassificationOverlay(data, bounds, metadata);
        default:
            return createImageOverlay(data, bounds);
    }
}

// 171-190: Create NDVI heatmap
function createNDVIHeatmap(
    ndviData: number[][],
    bounds: L.LatLngBounds,
    metadata: LayerMetadata
): L.ImageOverlay {
    // Convert NDVI to color gradient
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    // ... color mapping logic
    
    const imageUrl = canvas.toDataURL();
    return L.imageOverlay(imageUrl, bounds, {
        opacity: layerOpacity || 0.7,
        interactive: false
    });
}

// 191-220: Create image overlay
function createImageOverlay(
    imageData: ImageData,
    bounds: L.LatLngBounds
): L.ImageOverlay {
    // Convert image data to data URL
    const canvas = document.createElement('canvas');
    // ... draw image
    
    return L.imageOverlay(canvas.toDataURL(), bounds, {
        opacity: layerOpacity || 0.7
    });
}
```

#### Add Layer Controls UI (Lines 221-300)
```typescript
// 221-240: Add layer controls component
{layers && layers.length > 0 && (
    <div className="absolute top-4 right-4 z-[1000] bg-black/80 backdrop-blur rounded-lg p-3 border border-zinc-700">
        <div className="text-xs text-zinc-400 mb-2">Layer Overlays</div>
        
        <select
            value={selectedLayer || ''}
            onChange={(e) => onLayerSelect?.(e.target.value)}
            className="w-full bg-zinc-900 text-white text-xs p-2 rounded mb-2"
        >
            <option value="">None</option>
            {layers.map(layer => (
                <option key={layer.id} value={layer.id}>
                    {layer.metadata.name || layer.type}
                </option>
            ))}
        </select>
        
        {selectedLayer && (
            <div className="mt-2">
                <label className="text-xs text-zinc-400">Opacity</label>
                <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    value={layerOpacity || 0.7}
                    onChange={(e) => onOpacityChange?.(parseFloat(e.target.value))}
                    className="w-full"
                />
            </div>
        )}
    </div>
)}
```

### Frontend: `client/src/components/LayerBrowser.tsx`

#### Component Structure (Lines 1-100)
```typescript
// 1-30: Imports
import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { fetchWithAuth } from '@/context/AuthContext';
import type { LayerData, LayerMetadata } from '@/types/layers';
import { Layers, Eye, EyeOff, Info } from 'lucide-react';

// 31-60: Interface
interface LayerBrowserProps {
    assetId: number;
    onLayerSelect?: (layerId: string) => void;
    selectedLayerId?: string;
}

// 61-100: Component
export function LayerBrowser({ assetId, onLayerSelect, selectedLayerId }: LayerBrowserProps) {
    const [layers, setLayers] = useState<LayerData[]>([]);
    const [loading, setLoading] = useState(true);
    const [expandedLayer, setExpandedLayer] = useState<string | null>(null);
    
    // Fetch layers
    useEffect(() => {
        fetchLayers();
    }, [assetId]);
    
    const fetchLayers = async () => {
        setLoading(true);
        try {
            const response = await fetchWithAuth(`/api/layers/${assetId}`);
            if (response.ok) {
                const data = await response.json();
                setLayers(data.layers || []);
            }
        } catch (error) {
            console.error('Failed to fetch layers:', error);
        } finally {
            setLoading(false);
        }
    };
```

#### Layer List Display (Lines 101-200)
```typescript
// 101-130: Render layer list
return (
    <Card className="p-4">
        <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold flex items-center gap-2">
                <Layers className="w-5 h-5" />
                Available Layers
            </h3>
            <Button variant="ghost" size="sm" onClick={fetchLayers}>
                Refresh
            </Button>
        </div>
        
        {loading ? (
            <div className="text-center py-8">Loading layers...</div>
        ) : (
            <div className="space-y-2">
                {layers.map(layer => (
                    <LayerItem
                        key={layer.id}
                        layer={layer}
                        isSelected={layer.id === selectedLayerId}
                        isExpanded={expandedLayer === layer.id}
                        onSelect={() => onLayerSelect?.(layer.id)}
                        onExpand={() => setExpandedLayer(
                            expandedLayer === layer.id ? null : layer.id
                        )}
                    />
                ))}
            </div>
        )}
    </Card>
);
```

#### Layer Item Component (Lines 201-300)
```typescript
// 201-230: Layer item component
function LayerItem({
    layer,
    isSelected,
    isExpanded,
    onSelect,
    onExpand
}: {
    layer: LayerData;
    isSelected: boolean;
    isExpanded: boolean;
    onSelect: () => void;
    onExpand: () => void;
}) {
    return (
        <div
            className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                isSelected
                    ? 'border-indigo-500 bg-indigo-500/10'
                    : 'border-zinc-700 bg-zinc-900/50 hover:border-zinc-600'
            }`}
            onClick={onSelect}
        >
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-zinc-800 rounded flex items-center justify-center">
                        {/* Preview thumbnail */}
                        <img
                            src={layer.thumbnail_url || '/placeholder-layer.png'}
                            alt={layer.metadata.name}
                            className="w-full h-full object-cover rounded"
                        />
                    </div>
                    
                    <div>
                        <div className="font-medium text-sm">
                            {layer.metadata.name || layer.type}
                        </div>
                        <div className="text-xs text-zinc-400">
                            {layer.metadata.resolution}m • {layer.metadata.band_name || 'Derived'}
                        </div>
                    </div>
                </div>
                
                <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                        e.stopPropagation();
                        onExpand();
                    }}
                >
                    {isExpanded ? <EyeOff /> : <Eye />}
                </Button>
            </div>
            
            {isExpanded && (
                <div className="mt-3 pt-3 border-t border-zinc-700">
                    <LayerMetadataDisplay metadata={layer.metadata} />
                </div>
            )}
        </div>
    );
}
```

### Frontend: `client/src/hooks/useVerificationWebSocket.ts`

#### WebSocket Hook (Lines 1-150)
```typescript
// 1-30: Imports
import { useEffect, useRef, useState, useCallback } from 'react';
import type { LayerUpdate, VerificationProgress } from '@/types/layers';

// 31-60: Interface
interface UseVerificationWebSocketOptions {
    assetId: number;
    onLayerUpdate?: (update: LayerUpdate) => void;
    onProgress?: (progress: VerificationProgress) => void;
    onError?: (error: Error) => void;
    autoReconnect?: boolean;
    reconnectInterval?: number;
}

// 61-100: Hook implementation
export function useVerificationWebSocket({
    assetId,
    onLayerUpdate,
    onProgress,
    onError,
    autoReconnect = true,
    reconnectInterval = 3000
}: UseVerificationWebSocketOptions) {
    const [connected, setConnected] = useState(false);
    const [connectionError, setConnectionError] = useState<Error | null>(null);
    const wsRef = useRef<WebSocket | null>(null);
    const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
    
    // 101-150: Connection logic
    const connect = useCallback(() => {
        if (wsRef.current?.readyState === WebSocket.OPEN) {
            return; // Already connected
        }
        
        try {
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const wsUrl = `${protocol}//${window.location.host}/ws/verification/${assetId}`;
            
            const ws = new WebSocket(wsUrl);
            
            ws.onopen = () => {
                setConnected(true);
                setConnectionError(null);
                console.log('WebSocket connected');
            };
            
            ws.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    
                    if (data.type === 'layer_update') {
                        onLayerUpdate?.(data as LayerUpdate);
                    } else if (data.type === 'progress') {
                        onProgress?.(data as VerificationProgress);
                    }
                } catch (error) {
                    console.error('Failed to parse WebSocket message:', error);
                }
            };
            
            ws.onerror = (error) => {
                const err = new Error('WebSocket error');
                setConnectionError(err);
                onError?.(err);
            };
            
            ws.onclose = () => {
                setConnected(false);
                
                if (autoReconnect) {
                    reconnectTimeoutRef.current = setTimeout(() => {
                        connect();
                    }, reconnectInterval);
                }
            };
            
            wsRef.current = ws;
        } catch (error) {
            const err = error instanceof Error ? error : new Error('Connection failed');
            setConnectionError(err);
            onError?.(err);
        }
    }, [assetId, onLayerUpdate, onProgress, onError, autoReconnect, reconnectInterval]);
    
    // 151-200: Cleanup and effects
    useEffect(() => {
        connect();
        
        return () => {
            if (reconnectTimeoutRef.current) {
                clearTimeout(reconnectTimeoutRef.current);
            }
            if (wsRef.current) {
                wsRef.current.close();
            }
        };
    }, [connect]);
    
    return {
        connected,
        connectionError,
        reconnect: connect
    };
}
```

---

## API Specifications

### REST API Endpoints

#### GET /api/layers/{asset_id}
List all available layers for an asset.

**Response**:
```json
{
  "layers": [
    {
      "id": "layer_123",
      "type": "ndvi",
      "band_name": null,
      "metadata": {
        "name": "NDVI Index",
        "resolution": 10,
        "min_value": -0.2,
        "max_value": 0.9,
        "mean_value": 0.65,
        "created_at": "2024-12-01T10:00:00Z"
      },
      "thumbnail_url": "/api/layers/layer_123/thumbnail",
      "bounds": {
        "north": 38.3,
        "south": 38.29,
        "east": -122.28,
        "west": -122.29
      }
    }
  ]
}
```

#### GET /api/layers/{asset_id}/{layer_type}
Get specific layer data.

**Query Parameters**:
- `format`: `png` | `geotiff` | `json` (default: `png`)
- `resolution`: Resolution in meters (optional)

**Response** (PNG format):
- Binary PNG image data
- Content-Type: `image/png`

**Response** (JSON format):
```json
{
  "id": "layer_123",
  "type": "ndvi",
  "data": {
    "format": "array",
    "values": [[0.65, 0.72, ...], ...],
    "shape": [100, 100]
  },
  "metadata": { ... },
  "bounds": { ... }
}
```

#### GET /api/layers/{asset_id}/{layer_type}/metadata
Get layer metadata only.

**Response**:
```json
{
  "id": "layer_123",
  "type": "ndvi",
  "metadata": {
    "name": "NDVI Index",
    "resolution": 10,
    "min_value": -0.2,
    "max_value": 0.9,
    "mean_value": 0.65,
    "created_at": "2024-12-01T10:00:00Z"
  },
  "bounds": { ... },
  "file_size": 1024000,
  "file_path": "/storage/layers/layer_123.png"
}
```

#### POST /api/layers/{asset_id}/generate
Generate missing layers for an asset.

**Request Body**:
```json
{
  "layer_types": ["ndvi", "false_color", "classification"],
  "force_regenerate": false
}
```

**Response**:
```json
{
  "generated": ["layer_123", "layer_124"],
  "existing": ["layer_125"],
  "failed": []
}
```

### WebSocket API

#### Connection: `/ws/verification/{asset_id}`

**Message Types**:

1. **Progress Update**:
```json
{
  "type": "progress",
  "stage": "fetching_bands",
  "current": 5,
  "total": 13,
  "band": "B08",
  "percentage": 38.5,
  "estimated_seconds_remaining": 45
}
```

2. **Layer Update**:
```json
{
  "type": "layer_update",
  "layer_id": "layer_123",
  "layer_type": "ndvi",
  "status": "processing" | "complete" | "error",
  "progress": 0.75,
  "metadata": { ... },
  "thumbnail_url": "/api/layers/layer_123/thumbnail"
}
```

3. **Verification Complete**:
```json
{
  "type": "verification_complete",
  "asset_id": 123,
  "layers_generated": ["layer_123", "layer_124"],
  "ndvi_score": 0.65,
  "risk_status": "BREACH"
}
```

4. **Error**:
```json
{
  "type": "error",
  "message": "Failed to fetch satellite data",
  "stage": "fetching_bands",
  "retryable": true
}
```

---

## UI/UX Design

### Verification Progress Display

**Layout**:
```
┌─────────────────────────────────────────────────┐
│  Verification Progress                           │
├─────────────────────────────────────────────────┤
│  [████████████░░░░░░░░] 65%                     │
│                                                   │
│  Current Stage: Processing NDVI Layer            │
│                                                   │
│  ✓ Geocoding Complete                            │
│  ✓ Satellite Data Fetched                        │
│  → Calculating NDVI...                            │
│  ⏳ Land Use Classification (Pending)             │
│                                                   │
│  Estimated time remaining: 45 seconds            │
│                                                   │
│  [Cancel Verification]                            │
└─────────────────────────────────────────────────┘
```

### Layer Browser

**Layout**:
```
┌─────────────────────────────────────────────────┐
│  Available Layers                    [Refresh]  │
├─────────────────────────────────────────────────┤
│  ┌───────────────────────────────────────────┐ │
│  │ [Thumb] NDVI Index              [👁]      │ │
│  │         10m • Derived                     │ │
│  │         Min: -0.2, Max: 0.9              │ │
│  └───────────────────────────────────────────┘ │
│  ┌───────────────────────────────────────────┐ │
│  │ [Thumb] False Color Composite  [👁]      │ │
│  │         10m • NIR-Red-Blue                │ │
│  └───────────────────────────────────────────┘ │
│  ┌───────────────────────────────────────────┐ │
│  │ [Thumb] Land Use Classification [👁]      │ │
│  │         10m • Forest (94% confidence)    │ │
│  └───────────────────────────────────────────┘ │
│  ┌───────────────────────────────────────────┐ │
│  │ [Thumb] Sentinel-2 Band 4 (Red)  [👁]     │ │
│  │         10m • 665nm                       │ │
│  └───────────────────────────────────────────┘ │
└─────────────────────────────────────────────────┘
```

### Map Overlay Controls

**Layout**:
```
┌────────────────────────┐
│  Layer Overlays        │
├────────────────────────┤
│  [Layer Selector ▼]    │
│  NDVI Index            │
│                        │
│  Opacity: [━━━●━━] 70% │
│                        │
│  Blending: [Normal ▼]  │
│                        │
│  [✓] Show on Map       │
│  [ ] Compare Mode      │
└────────────────────────┘
```

### Layer Animation Controller

**Layout**:
```
┌─────────────────────────────────────────┐
│  Layer Animation                       │
├─────────────────────────────────────────┤
│  [⏮] [⏸] [⏭]  Speed: [●○○] Normal    │
│                                           │
│  [━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━]   │
│  Layer 5 of 13: NDVI Index               │
│                                           │
│  [✓] Loop                                │
└─────────────────────────────────────────┘
```

---

## Testing Strategy

### Unit Tests

1. **Backend**:
   - `test_layer_processing_service.py`: Test layer generation methods
   - `test_layer_storage_service.py`: Test storage and retrieval
   - `test_layer_routes.py`: Test API endpoints

2. **Frontend**:
   - `LayerBrowser.test.tsx`: Test layer browser component
   - `VerificationProgress.test.tsx`: Test progress display
   - `useVerificationWebSocket.test.ts`: Test WebSocket hook

### Integration Tests

1. **End-to-End Verification Flow**:
   - Test complete verification with layer generation
   - Test WebSocket connection and updates
   - Test layer display on map

2. **Layer Browser**:
   - Test layer fetching and display
   - Test layer selection and map update
   - Test layer comparison mode

### Performance Tests

1. **Layer Loading**:
   - Test loading time for large layers
   - Test memory usage with multiple layers
   - Test map rendering performance

2. **WebSocket**:
   - Test connection stability
   - Test message handling performance
   - Test reconnection logic

---

## Deployment Plan

### Phase 1: Backend Foundation (Week 1)
- Implement layer processing service
- Create database models and migrations
- Implement basic layer API endpoints
- Add unit tests

### Phase 2: Frontend Components (Week 2)
- Create layer browser component
- Enhance MapView with overlay support
- Create verification progress component
- Add basic styling

### Phase 3: Real-Time Integration (Week 3)
- Implement WebSocket backend
- Integrate WebSocket client
- Add real-time layer updates
- Test end-to-end flow

### Phase 4: Polish & Enhancement (Week 4)
- Add layer animation controller
- Enhance UI/UX
- Add error handling and edge cases
- Performance optimization
- Documentation

### Rollout Strategy

1. **Development**: Feature flag `ENABLE_LAYER_VISUALIZATION`
2. **Staging**: Full testing with real satellite data
3. **Production**: Gradual rollout (10% → 50% → 100%)

---

## Success Metrics

1. **User Engagement**:
   - % of users who interact with layer browser
   - Average time spent viewing layers
   - Number of layers viewed per verification

2. **Performance**:
   - Layer loading time < 2 seconds
   - Map rendering FPS > 30
   - WebSocket connection stability > 99%

3. **User Satisfaction**:
   - User feedback on layer visualization
   - Reduction in support tickets about verification status
   - Increased feature adoption rate

---

## Future Enhancements

1. **Temporal Analysis**: Compare layers across time periods
2. **3D Visualization**: Add 3D terrain visualization
3. **Machine Learning Insights**: Auto-detect anomalies in layers
4. **Export Functionality**: Export layers as GeoTIFF/PNG
5. **Collaborative Features**: Share layer views with team
6. **Custom Layer Creation**: Allow users to create custom derived layers

---

## Appendix

### A. Layer Type Definitions

```typescript
enum LayerType {
  SENTINEL_BAND = 'sentinel_band',
  NDVI = 'ndvi',
  FALSE_COLOR = 'false_color',
  CLASSIFICATION = 'classification',
  RISK_STATUS = 'risk_status',
  AIR_QUALITY = 'air_quality',
  OSM_OVERLAY = 'osm_overlay'
}
```

### B. Color Schemes

**NDVI Heatmap**:
- -1.0 to 0.0: Blue (water/bare soil)
- 0.0 to 0.3: Yellow (sparse vegetation)
- 0.3 to 0.6: Light Green (moderate vegetation)
- 0.6 to 1.0: Dark Green (dense vegetation)

**Risk Status**:
- COMPLIANT: Green (#10b981)
- WARNING: Yellow (#f59e0b)
- BREACH: Red (#ef4444)

### C. Performance Benchmarks

- Layer generation: < 5 seconds per layer
- Layer loading: < 2 seconds
- Map overlay rendering: 60 FPS
- WebSocket message processing: < 50ms

---

**Document Version**: 1.0  
**Last Updated**: 2024-12-XX  
**Author**: CreditNexus Development Team  
**Status**: Ready for Implementation
