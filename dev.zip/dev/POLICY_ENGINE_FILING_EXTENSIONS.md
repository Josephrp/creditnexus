# Policy Engine Extensions for Filing Compliance

## Executive Summary

This document outlines how to extend the CreditNexus policy engine to include filing compliance rules, deadline tracking, and automated filing requirement evaluation. It integrates with the existing policy service architecture and follows CDM compliance patterns.

**Last Updated**: 2024-12-XX  
**Status**: Design Complete - Ready for Implementation

---

## Table of Contents

1. [Policy Engine Architecture](#policy-engine-architecture)
2. [New Policy Evaluation Methods](#new-policy-evaluation-methods)
3. [Filing Compliance Rules](#filing-compliance-rules)
4. [Deadline Tracking Policies](#deadline-tracking-policies)
5. [Integration with Existing Policy Service](#integration-with-existing-policy-service)
6. [CDM Event Generation](#cdm-event-generation)

---

## Policy Engine Architecture

### Current Policy Service Structure

```python
# app/services/policy_service.py
class PolicyService:
    def evaluate_facility_creation(...) -> PolicyDecision
    def evaluate_trade_execution(...) -> PolicyDecision
    def evaluate_loan_asset(...) -> PolicyDecision
    def evaluate_terms_change(...) -> PolicyDecision
```

### Extended Policy Service Structure

```python
# app/services/policy_service.py (Extended)
class PolicyService:
    # Existing methods...
    def evaluate_facility_creation(...) -> PolicyDecision
    def evaluate_trade_execution(...) -> PolicyDecision
    def evaluate_loan_asset(...) -> PolicyDecision
    def evaluate_terms_change(...) -> PolicyDecision
    
    # New filing-related methods
    def evaluate_filing_requirements(
        self,
        credit_agreement: CreditAgreement,
        document_id: Optional[int] = None
    ) -> FilingRequirementDecision
    
    def check_filing_deadlines(
        self,
        deal_id: Optional[int] = None,
        document_id: Optional[int] = None
    ) -> List[DeadlineAlert]
    
    def evaluate_filing_compliance(
        self,
        filing_id: int,
        jurisdiction: str
    ) -> PolicyDecision
```

---

## New Policy Evaluation Methods

### 1. evaluate_filing_requirements()

**Purpose**: Determine which filing requirements apply to a credit agreement based on jurisdiction, agreement type, and transaction characteristics.

**Method Signature**:
```python
def evaluate_filing_requirements(
    self,
    credit_agreement: CreditAgreement,
    document_id: Optional[int] = None,
    deal_id: Optional[int] = None
) -> FilingRequirementDecision:
    """
    Evaluate filing requirements for a credit agreement.
    
    Args:
        credit_agreement: CDM CreditAgreement instance
        document_id: Optional document ID for audit trail
        deal_id: Optional deal ID for context
        
    Returns:
        FilingRequirementDecision with:
        - required_filings: List of FilingRequirement objects
        - deadline_alerts: List of DeadlineAlert objects
        - compliance_status: "compliant" | "non_compliant" | "pending"
    """
```

**Implementation Pattern**:
```python
def evaluate_filing_requirements(
    self,
    credit_agreement: CreditAgreement,
    document_id: Optional[int] = None,
    deal_id: Optional[int] = None
) -> FilingRequirementDecision:
    """Evaluate filing requirements for a credit agreement."""
    # 1. Extract jurisdiction from governing_law
    jurisdiction = self._extract_jurisdiction(credit_agreement.governing_law)
    
    # 2. Determine agreement type from CDM data
    agreement_type = self._determine_agreement_type(credit_agreement)
    
    # 3. Load compliance rules for jurisdiction
    compliance_rules = self._load_compliance_rules(jurisdiction)
    
    # 4. Evaluate each rule's trigger conditions
    required_filings = []
    for rule in compliance_rules:
        if agreement_type in rule.agreement_types:
            if self._evaluate_triggers(rule.triggers, credit_agreement):
                filing_req = FilingRequirement(
                    authority=rule.authority,
                    filing_system=rule.filing_system,
                    deadline=self._calculate_deadline(rule.deadline, credit_agreement),
                    required_fields=rule.required_fields,
                    api_available=rule.api_available,
                    api_endpoint=rule.api_endpoint if rule.api_available else None,
                    penalty=rule.penalty
                )
                required_filings.append(filing_req)
    
    # 5. Check if all required fields are present
    missing_fields = self._check_required_fields(required_filings, credit_agreement)
    
    # 6. Determine compliance status
    compliance_status = "compliant" if not missing_fields else "non_compliant"
    
    # 7. Generate deadline alerts
    deadline_alerts = self._generate_deadline_alerts(required_filings)
    
    return FilingRequirementDecision(
        required_filings=required_filings,
        deadline_alerts=deadline_alerts,
        compliance_status=compliance_status,
        missing_fields=missing_fields,
        trace_id=f"filing_req_{document_id}_{datetime.utcnow().isoformat()}" if document_id else f"filing_req_{datetime.utcnow().isoformat()}",
        metadata={"document_id": document_id, "deal_id": deal_id, "jurisdiction": jurisdiction}
    )
```

### 2. check_filing_deadlines()

**Purpose**: Monitor and alert on approaching filing deadlines for active deals and documents.

**Method Signature**:
```python
def check_filing_deadlines(
    self,
    deal_id: Optional[int] = None,
    document_id: Optional[int] = None,
    days_ahead: int = 7
) -> List[DeadlineAlert]:
    """
    Check for approaching filing deadlines.
    
    Args:
        deal_id: Optional deal ID to check
        document_id: Optional document ID to check
        days_ahead: Number of days ahead to check (default: 7)
        
    Returns:
        List of DeadlineAlert objects for deadlines within days_ahead
    """
```

**Implementation Pattern**:
```python
def check_filing_deadlines(
    self,
    deal_id: Optional[int] = None,
    document_id: Optional[int] = None,
    days_ahead: int = 7
) -> List[DeadlineAlert]:
    """Check for approaching filing deadlines."""
    from app.db.models import DocumentFiling, Document, Deal
    from datetime import datetime, timedelta
    
    alerts = []
    cutoff_date = datetime.utcnow() + timedelta(days=days_ahead)
    
    # Query pending filings
    query = self.db.query(DocumentFiling).filter(
        DocumentFiling.filing_status == "pending"
    )
    
    if deal_id:
        query = query.filter(DocumentFiling.deal_id == deal_id)
    if document_id:
        query = query.filter(DocumentFiling.document_id == document_id)
    
    pending_filings = query.all()
    
    for filing in pending_filings:
        # Calculate deadline from agreement date
        if filing.document:
            agreement_date = filing.document.agreement_date
            if agreement_date:
                # Get deadline rule for this filing
                deadline_rule = self._get_deadline_rule(
                    filing.jurisdiction,
                    filing.agreement_type
                )
                
                if deadline_rule:
                    deadline = self._calculate_deadline(
                        deadline_rule.deadline,
                        agreement_date
                    )
                    
                    if deadline <= cutoff_date:
                        days_remaining = (deadline - datetime.utcnow()).days
                        alert = DeadlineAlert(
                            filing_id=filing.id,
                            document_id=filing.document_id,
                            deal_id=filing.deal_id,
                            authority=filing.filing_authority,
                            deadline=deadline,
                            days_remaining=days_remaining,
                            urgency="critical" if days_remaining <= 1 else "high" if days_remaining <= 3 else "medium",
                            penalty=filing.penalty if hasattr(filing, 'penalty') else None
                        )
                        alerts.append(alert)
    
    return alerts
```

### 3. evaluate_filing_compliance()

**Purpose**: Evaluate whether a filing submission meets compliance requirements before submission.

**Method Signature**:
```python
def evaluate_filing_compliance(
    self,
    filing_id: int,
    jurisdiction: str
) -> PolicyDecision:
    """
    Evaluate filing compliance before submission.
    
    Args:
        filing_id: DocumentFiling ID
        jurisdiction: Filing jurisdiction
        
    Returns:
        PolicyDecision with ALLOW/BLOCK/FLAG
    """
```

---

## Filing Compliance Rules

### Policy Rule Format

Filing compliance rules follow the existing policy rule format but with filing-specific fields:

```yaml
# app/policies/filing_compliance.yaml

- name: us_sec_material_agreement_filing
  when:
    all:
      - field: jurisdiction
        op: equals
        value: "US"
      - field: agreement_type
        op: in
        value: ["facility_agreement", "loan_agreement", "credit_agreement"]
      - any:
          - field: total_commitment
            op: greater_than
            value: "total_assets * 0.10"
          - field: total_commitment
            op: greater_than
            value: 1000000
          - field: material_restrictions
            op: equals
            value: true
  action: require_filing
  filing_authority: "SEC"
  filing_system: "edgar"
  filing_form: "8-K"
  deadline: "4 business days from agreement_date"
  priority: 100
  description: "SEC 8-K filing required for material credit agreements"

- name: uk_companies_house_charge_filing
  when:
    all:
      - field: jurisdiction
        op: equals
        value: "UK"
      - field: security_type
        op: in
        value: ["charge", "mortgage", "security_interest"]
      - field: agreement_type
        op: in
        value: ["facility_agreement", "security_agreement", "charge_agreement"]
  action: require_filing
  filing_authority: "Companies House"
  filing_system: "companies_house_api"
  filing_form: "MR01"
  deadline: "21 days from charge_creation_date"
  priority: 100
  description: "Companies House charge registration required within 21 days"
  api_available: true
  api_endpoint: "POST /company/{company_number}/charges"

- name: fr_amf_foreign_investment_filing
  when:
    all:
      - field: jurisdiction
        op: equals
        value: "FR"
      - field: foreign_investor
        op: equals
        value: true
      - field: ownership_percentage
        op: greater_than
        value: 25
      - field: sector
        op: in
        value: ["defense", "energy", "water", "transport"]
  action: require_filing
  filing_authority: "AMF"
  filing_system: "manual"
  deadline: "Before transaction_closing_date"
  priority: 100
  description: "AMF foreign investment authorization required for strategic sectors"
  language_requirement: "French"
```

### Rule Loading Integration

```python
# app/services/policy_service.py

def _load_filing_compliance_rules(self, jurisdiction: str) -> List[Dict[str, Any]]:
    """Load filing compliance rules for a jurisdiction."""
    from app.core.policy_config import PolicyConfigLoader
    
    loader = PolicyConfigLoader()
    rules = loader.load_rules_from_file(
        f"app/policies/filing_compliance_{jurisdiction.lower()}.yaml"
    )
    
    # Also load general filing rules
    general_rules = loader.load_rules_from_file(
        "app/policies/filing_compliance.yaml"
    )
    
    # Filter by jurisdiction
    jurisdiction_rules = [
        rule for rule in general_rules + rules
        if rule.get("when", {}).get("all", [{}])[0].get("value") == jurisdiction
    ]
    
    return jurisdiction_rules
```

---

## Deadline Tracking Policies

### Deadline Alert Policy

```yaml
# app/policies/filing_deadlines.yaml

- name: filing_deadline_approaching_critical
  when:
    all:
      - field: filing_status
        op: equals
        value: "pending"
      - field: days_until_deadline
        op: less_than_or_equal
        value: 1
  action: alert
  priority: 1000
  alert_type: "critical"
  description: "Filing deadline is today or tomorrow - immediate action required"
  notification_channels: ["email", "slack", "in_app"]

- name: filing_deadline_approaching_high
  when:
    all:
      - field: filing_status
        op: equals
        value: "pending"
      - field: days_until_deadline
        op: between
        value: [2, 3]
  action: alert
  priority: 500
  alert_type: "high"
  description: "Filing deadline approaching within 2-3 days"
  notification_channels: ["email", "in_app"]

- name: filing_deadline_approaching_medium
  when:
    all:
      - field: filing_status
        op: equals
        value: "pending"
      - field: days_until_deadline
        op: between
        value: [4, 7]
  action: alert
  priority: 200
  alert_type: "medium"
  description: "Filing deadline approaching within 4-7 days"
  notification_channels: ["in_app"]
```

---

## Integration with Existing Policy Service

### Extended Policy Service Class

```python
# app/services/policy_service.py

from dataclasses import dataclass
from typing import List, Optional, Dict, Any
from datetime import datetime

@dataclass
class FilingRequirement:
    """Represents a filing requirement for an agreement."""
    authority: str
    filing_system: str
    deadline: datetime
    required_fields: List[str]
    api_available: bool
    api_endpoint: Optional[str] = None
    penalty: Optional[str] = None
    language_requirement: Optional[str] = None

@dataclass
class DeadlineAlert:
    """Represents a deadline alert for a filing."""
    filing_id: int
    document_id: Optional[int]
    deal_id: Optional[int]
    authority: str
    deadline: datetime
    days_remaining: int
    urgency: str  # "critical", "high", "medium", "low"
    penalty: Optional[str] = None

@dataclass
class FilingRequirementDecision:
    """Result of filing requirement evaluation."""
    required_filings: List[FilingRequirement]
    deadline_alerts: List[DeadlineAlert]
    compliance_status: str  # "compliant", "non_compliant", "pending"
    missing_fields: List[str]
    trace_id: str
    metadata: Dict[str, Any]

class PolicyService:
    # ... existing methods ...
    
    def evaluate_filing_requirements(
        self,
        credit_agreement: CreditAgreement,
        document_id: Optional[int] = None,
        deal_id: Optional[int] = None
    ) -> FilingRequirementDecision:
        """Evaluate filing requirements for a credit agreement."""
        # Implementation as shown above
        pass
    
    def check_filing_deadlines(
        self,
        deal_id: Optional[int] = None,
        document_id: Optional[int] = None,
        days_ahead: int = 7
    ) -> List[DeadlineAlert]:
        """Check for approaching filing deadlines."""
        # Implementation as shown above
        pass
    
    def evaluate_filing_compliance(
        self,
        filing_id: int,
        jurisdiction: str
    ) -> PolicyDecision:
        """Evaluate filing compliance before submission."""
        # Load filing from database
        from app.db.models import DocumentFiling
        filing = self.db.query(DocumentFiling).filter(
            DocumentFiling.id == filing_id
        ).first()
        
        if not filing:
            raise ValueError(f"Filing {filing_id} not found")
        
        # Convert filing to policy transaction
        tx = self._filing_to_policy_transaction(filing, jurisdiction)
        
        # Evaluate using policy engine
        result = self.engine.evaluate(tx)
        
        return PolicyDecision(
            decision=result["decision"],
            rule_applied=result.get("rule"),
            trace_id=f"filing_compliance_{filing_id}_{datetime.utcnow().isoformat()}",
            trace=result.get("trace", []),
            matched_rules=result.get("matched_rules", []),
            metadata={"filing_id": filing_id, "jurisdiction": jurisdiction}
        )
```

---

## CDM Event Generation

### Filing Requirement CDM Event

```python
# app/models/cdm_events.py

def generate_cdm_filing_requirement(
    transaction_id: str,
    filing_requirement: FilingRequirement,
    credit_agreement: CreditAgreement,
    related_event_identifiers: List[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Generate CDM event for filing requirement.
    
    Args:
        transaction_id: Deal/transaction identifier
        filing_requirement: FilingRequirement object
        credit_agreement: Source credit agreement
        related_event_identifiers: Related CDM events
        
    Returns:
        CDM FilingRequirement event dictionary
    """
    return {
        "eventType": "FilingRequirement",
        "eventDate": datetime.utcnow().isoformat(),
        "meta": {
            "globalKey": {
                "issuer": "CreditNexus",
                "assignedIdentifier": [{
                    "identifier": {
                        "value": f"filing_req_{transaction_id}_{datetime.utcnow().timestamp()}"
                    }
                }]
            }
        },
        "transactionIdentifier": {
            "issuer": "CreditNexus",
            "assignedIdentifier": [{
                "identifier": {
                    "value": transaction_id
                }
            }]
        },
        "filingRequirement": {
            "authority": filing_requirement.authority,
            "filingSystem": filing_requirement.filing_system,
            "deadline": filing_requirement.deadline.isoformat(),
            "requiredFields": filing_requirement.required_fields,
            "apiAvailable": filing_requirement.api_available,
            "apiEndpoint": filing_requirement.api_endpoint,
            "penalty": filing_requirement.penalty
        },
        "relatedEventIdentifier": related_event_identifiers or []
    }
```

### Filing Submission CDM Event

```python
def generate_cdm_filing_submission(
    transaction_id: str,
    filing_id: int,
    filing_status: str,
    filing_reference: Optional[str] = None,
    related_event_identifiers: List[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Generate CDM event for filing submission.
    
    Args:
        transaction_id: Deal/transaction identifier
        filing_id: DocumentFiling ID
        filing_status: "pending", "submitted", "accepted", "rejected"
        filing_reference: External filing reference (if available)
        related_event_identifiers: Related CDM events
        
    Returns:
        CDM FilingSubmission event dictionary
    """
    return {
        "eventType": "FilingSubmission",
        "eventDate": datetime.utcnow().isoformat(),
        "meta": {
            "globalKey": {
                "issuer": "CreditNexus",
                "assignedIdentifier": [{
                    "identifier": {
                        "value": f"filing_sub_{filing_id}_{datetime.utcnow().timestamp()}"
                    }
                }]
            }
        },
        "transactionIdentifier": {
            "issuer": "CreditNexus",
            "assignedIdentifier": [{
                "identifier": {
                    "value": transaction_id
                }
            }]
        },
        "filingSubmission": {
            "filingId": filing_id,
            "filingStatus": filing_status,
            "filingReference": filing_reference,
            "submittedAt": datetime.utcnow().isoformat()
        },
        "relatedEventIdentifier": related_event_identifiers or []
    }
```

---

## Integration Points

### 1. Document Generation Workflow

```python
# app/generation/service.py

def generate_document(...) -> GeneratedDocument:
    # ... existing generation logic ...
    
    # After document generation, evaluate filing requirements
    if deal_id:
        policy_service = PolicyService(get_policy_engine())
        filing_requirements = policy_service.evaluate_filing_requirements(
            credit_agreement=cdm_data,
            document_id=generated_doc_record.id,
            deal_id=deal_id
        )
        
        # Create filing records for each requirement
        for req in filing_requirements.required_filings:
            filing_service = FilingService(db)
            filing_service.create_filing_requirement(
                document_id=generated_doc_record.id,
                deal_id=deal_id,
                requirement=req
            )
```

### 2. Workflow Approval Trigger

```python
# app/api/routes.py

@router.post("/documents/{document_id}/workflow/approve")
async def approve_document(...):
    # ... existing approval logic ...
    
    # After approval, check filing requirements
    if workflow.state == WorkflowState.APPROVED.value:
        policy_service = PolicyService(get_policy_engine())
        filing_requirements = policy_service.evaluate_filing_requirements(
            credit_agreement=credit_agreement,
            document_id=document_id,
            deal_id=document.deal_id
        )
        
        # Auto-queue filings if configured
        if settings.AUTO_FILE_ON_APPROVAL:
            filing_service = FilingService(db)
            for req in filing_requirements.required_filings:
                if req.api_available:
                    filing_service.file_document_automatically(
                        document_id=document_id,
                        requirement=req
                    )
```

---

## Next Steps

1. ✅ **Policy Engine Extensions Designed** - This document
2. ⏳ **Policy Rules Implementation** - Create YAML rule files
3. ⏳ **Service Implementation** - Implement new methods
4. ⏳ **CDM Event Integration** - Add event generation
5. ⏳ **Testing** - Unit and integration tests

---

**Document Status**: ✅ Complete  
**Ready for**: Implementation
