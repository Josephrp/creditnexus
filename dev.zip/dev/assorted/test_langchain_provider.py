"""
Test script to verify HuggingFace inference provider integration with OpenAI-compatible endpoints.
Tests structured outputs, device auto-detection, and provider configuration.
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv
from typing import Optional

# Load environment variables from .env file
env_path = Path(__file__).parent.parent / ".env"
if env_path.exists():
    load_dotenv(env_path)
    print(f"Loaded environment from: {env_path}")
else:
    print(f"WARNING: .env file not found at {env_path}")

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

def test_structured_outputs(llm, test_name: str = "Test") -> bool:
    """Test structured outputs with a Pydantic schema."""
    try:
        from pydantic import BaseModel, Field
        from typing import Optional
        
        class TestSchema(BaseModel):
            """Test schema for structured output."""
            name: str = Field(description="A name")
            value: int = Field(description="A numeric value")
            optional_field: Optional[str] = Field(None, description="An optional field")
        
        print(f"\n   Testing structured outputs with {test_name}...")
        structured_llm = llm.with_structured_output(TestSchema)
        
        response = structured_llm.invoke("Extract: name is 'TestModel', value is 42")
        
        if isinstance(response, TestSchema):
            print(f"   [OK] Structured output successful!")
            print(f"   - name: {response.name}")
            print(f"   - value: {response.value}")
            return True
        else:
            print(f"   [FAIL] Unexpected response type: {type(response)}")
            return False
    except Exception as e:
        print(f"   [FAIL] Structured output failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_device_auto_detection() -> bool:
    """Test device auto-detection for embeddings."""
    try:
        from app.core.llm_client import create_embeddings_model
        
        print("\n" + "-" * 80)
        print("Test: Device Auto-Detection for Embeddings")
        print("-" * 80)
        
        # Test with device="auto"
        print("   Testing with device='auto'...")
        embeddings = create_embeddings_model(
            provider="huggingface",
            model="sentence-transformers/all-MiniLM-L6-v2",
            use_local=True,
            device="auto",
            api_key=os.environ.get("HUGGINGFACE_API_KEY")
        )
        
        print(f"   [OK] Embeddings model created successfully")
        print(f"   - Type: {type(embeddings)}")
        
        # Test embedding generation
        print("\n   Testing embedding generation...")
        test_text = "This is a test sentence."
        embedding = embeddings.embed_query(test_text)
        
        print(f"   [OK] Embedding generated successfully")
        print(f"   - Embedding dimension: {len(embedding)}")
        return True
        
    except Exception as e:
        print(f"   [FAIL] Device auto-detection test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_langchain_init_chat_model():
    """Test HuggingFace inference providers with OpenAI-compatible endpoints."""
    
    print("=" * 80)
    print("Testing HuggingFace Inference Providers with OpenAI-Compatible Endpoints")
    print("=" * 80)
    
    # Get API key from environment
    hf_token = os.environ.get("HUGGINGFACEHUB_API_TOKEN") or os.environ.get("HUGGINGFACE_API_KEY")
    if not hf_token:
        print("ERROR: HUGGINGFACEHUB_API_TOKEN or HUGGINGFACE_API_KEY not set in .env")
        print("Please set HUGGINGFACE_API_KEY in your .env file")
        return False
    
    # Set token for LangChain
    os.environ["HUGGINGFACEHUB_API_TOKEN"] = hf_token
    print(f"SUCCESS: Using HuggingFace API token (length: {len(hf_token)})")
    
    results = []
    
    # Test 1: OpenAI-Compatible Endpoint (New Implementation)
    print("\n" + "-" * 80)
    print("Test 1: OpenAI-Compatible Endpoint with ChatOpenAI")
    print("-" * 80)
    try:
        from app.core.llm_client import create_chat_model
        from langchain_core.messages import HumanMessage
        
        # Use user's model from .env
        test_model = os.environ.get("LLM_MODEL", "deepseek-ai/DeepSeek-V3.2-Exp:novita")
        print(f"   Testing with model: {test_model}")
        
        llm = create_chat_model(
            provider="huggingface",
            model=test_model,
            temperature=0.8,
            api_key=hf_token
        )
        
        print(f"   [OK] Created ChatOpenAI with OpenAI-compatible endpoint")
        print(f"   - Type: {type(llm)}")
        print(f"   - Base URL: {llm.openai_api_base if hasattr(llm, 'openai_api_base') else 'N/A'}")
        
        # Test basic inference
        print("\n   Testing basic inference...")
        response = llm.invoke([HumanMessage(content="Say 'Hello' in one word.")])
        print(f"   Response: {response.content}")
        print("   [OK] Basic inference working!")
        
        # Test structured outputs
        structured_result = test_structured_outputs(llm, "ChatOpenAI")
        results.append(("Test 1: OpenAI-Compatible Endpoint", structured_result))
        
    except Exception as e:
        print(f"   [FAIL] Test 1 failed: {e}")
        import traceback
        traceback.print_exc()
        results.append(("Test 1: OpenAI-Compatible Endpoint", False))
    
    # Test 2: Model:Provider Format Parsing
    print("\n" + "-" * 80)
    print("Test 2: Model:Provider Format Parsing")
    print("-" * 80)
    try:
        from app.core.llm_client import create_chat_model
        from langchain_core.messages import HumanMessage
        
        # Test with model:provider format
        model_with_provider = "deepseek-ai/DeepSeek-V3.2-Exp:novita"
        print(f"   Input: {model_with_provider}")
        
        llm = create_chat_model(
            provider="huggingface",
            model=model_with_provider,
            temperature=0.8,
            api_key=hf_token,
            inference_provider="together"  # This should be overridden by model:provider
        )
        
        print(f"   [OK] Created model from model:provider format")
        print(f"   - Type: {type(llm)}")
        
        # Verify provider was extracted correctly by checking base URL
        if hasattr(llm, 'openai_api_base'):
            base_url = llm.openai_api_base
            if "novita" in base_url:
                print(f"   [OK] Provider 'novita' correctly extracted (base_url contains 'novita')")
            else:
                print(f"   [WARN] Base URL: {base_url}")
        
        # Test inference
        print("\n   Testing inference with parsed provider...")
        response = llm.invoke([HumanMessage(content="Say 'Test' in one word.")])
        print(f"   Response: {response.content}")
        print("   [OK] Model:provider format working correctly!")
        
        results.append(("Test 2: Model:Provider Format", True))
        
    except Exception as e:
        print(f"   [FAIL] Test 2 failed: {e}")
        import traceback
        traceback.print_exc()
        results.append(("Test 2: Model:Provider Format", False))
    
    # Test 3: Provider via Configuration Parameter
    print("\n" + "-" * 80)
    print("Test 3: Provider via Configuration Parameter")
    print("-" * 80)
    try:
        from app.core.llm_client import create_chat_model
        
        # Test without provider in model name, using inference_provider parameter
        model_without_provider = "deepseek-ai/DeepSeek-V3.2-Exp"
        print(f"   Input: {model_without_provider}")
        print(f"   Using inference_provider: 'novita'")
        
        llm = create_chat_model(
            provider="huggingface",
            model=model_without_provider,
            temperature=0.8,
            api_key=hf_token,
            inference_provider="novita"  # From config
        )
        
        print(f"   [OK] Created model with provider from parameter")
        print(f"   - Type: {type(llm)}")
        
        # Verify provider in base URL
        if hasattr(llm, 'openai_api_base'):
            base_url = llm.openai_api_base
            if "novita" in base_url:
                print(f"   [OK] Provider 'novita' correctly used (base_url contains 'novita')")
            else:
                print(f"   [WARN] Base URL: {base_url}")
        
        print("\n   Skipping inference test (rate limit protection)")
        results.append(("Test 3: Provider via Config", True))
        
    except Exception as e:
        print(f"   [FAIL] Test 3 failed: {e}")
        import traceback
        traceback.print_exc()
        results.append(("Test 3: Provider via Config", False))
    
    # Test 4: Provider Priority
    print("\n" + "-" * 80)
    print("Test 4: Provider Priority (model:provider vs config)")
    print("-" * 80)
    try:
        from app.core.llm_client import create_chat_model
        
        # Model with provider should override config
        model_with_provider = "deepseek-ai/DeepSeek-V3.2-Exp:novita"
        print(f"   Model: {model_with_provider}")
        print(f"   inference_provider parameter: 'together' (should be ignored)")
        
        llm = create_chat_model(
            provider="huggingface",
            model=model_with_provider,
            temperature=0.8,
            api_key=hf_token,
            inference_provider="together"  # Should be overridden by model:provider
        )
        
        print(f"   [OK] Created model - provider from model name takes priority")
        print(f"   - Type: {type(llm)}")
        
        # Verify provider from model name was used
        if hasattr(llm, 'openai_api_base'):
            base_url = llm.openai_api_base
            if "novita" in base_url and "together" not in base_url:
                print(f"   [OK] Provider priority correct: 'novita' from model name used")
            else:
                print(f"   [WARN] Base URL: {base_url}")
        
        print("\n   Skipping inference test (rate limit protection)")
        results.append(("Test 4: Provider Priority", True))
        
    except Exception as e:
        print(f"   [FAIL] Test 4 failed: {e}")
        import traceback
        traceback.print_exc()
        results.append(("Test 4: Provider Priority", False))
    
    # Test 5: Device Auto-Detection
    device_result = test_device_auto_detection()
    results.append(("Test 5: Device Auto-Detection", device_result))
    
    # Print Summary
    print("\n" + "=" * 80)
    print("Test Summary:")
    print("=" * 80)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "[PASSED]" if result else "[FAILED]"
        print(f"{status}: {test_name}")
    
    print("=" * 80)
    print(f"Results: {passed}/{total} tests passed")
    print("=" * 80)
    
    return passed == total

if __name__ == "__main__":
    test_langchain_init_chat_model()

