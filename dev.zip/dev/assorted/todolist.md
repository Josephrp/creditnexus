
- [ ] customer splash screen thing
- [ ] llama.cpp client for embeddings
