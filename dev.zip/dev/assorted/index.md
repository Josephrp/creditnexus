# CreditNexus Cursor Rules Index

## Overview

This directory contains comprehensive cursor rules for CreditNexus development, organized by topic. Each file focuses on specific aspects of the codebase and provides patterns, examples, and guidelines.

## Rules Files

### 01-architecture.mdc
**System Architecture and Design Patterns**
- Dependency injection patterns
- Service layer architecture
- Repository patterns
- Factory patterns
- Lifespan management
- Error handling hierarchy
- Configuration management
- Logging patterns
- State management
- Performance guidelines

### 02-cdm-compliance.mdc
**FINOS CDM Compliance Rules**
- CDM event model requirements
- Policy evaluation events
- CDM process model (Validation → Calculation → Event Creation)
- CDM model validation
- CDM state machine
- CDM event storage
- Event relationships
- Compliance checklist

### 03-policy-engine.mdc
**Policy Engine Integration**
- Policy service layer
- Four evaluation types (facility, trade, loan asset, terms change)
- Policy decision handling (BLOCK, FLAG, ALLOW)
- YAML rule configuration
- Policy engine initialization
- Vendor-agnostic interface
- Policy decision storage
- Performance requirements

### 04-llm-client.mdc
**LLM Client Abstraction**
- Abstraction layer patterns
- Provider support (OpenAI, vLLM, HuggingFace)
- Client initialization
- Factory functions (get_chat_model, get_embeddings_model)
- LangChain integration
- Provider-specific details
- Error handling
- Refactoring patterns

### 05-database-orm.mdc
**Database and ORM Patterns**
- SQLAlchemy 2.0 patterns
- Session management
- Database models with type hints
- Query patterns (eager loading, filtering, pagination)
- Transaction management
- Database migrations (Alembic)
- Model serialization
- Connection pooling
- Audit logging

### 06-api-routing.mdc
**API and Routing Patterns**
- FastAPI route definition
- Dependency injection
- Request validation (Pydantic)
- Response patterns
- Error handling hierarchy
- Query parameters
- Pagination
- Authentication and authorization
- Audit logging
- Response streaming
- API documentation

### 07-frontend.mdc
**Frontend Development Rules**
- React functional components
- TypeScript patterns
- State management
- Tailwind CSS styling
- FDC3 integration
- API integration
- Form handling
- Performance optimization
- Type safety

### 08-data-validation.mdc
**Data Validation Patterns**
- Pydantic field validation
- Model validators
- Data normalization (monetary, dates, spreads)
- Business logic validation
- Policy compliance validation
- API request validation
- File upload validation
- Error messages
- Multi-layer validation

## Quick Reference

### Core Principles
1. **CDM Compliance**: All policy decisions as CDM events
2. **LLM Abstraction**: Never direct instantiation, always use factory functions
3. **Policy Integration**: Always evaluate policies, always create CDM events
4. **Data Validation**: Always validate at point of creation
5. **Dependency Injection**: Always use FastAPI Depends()
6. **Type Safety**: Always use TypeScript/Pydantic types

### Common Patterns

**Backend:**
- Use `Depends(get_db)` for database sessions
- Use `Depends(get_current_user)` for authentication
- Use `get_chat_model()` for LLM clients
- Use `PolicyService` for policy evaluation
- Use `log_audit_action()` for audit logging

**Frontend:**
- Use functional components with hooks
- Use TypeScript for all components
- Use Tailwind CSS for styling
- Use FDC3 for desktop integration
- Handle loading and error states

### File Organization

**Backend:**
```
app/
├── core/           # Configuration and utilities
├── models/         # Pydantic models (CDM, events)
├── db/             # Database models
├── api/            # FastAPI routes
├── services/       # Business logic
├── chains/         # LangChain chains
└── policies/       # Policy YAML files
```

**Frontend:**
```
client/src/
├── apps/           # Feature apps
├── components/     # UI components
├── context/        # React context
├── hooks/          # Custom hooks
└── lib/            # Utilities
```

## Usage

When implementing features, refer to the relevant rules file:
- **New API endpoint**: See `06-api-routing.mdc`
- **New database model**: See `05-database-orm.mdc`
- **Policy integration**: See `03-policy-engine.mdc` and `02-cdm-compliance.mdc`
- **LLM integration**: See `04-llm-client.mdc`
- **Frontend component**: See `07-frontend.mdc`
- **Data validation**: See `08-data-validation.mdc`
- **Architecture decisions**: See `01-architecture.mdc`

## Compliance Checklist

When implementing features:
- [ ] Follows CDM compliance rules (02-cdm-compliance.mdc)
- [ ] Uses LLM client abstraction (04-llm-client.mdc)
- [ ] Integrates policy evaluation if applicable (03-policy-engine.mdc)
- [ ] Validates data at creation point (08-data-validation.mdc)
- [ ] Uses dependency injection (01-architecture.mdc)
- [ ] Follows database patterns (05-database-orm.mdc)
- [ ] Follows API patterns (06-api-routing.mdc)
- [ ] Follows frontend patterns (07-frontend.mdc)
- [ ] Includes audit logging
- [ ] Includes error handling
- [ ] Includes tests

## Version

**Version**: 1.0  
**Last Updated**: 2024-12-XX  
**Maintainer**: CreditNexus Architecture Team
