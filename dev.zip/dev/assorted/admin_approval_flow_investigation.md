# Admin Approval Flow & Dashboard Investigation

## Current State Analysis

### 1. User Registration Flow
**Location**: `app/auth/jwt_auth.py`

**Current Behavior**:
- Users are created immediately with `is_active=True` upon registration
- No approval workflow for new user signups
- Users can access the system immediately after registration
- Profile data is stored in `User.profile_data` JSONB column
- Multi-step signup exists (`/signup/step1`, `/signup/step2`) but no approval step

**User Model Fields**:
- `is_active`: Boolean (default: True)
- `role`: String (default: ANALYST)
- `profile_data`: JSONB (stores enriched profile information)
- `is_email_verified`: Boolean (default: False)

### 2. Application Approval Flow
**Location**: `app/api/routes.py`

**Current Behavior**:
- Applications have status workflow: `DRAFT → SUBMITTED → UNDER_REVIEW → APPROVED/REJECTED`
- Admin-only endpoints exist:
  - `POST /api/applications/{id}/approve` - Approve application
  - `POST /api/applications/{id}/reject` - Reject application (with reason)
- Applications are linked to users via `user_id`
- Applications can be converted to deals when approved

**Application Model Fields**:
- `status`: Enum (DRAFT, SUBMITTED, UNDER_REVIEW, APPROVED, REJECTED)
- `submitted_at`: DateTime
- `reviewed_at`: DateTime
- `approved_at`: DateTime
- `rejected_at`: DateTime
- `rejection_reason`: Text

### 3. Existing Admin Capabilities
**Location**: `client/src/components/ApplicationDashboard.tsx`

**Current Features**:
- Users can view their own applications
- Filter by status and type
- Submit applications for review
- Create deals from approved applications
- **No admin-specific dashboard for reviewing all applications**

**Admin Permissions** (from `client/src/utils/permissions.ts`):
- Admin has all permissions including:
  - `APPLICATION_APPROVE`
  - `APPLICATION_REJECT`
  - `APPLICATION_VIEW` (all applications, not just own)

### 4. Missing Components

#### A. User Signup Approval Flow
**Gap**: No approval workflow for new user registrations

**Requirements**:
1. New users should be created with `is_active=False` or `signup_status='pending'`
2. Admin dashboard to review pending signups
3. Admin can approve/reject signups with reasons
4. Email notifications for approval/rejection
5. Profile data extraction should happen before approval (for review)

#### B. Admin Dashboard for Signups
**Gap**: No centralized admin interface for reviewing signups

**Requirements**:
1. List all pending signups with:
   - User email, display name, role
   - Profile data (extracted from documents)
   - Signup date
   - Documents uploaded
2. Filter by:
   - Status (pending, approved, rejected)
   - Role
   - Signup date range
3. Actions:
   - View full profile details
   - View uploaded documents
   - Approve signup (activates account)
   - Reject signup (with reason)
   - Request additional information

#### C. Admin Dashboard for Applications
**Gap**: No centralized admin interface for reviewing all applications

**Requirements**:
1. List all applications (not just user's own) with:
   - Application type, status
   - Applicant information
   - Submitted date
   - Review deadline
2. Filter by:
   - Status (draft, submitted, under_review, approved, rejected)
   - Application type (individual, business)
   - Date range
3. Actions:
   - View full application details
   - Approve application
   - Reject application (with reason)
   - Assign to reviewer
   - Add review notes

## Proposed Implementation

### Phase 1: User Signup Approval Flow

#### 1.1 Database Schema Changes
**File**: `app/db/models.py`

Add to `User` model:
```python
signup_status = Column(String(20), default="pending", nullable=False, index=True)  # pending, approved, rejected
signup_submitted_at = Column(DateTime, nullable=True)
signup_reviewed_at = Column(DateTime, nullable=True)
signup_reviewed_by = Column(Integer, ForeignKey("users.id"), nullable=True)
signup_rejection_reason = Column(Text, nullable=True)
```

**Migration**: Create Alembic migration to add these columns

#### 1.2 Backend API Endpoints
**File**: `app/api/routes.py`

New endpoints:
- `GET /api/admin/signups` - List pending signups (admin only)
- `GET /api/admin/signups/{user_id}` - Get signup details (admin only)
- `POST /api/admin/signups/{user_id}/approve` - Approve signup (admin only)
- `POST /api/admin/signups/{user_id}/reject` - Reject signup with reason (admin only)

Modify existing:
- `POST /auth/register` - Set `is_active=False`, `signup_status='pending'`
- `POST /auth/signup/step1` - Set `is_active=False`, `signup_status='pending'`
- `POST /auth/signup/step2` - Keep status as pending, extract profile data

#### 1.3 Profile Extraction Integration
**File**: `app/services/profile_extraction_service.py`

- Extract profile data from uploaded documents during signup
- Store in `User.profile_data`
- Index in ChromaDB for semantic search
- Make profile data available for admin review

### Phase 2: Admin Dashboard for Signups

#### 2.1 Frontend Component
**File**: `client/src/components/AdminSignupDashboard.tsx`

Features:
- Table/list of pending signups
- Filters (status, role, date range)
- Search functionality
- Detail view modal
- Approve/Reject actions
- Document viewer integration

#### 2.2 Integration Points
- Use `ProfileEnrichment` component to display extracted profile data
- Link to document viewer for uploaded files
- Show profile extraction confidence scores
- Display ChromaDB search results for similar profiles

### Phase 3: Admin Dashboard for Applications

#### 3.1 Frontend Component
**File**: `client/src/components/AdminApplicationDashboard.tsx`

Features:
- Table/list of all applications
- Filters (status, type, date range)
- Search functionality
- Detail view modal
- Approve/Reject actions
- Assign to reviewer
- Review notes

#### 3.2 Enhancements to Existing
**File**: `client/src/components/ApplicationDashboard.tsx`

- Add admin view mode (show all applications if admin)
- Add bulk actions (approve/reject multiple)
- Add review assignment functionality

### Phase 4: Notification System

#### 4.1 Email Notifications
- Signup approved notification
- Signup rejected notification (with reason)
- Application approved notification
- Application rejected notification (with reason)

#### 4.2 In-App Notifications
- Notification center for users
- Real-time updates for admins

## Implementation Priority

### High Priority (P0)
1. **User Signup Approval Flow** - Critical for security and compliance
   - Database schema changes
   - Backend API endpoints
   - Admin dashboard for signups

2. **Admin Dashboard for Applications** - Essential for operations
   - Enhanced ApplicationDashboard with admin view
   - Bulk actions

### Medium Priority (P1)
3. **Profile Extraction Integration** - Improves review quality
   - Extract profile during signup
   - Display in admin dashboard

4. **Notification System** - Improves UX
   - Email notifications
   - In-app notifications

### Low Priority (P2)
5. **Advanced Features**
   - Review assignment
   - Review notes
   - Automated approval rules
   - Signup analytics

## Technical Considerations

### Security
- All admin endpoints must check `current_user.role == "admin"`
- Use permission system (`PERMISSION_USER_APPROVE`, etc.)
- Audit logging for all approval/rejection actions
- Rate limiting on approval endpoints

### Performance
- Pagination for signup/application lists
- Index database columns for filtering
- Cache frequently accessed data
- Lazy load profile data and documents

### User Experience
- Clear status indicators
- Actionable error messages
- Bulk operations for efficiency
- Real-time status updates

## Database Schema Summary

### New Columns for User Model
```python
signup_status = Column(String(20), default="pending", nullable=False, index=True)
signup_submitted_at = Column(DateTime, nullable=True)
signup_reviewed_at = Column(DateTime, nullable=True)
signup_reviewed_by = Column(Integer, ForeignKey("users.id"), nullable=True)
signup_rejection_reason = Column(Text, nullable=True)
```

### New Permissions Needed
```python
PERMISSION_USER_APPROVE = "USER_APPROVE"
PERMISSION_USER_REJECT = "USER_REJECT"
PERMISSION_USER_VIEW_ALL = "USER_VIEW_ALL"
```

## API Endpoints Summary

### Signup Management (Admin Only)
```
GET    /api/admin/signups                    # List pending signups
GET    /api/admin/signups/{user_id}          # Get signup details
POST   /api/admin/signups/{user_id}/approve  # Approve signup
POST   /api/admin/signups/{user_id}/reject  # Reject signup
```

### Application Management (Admin Only)
```
GET    /api/admin/applications               # List all applications (enhanced)
POST   /api/admin/applications/{id}/assign   # Assign to reviewer
POST   /api/admin/applications/{id}/notes    # Add review notes
```

## Next Steps

1. **Immediate**: Continue with current todos (ProfileEnrichment, LoginForm update)
2. **After Current Phase**: Implement Phase 1 (User Signup Approval Flow)
3. **Follow-up**: Implement Phase 2 & 3 (Admin Dashboards)
4. **Future**: Implement Phase 4 (Notification System)
