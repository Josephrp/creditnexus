# CreditNexus Environment Variables & Configuration

This document provides a comprehensive inventory of all environment variables and configurable options for the CreditNexus application.

## Table of Contents

- [Required Variables](#required-variables)
- [LLM Configuration](#llm-configuration)
- [Database Configuration](#database-configuration)
- [Authentication & Security](#authentication--security)
- [Policy Engine Configuration](#policy-engine-configuration)
- [x402 Payment Configuration](#x402-payment-configuration)
- [Satellite Imagery (Sentinel Hub)](#satellite-imagery-sentinel-hub)
- [Audio & Image Processing](#audio--image-processing)
- [Vector Store & ChromaDB](#vector-store--chromadb)
- [Session & Deployment](#session--deployment)
- [Replit-Specific Configuration](#replit-specific-configuration)
- [Frontend Configuration](#frontend-configuration)
- [Alembic Database Migrations](#alembic-database-migrations)

---

## Required Variables

These environment variables **must** be set for the application to function:

| Variable | Type | Description | Default | Location |
|----------|------|-------------|---------|----------|
| `OPENAI_API_KEY` | `SecretStr` | OpenAI API key for LLM operations | **Required** | `app/core/config.py:38` |

---

## LLM Configuration

Configure which LLM provider to use and model settings.

| Variable | Type | Description | Default | Location |
|----------|------|-------------|---------|----------|
| `LLM_PROVIDER` | `LLMProvider` | LLM provider: `openai`, `vllm`, or `huggingface` | `openai` | `app/core/config.py:45` |
| `LLM_MODEL` | `str` | Model name (e.g., `gpt-4o`, `gpt-4-turbo`) | `gpt-4o` | `app/core/config.py:46` |
| `LLM_TEMPERATURE` | `float` | Temperature for LLM generation (0.0-1.0) | `0.0` | `app/core/config.py:47` |
| `EMBEDDINGS_MODEL` | `str` | Embeddings model name | `text-embedding-3-small` | `app/core/config.py:60` |
| `EMBEDDINGS_PROVIDER` | `Optional[LLMProvider]` | Embeddings provider (if None, uses `LLM_PROVIDER`) | `None` | `app/core/config.py:61` |

### vLLM-Specific Settings

| Variable | Type | Description | Default | Location |
|----------|------|-------------|---------|----------|
| `VLLM_BASE_URL` | `Optional[str]` | vLLM server base URL (e.g., `http://localhost:8000`) | `None` | `app/core/config.py:50` |
| `VLLM_API_KEY` | `Optional[SecretStr]` | Optional API key for vLLM authentication | `None` | `app/core/config.py:51` |

### HuggingFace-Specific Settings

| Variable | Type | Description | Default | Location |
|----------|------|-------------|---------|----------|
| `HUGGINGFACE_API_KEY` | `Optional[SecretStr]` | HuggingFace API key | `None` | `app/core/config.py:54` |
| `HUGGINGFACE_BASE_URL` | `Optional[str]` | HuggingFace API base URL | `https://api-inference.huggingface.co/v1` | `app/core/config.py:55` |

**Note**: For HuggingFace Inference Providers (Cohere, fal, etc.), use:
```
HUGGINGFACE_BASE_URL=router.huggingface.co/{provider}/v3/openai
```

---

## Database Configuration

| Variable | Type | Description | Default | Location |
|----------|------|-------------|---------|----------|
| `DATABASE_URL` | `str` | PostgreSQL connection string (e.g., `postgresql://user:pass@localhost/creditnexus`) | **Required for DB operations** | `app/db/__init__.py:8`, `alembic/env.py:25` |

**Database Connection Pool Settings** (hardcoded in `app/db/__init__.py`):
- `pool_recycle`: 300 seconds
- `pool_pre_ping`: True

---

## Authentication & Security

### JWT Authentication

| Variable | Type | Description | Default | Location |
|----------|------|-------------|---------|----------|
| `JWT_SECRET_KEY` | `str` | Secret key for JWT access tokens | Auto-generated (not suitable for production) | `app/auth/jwt_auth.py:34` |
| `JWT_REFRESH_SECRET_KEY` | `str` | Secret key for JWT refresh tokens | Auto-generated (not suitable for production) | `app/auth/jwt_auth.py:35` |

**JWT Settings** (hardcoded in `app/auth/jwt_auth.py`):
- `JWT_ALGORITHM`: `HS256`
- `ACCESS_TOKEN_EXPIRE_MINUTES`: 30
- `REFRESH_TOKEN_EXPIRE_DAYS`: 7
- `MAX_LOGIN_ATTEMPTS`: 5
- `LOCKOUT_DURATION_MINUTES`: 30
- `MIN_PASSWORD_LENGTH`: 12

### Session Management

| Variable | Type | Description | Default | Location |
|----------|------|-------------|---------|----------|
| `SESSION_SECRET` | `str` | Secret key for session middleware | Auto-generated (not suitable for production) | `server.py:178` |

**Session Settings** (hardcoded in `server.py`):
- `session_cookie`: `creditnexus_session`
- `max_age`: 86400 * 7 (7 days)
- `same_site`: `lax`
- `https_only`: Enabled in production (when `REPLIT_DEPLOYMENT=1`)

---

## Policy Engine Configuration

Configure the policy-as-code engine for regulatory compliance.

| Variable | Type | Description | Default | Location |
|----------|------|-------------|---------|----------|
| `POLICY_ENABLED` | `bool` | Enable/disable policy engine | `True` | `app/core/config.py:64` |
| `POLICY_RULES_DIR` | `Path` | Directory containing YAML policy rule files | `app/policies` | `app/core/config.py:65` |
| `POLICY_RULES_PATTERN` | `str` | File pattern for policy rule files | `*.yaml` | `app/core/config.py:66` |
| `POLICY_ENGINE_VENDOR` | `Optional[str]` | Policy engine implementation (e.g., `aspasia`, `custom`) | `None` (uses `default`) | `app/core/config.py:67` |
| `POLICY_AUTO_RELOAD` | `bool` | Auto-reload policies on file change (development only) | `False` | `app/core/config.py:68` |

---

## x402 Payment Configuration

Configure x402 payment processing for blockchain-based payments.

| Variable | Type | Description | Default | Location |
|----------|------|-------------|---------|----------|
| `X402_ENABLED` | `bool` | Enable/disable x402 payment service | `True` | `app/core/config.py:71` |
| `X402_FACILITATOR_URL` | `str` | x402 facilitator service URL | `https://facilitator.x402.org` | `app/core/config.py:72` |
| `X402_NETWORK` | `str` | Blockchain network (`base`, `ethereum`, etc.) | `base` | `app/core/config.py:73` |
| `X402_TOKEN` | `str` | Token symbol (`USDC`, `USDT`, etc.) | `USDC` | `app/core/config.py:74` |

---

## Satellite Imagery (Sentinel Hub)

Configure Sentinel Hub for satellite imagery and NDVI verification.

| Variable | Type | Description | Default | Location |
|----------|------|-------------|---------|----------|
| `SENTINELHUB_KEY` | `Optional[SecretStr]` | Sentinel Hub API key | `None` | `app/core/config.py:41` |
| `SENTINELHUB_SECRET` | `Optional[SecretStr]` | Sentinel Hub API secret | `None` | `app/core/config.py:42` |

---

## Audio & Image Processing

### Speech-to-Text (STT) Configuration

| Variable | Type | Description | Default | Location |
|----------|------|-------------|---------|----------|
| `STT_API_URL` | `Optional[str]` | Gradio Space URL for STT (default: `nvidia/canary-1b-v2`) | `None` | `app/core/config.py:77` |
| `STT_SOURCE_LANG` | `str` | Source language code for transcription | `en` | `app/core/config.py:78` |
| `STT_TARGET_LANG` | `str` | Target language code for transcription | `en` | `app/core/config.py:79` |

### Image OCR Configuration

| Variable | Type | Description | Default | Location |
|----------|------|-------------|---------|----------|
| `OCR_API_URL` | `Optional[str]` | Gradio Space URL for OCR (default: `prithivMLmods/Multimodal-OCR3`) | `None` | `app/core/config.py:82` |

---

## Vector Store & ChromaDB

Configure vector store for semantic search and embeddings.

| Variable | Type | Description | Default | Location |
|----------|------|-------------|---------|----------|
| `CHROMADB_PERSIST_DIR` | `str` | Directory to persist ChromaDB data | `./chroma_db` | `app/core/config.py:85` |

**Vector Store Settings** (hardcoded in `app/agents/vector_store.py`):
- `EMBEDDING_DIM`: 1536 (OpenAI text-embedding-ada-002)
- Falls back to mock embeddings if `OPENAI_API_KEY` is not available

---

## Session & Deployment

| Variable | Type | Description | Default | Location |
|----------|------|-------------|---------|----------|
| `REPLIT_DEPLOYMENT` | `str` | Set to `1` to enable production mode | `None` | `server.py:179` |

When `REPLIT_DEPLOYMENT=1`:
- `SESSION_SECRET` becomes required (raises error if not set)
- Session cookies use `https_only=True`

---

## Replit-Specific Configuration

These variables are used for Replit OAuth2 PKCE authentication flow.

| Variable | Type | Description | Default | Location |
|----------|------|-------------|---------|----------|
| `REPL_ID` | `str` | Replit application ID (client ID for OAuth) | **Required for Replit OAuth** | `app/auth/routes.py:130,194,337` |

**Replit OAuth Settings** (hardcoded in `app/auth/routes.py`):
- `REPLIT_ISSUER_URL`: `https://replit.com/oidc`
- `REPLIT_JWKS_URL`: `https://replit.com/oidc/.well-known/jwks.json`
- `SCOPES`: `["openid", "profile", "email", "offline_access"]`
- `JWKS_CACHE_DURATION`: 3600 seconds

---

## Frontend Configuration

### Vite Development Server

**Settings** (hardcoded in `client/vite.config.ts`):
- `host`: `0.0.0.0`
- `port`: `5000`
- `strictPort`: `true`
- `allowedHosts`: `true`
- Proxy: `/api` → `http://localhost:8000`

### Environment Variables

Frontend environment variables should be prefixed with `VITE_` to be accessible in the React application. Currently, no frontend-specific environment variables are configured.

---

## Alembic Database Migrations

Alembic reads the database URL from the `DATABASE_URL` environment variable. The configuration file is located at `alembic.ini`.

**Alembic Settings** (in `alembic.ini`):
- `script_location`: `alembic`
- `prepend_sys_path`: `.`
- Logging: WARNING level for root and sqlalchemy, INFO for alembic

---

## Configuration Loading

The application uses Pydantic Settings with the following configuration:

- **Config File**: `.env` (in project root)
- **Encoding**: `utf-8`
- **Case Sensitivity**: Case-insensitive
- **Extra Fields**: Ignored (`extra="ignore"`)

Environment variables are loaded using `python-dotenv` in:
- `app/core/config.py` (via `load_dotenv()`)
- `alembic/env.py` (via `load_dotenv()`)

---

## Example `.env` File

```bash
# Required
OPENAI_API_KEY=sk-...

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/creditnexus

# LLM Configuration
LLM_PROVIDER=openai
LLM_MODEL=gpt-4o
LLM_TEMPERATURE=0.0
EMBEDDINGS_MODEL=text-embedding-3-small

# Authentication
JWT_SECRET_KEY=your-secret-key-here-min-32-chars
JWT_REFRESH_SECRET_KEY=your-refresh-secret-key-here-min-32-chars
SESSION_SECRET=your-session-secret-here-min-32-chars

# Policy Engine
POLICY_ENABLED=true
POLICY_RULES_DIR=app/policies
POLICY_RULES_PATTERN=*.yaml
POLICY_AUTO_RELOAD=false

# x402 Payments
X402_ENABLED=true
X402_FACILITATOR_URL=https://facilitator.x402.org
X402_NETWORK=base
X402_TOKEN=USDC

# Sentinel Hub (Optional)
SENTINELHUB_KEY=your-sentinelhub-key
SENTINELHUB_SECRET=your-sentinelhub-secret

# Audio/Image Processing (Optional)
STT_API_URL=https://nvidia-canary-1b-v2.hf.space
STT_SOURCE_LANG=en
STT_TARGET_LANG=en
OCR_API_URL=https://prithivmlmods-multimodal-ocr3.hf.space

# Vector Store
CHROMADB_PERSIST_DIR=./chroma_db

# Replit (if using Replit OAuth)
REPL_ID=your-replit-app-id
REPLIT_DEPLOYMENT=1

# vLLM (if using vLLM provider)
# VLLM_BASE_URL=http://localhost:8000
# VLLM_API_KEY=optional-api-key

# HuggingFace (if using HuggingFace provider)
# HUGGINGFACE_API_KEY=hf_...
# HUGGINGFACE_BASE_URL=https://api-inference.huggingface.co/v1
```

---

## Validation & Verification

The application validates configuration at startup:

1. **Required Variables**: `OPENAI_API_KEY` must be set (raises error if missing)
2. **LLM Provider**: Must be one of `openai`, `vllm`, or `huggingface`
3. **Database**: `DATABASE_URL` is checked during database initialization
4. **Policy Engine**: Policy rules are validated on load
5. **JWT Secrets**: Auto-generated if not set (not suitable for production)

You can verify your environment configuration by running:

```bash
python verify_env.py
```

---

## Notes

- **Secret Values**: Variables marked as `SecretStr` in Pydantic are automatically masked in logs
- **Optional Variables**: Variables with `Optional[...]` type can be omitted, but may disable certain features
- **Production**: Always set `SESSION_SECRET`, `JWT_SECRET_KEY`, and `JWT_REFRESH_SECRET_KEY` in production
- **Development**: `POLICY_AUTO_RELOAD=true` enables hot-reloading of policy rules during development
- **Case Insensitive**: All environment variable names are case-insensitive due to Pydantic Settings configuration

---

**Last Updated**: 2024-12-XX  
**Version**: 1.0

