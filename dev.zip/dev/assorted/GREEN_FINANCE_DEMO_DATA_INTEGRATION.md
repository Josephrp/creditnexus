# Green Finance Demo Data Integration

## Overview

This document explains how green finance metrics and policies are integrated into the CreditNexus demo data seeding workflow.

---

## Demo Data Seeding Workflow

### High-Level Flow

```
1. Generate Applications (12-15)
   ↓
2. Create Deals from Applications
   ↓
3. Generate Documents for Deals (18-36)
   ↓
4. Create DocumentVersions
   ↓
5. Generate Workflows
   ↓
6. Generate LoanAssets for sustainability-linked deals (4-6)
   ↓
6b. Create Green Finance Assessments (NEW)
   ↓
7. Generate Documents from Templates
   ↓
8. Create Deal Notes
   ↓
9. Create Policy Decisions for Documents
   ↓
9b. Create Green Finance Policy Decisions (NEW)
   ↓
10. Store Generated Documents as Files
   ↓
11. Index Documents in ChromaDB
```

---

## How Prompts Transform into Demo Data

### 1. Deal Generation Chain (`app/chains/deal_generation_chain.py`)

**Process:**
1. **Prompt Selection**: System selects scenario (corporate_lending, sustainability_linked, refinancing, restructuring) and industry
2. **LLM Generation**: Uses `create_deal_generation_chain()` with structured output bound to `CreditAgreement` Pydantic model
3. **CDM Validation**: Validates generated data against CDM schema using `_validate_generated_cdm()`
4. **Retry Logic**: Up to 3 retries if validation fails

**Key Prompts** (`app/prompts/demo/deal_generation.py`):
- `get_corporate_lending_system_prompt()` - Standard corporate loans
- `get_sustainability_linked_system_prompt()` - ESG loans with NDVI targets
- `get_refinancing_system_prompt()` - Refinancing scenarios
- `get_restructuring_system_prompt()` - Workout financing

**Example Prompt Variables:**
```python
{
    "deal_type": "loan_application",
    "scenario": "sustainability_linked",
    "industry": "Agriculture",
    "loan_size_range": "$2M - $30M",
    "term_range": "3-7 years",
    "interest_range": "SOFR + 250-450 bps",
    "sustainability_note": "Sustainability-Linked: YES - Must include ESG KPI targets with NDVI vegetation index"
}
```

### 2. Demo Data Service (`app/services/demo_data_service.py`)

**Key Methods:**

#### `_generate_cdm_for_deal()`
- Calls `generate_cdm_for_deal()` from deal generation chain
- Caches results using `DemoDataCache` for performance
- Returns validated `CreditAgreement` object

#### `_generate_loan_assets_for_deals()`
- **Location**: Lines 1234-1480
- Filters sustainability-linked deals (30% of all deals)
- Generates synthetic green finance metrics for each loan asset

---

## Green Finance Metrics Generation (Demo Mode)

### Synthetic Data Generation

For demo purposes, we generate **synthetic green finance metrics** instead of making real API calls to:
- Avoid rate limiting
- Reduce API costs
- Speed up seeding
- Remove external dependencies

### Location-Based Metrics

**Location Classification:**
```python
location_type_map = {
    "123 Industrial Way, Detroit, MI 48201": "urban",
    "456 Farm Road, Napa, CA 94558": "rural",
    "789 Agricultural Blvd, Fresno, CA 93721": "suburban",
    "321 Green Valley Lane, Austin, TX 78701": "suburban"
}
```

**Air Quality (Location-Dependent):**
- **Urban**: AQI 80-150 (Moderate to Unhealthy for Sensitive Groups)
- **Suburban**: AQI 50-100 (Good to Moderate)
- **Rural**: AQI 20-60 (Good)

**OSM Metrics (Location-Dependent):**
- **Urban**: 
  - Building count: 500-2000
  - Building density: 50-150 buildings/km²
  - Road density: 8-15 km/km²
  - Green infrastructure: 10-25%
- **Suburban**:
  - Building count: 100-500
  - Building density: 20-50 buildings/km²
  - Road density: 5-10 km/km²
  - Green infrastructure: 25-40%
- **Rural**:
  - Building count: 10-100
  - Building density: 2-20 buildings/km²
  - Road density: 2-6 km/km²
  - Green infrastructure: 40-70%

### Sustainability Score Calculation

**Components:**
1. **Vegetation Health**: NDVI score (0.0-1.0)
2. **Air Quality**: Normalized AQI score (inverse: lower AQI = higher score)
3. **Urban Activity**: Inverse of building/road density
4. **Green Infrastructure**: Direct coverage percentage
5. **Pollution Levels**: Inverse of AQI

**Default Weights:**
```python
weights = {
    "vegetation_health": 0.30,
    "air_quality": 0.25,
    "urban_activity": 0.15,
    "green_infrastructure": 0.20,
    "pollution_levels": 0.10
}
```

**Formula:**
```python
composite_sustainability_score = (
    vegetation_health * 0.30 +
    air_quality_score * 0.25 +
    activity_score * 0.15 +
    green_infra_score * 0.20 +
    pollution_score * 0.10
)
```

### SDG Alignment Calculation

**SDG Scores:**
- **SDG 11** (Sustainable Cities): Based on composite sustainability score
- **SDG 13** (Climate Action): Inverse of AQI (lower pollution = higher score)
- **SDG 15** (Life on Land): NDVI score (vegetation health)

**Aligned Goals**: SDG scores >= 70%
**Needs Improvement**: SDG scores < 50%

---

## Green Finance Assessment Creation

### Method: `_create_green_finance_assessments()`

**Location**: Lines 1931-2039 in `app/services/demo_data_service.py`

**Process:**
1. Iterates through loan assets with location data
2. Extracts green finance metrics from `loan_asset.green_finance_metrics`
3. Builds environmental and urban activity metrics
4. Calculates SDG alignment scores
5. Creates `GreenFinanceAssessment` database records

**Data Structure:**
```python
GreenFinanceAssessment(
    transaction_id=loan_asset.loan_id,
    deal_id=deal_id,
    loan_asset_id=loan_asset.id,
    location_lat=loan_asset.geo_lat,
    location_lon=loan_asset.geo_lon,
    location_type=loan_asset.location_type,
    environmental_metrics={...},
    urban_activity_metrics={...},
    sustainability_score=composite_sustainability_score,
    sustainability_components={...},
    sdg_alignment={...}
)
```

---

## Green Finance Policy Evaluation

### Method: `_create_green_finance_policy_decisions()`

**Location**: Lines 1849-1929 in `app/services/demo_data_service.py`

**Process:**
1. Uses `PolicyService.evaluate_green_finance_compliance()` to evaluate each loan asset
2. Creates `PolicyDecision` records with:
   - Decision: ALLOW/BLOCK/FLAG
   - Rule applied: Green finance policy rule name
   - Evaluation trace: Full policy evaluation trace
   - Matched rules: List of matching green finance rules

**Integration Points:**
- Called after loan assets are created (Step 6b)
- Runs only if `ENHANCED_SATELLITE_ENABLED=True`
- Creates policy decisions linked to loan assets via `loan_asset_id`

---

## Demo Data Flow Diagram

```
┌─────────────────────────────────────────────────────────────┐
│ 1. Generate Applications (via _generate_applications)      │
│    - Business/Individual types                              │
│    - Status distribution (Draft, Submitted, Under Review)   │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 2. Create Deals (via _create_deals_from_applications)      │
│    - Deal ID format: DEAL-YYYY-MM-XXX                      │
│    - 30% sustainability-linked                             │
│    - Deal data includes ESG targets                        │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 3. Generate Documents (via _generate_deal_documents)       │
│    - Uses LLM to generate CDM CreditAgreement               │
│    - 1-3 documents per deal                                 │
│    - Includes ESG metadata for sustainability-linked deals │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 6. Generate Loan Assets (via _generate_loan_assets_for_deals)│
│    - Only for sustainability-linked deals                   │
│    - Generates synthetic green finance metrics:            │
│      • Location type (urban/suburban/rural)                │
│      • Air quality index (AQI)                             │
│      • OSM metrics (buildings, roads, green infrastructure)│
│      • Sustainability components                           │
│      • Composite sustainability score                      │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 6b. Create Green Finance Assessments (NEW)                 │
│     (via _create_green_finance_assessments)                 │
│    - Creates GreenFinanceAssessment records                 │
│    - Calculates SDG alignment                               │
│    - Stores environmental and urban activity metrics        │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 9b. Create Green Finance Policy Decisions (NEW)          │
│     (via _create_green_finance_policy_decisions)             │
│    - Evaluates green finance compliance                     │
│    - Creates PolicyDecision records                         │
│    - Links to loan assets and deals                         │
└─────────────────────────────────────────────────────────────┘
```

---

## Configuration

### Environment Variables

```env
# Enable enhanced satellite features (required for green finance)
ENHANCED_SATELLITE_ENABLED=true

# OSM Configuration
OSM_OVERPASS_API_URL=https://overpass-api.de/api/interpreter
OSM_CACHE_ENABLED=true
OSM_CACHE_TTL_HOURS=24

# Air Quality Configuration
AIR_QUALITY_ENABLED=true
AIR_QUALITY_API_PROVIDER=openaq
AIR_QUALITY_CACHE_ENABLED=true
AIR_QUALITY_CACHE_TTL_HOURS=6

# Sustainability Scoring Weights
SUSTAINABILITY_NDVI_WEIGHT=0.30
SUSTAINABILITY_AQI_WEIGHT=0.25
SUSTAINABILITY_ACTIVITY_WEIGHT=0.15
SUSTAINABILITY_GREEN_INFRA_WEIGHT=0.20
SUSTAINABILITY_POLLUTION_WEIGHT=0.10
```

---

## Data Transformation Examples

### Example 1: Urban Location (Detroit)

**Input:**
- Address: "123 Industrial Way, Detroit, MI 48201"
- Coordinates: (42.3314, -83.0458)
- NDVI: 0.65

**Generated Metrics:**
```json
{
  "location_type": "urban",
  "location_confidence": 0.85,
  "air_quality_index": 120.0,
  "pm25": 45.0,
  "pm10": 85.0,
  "no2": 60.0,
  "osm_metrics": {
    "building_count": 1200,
    "building_density": 95.0,
    "road_density": 12.0,
    "green_infrastructure_coverage": 0.18
  },
  "sustainability_components": {
    "vegetation_health": 0.65,
    "air_quality": 0.6,
    "urban_activity": 0.35,
    "green_infrastructure": 0.18,
    "pollution_levels": 0.6
  },
  "composite_sustainability_score": 0.52
}
```

### Example 2: Rural Location (Napa)

**Input:**
- Address: "456 Farm Road, Napa, CA 94558"
- Coordinates: (38.2975, -122.2869)
- NDVI: 0.82

**Generated Metrics:**
```json
{
  "location_type": "rural",
  "location_confidence": 0.92,
  "air_quality_index": 35.0,
  "pm25": 12.0,
  "pm10": 25.0,
  "no2": 15.0,
  "osm_metrics": {
    "building_count": 45,
    "building_density": 8.0,
    "road_density": 3.5,
    "green_infrastructure_coverage": 0.65
  },
  "sustainability_components": {
    "vegetation_health": 0.82,
    "air_quality": 1.0,
    "urban_activity": 0.75,
    "green_infrastructure": 0.65,
    "pollution_levels": 0.88
  },
  "composite_sustainability_score": 0.84
}
```

---

## Integration with Existing Workflows

### Deal Creation Workflow

When a deal is created from an application:
1. `DealService.create_deal_from_application()` is called
2. If `ENHANCED_SATELLITE_ENABLED=True` and loan assets exist:
   - Calls `PolicyService.evaluate_green_finance_compliance()`
   - Stores result in `deal.deal_data["green_finance_assessment"]`
   - Creates `PolicyDecision` record

### Verification Workflow

When a loan asset is verified:
1. `verify_asset_location()` is called (in `app/agents/verifier.py`)
2. Enhanced metrics are automatically calculated:
   - OSM data fetched (or synthetic for demo)
   - Air quality retrieved (or synthetic for demo)
   - Location classified
   - Sustainability score calculated
3. Results stored in `LoanAsset` model fields

---

## Demo Data Seeding API

### Endpoint: `POST /api/demo/seed`

**Request:**
```json
{
  "seed_users": true,
  "seed_templates": true,
  "seed_policies": true,
  "seed_policy_templates": true,
  "generate_deals": true,
  "deal_count": 12,
  "dry_run": false
}
```

**Response:**
```json
{
  "status": "success",
  "created": {
    "users": 15,
    "templates": 8,
    "policies": 12,
    "deals": 12,
    "documents": 24,
    "loan_assets": 4,
    "green_finance_assessments": 4,
    "policy_decisions": 30
  },
  "updated": {...},
  "errors": []
}
```

### Seeding Status: `GET /api/demo/seed/status`

Returns progress for each stage:
- `applications`
- `deals_creation`
- `documents`
- `loan_assets`
- `green_finance_assessments` (NEW)
- `policy_decisions`
- `green_finance_policy_decisions` (NEW)

---

## Testing Green Finance Demo Data

### 1. Seed Demo Data

```bash
curl -X POST http://localhost:8000/api/demo/seed \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "generate_deals": true,
    "deal_count": 12
  }'
```

### 2. Verify Loan Assets

```bash
curl http://localhost:8000/api/loan-assets?limit=10
```

**Expected Response:**
- Loan assets should have `location_type`, `air_quality_index`, `composite_sustainability_score`
- `green_finance_metrics` should contain full metrics structure

### 3. Verify Green Finance Assessments

```bash
curl http://localhost:8000/api/green-finance/assessments
```

**Expected Response:**
- List of `GreenFinanceAssessment` records
- Each assessment linked to a loan asset and deal
- Contains SDG alignment scores

### 4. Verify Policy Decisions

```bash
curl http://localhost:8000/api/policy-decisions?loan_asset_id=<id>
```

**Expected Response:**
- Policy decisions with `loan_asset_id` set
- Decision types: ALLOW, BLOCK, or FLAG
- Green finance rules applied

---

## Production vs Demo Mode

### Demo Mode (Current Implementation)
- **Synthetic data**: All green finance metrics are generated synthetically
- **No API calls**: No calls to OSM Overpass API or OpenAQ API
- **Fast seeding**: Completes in seconds
- **Deterministic**: Same inputs produce same outputs (with seed)

### Production Mode (Future Enhancement)
- **Real API calls**: Uses actual OSM and OpenAQ services
- **Caching**: Results cached to reduce API calls
- **Error handling**: Graceful fallback if APIs unavailable
- **Rate limiting**: Respects API rate limits

**To Enable Production Mode:**
1. Set `ENHANCED_SATELLITE_ENABLED=true`
2. Configure OSM and OpenAQ API credentials
3. Update `_generate_loan_assets_for_deals()` to use real services instead of synthetic data

---

## Summary

### What Was Added

1. **Green Finance Metrics to Loan Assets**:
   - Location type (urban/suburban/rural)
   - Air quality index (AQI)
   - Composite sustainability score
   - OSM metrics (buildings, roads, green infrastructure)
   - Sustainability components breakdown

2. **Green Finance Assessments**:
   - Database records for each loan asset
   - SDG alignment scores
   - Environmental and urban activity metrics

3. **Green Finance Policy Decisions**:
   - Policy evaluations for green finance compliance
   - Linked to loan assets and deals
   - CDM-compliant policy evaluation events

### Integration Points

- **Demo Data Service**: `_generate_loan_assets_for_deals()` now includes green finance metrics
- **Deal Service**: Automatically evaluates green finance on deal creation
- **Verifier Agent**: Enhanced metrics included in verification results
- **Policy Service**: Green finance evaluation methods available

### Next Steps

1. **Apply Database Migration**: Run `uv run alembic upgrade head` to create `green_finance_assessments` table
2. **Seed Demo Data**: Use `/api/demo/seed` endpoint to generate demo deals with green finance metrics
3. **Test UI**: Verify green finance metrics display in VerificationDashboard, VerificationWidget, and GreenLens
4. **Production Mode**: When ready, switch from synthetic to real API calls

---

**Last Updated**: 2026-01-11  
**Version**: 1.0
