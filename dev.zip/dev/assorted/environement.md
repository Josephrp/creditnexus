# =============================================================================
# REQUIRED: OpenAI API Key (always required, even if using other providers)
# =============================================================================
OPENAI_API_KEY=your_openai_api_key_here

# =============================================================================
# LLM Provider Configuration
# =============================================================================
# Choose your LLM provider: "openai", "vllm", or "huggingface"
LLM_PROVIDER=openai

# Model name/identifier (varies by provider)
# OpenAI: "gpt-4o", "gpt-4o-mini", "gpt-3.5-turbo"
# vLLM: Model name as configured in your vLLM server
# HuggingFace: Model ID from HuggingFace Hub (e.g., "microsoft/Phi-3-mini-4k-instruct")
LLM_MODEL=gpt-4o

# Temperature for LLM generation (0.0 = deterministic, 1.0 = creative)
LLM_TEMPERATURE=0.0

# =============================================================================
# vLLM Configuration (only needed if LLM_PROVIDER=vllm)
# =============================================================================
# Base URL for your vLLM server (e.g., "http://localhost:8000")
VLLM_BASE_URL=

# Optional API key if your vLLM server requires authentication
VLLM_API_KEY=

# =============================================================================
# HuggingFace Configuration (only needed if LLM_PROVIDER=huggingface)
# =============================================================================
# HuggingFace API token (get from https://huggingface.co/settings/tokens)
HUGGINGFACE_API_KEY=

# Optional: Custom base URL for HuggingFace API
# Default: https://api-inference.huggingface.co/v1
# For Inference Providers router: https://router.huggingface.co/{provider}/v3/openai
HUGGINGFACE_BASE_URL=

# HuggingFace Inference Provider Selection
# Available providers: "auto", "together", "sambanova", "fireworks-ai", "cohere", 
# "fal-ai", "groq", "replicate", "hf-inference", "black-forest-labs", "cerebras",
# "featherless-ai", "hyperbolic", "nebius", "novita", "nscale", "openai"
# "auto" (default): Selects first available provider based on your preferences
#   at https://hf.co/settings/inference-providers
# Specific provider: Forces use of that provider (e.g., "together", "sambanova")
HUGGINGFACE_INFERENCE_PROVIDER=auto

# HuggingFace Local Model Configuration
# Set to true to load models locally using transformers (requires GPU/CPU resources)
# Set to false to use inference endpoints (API-based, no local resources needed)
HUGGINGFACE_USE_LOCAL=false

# =============================================================================
# Embeddings Configuration
# =============================================================================
# Embeddings model name/identifier
# OpenAI: "text-embedding-3-small", "text-embedding-3-large", "text-embedding-ada-002"
# HuggingFace: Model ID from Hub (e.g., "sentence-transformers/all-MiniLM-L6-v2")
EMBEDDINGS_MODEL=text-embedding-3-small

# Embeddings provider (if None, uses LLM_PROVIDER)
# Options: "openai", "huggingface", or leave empty to use LLM_PROVIDER
EMBEDDINGS_PROVIDER=huggingface

# Local Embeddings Configuration (HuggingFace only)
# Set to true to use local embeddings model instead of API
EMBEDDINGS_USE_LOCAL=false

# Device for local embeddings: "cpu", "cuda", "cuda:0", etc.
# "auto" will automatically select the best available device
EMBEDDINGS_DEVICE=cpu

# Additional model_kwargs for HuggingFaceEmbeddings (JSON string)
# Examples:
#   '{"device_map":"auto"}' - Auto device mapping
#   '{"trust_remote_code":true}' - Trust remote code
#   '{"device":"cuda","model_kwargs":{"torch_dtype":"float16"}}' - GPU with float16
EMBEDDINGS_MODEL_KWARGS=

# =============================================================================
# Sentinel Hub Configuration (for satellite imagery)
# =============================================================================
# Get credentials from https://www.sentinel-hub.com/
SENTINELHUB_KEY=
SENTINELHUB_SECRET=

# =============================================================================
# Policy Engine Configuration
# =============================================================================
POLICY_ENABLED=true
POLICY_RULES_DIR=app/policies
POLICY_RULES_PATTERN=*.yaml
POLICY_ENGINE_VENDOR=
POLICY_AUTO_RELOAD=false

# =============================================================================
# x402 Payment Engine Configuration
# =============================================================================
X402_ENABLED=true
X402_FACILITATOR_URL=https://facilitator.x402.org
X402_NETWORK=base
X402_TOKEN=USDC

# =============================================================================
# Audio Transcription (STT) Configuration
# =============================================================================
# Gradio Space URL for speech-to-text (default: nvidia/canary-1b-v2)
STT_API_URL=https://nvidia-canary-1b-v2.hf.space
STT_SOURCE_LANG=en
STT_TARGET_LANG=en

# =============================================================================
# Image OCR Configuration
# =============================================================================
# Gradio Space URL for OCR (default: prithivMLmods/Multimodal-OCR3)
OCR_API_URL=https://prithivmlmods-multimodal-ocr3.hf.space

# =============================================================================
# ChromaDB Configuration
# =============================================================================
CHROMADB_PERSIST_DIR=./chroma_db
# Optional: Directory to load documents into ChromaDB on startup
CHROMADB_SEED_DOCUMENTS_DIR=

# =============================================================================
# Enhanced Satellite Verification & Green Finance
# =============================================================================
# Enable enhanced satellite features (green finance metrics, OSM, air quality)
ENHANCED_SATELLITE_ENABLED=true
# Street map API provider (only "openstreetmap" supported)
STREET_MAP_API_PROVIDER=openstreetmap

# OpenStreetMap Configuration
OSM_OVERPASS_API_URL=https://overpass-api.de/api/interpreter
OSM_CACHE_ENABLED=true
OSM_CACHE_TTL_HOURS=24

# Air Quality Configuration
AIR_QUALITY_ENABLED=true
AIR_QUALITY_API_PROVIDER=openaq
# Not required for OpenAQ free tier
AIR_QUALITY_API_KEY=
AIR_QUALITY_CACHE_ENABLED=true
AIR_QUALITY_CACHE_TTL_HOURS=24

# Vehicle Detection (Selective - High Cost)
# Default: disabled, enable for high-value cases only
VEHICLE_DETECTION_ENABLED=false
VEHICLE_DETECTION_MODEL_PATH=./models/vehicle_detector.pt
# Only process if transaction amount > $1M
VEHICLE_DETECTION_MIN_TRANSACTION_AMOUNT=1000000.0
VEHICLE_DETECTION_USE_HIGH_RES_IMAGERY=true

# Pollution Monitoring
POLLUTION_MONITORING_ENABLED=true
METHANE_MONITORING_ENABLED=true
# Use Sentinel-5P for methane detection (free, coarse resolution)
METHANE_USE_SENTINEL5P=true

# Sustainability Scoring
SUSTAINABILITY_SCORING_ENABLED=true
# Component weights (must sum to 1.0)
SUSTAINABILITY_NDVI_WEIGHT=0.25
SUSTAINABILITY_AQI_WEIGHT=0.25
SUSTAINABILITY_ACTIVITY_WEIGHT=0.20
SUSTAINABILITY_GREEN_INFRA_WEIGHT=0.15
SUSTAINABILITY_POLLUTION_WEIGHT=0.15

# =============================================================================
# Twilio Configuration (for loan recovery notifications)
# =============================================================================
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
TWILIO_PHONE_NUMBER=

# =============================================================================
# Demo Data Configuration
# =============================================================================
DEMO_DATA_ENABLED=true
DEMO_DATA_DEAL_COUNT=12
DEMO_DATA_DEAL_TYPES=loan_application,refinancing,restructuring
DEMO_DATA_STORAGE_PATH=storage/deals/demo
DEMO_DATA_CACHE_ENABLED=true
DEMO_DATA_CACHE_TTL=86400
DEMO_DATA_CACHE_PATH=

# =============================================================================
# Database Configuration
# =============================================================================
# PostgreSQL connection string:
#   postgresql://user:password@localhost:5432/creditnexus
# SQLite (development fallback, auto-created if not set):
#   sqlite:///./creditnexus.db
DATABASE_URL=postgresql://user:password@localhost:5432/creditnexus

DATABASE_ENABLED=true

# =============================================================================
# Authentication Configuration
# =============================================================================
# JWT secret key for token generation (generate a secure random string)
JWT_SECRET_KEY=your_jwt_secret_key_here
JWT_ALGORITHM=HS256

# =============================================================================
# Seeding Configuration
# =============================================================================
# Seed permission definitions and role mappings on startup
SEED_PERMISSIONS=false
# Force update existing permissions (use with caution)
SEED_PERMISSIONS_FORCE=false
# Seed demo users on startup
SEED_DEMO_USERS=false
# Force update existing demo users (use with caution)
SEED_DEMO_USERS_FORCE=false
# Seed individual demo user roles
SEED_AUDITOR=false
SEED_BANKER=false
SEED_LAW_OFFICER=false
SEED_ACCOUNTANT=false
SEED_APPLICANT=false