# Document Generation Flow Hydration Investigation

## Executive Summary

This document investigates how the document generation flow can be logically hydrated with available data from:
- Deal context (deal metadata, status, type, deal_data)
- User profile (role, permissions, profile_data)
- Related documents (attached to deal, semantically similar)
- Deal notes (recent activity, context)

## Current Document Generation Flow

### 1. API Endpoint: `/api/templates/generate`

**Location**: `app/api/routes.py:6578`

**Current Request Model**:
```python
class GenerateDocumentRequest(BaseModel):
    template_id: int
    cdm_data: Optional[dict]  # CDM CreditAgreement data
    document_id: Optional[int]  # Load CDM from existing document
    source_document_id: Optional[int]
    field_overrides: Optional[Dict[str, Any]]
```

**Current Flow**:
1. Accepts `cdm_data` directly OR loads from `document_id`
2. Parses CDM data into `CreditAgreement` model
3. Calls `DocumentGenerationService.generate_document()`
4. Returns generated document metadata

**Missing Context**:
- ❌ No `deal_id` parameter
- ❌ No access to deal metadata
- ❌ No access to user profile beyond `user_id`
- ❌ No access to related documents
- ❌ No access to deal notes

### 2. DocumentGenerationService

**Location**: `app/generation/service.py:32`

**Current Method Signature**:
```python
def generate_document(
    self,
    db: Session,
    template_id: int,
    cdm_data: CreditAgreement,
    user_id: Optional[int] = None,
    source_document_id: Optional[int] = None,
    field_overrides: Optional[Dict[str, Any]] = None
) -> GeneratedDocument
```

**Current Flow**:
1. Applies field overrides to CDM data
2. Loads template and field mappings
3. Maps CDM data to template fields (`FieldMapper`)
4. Generates AI-populated fields (`AIFieldPopulator`)
5. Renders document (`DocumentRenderer`)
6. Saves generated document

**Missing Context**:
- ❌ No `deal_id` parameter
- ❌ No deal context loading
- ❌ No user profile access
- ❌ No related documents access

### 3. AIFieldPopulator

**Location**: `app/generation/populator.py:25`

**Current Method Signature**:
```python
def populate_ai_fields(
    self,
    cdm_data: CreditAgreement,
    template: LMATemplate,
    mapped_fields: Dict[str, Any],
    user_id: Optional[int] = None
) -> Dict[str, str]
```

**Current Prompt Variables** (`_prepare_prompt_variables`):
- ✅ Borrower name, LEI
- ✅ Facility name, commitment amount, currency
- ✅ Maturity date, interest rate
- ✅ ESG KPI targets
- ✅ Agreement date, governing law
- ✅ Additional context from mapped fields

**Missing Context**:
- ❌ No deal type/status information
- ❌ No deal-specific metadata
- ❌ No user role/permissions context
- ❌ No related documents for reference
- ❌ No deal notes/history
- ❌ No similar deals for pattern matching

## Summary

Investigated and verified the document generation flow hydration. Findings:

### Investigation document

Created `dev/document_generation_hydration_investigation.md` covering:

1. Current state analysis:
   - Document generation accepts CDM data directly or from existing documents
   - AI field population uses CDM data only
   - No deal context, user profile, or related documents are used

2. Proposed enhancements:
   - Add `deal_id` parameter to `GenerateDocumentRequest`
   - Load deal context (metadata, status, type, deal_data) in `DocumentGenerationService`
   - Load user profile (role, permissions, profile_data) for role-aware generation
   - Query ChromaDB for related documents as precedent
   - Enhance `AIFieldPopulator` prompt variables with deal context, user profile, and related documents
   - Link generated documents to deals automatically

3. Data flow diagram:
   - Shows how deal context, user profile, and related documents flow through the generation pipeline

4. Implementation priority:
   - High: `deal_id` support, deal context loading, linking to deals
   - Medium: User profile loading, related documents from ChromaDB
   - Low: Deal notes in prompts, semantic search for similar deals

### Current gaps

- No `deal_id` parameter in document generation
- No deal context access during generation
- No user profile access beyond `user_id`
- No related documents for precedent/reference
- AI prompts only use CDM data

### Benefits of proposed enhancements

- More accurate, contextual legal clauses
- Deal-aware document generation
- Better consistency across deal documents
- Improved user experience with deal-centric workflow
- Role/permission-aware generation

The investigation document provides a roadmap for hydrating the document generation flow with available data from deals, user profiles, and related documents.

# Field Coverage Analysis: CDM Extraction vs Template Mappings

## CDM Model Structure

### CreditAgreement (Root)
- `agreement_date` (date) ✅
- `parties` (List[Party]) ✅
- `facilities` (List[LoanFacility]) ✅
- `governing_law` (str) ✅
- `sustainability_linked` (bool) ✅
- `esg_kpi_targets` (List[ESGKPITarget]) ✅
- `deal_id` (str, optional)
- `loan_identification_number` (str, optional)

### Party
- `id` (str)
- `name` (str) ✅
- `role` (str) ✅
- `lei` (str, optional) ✅

### LoanFacility
- `facility_name` (str) ✅
- `commitment_amount` (Money) ✅
- `interest_terms` (InterestRatePayout) ✅
- `maturity_date` (date) ✅

### Money
- `amount` (Decimal) ✅
- `currency` (Currency enum) ✅

### InterestRatePayout
- `rate_option` (FloatingRateOption) ✅
- `payment_frequency` (Frequency) ✅

### FloatingRateOption
- `benchmark` (str) ✅
- `spread_bps` (float) ✅

### Frequency
- `period` (PeriodEnum) ✅
- `period_multiplier` (int) ✅

### ESGKPITarget
- `kpi_type` (ESGKPIType)
- `target_value` (float)
- `current_value` (float, optional)
- `unit` (str)
- `margin_adjustment_bps` (float)

## Template Field Mappings Coverage

### Facility Agreement (LMA-CL-FA-2024-EN) - 17 mappings

#### Parties (4 mappings) ✅
- `[BORROWER_NAME]` → `parties[role='Borrower'].name` ✅
- `[BORROWER_LEI]` → `parties[role='Borrower'].lei` ✅
- `[LENDER_NAME]` → `parties[role='Lender'].name` ✅
- `[ADMINISTRATIVE_AGENT_NAME]` → `parties[role='AdministrativeAgent'].name` ✅

#### Facility Details (5 mappings) ✅
- `[FACILITY_NAME]` → `facilities[0].facility_name` ✅
- `[COMMITMENT_AMOUNT]` → `facilities[0].commitment_amount.amount` ✅
- `[CURRENCY]` → `facilities[0].commitment_amount.currency` ✅
- `[MATURITY_DATE]` → `facilities[0].maturity_date` ✅
- `[AGREEMENT_DATE]` → `agreement_date` ✅

#### Interest Terms (3 mappings) ✅
- `[BENCHMARK]` → `facilities[0].interest_terms.rate_option.benchmark` ✅
- `[SPREAD]` → `facilities[0].interest_terms.rate_option.spread_bps` ✅
- `[PAYMENT_FREQUENCY]` → `facilities[0].interest_terms.payment_frequency` ✅

#### Governing Law (1 mapping) ✅
- `[GOVERNING_LAW]` → `governing_law` ✅

#### ESG Fields (4 mappings) ✅
- `[SUSTAINABILITY_LINKED]` → `sustainability_linked` ✅
- `[ESG_KPI_TARGETS]` → `esg_kpi_targets` ✅
- `[SPT_DEFINITIONS]` → `spt_definitions` ⚠️ (Not in CDM model - may need custom handling)
- `[MARGIN_ADJUSTMENT]` → `margin_adjustment` ⚠️ (Not in CDM model - may need custom handling)

### Term Sheet (LMA-CL-TS-2024-EN) - 12 mappings

All mappings are covered by the same CDM structure as Facility Agreement.

## Extraction Prompt Coverage

The extraction prompt (`create_extraction_prompt`) explicitly requests:
1. ✅ Party names and roles
2. ✅ LEI extraction
3. ✅ Financial amounts and currency
4. ✅ Spread in basis points
5. ✅ Dates in ISO 8601 format
6. ✅ Loan facilities and terms
7. ✅ Payment frequency with period and period_multiplier
8. ✅ Governing law/jurisdiction
9. ✅ Sustainability-linked provisions

**Updated in extraction_chain.py:**
- ✅ Explicitly requests `spread_bps` extraction
- ✅ Explicitly requests `period_multiplier` extraction
- ✅ Explicitly requests LEI extraction

## Issues Identified and Fixed

### 1. Incorrect CDM Paths in Field Mappings ✅ FIXED
- **Before:** `facilities[0].total_commitment.amount`
- **After:** `facilities[0].commitment_amount.amount`

- **Before:** `facilities[0].interest_rate.benchmark`
- **After:** `facilities[0].interest_terms.rate_option.benchmark`

- **Before:** `facilities[0].interest_rate.spread`
- **After:** `facilities[0].interest_terms.rate_option.spread_bps`

- **Before:** `facilities[0].payment_frequency`
- **After:** `facilities[0].interest_terms.payment_frequency`

### 2. Missing Explicit Extraction Instructions ✅ FIXED
- Added explicit request for `spread_bps` in extraction prompt
- Added explicit request for `period_multiplier` in extraction prompt
- Added explicit request for LEI extraction

### 3. Fields Not in CDM Model ⚠️ NEEDS ATTENTION
- `[SPT_DEFINITIONS]` - Not a direct CDM field, may need computed mapping from `esg_kpi_targets`
- `[MARGIN_ADJUSTMENT]` - Not a direct CDM field, may need computed mapping from `esg_kpi_targets[0].margin_adjustment_bps`

## Recommendations

1. ✅ **COMPLETED:** Fixed incorrect CDM paths in field mappings
2. ✅ **COMPLETED:** Updated extraction prompt to explicitly request all required fields
3. ⚠️ **TODO:** Consider adding computed mappings for `[SPT_DEFINITIONS]` and `[MARGIN_ADJUSTMENT]` that extract from `esg_kpi_targets`
4. ⚠️ **TODO:** Verify that `FieldPathParser` correctly handles nested paths like `facilities[0].interest_terms.rate_option.benchmark`

## Verification Status

- ✅ All template field mappings have corresponding CDM fields
- ✅ Extraction prompt explicitly requests all required fields
- ✅ Field mappings use correct CDM paths
- ⚠️ Two mappings (`[SPT_DEFINITIONS]`, `[MARGIN_ADJUSTMENT]`) reference fields not directly in CDM model

## Proposed Enhancements

### Enhancement 1: Add `deal_id` to GenerateDocumentRequest

**File**: `app/api/routes.py`

**Change**:
```python
class GenerateDocumentRequest(BaseModel):
    template_id: int
    cdm_data: Optional[dict]
    document_id: Optional[int]
    deal_id: Optional[int] = Field(None, description="Optional deal ID to load deal context")
    source_document_id: Optional[int]
    field_overrides: Optional[Dict[str, Any]]
```

**Benefits**:
- Enables deal-aware document generation
- Allows loading deal metadata for context
- Links generated documents to deals automatically

### Enhancement 2: Load Deal Context in Document Generation Service

**File**: `app/generation/service.py`

**Change**:
```python
def generate_document(
    self,
    db: Session,
    template_id: int,
    cdm_data: CreditAgreement,
    user_id: Optional[int] = None,
    source_document_id: Optional[int] = None,
    deal_id: Optional[int] = None,  # NEW
    field_overrides: Optional[Dict[str, Any]] = None
) -> GeneratedDocument:
    # Load deal context if deal_id provided
    deal_context = None
    if deal_id:
        from app.services.deal_service import DealService
        deal_service = DealService(db)
        deal = deal_service.get_deal(deal_id)
        if deal:
            deal_context = {
                "deal_id": deal.deal_id,
                "status": deal.status,
                "deal_type": deal.deal_type,
                "deal_data": deal.deal_data,
            }
    
    # Load user profile if user_id provided
    user_profile = None
    if user_id:
        from app.db.models import User
        user = db.query(User).filter(User.id == user_id).first()
        if user:
            user_profile = {
                "role": user.role,
                "display_name": user.display_name,
                "profile_data": user.profile_data,
            }
    
    # Pass context to AIFieldPopulator
    ai_populator = AIFieldPopulator(db=db)
    ai_fields = ai_populator.populate_ai_fields(
        cdm_data=cdm_data,
        template=template,
        mapped_fields=mapped_fields,
        user_id=user_id,
        deal_context=deal_context,  # NEW
        user_profile=user_profile,  # NEW
    )
```

**Benefits**:
- Provides deal metadata to AI generation
- Enables deal-specific clause generation
- Links generation to deal lifecycle

### Enhancement 3: Enhance AIFieldPopulator with Deal Context

**File**: `app/generation/populator.py`

**Change**:
```python
def populate_ai_fields(
    self,
    cdm_data: CreditAgreement,
    template: LMATemplate,
    mapped_fields: Dict[str, Any],
    user_id: Optional[int] = None,
    deal_context: Optional[Dict[str, Any]] = None,  # NEW
    user_profile: Optional[Dict[str, Any]] = None,  # NEW
    related_documents: Optional[List[Dict[str, Any]]] = None  # NEW
) -> Dict[str, str]:
    # ... existing code ...
    
    generated_content = self._generate_section(
        section_name=section_name,
        cdm_data=cdm_data,
        template=template,
        mapped_fields=mapped_fields,
        deal_context=deal_context,  # NEW
        user_profile=user_profile,  # NEW
        related_documents=related_documents  # NEW
    )
```

**Enhanced `_prepare_prompt_variables`**:
```python
def _prepare_prompt_variables(
    self,
    cdm_data: CreditAgreement,
    template: LMATemplate,
    mapped_fields: Optional[Dict[str, Any]],
    deal_context: Optional[Dict[str, Any]] = None,  # NEW
    user_profile: Optional[Dict[str, Any]] = None,  # NEW
    related_documents: Optional[List[Dict[str, Any]]] = None  # NEW
) -> Dict[str, Any]:
    # ... existing variables ...
    
    # Add deal context
    deal_info = ""
    if deal_context:
        deal_info = f"""
Deal Context:
- Deal ID: {deal_context.get('deal_id')}
- Deal Type: {deal_context.get('deal_type')}
- Deal Status: {deal_context.get('status')}
"""
        if deal_context.get('deal_data'):
            deal_info += f"- Deal Data: {json.dumps(deal_context['deal_data'], indent=2)}"
    
    # Add user profile context
    user_info = ""
    if user_profile:
        user_info = f"""
User Context:
- Role: {user_profile.get('role')}
- Name: {user_profile.get('display_name')}
"""
        if user_profile.get('profile_data'):
            # Extract relevant profile info
            profile = user_profile['profile_data']
            if profile.get('company', {}).get('name'):
                user_info += f"- Company: {profile['company']['name']}\n"
            if profile.get('professional', {}).get('job_title'):
                user_info += f"- Job Title: {profile['professional']['job_title']}\n"
    
    # Add related documents context
    documents_info = ""
    if related_documents:
        documents_info = "\nRelated Documents:\n"
        for doc in related_documents[:5]:  # Limit to 5 most relevant
            documents_info += f"- {doc.get('title', 'Document')} ({doc.get('subdirectory', 'documents')})\n"
    
    return {
        # ... existing variables ...
        "deal_context": deal_info or "Not applicable",
        "user_context": user_info or "Not applicable",
        "related_documents": documents_info or "Not applicable",
    }
```

**Benefits**:
- AI-generated clauses can reference deal-specific information
- User role/permissions can influence clause generation
- Related documents provide precedent/context
- More accurate and contextual legal language

### Enhancement 4: Load Related Documents from ChromaDB

**File**: `app/generation/service.py`

**Add to `generate_document` method**:
```python
# Load related documents from ChromaDB if deal_id provided
related_documents = []
if deal_id:
    try:
        from app.chains.document_retrieval_chain import DocumentRetrievalService
        from app.services.deal_service import DealService
        
        deal_service = DealService(db)
        deal = deal_service.get_deal(deal_id)
        
        if deal:
            # Query ChromaDB for semantically similar documents
            doc_retrieval = DocumentRetrievalService(collection_name="creditnexus_documents")
            search_query = f"deal {deal.deal_id} {deal.deal_type or ''} {deal.status or ''}"
            
            similar_docs = doc_retrieval.retrieve_similar_documents(
                query=search_query,
                top_k=5,
                filter_metadata={"deal_id": str(deal_id)} if deal_id else None
            )
            
            related_documents = similar_docs
            
            # Also get documents from database
            from app.db.models import Document
            db_docs = db.query(Document).filter(
                Document.deal_id == deal_id
            ).order_by(Document.created_at.desc()).limit(5).all()
            
            for doc in db_docs:
                related_documents.append({
                    "document_id": doc.id,
                    "title": doc.title,
                    "subdirectory": "documents",
                    "source": "database",
                })
    except Exception as e:
        logger.warning(f"Failed to load related documents: {e}")

# Pass to AIFieldPopulator
ai_fields = ai_populator.populate_ai_fields(
    cdm_data=cdm_data,
    template=template,
    mapped_fields=mapped_fields,
    user_id=user_id,
    deal_context=deal_context,
    user_profile=user_profile,
    related_documents=related_documents
)
```

**Benefits**:
- Provides precedent documents for clause generation
- Enables pattern matching from similar deals
- Improves consistency across deal documents

### Enhancement 5: Link Generated Documents to Deals

**File**: `app/generation/service.py`

**Add to `generate_document` method** (after document creation):
```python
# Link generated document to deal if deal_id provided
if deal_id:
    try:
        from app.db.models import Document
        from app.services.deal_service import DealService
        
        # Create Document record for generated document
        generated_doc_record = Document(
            title=generated_doc.title or f"Generated from {template.template_code}",
            uploaded_by=user_id,
            deal_id=deal_id,
            is_generated=True,
            template_id=template_id,
            source_cdm_data=cdm_data.model_dump() if hasattr(cdm_data, 'model_dump') else None,
        )
        db.add(generated_doc_record)
        db.flush()
        
        # Attach to deal via DealService
        deal_service = DealService(db)
        deal_service.attach_document_to_deal(
            deal_id=deal_id,
            document_id=generated_doc_record.id,
            user_id=user_id
        )
        
        logger.info(f"Linked generated document {generated_doc_record.id} to deal {deal_id}")
    except Exception as e:
        logger.warning(f"Failed to link generated document to deal: {e}")
```

**Benefits**:
- Generated documents appear in deal timeline
- Documents are organized by deal
- Enables deal-based document management

## Data Flow Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    API Request                                │
│  GenerateDocumentRequest:                                     │
│    - template_id                                             │
│    - cdm_data OR document_id                                 │
│    - deal_id (NEW)                                           │
│    - field_overrides                                         │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│              DocumentGenerationService                        │
│                                                               │
│  1. Load Deal Context (if deal_id)                           │
│     ├─ Deal metadata (status, type, deal_data)              │
│     ├─ Related documents (ChromaDB + database)               │
│     └─ Deal notes                                            │
│                                                               │
│  2. Load User Profile (if user_id)                           │
│     ├─ Role, permissions                                     │
│     └─ Profile data (company, job title, etc.)              │
│                                                               │
│  3. Map CDM Data → Template Fields                           │
│     └─ FieldMapper.map_cdm_to_template()                    │
│                                                               │
│  4. Generate AI Fields                                       │
│     └─ AIFieldPopulator.populate_ai_fields()                │
│         ├─ CDM data                                          │
│         ├─ Deal context (NEW)                                │
│         ├─ User profile (NEW)                                │
│         └─ Related documents (NEW)                           │
│                                                               │
│  5. Render Document                                          │
│     └─ DocumentRenderer.render_template()                   │
│                                                               │
│  6. Link to Deal (if deal_id)                                │
│     └─ Create Document record + attach to deal               │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│              Generated Document                               │
│  - Stored in file system                                     │
│  - Linked to deal (if deal_id provided)                      │
│  - Available in deal timeline                                │
└─────────────────────────────────────────────────────────────┘
```

## Verification Checklist

### ✅ Current State
- [x] Document generation accepts CDM data
- [x] Document generation can load CDM from existing documents
- [x] AI field population uses CDM data
- [x] Field mapping works correctly
- [x] Document rendering works

### ❌ Missing Enhancements
- [ ] `deal_id` parameter in `GenerateDocumentRequest`
- [ ] Deal context loading in `DocumentGenerationService`
- [ ] User profile loading in `DocumentGenerationService`
- [ ] Related documents loading from ChromaDB
- [ ] Deal context in `AIFieldPopulator` prompt variables
- [ ] User profile in `AIFieldPopulator` prompt variables
- [ ] Related documents in `AIFieldPopulator` prompt variables
- [ ] Generated document linking to deals
- [ ] Deal notes in prompt context

## Implementation Priority

1. **High Priority**:
   - Add `deal_id` to `GenerateDocumentRequest`
   - Load deal context in `DocumentGenerationService`
   - Pass deal context to `AIFieldPopulator`
   - Link generated documents to deals

2. **Medium Priority**:
   - Load user profile in `DocumentGenerationService`
   - Pass user profile to `AIFieldPopulator`
   - Load related documents from ChromaDB

3. **Low Priority**:
   - Include deal notes in prompt context
   - Semantic search for similar deals
   - Pattern matching from historical documents

## Conclusion

The document generation flow currently uses only CDM data for generation. To fully hydrate it with available data:

1. **Add `deal_id` support** throughout the generation pipeline
2. **Load deal context** (metadata, documents, notes) when available
3. **Load user profile** for role/permission-aware generation
4. **Query ChromaDB** for related documents as precedent
5. **Enhance AI prompts** with all available context
6. **Link generated documents** to deals automatically

This will result in:
- More accurate and contextual legal clauses
- Deal-aware document generation
- Better consistency across deal documents
- Improved user experience with deal-centric workflow
