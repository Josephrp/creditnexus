# CreditNexus Multi-User Permission System & Deal Lifecycle Implementation Plan

## Executive Summary

This plan outlines the implementation of a comprehensive multi-user permission system, role-based access control (RBAC), enhanced user signup flows, deal lifecycle management, and integration with existing features including satellite verification, ChromaDB, and decision support chatbot.

**Priority**: High  
**Estimated Timeline**: 6-8 weeks  
**Complexity**: High

---

## Project 1: Enhanced Role-Based Permission System

### Overview
Extend the current basic role enum (VIEWER, ANALYST, REVIEWER, ADMIN) to a granular permission-based system supporting five distinct user types: Auditor, Banker, Law Officer, Accountant, and Applicant.

### Activities

#### Activity 1.1: Database Schema Updates
**Priority**: P0 (Critical)  
**Estimated Time**: 2 days

**Tasks:**
1. Create Alembic migration for permission system
   - Add `permissions` JSONB column to `users` table
   - Create `permission_definitions` table (id, name, description, category)
   - Create `role_permissions` junction table (role, permission_id)
   - Add indexes for performance

2. Update `UserRole` enum in `app/db/models.py`
   ```python
   class UserRole(str, enum.Enum):
       AUDITOR = "auditor"      # Full oversight, read-only access to all
       BANKER = "banker"        # Write permissions for deals, documents
       LAW_OFFICER = "law_officer"  # Write/edit for legal documents
       ACCOUNTANT = "accountant"     # Write/edit for financial data
       APPLICANT = "applicant"      # Apply and track applications
       # Legacy roles for backward compatibility
       VIEWER = "viewer"
       ANALYST = "analyst"
       REVIEWER = "reviewer"
       ADMIN = "admin"
   ```

3. Create `Permission` model in `app/db/models.py`
   ```python
   class Permission(Base):
       __tablename__ = "permission_definitions"
       id = Column(Integer, primary_key=True)
       name = Column(String(100), unique=True, nullable=False)
       description = Column(Text, nullable=True)
       category = Column(String(50), nullable=False)  # 'document', 'deal', 'user', 'policy', etc.
   ```

4. Create permission constants file `app/core/permissions.py`
   - Define all permission constants (e.g., `DOCUMENT_CREATE`, `DOCUMENT_EDIT`, `DEAL_VIEW`, etc.)
   - Create permission mapping by role

**Files to Modify:**
- `app/db/models.py` (lines 12-17, add Permission model)
- `alembic/versions/XXXX_add_permissions_system.py` (new file)
- `app/core/permissions.py` (new file)

---

#### Activity 1.2: Permission Checking Middleware
**Priority**: P0  
**Estimated Time**: 3 days

**Tasks:**
1. Create `PermissionChecker` dependency in `app/auth/dependencies.py`
   ```python
   class PermissionChecker:
       def __init__(self, required_permissions: List[str]):
           self.required_permissions = required_permissions
       
       async def __call__(self, user: User = Depends(get_current_user)) -> User:
           if not has_permissions(user, self.required_permissions):
               raise HTTPException(403, "Insufficient permissions")
           return user
   ```

2. Create `has_permission()` and `has_permissions()` helper functions
   - Check user role permissions
   - Check explicit user permissions (if any)
   - Support permission inheritance

3. Update existing `RoleChecker` to use new permission system
   - Maintain backward compatibility
   - Add deprecation warnings

4. Add permission decorators for routes
   ```python
   @require_permission("DOCUMENT_CREATE")
   @router.post("/documents")
   ```

**Files to Modify:**
- `app/auth/dependencies.py` (extend existing, add PermissionChecker)
- `app/core/permissions.py` (add helper functions)

---

#### Activity 1.3: Permission Configuration & Seeding
**Priority**: P0  
**Estimated Time**: 2 days

**Tasks:**
1. Create `app/core/permission_config.py`
   - Define default permissions for each role
   - Auditor: `*_VIEW`, `*_AUDIT`, `*_EXPORT` (read-only oversight)
   - Banker: `DOCUMENT_*`, `DEAL_*`, `TRADE_*` (full write access)
   - Law Officer: `DOCUMENT_EDIT`, `DOCUMENT_REVIEW`, `TEMPLATE_*`
   - Accountant: `PAYMENT_*`, `FINANCIAL_*`, `DOCUMENT_VIEW`
   - Applicant: `APPLICATION_*`, `DEAL_VIEW_OWN`, `INQUIRY_*`

2. Create seed script `scripts/seed_permissions.py`
   - Seed permission definitions
   - Assign permissions to roles
   - Make configurable via environment flags

3. Update `server.py` lifespan to seed permissions on startup (if flag enabled)

**Files to Create:**
- `app/core/permission_config.py` (new file)
- `scripts/seed_permissions.py` (new file)

**Files to Modify:**
- `server.py` (add permission seeding to lifespan)

---

## Project 2: Enhanced User Signup & Profile System

### Overview
Implement multi-step signup flow with role selection, profile enrichment using forms, text entry, and multimodal input (images, documents), and automatic ChromaDB indexing.

### Activities

#### Activity 2.1: Multi-Step Signup Flow Backend
**Priority**: P0  
**Estimated Time**: 4 days

**Tasks:**
1. Create signup request models in `app/auth/jwt_auth.py`
   ```python
   class UserSignupStep1(BaseModel):  # Basic info
       email: EmailStr
       password: str
       display_name: str
       role: UserRole  # Selected role
   
   class UserSignupStep2(BaseModel):  # Profile enrichment
       phone: Optional[str]
       company: Optional[str]
       job_title: Optional[str]
       address: Optional[str]
       # Additional fields based on role and likely deals based on applicant types / business / individual
   ```

2. Create `/api/auth/signup/step1` endpoint
   - Validate email uniqueness
   - Validate password strength
   - Create user with selected role
   - Return signup token (temporary, expires in 1 hour)

3. Create `/api/auth/signup/step2` endpoint
   - Accept signup token
   - Accept profile data (JSON)
   - Accept file uploads (profile image, documents)
   - Update user profile
   - Extract structured data from documents using LLM
   - Index in ChromaDB

4. Create user profile model extension
   - Add `profile_data` JSONB column to `users` table
   - Store enriched profile information
   - Support role-specific fields

**Files to Modify:**
- `app/auth/jwt_auth.py` (add signup models and endpoints)
- `app/db/models.py` (add profile_data column to User)
- `alembic/versions/XXXX_add_user_profile_data.py` (new migration)

---

#### Activity 2.2: Multimodal Profile Extraction
**Priority**: P1  
**Estimated Time**: 3 days

**Tasks:**
1. Create `app/services/profile_extraction_service.py`
   - Extract text from uploaded documents (PDF, images)
   - Use OCR for images (existing OCR service)
   - Use LLM to extract structured profile data
   - Support multiple document types (ID, business license, financial statements)

2. Create profile extraction chain in `app/chains/profile_extraction_chain.py`
   - Use structured output to extract: name, address, company, financial info, etc.
   - Validate extracted data
   - Merge with form data

3. Integrate with ChromaDB
   - Index user profile data in ChromaDB collection `user_profiles`
   - Store embeddings for semantic search
   - Link to user_id for retrieval

**Files to Create:**
- `app/services/profile_extraction_service.py` (new file)
- `app/chains/profile_extraction_chain.py` (new file)

**Files to Modify:**
- `app/chains/document_retrieval_chain.py` (add user profile collection)

---

#### Activity 2.3: Frontend Signup Flow
**Priority**: P0  
**Estimated Time**: 5 days

**Tasks:**
1. Create `client/src/components/SignupFlow.tsx`
   - Step 1: Basic info + role selection
   - Step 2: Profile enrichment form
   - Step 3: Document upload (multimodal)
   - Step 4: Review & submit

2. Create role-specific signup forms
   - `SignupFormApplicant.tsx` (for applicants)
   - `SignupFormBanker.tsx` (for bankers)
   - `SignupFormLawOfficer.tsx` (for law officers)
   - `SignupFormAccountant.tsx` (for accountants)

3. Create `client/src/components/ProfileEnrichment.tsx`
   - Form fields based on role
   - File upload component
   - Progress indicator
   - Real-time validation

4. Update `LoginForm.tsx` to link to signup flow

**Files to Create:**
- `client/src/components/SignupFlow.tsx` (new file)
- `client/src/components/SignupFormApplicant.tsx` (new file)
- `client/src/components/SignupFormBanker.tsx` (new file)
- `client/src/components/SignupFormLawOfficer.tsx` (new file)
- `client/src/components/SignupFormAccountant.tsx` (new file)
- `client/src/components/ProfileEnrichment.tsx` (new file)

**Files to Modify:**
- `client/src/components/LoginForm.tsx` (add signup link)
- `client/src/context/AuthContext.tsx` (add signup methods)

---

## Project 3: Deal Lifecycle & File Management

### Overview
Implement deal tracking system where each user's application creates a deal file that follows them through the lifecycle, with all documents and updates attached to user/deal folders.

### Activities

#### Activity 3.1: Deal Model & Database Schema
**Priority**: P0  
**Estimated Time**: 3 days

**Tasks:**
1. Create `Deal` model in `app/db/models.py`
   ```python
   class Deal(Base):
       __tablename__ = "deals"
       id = Column(Integer, primary_key=True)
       deal_id = Column(String(255), unique=True, index=True)  # External deal identifier
       applicant_id = Column(Integer, ForeignKey("users.id"), nullable=False)
       application_id = Column(Integer, ForeignKey("applications.id"), nullable=True)
       status = Column(String(50), default="draft")  # draft, submitted, under_review, approved, rejected, active, closed
       deal_type = Column(String(50))  # loan_application, debt_sale, loan_purchase, etc.
       deal_data = Column(JSONB)  # Deal parameters, metadata
       folder_path = Column(String(500))  # File system path for deal documents
       created_at = Column(DateTime, default=datetime.utcnow)
       updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
   ```

2. Create deal-document relationship
   - Add `deal_id` foreign key to `documents` table
   - Create `deal_documents` junction table if many-to-many needed

3. Create file system structure
   - `storage/deals/{user_id}/{deal_id}/` for each deal
   - Subdirectories: `documents/`, `extractions/`, `generated/`, `notes/`

4. Create Alembic migration

**Files to Modify:**
- `app/db/models.py` (add Deal model)
- `alembic/versions/XXXX_add_deals_table.py` (new migration)

---

#### Activity 3.2: Deal Lifecycle State Machine
**Priority**: P0  
**Estimated Time**: 2 days

**Tasks:**
1. Create `app/services/deal_service.py`
   - `create_deal_from_application()` - Convert application to deal
   - `update_deal_status()` - State transitions with validation
   - `attach_document_to_deal()` - Link documents to deals
   - `get_deal_timeline()` - Get all events/updates for a deal

2. Implement deal status transitions
   - draft → submitted → under_review → approved/rejected
   - approved → active → closed
   - Validate transitions based on user permissions

3. Create CDM events for deal state changes
   - Use `generate_cdm_policy_evaluation()` for approvals
   - Create deal-specific CDM events

**Files to Create:**
- `app/services/deal_service.py` (new file)

**Files to Modify:**
- `app/models/cdm_events.py` (add deal-related event generators)

---

#### Activity 3.3: Deal File Management
**Priority**: P1  
**Estimated Time**: 3 days

**Tasks:**
1. Create `app/services/file_storage_service.py`
   - `create_deal_folder()` - Create folder structure
   - `store_deal_document()` - Save documents to deal folder
   - `get_deal_documents()` - List all documents for a deal
   - `archive_deal()` - Move deal to archive

2. Update document creation to link to deals
   - Modify `/api/documents` POST endpoint
   - Auto-create deal folder if not exists
   - Store documents in deal folder

3. Create deal notes system
   - `DealNote` model for user notes on deals
   - Store in `storage/deals/{deal_id}/notes/`
   - Index notes in ChromaDB for search

**Files to Create:**
- `app/services/file_storage_service.py` (new file)

**Files to Modify:**
- `app/api/routes.py` (update document creation endpoint)
- `app/db/models.py` (add DealNote model if needed)

---

#### Activity 3.4: Deal Tracking Frontend
**Priority**: P1  
**Estimated Time**: 4 days

**Tasks:**
1. Create `client/src/components/DealDashboard.tsx`
   - List all deals for current user (or all deals if admin/auditor)
   - Filter by status, deal type
   - Search functionality

2. Create `client/src/components/DealDetail.tsx`
   - Deal information
   - Timeline of events
   - Attached documents
   - Notes section
   - Status updates

3. Create `client/src/components/DealTimeline.tsx`
   - Visual timeline of deal lifecycle
   - Show CDM events
   - Show document uploads
   - Show status changes

4. Update `ApplicationDashboard.tsx` to create deals from approved applications

**Files to Create:**
- `client/src/components/DealDashboard.tsx` (new file)
- `client/src/components/DealDetail.tsx` (new file)
- `client/src/components/DealTimeline.tsx` (new file)

**Files to Modify:**
- `client/src/components/ApplicationDashboard.tsx` (add deal creation)

---

## Project 4: Satellite Verification CDM Event Integration

### Overview
Ensure satellite verification (green loan NDVI checks) properly creates CDM events (Observation, TermsChange) and updates deal files.

### Activities

#### Activity 4.1: CDM Event Generation for Satellite Verification
**Priority**: P0  
**Estimated Time**: 2 days

**Tasks:**
1. Review `app/agents/verifier.py` and `app/agents/audit_workflow.py`
   - Verify CDM Observation events are created (already implemented)
   - Verify TermsChange events are triggered on breach (check implementation)

2. Ensure events are stored in database
   - Check `PolicyDecision` model stores CDM events
   - Verify events are linked to deals/loans

3. Create deal update on satellite verification
   - When satellite verification completes, update deal status/metadata
   - Add verification result to deal folder
   - Create deal note about verification

**Files to Modify:**
- `app/agents/audit_workflow.py` (ensure CDM events are created and stored)
- `app/services/deal_service.py` (add update_deal_from_verification method)

---

#### Activity 4.2: Deal File Updates from Satellite Events
**Priority**: P1  
**Estimated Time**: 2 days

**Tasks:**
1. Create event handler for satellite verification results
   - Listen for verification completion
   - Update deal file with verification results
   - Store satellite images in deal folder if available

2. Create CDM event file storage
   - Store all CDM events for a deal in `storage/deals/{deal_id}/events/`
   - JSON files for each event type
   - Maintain event log

**Files to Create:**
- `app/services/deal_event_handler.py` (new file)

**Files to Modify:**
- `app/agents/audit_workflow.py` (trigger deal updates)

---

## Project 5: Permission-Based UI Visibility

### Overview
Implement frontend permission checking to show/hide UI elements based on user roles and permissions.

### Activities

#### Activity 5.1: Frontend Permission Hooks
**Priority**: P0  
**Estimated Time**: 2 days

**Tasks:**
1. Create `client/src/hooks/usePermissions.ts`
   ```typescript
   export function usePermissions() {
     const { user } = useAuth();
     const hasPermission = (permission: string) => {
       // Check user role permissions
     };
     const hasAnyPermission = (permissions: string[]) => {
       // Check if user has any of the permissions
     };
     return { hasPermission, hasAnyPermission, userRole: user?.role };
   }
   ```

2. Create `client/src/utils/permissions.ts`
   - Permission constants matching backend
   - Permission mapping by role
   - Helper functions

**Files to Create:**
- `client/src/hooks/usePermissions.ts` (new file)
- `client/src/utils/permissions.ts` (new file)

---

#### Activity 5.2: Permission-Based Component Wrappers
**Priority**: P0  
**Estimated Time**: 3 days

**Tasks:**
1. Create `PermissionGate` component
   ```typescript
   <PermissionGate permission="DOCUMENT_CREATE">
     <Button>Create Document</Button>
   </PermissionGate>
   ```

2. Update existing components to use permission checks
   - `DocumentHistory.tsx` - Hide edit/delete for viewers
   - `Dashboard.tsx` - Show/hide sections based on role
   - `TradeBlotter.tsx` - Hide execute for non-bankers
   - `ReviewInterface.tsx` - Show only for reviewers/law officers

3. Update navigation to hide menu items
   - `MainNavigation.tsx` - Filter menu items by permissions
   - `DesktopAppLayout.tsx` - Hide apps based on permissions

**Files to Create:**
- `client/src/components/PermissionGate.tsx` (new file)

**Files to Modify:**
- `client/src/components/DocumentHistory.tsx`
- `client/src/components/Dashboard.tsx`
- `client/src/components/TradeBlotter.tsx`
- `client/src/components/ReviewInterface.tsx`
- `client/src/components/MainNavigation.tsx`
- `client/src/components/DesktopAppLayout.tsx`

---

## Project 6: Deal-Type Driven Chatbot Decision Support

### Overview
Enhance the decision support chatbot to provide deal-type specific guidance based on attached documents and required templates.

### Activities

#### Activity 6.1: Deal Context Integration
**Priority**: P1  
**Estimated Time**: 3 days

**Tasks:**
1. Update `DecisionSupportChatbot` in `app/chains/decision_support_chain.py`
   - Accept `deal_id` parameter
   - Load deal context (deal type, documents, status)
   - Load user profile from ChromaDB
   - Inject deal-specific information into prompts

2. Create deal context retrieval
   - Query ChromaDB for deal documents
   - Query ChromaDB for user profile
   - Query database for deal metadata
   - Combine into context string

3. Update chatbot prompt to include deal context
   - Add deal type to system prompt
   - Add available documents
   - Add required templates based on deal type
   - Add user role/permissions context

**Files to Modify:**
- `app/chains/decision_support_chain.py` (add deal context support)
- `app/api/routes.py` (update `/api/chatbot/chat` endpoint to accept deal_id)

---

#### Activity 6.2: Template Recommendation Based on Deal Type
**Priority**: P1  
**Estimated Time**: 2 days

**Tasks:**
1. Create `app/services/template_recommendation_service.py`
   - Map deal types to required templates
   - Check which templates are already generated
   - Recommend missing templates

2. Integrate with chatbot
   - Chatbot suggests templates based on deal type
   - Chatbot explains why templates are needed
   - Chatbot helps fill template fields from deal data

**Files to Create:**
- `app/services/template_recommendation_service.py` (new file)

**Files to Modify:**
- `app/chains/decision_support_chain.py` (add template recommendations)

---

#### Activity 6.3: Frontend Chatbot Integration with Deals
**Priority**: P1  
**Estimated Time**: 2 days

**Tasks:**
1. Update chatbot UI to show deal context
   - Display current deal information
   - Show attached documents
   - Show recommended templates

2. Add deal selection to chatbot
   - Allow user to select deal for context
   - Auto-select deal if on deal detail page

**Files to Modify:**
- `client/src/components/DocumentGenerator.tsx` (if chatbot is embedded there)
- Create `client/src/components/ChatbotInterface.tsx` if standalone

---

## Project 7: User Seeding Script with Configuration

### Overview
Create configurable user seeding script that can seed multiple users with different roles for demo purposes.

### Activities

#### Activity 7.1: Seeding Script with Flags
**Priority**: P0  
**Estimated Time**: 2 days

**Tasks:**
1. Create `scripts/seed_demo_users.py`
   ```python
   # Seed users based on environment flags
   SEED_AUDITOR = os.getenv("SEED_AUDITOR", "false").lower() == "true"
   SEED_BANKER = os.getenv("SEED_BANKER", "false").lower() == "true"
   # ... etc
   ```

2. Define demo users with roles
   - auditor@creditnexus.app / Auditor123!
   - banker@creditnexus.app / Banker123!
   - lawofficer@creditnexus.app / LawOfficer123!
   - accountant@creditnexus.app / Accountant123!
   - applicant@creditnexus.app / Applicant123!

3. Add profile data for each user
   - Company names
   - Job titles
   - Sample documents (optional)

4. Make script idempotent
   - Check if users exist before creating
   - Update existing users if needed

**Files to Create:**
- `scripts/seed_demo_users.py` (new file)

**Files to Modify:**
- `server.py` (add seeding to lifespan with flags)
- `.env.example` (add seeding flags)

---

#### Activity 7.2: Seeding Configuration
**Priority**: P1  
**Estimated Time**: 1 day

**Tasks:**
1. Add seeding configuration to `app/core/config.py`
   ```python
   SEED_DEMO_USERS: bool = False
   SEED_AUDITOR: bool = False
   SEED_BANKER: bool = False
   # ... etc
   ```

2. Update `server.py` to use config flags
   - Only seed if flags are enabled
   - Log seeding actions

**Files to Modify:**
- `app/core/config.py` (add seeding flags)
- `server.py` (use config flags)

---

## Project 8: ChromaDB Integration for User & Deal Data

### Overview
Ensure user profiles, deal information, and documents are properly indexed in ChromaDB for semantic search and retrieval.

### Activities

#### Activity 8.1: User Profile Indexing
**Priority**: P1  
**Estimated Time**: 2 days

**Tasks:**
1. Update `DocumentRetrievalService` to support user profiles
   - Create `user_profiles` collection
   - Index user profile data on signup/update
   - Support semantic search for users

2. Create user profile retrieval endpoint
   - `/api/users/search` - Semantic search for users
   - Use case: Find users by company, role, etc.

**Files to Modify:**
- `app/chains/document_retrieval_chain.py` (add user profile collection)
- `app/api/routes.py` (add user search endpoint)

---

#### Activity 8.2: Deal Data Indexing
**Priority**: P1  
**Estimated Time**: 2 days

**Tasks:**
1. Index deal information in ChromaDB
   - Create `deals` collection
   - Index deal metadata, documents, notes
   - Support semantic search for deals

2. Update deal creation/update to index in ChromaDB
   - Auto-index on deal creation
   - Re-index on deal update
   - Index attached documents

**Files to Modify:**
- `app/chains/document_retrieval_chain.py` (add deals collection)
- `app/services/deal_service.py` (add ChromaDB indexing)

---

## Project 9: Credit Risk Model Policy Framework

### Overview
Extend the policy engine to support internal credit risk model policies including Basel III capital requirements, internal rating systems (IRB), creditworthiness assessment, collateral requirements, and risk rating systems.

### Activities

#### Activity 9.1: Credit Risk Policy Rule Definitions
**Priority**: P0  
**Estimated Time**: 3 days

**Tasks:**
1. Create credit risk policy YAML templates in `app/policies/credit_risk/`
   - `basel_iii_capital.yaml` - Basel III capital adequacy rules
   - `irb_ratings.yaml` - Internal Ratings-Based (IRB) approach rules
   - `creditworthiness.yaml` - Creditworthiness assessment policies
   - `collateral_requirements.yaml` - Collateral valuation and requirements
   - `risk_rating.yaml` - Risk rating classification policies
   - `stress_testing.yaml` - Stress testing and scenario analysis rules
   - `data_quality.yaml` - Data quality management policies
   - `model_validation.yaml` - Model validation and backtesting rules

2. Define credit risk policy rule structure
   ```yaml
   - name: block_insufficient_capital_coverage
     when:
       all:
         - field: transaction_type
           op: eq
           value: "facility_creation"
         - field: risk_weighted_assets
           op: gt
           value: available_capital * 0.08  # 8% minimum capital ratio
     action: block
     priority: 95
     description: "Block facilities that would breach minimum capital adequacy ratio"
     category: "basel_iii"
   ```

3. Create credit risk field mappings
   - Map CDM fields to credit risk metrics
   - Support risk-weighted asset calculations
   - Support probability of default (PD) and loss given default (LGD) inputs

**Files to Create:**
- `app/policies/credit_risk/basel_iii_capital.yaml` (new file)
- `app/policies/credit_risk/irb_ratings.yaml` (new file)
- `app/policies/credit_risk/creditworthiness.yaml` (new file)
- `app/policies/credit_risk/collateral_requirements.yaml` (new file)
- `app/policies/credit_risk/risk_rating.yaml` (new file)
- `app/policies/credit_risk/stress_testing.yaml` (new file)
- `app/policies/credit_risk/data_quality.yaml` (new file)
- `app/policies/credit_risk/model_validation.yaml` (new file)

**Files to Modify:**
- `app/services/policy_service.py` (add credit risk evaluation methods)
- `app/core/policy_config.py` (support credit risk policy categories)

---

#### Activity 9.2: Credit Risk Calculation Service
**Priority**: P0  
**Estimated Time**: 4 days

**Tasks:**
1. Create `app/services/credit_risk_service.py`
   - Calculate risk-weighted assets (RWA)
   - Calculate capital requirements (Basel III)
   - Calculate probability of default (PD) from credit data
   - Calculate loss given default (LGD) from collateral data
   - Calculate exposure at default (EAD)
   - Support IRB approach calculations

2. Integrate with policy engine
   - Add credit risk metrics to policy transaction context
   - Support dynamic calculations in policy rules
   - Cache calculation results for performance

3. Create credit risk model interface
   - Abstract interface for different credit risk models
   - Support internal rating models
   - Support external rating mappings (S&P, Moody's, Fitch)

**Files to Create:**
- `app/services/credit_risk_service.py` (new file)
- `app/models/credit_risk.py` (new file - credit risk data models)

**Files to Modify:**
- `app/services/policy_service.py` (integrate credit risk calculations)
- `app/models/cdm.py` (add credit risk fields to CreditAgreement)

---

#### Activity 9.3: Credit Risk Policy Evaluation Integration
**Priority**: P0  
**Estimated Time**: 3 days

**Tasks:**
1. Extend `PolicyService` with credit risk evaluation methods
   - `evaluate_credit_risk()` - Full credit risk assessment
   - `calculate_capital_requirements()` - Basel III capital calculation
   - `assess_creditworthiness()` - Creditworthiness scoring
   - `validate_collateral()` - Collateral adequacy check

2. Create CDM events for credit risk evaluations
   - `CreditRiskAssessment` event type
   - Store risk ratings, capital requirements, PD/LGD/EAD
   - Link to policy evaluation events

3. Integrate with deal lifecycle
   - Auto-evaluate credit risk on deal creation
   - Re-evaluate on deal updates
   - Store risk metrics in deal metadata

**Files to Modify:**
- `app/services/policy_service.py` (add credit risk methods)
- `app/models/cdm_events.py` (add credit risk event generators)
- `app/services/deal_service.py` (integrate credit risk evaluation)

---

#### Activity 9.4: Credit Risk Dashboard & Reporting
**Priority**: P1  
**Estimated Time**: 3 days

**Tasks:**
1. Create credit risk API endpoints
   - `/api/credit-risk/assess` - Assess credit risk for a deal
   - `/api/credit-risk/capital-requirements` - Calculate capital requirements
   - `/api/credit-risk/portfolio-summary` - Portfolio-level risk summary
   - `/api/credit-risk/stress-test` - Run stress test scenarios

2. Create credit risk data models
   - Risk rating scales (AAA to D, or 1-10 internal scale)
   - Capital requirement breakdowns
   - Portfolio concentration metrics

**Files to Create:**
- `app/api/credit_risk_routes.py` (new file)

**Files to Modify:**
- `app/api/routes.py` (include credit risk routes)
- `app/db/models.py` (add CreditRiskAssessment model)

---

## Project 10: Policy Editor and Builder Workflow

### Overview
Build a comprehensive policy editor and builder system with visual rule creation, YAML editing, policy templates, version control, approval workflows, and testing capabilities.

### Activities

#### Activity 10.1: Policy Editor Backend API
**Priority**: P0  
**Estimated Time**: 4 days

**Tasks:**
1. Create policy management API endpoints
   - `GET /api/policies` - List all policies with metadata
   - `GET /api/policies/{policy_id}` - Get policy details
   - `POST /api/policies` - Create new policy
   - `PUT /api/policies/{policy_id}` - Update policy
   - `DELETE /api/policies/{policy_id}` - Delete policy (soft delete)
   - `POST /api/policies/{policy_id}/validate` - Validate policy YAML
   - `POST /api/policies/{policy_id}/test` - Test policy against sample transactions
   - `POST /api/policies/{policy_id}/activate` - Activate policy version
   - `GET /api/policies/{policy_id}/versions` - Get policy version history
   - `POST /api/policies/{policy_id}/approve` - Approve policy for activation

2. Create policy database models
   ```python
   class Policy(Base):
       __tablename__ = "policies"
       id = Column(Integer, primary_key=True)
       name = Column(String(255), nullable=False)
       category = Column(String(100))  # 'regulatory', 'credit_risk', 'esg', etc.
       description = Column(Text)
       rules_yaml = Column(Text)  # Full YAML content
       status = Column(String(50))  # 'draft', 'pending_approval', 'active', 'archived'
       version = Column(Integer, default=1)
       created_by = Column(Integer, ForeignKey("users.id"))
       approved_by = Column(Integer, ForeignKey("users.id"), nullable=True)
       created_at = Column(DateTime, default=datetime.utcnow)
       updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
       metadata = Column(JSONB)  # Additional metadata
   ```

3. Implement policy validation service
   - Validate YAML syntax
   - Validate rule structure
   - Check for circular dependencies
   - Validate field references

4. Implement policy testing service
   - Test policy against sample transactions
   - Generate test results with pass/fail
   - Support batch testing

**Files to Create:**
- `app/api/policy_editor_routes.py` (new file)
- `app/services/policy_editor_service.py` (new file)
- `app/services/policy_validator.py` (new file)
- `app/services/policy_tester.py` (new file)

**Files to Modify:**
- `app/db/models.py` (add Policy, PolicyVersion models)
- `app/api/routes.py` (include policy editor routes)
- `alembic/versions/XXXX_add_policy_editor_tables.py` (new migration)

---

#### Activity 10.2: Policy Builder UI Components
**Priority**: P0  
**Estimated Time**: 5 days

**Tasks:**
1. Create `PolicyEditor.tsx` main component
   - Split-pane layout: rule builder on left, YAML preview on right
   - Real-time YAML generation from visual builder
   - Real-time validation feedback
   - Save draft functionality

2. Create `RuleBuilder.tsx` component
   - Visual rule creation form
   - Condition builder with drag-and-drop
   - Field selector with autocomplete
   - Operator selector (eq, gt, lt, in, contains, etc.)
   - Value input with type validation
   - Support for nested `any`/`all` conditions

3. Create `PolicyTemplateSelector.tsx` component
   - Template library browser
   - Filter by category (regulatory, credit_risk, esg, etc.)
   - Preview template structure
   - Clone template to new policy

4. Create `PolicyVersionHistory.tsx` component
   - Version timeline view
   - Diff viewer between versions
   - Rollback functionality
   - Version comparison

**Files to Create:**
- `client/src/apps/policy-editor/PolicyEditor.tsx` (new file)
- `client/src/apps/policy-editor/RuleBuilder.tsx` (new file)
- `client/src/apps/policy-editor/PolicyTemplateSelector.tsx` (new file)
- `client/src/apps/policy-editor/PolicyVersionHistory.tsx` (new file)
- `client/src/apps/policy-editor/ConditionBuilder.tsx` (new file)
- `client/src/apps/policy-editor/YamlEditor.tsx` (new file)

---

#### Activity 10.3: Policy Testing & Validation UI
**Priority**: P1  
**Estimated Time**: 3 days

**Tasks:**
1. Create `PolicyTester.tsx` component
   - Transaction builder form
   - Test transaction against policy
   - Show evaluation trace
   - Show matched rules
   - Show decision result (ALLOW/BLOCK/FLAG)

2. Create `PolicyValidator.tsx` component
   - Real-time YAML validation
   - Syntax error highlighting
   - Structure validation feedback
   - Field reference validation

3. Create `TestTransactionBuilder.tsx` component
   - Form to build test transactions
   - Pre-populate from deal/CDM data
   - Save test cases for regression testing

**Files to Create:**
- `client/src/apps/policy-editor/PolicyTester.tsx` (new file)
- `client/src/apps/policy-editor/PolicyValidator.tsx` (new file)
- `client/src/apps/policy-editor/TestTransactionBuilder.tsx` (new file)

---

#### Activity 10.4: Policy Approval Workflow
**Priority**: P1  
**Estimated Time**: 3 days

**Tasks:**
1. Create approval workflow backend
   - Policy status state machine (draft → pending_approval → active)
   - Approval routing based on policy category
   - Email notifications for approval requests
   - Approval history tracking

2. Create approval UI components
   - `PolicyApprovalQueue.tsx` - List policies pending approval
   - `PolicyApprovalModal.tsx` - Approve/reject with comments
   - `ApprovalHistory.tsx` - View approval history

3. Integrate with permission system
   - Only authorized users can approve policies
   - Role-based approval permissions
   - Audit trail for approvals

**Files to Create:**
- `app/services/policy_approval_service.py` (new file)
- `client/src/apps/policy-editor/PolicyApprovalQueue.tsx` (new file)
- `client/src/apps/policy-editor/PolicyApprovalModal.tsx` (new file)

**Files to Modify:**
- `app/db/models.py` (add PolicyApproval model)
- `app/core/permissions.py` (add policy approval permissions)

---

#### Activity 10.5: Policy Template Library
**Priority**: P1  
**Estimated Time**: 2 days

**Tasks:**
1. Create policy template database
   - Store pre-built policy templates
   - Categorize by use case (regulatory, credit_risk, esg, etc.)
   - Include template metadata and descriptions

2. Create template management UI
   - `PolicyTemplateLibrary.tsx` - Browse templates
   - `TemplatePreview.tsx` - Preview template rules
   - `TemplateCreator.tsx` - Create new templates from policies

3. Seed initial templates
   - Basel III capital requirements template
   - Sanctions screening template
   - ESG compliance template
   - Credit risk assessment template

**Files to Create:**
- `app/db/models.py` (add PolicyTemplate model)
- `client/src/apps/policy-editor/PolicyTemplateLibrary.tsx` (new file)
- `scripts/seed_policy_templates.py` (new file)

---

## Project 11: Green Finance Policy Framework & Enhanced Satellite Verification

### Overview
Extend the policy engine to support comprehensive green finance policies using enhanced satellite imagery analysis including urban activity indicators, vehicle emissions, pollution monitoring, and multi-dimensional environmental metrics beyond NDVI.

### Activities

#### Activity 11.1: Green Finance Policy Rule Definitions
**Priority**: P0  
**Estimated Time**: 3 days

**Tasks:**
1. Create green finance policy YAML templates in `app/policies/green_finance/`
   - `urban_sustainability.yaml` - Urban development sustainability rules
   - `emissions_monitoring.yaml` - CO2 and air quality monitoring policies
   - `vehicle_activity.yaml` - Traffic and vehicle emission policies
   - `pollution_compliance.yaml` - Pollution threshold and compliance rules
   - `sustainable_infrastructure.yaml` - Green infrastructure verification
   - `climate_resilience.yaml` - Climate risk and resilience policies
   - `sdg_alignment.yaml` - Sustainable Development Goals alignment

2. Define green finance policy rule structure
   ```yaml
   - name: block_high_emission_urban_development
     when:
       all:
         - field: transaction_type
           op: eq
           value: "facility_creation"
         - field: location_type
           op: eq
           value: "urban"
         - field: estimated_vehicle_emissions
           op: gt
           value: 100  # tons CO2/year per km²
         - field: air_quality_index
           op: gt
           value: 150  # Unhealthy AQI threshold
     action: block
     priority: 90
     description: "Block facilities in high-emission urban areas exceeding air quality thresholds"
     category: "green_finance"
   ```

3. Create green finance field mappings
   - Map satellite-derived indicators to policy fields
   - Support multi-dimensional environmental metrics
   - Support temporal trend analysis

**Files to Create:**
- `app/policies/green_finance/urban_sustainability.yaml` (new file)
- `app/policies/green_finance/emissions_monitoring.yaml` (new file)
- `app/policies/green_finance/vehicle_activity.yaml` (new file)
- `app/policies/green_finance/pollution_compliance.yaml` (new file)
- `app/policies/green_finance/sustainable_infrastructure.yaml` (new file)
- `app/policies/green_finance/climate_resilience.yaml` (new file)
- `app/policies/green_finance/sdg_alignment.yaml` (new file)

**Files to Modify:**
- `app/services/policy_service.py` (add green finance evaluation methods)
- `app/core/policy_config.py` (support green finance policy categories)

---

#### Activity 11.2: Enhanced Satellite Verification Service
**Priority**: P0  
**Estimated Time**: 5 days

**Tasks:**
1. Extend `app/agents/verifier.py` with enhanced satellite analysis
   - Integrate street map layer APIs (OpenStreetMap, Google Maps, Mapbox)
   - Vehicle counting from satellite imagery using computer vision
   - Street activity detection (pedestrian traffic, commercial activity)
   - Pollution layer integration (air quality, methane emissions)
   - Urban heat island detection
   - Green infrastructure identification (parks, green roofs, solar panels)

2. Create multi-dimensional environmental scoring
   - Combine NDVI with urban activity metrics
   - Calculate composite sustainability score
   - Support location-specific thresholds (urban vs. rural)

3. Integrate with policy engine
   - Add enhanced satellite metrics to policy transaction context
   - Support green finance policy evaluation
   - Create CDM events for green finance verifications

**Files to Create:**
- `app/services/enhanced_satellite_service.py` (new file)
- `app/services/urban_activity_analyzer.py` (new file)
- `app/services/pollution_monitor_service.py` (new file)

**Files to Modify:**
- `app/agents/verifier.py` (add enhanced satellite analysis methods)
- `app/models/loan_asset.py` (add green finance metrics fields)
- `app/services/policy_service.py` (integrate enhanced satellite metrics)

---

#### Activity 11.3: Green Finance Policy Evaluation Integration
**Priority**: P0  
**Estimated Time**: 3 days

**Tasks:**
1. Extend `PolicyService` with green finance evaluation methods
   - `evaluate_green_finance_compliance()` - Full green finance assessment
   - `assess_urban_sustainability()` - Urban development sustainability scoring
   - `monitor_emissions_compliance()` - Emissions and air quality compliance
   - `evaluate_sdg_alignment()` - SDG alignment scoring

2. Create CDM events for green finance evaluations
   - `GreenFinanceAssessment` event type
   - Store environmental metrics, sustainability scores, SDG alignment
   - Link to policy evaluation events

3. Integrate with deal lifecycle
   - Auto-evaluate green finance on deal creation
   - Re-evaluate on deal updates
   - Store green finance metrics in deal metadata

**Files to Modify:**
- `app/services/policy_service.py` (add green finance methods)
- `app/models/cdm_events.py` (add green finance event generators)
- `app/services/deal_service.py` (integrate green finance evaluation)

---

#### Activity 11.4: Green Finance Dashboard & Reporting
**Priority**: P1  
**Estimated Time**: 3 days

**Tasks:**
1. Create green finance API endpoints
   - `/api/green-finance/assess` - Assess green finance compliance for a deal
   - `/api/green-finance/emissions` - Get emissions and air quality data
   - `/api/green-finance/urban-activity` - Get urban activity metrics
   - `/api/green-finance/sdg-alignment` - Calculate SDG alignment score
   - `/api/green-finance/sustainability-score` - Calculate composite sustainability score

2. Create green finance data models
   - Environmental metrics (emissions, air quality, pollution)
   - Urban activity metrics (vehicle counts, traffic density, commercial activity)
   - Sustainability scores (composite, SDG-aligned)
   - Temporal trend data

**Files to Create:**
- `app/api/green_finance_routes.py` (new file)

**Files to Modify:**
- `app/api/routes.py` (include green finance routes)
- `app/db/models.py` (add GreenFinanceAssessment model)

---

## Implementation Priority & Timeline

### Phase 1: Foundation (Weeks 1-2) ✅ COMPLETED
**Critical Path Items:**
1. ✅ Project 1: Enhanced Role-Based Permission System (5 days) - COMPLETED
2. ✅ Project 2.1: Multi-Step Signup Flow Backend (4 days) - COMPLETED
3. ✅ Project 7: User Seeding Script (2 days) - COMPLETED
4. ✅ Project 5: Permission-Based UI Visibility (5 days) - COMPLETED

**Deliverables:**
- ✅ Permission system in database
- ✅ Enhanced signup flow
- ✅ Demo users seeded
- ✅ UI elements hidden based on permissions

### Phase 2: Deal Lifecycle (Weeks 3-4) ✅ COMPLETED
**Critical Path Items:**
1. ✅ Project 3: Deal Lifecycle & File Management (12 days) - COMPLETED
2. ✅ Project 4: Satellite Verification CDM Event Integration (4 days) - COMPLETED

**Deliverables:**
- ✅ Deal model and state machine
- ✅ File organization by user/deal
- ✅ Satellite verification updates deals
- ✅ CDM events stored and linked to deals

### Phase 3: Enhancement (Weeks 5-6) ✅ COMPLETED
**Enhancement Items:**
1. ✅ Project 2.2-2.3: Multimodal Profile Extraction & Frontend (8 days) - COMPLETED
2. ✅ Project 6: Deal-Type Driven Chatbot (7 days) - COMPLETED
3. ✅ Project 8: ChromaDB Integration (4 days) - COMPLETED

**Deliverables:**
- ✅ Rich profile extraction from documents
- ✅ Chatbot with deal context
- ✅ Full ChromaDB indexing

### Phase 4: Credit Risk & Policy Management (Weeks 7-10) 🚧 IN PROGRESS
**Critical Path Items:**
1. ⏳ Project 9: Credit Risk Model Policy Framework (13 days) - IN PROGRESS
2. ⏳ Project 10: Policy Editor and Builder Workflow (17 days) - PENDING

**Deliverables:**
- ⏳ Credit risk calculation service with Basel III support
- ⏳ Credit risk policy rules (8 YAML files)
- ⏳ Policy editor UI with visual rule builder
- ⏳ Policy testing and validation tools
- ⏳ Policy approval workflow
- ⏳ Policy template library

### Phase 5: Green Finance & Enhanced Satellite Verification (Weeks 11-13)
**Critical Path Items:**
1. ✅ Project 11: Green Finance Policy Framework & Enhanced Satellite Verification (14 days)

**Deliverables:**
- Green finance policy rules (7 YAML files)
- Enhanced satellite verification with street map layers
- Urban activity analysis (vehicle counting, traffic density)
- Pollution and emissions monitoring
- SDG alignment scoring
- Green finance dashboard and reporting

---

## File-Level Task Breakdown

### Backend Files to Create (40 new files)
1. `alembic/versions/XXXX_add_permissions_system.py`
2. `alembic/versions/XXXX_add_user_profile_data.py`
3. `alembic/versions/XXXX_add_deals_table.py`
4. `alembic/versions/XXXX_add_policy_editor_tables.py`
5. `app/core/permissions.py`
6. `app/core/permission_config.py`
7. `app/services/profile_extraction_service.py`
8. `app/chains/profile_extraction_chain.py`
9. `app/services/deal_service.py`
10. `app/services/file_storage_service.py`
11. `app/services/deal_event_handler.py`
12. `app/services/template_recommendation_service.py`
13. `app/services/credit_risk_service.py`
14. `app/services/policy_editor_service.py`
15. `app/services/policy_validator.py`
16. `app/services/policy_tester.py`
17. `app/services/policy_approval_service.py`
18. `app/models/credit_risk.py`
19. `app/api/policy_editor_routes.py`
20. `app/api/credit_risk_routes.py`
21. `app/policies/credit_risk/basel_iii_capital.yaml`
22. `app/policies/credit_risk/irb_ratings.yaml`
23. `app/policies/credit_risk/creditworthiness.yaml`
24. `app/policies/credit_risk/collateral_requirements.yaml`
25. `app/policies/credit_risk/risk_rating.yaml`
26. `app/policies/credit_risk/stress_testing.yaml`
27. `app/policies/credit_risk/data_quality.yaml`
28. `app/policies/credit_risk/model_validation.yaml`
29. `app/policies/green_finance/urban_sustainability.yaml`
30. `app/policies/green_finance/emissions_monitoring.yaml`
31. `app/policies/green_finance/vehicle_activity.yaml`
32. `app/policies/green_finance/pollution_compliance.yaml`
33. `app/policies/green_finance/sustainable_infrastructure.yaml`
34. `app/policies/green_finance/climate_resilience.yaml`
35. `app/policies/green_finance/sdg_alignment.yaml`
36. `app/services/enhanced_satellite_service.py`
37. `app/services/urban_activity_analyzer.py`
38. `app/services/pollution_monitor_service.py`
39. `app/api/green_finance_routes.py`
40. `scripts/seed_permissions.py`
41. `scripts/seed_demo_users.py`
42. `scripts/seed_policy_templates.py`

### Backend Files to Modify (15 files)
1. `app/db/models.py` - Add Permission, Deal, Policy, PolicyVersion, PolicyApproval, CreditRiskAssessment models, update User
2. `app/auth/jwt_auth.py` - Add signup endpoints
3. `app/auth/dependencies.py` - Add PermissionChecker
4. `app/api/routes.py` - Add deal endpoints, include policy editor and credit risk routes, update document creation
5. `app/models/cdm_events.py` - Add deal events, credit risk events
6. `app/agents/audit_workflow.py` - Ensure CDM events stored
7. `app/chains/document_retrieval_chain.py` - Add user/deal collections
8. `app/chains/decision_support_chain.py` - Add deal context
9. `app/core/config.py` - Add seeding flags, policy editor config
10. `app/core/policy_config.py` - Support credit risk policy categories
11. `app/services/policy_service.py` - Add credit risk and green finance evaluation methods, integrate calculations
12. `app/models/cdm.py` - Add credit risk and green finance fields to CreditAgreement
13. `app/services/deal_service.py` - Integrate credit risk and green finance evaluation
14. `app/agents/verifier.py` - Add enhanced satellite analysis with street map layers
15. `app/models/loan_asset.py` - Add green finance metrics fields
16. `server.py` - Add seeding to lifespan
17. `.env.example` - Add new environment variables

### Frontend Files to Create (25 new files)
1. `client/src/components/SignupFlow.tsx`
2. `client/src/components/SignupFormApplicant.tsx`
3. `client/src/components/SignupFormBanker.tsx`
4. `client/src/components/SignupFormLawOfficer.tsx`
5. `client/src/components/SignupFormAccountant.tsx`
6. `client/src/components/ProfileEnrichment.tsx`
7. `client/src/components/DealDashboard.tsx`
8. `client/src/components/DealDetail.tsx`
9. `client/src/components/DealTimeline.tsx`
10. `client/src/components/PermissionGate.tsx`
11. `client/src/hooks/usePermissions.ts`
12. `client/src/utils/permissions.ts`
13. `client/src/apps/policy-editor/PolicyEditor.tsx`
14. `client/src/apps/policy-editor/RuleBuilder.tsx`
15. `client/src/apps/policy-editor/PolicyTemplateSelector.tsx`
16. `client/src/apps/policy-editor/PolicyVersionHistory.tsx`
17. `client/src/apps/policy-editor/ConditionBuilder.tsx`
18. `client/src/apps/policy-editor/YamlEditor.tsx`
19. `client/src/apps/policy-editor/PolicyTester.tsx`
20. `client/src/apps/policy-editor/PolicyValidator.tsx`
21. `client/src/apps/policy-editor/TestTransactionBuilder.tsx`
22. `client/src/apps/policy-editor/PolicyApprovalQueue.tsx`
23. `client/src/apps/policy-editor/PolicyApprovalModal.tsx`
24. `client/src/apps/policy-editor/PolicyTemplateLibrary.tsx`
25. `client/src/apps/policy-editor/TemplatePreview.tsx`

### Frontend Files to Modify (8 files)
1. `client/src/components/LoginForm.tsx` - Add signup link
2. `client/src/context/AuthContext.tsx` - Add signup methods
3. `client/src/components/DocumentHistory.tsx` - Add permission checks
4. `client/src/components/Dashboard.tsx` - Hide sections by permission
5. `client/src/components/TradeBlotter.tsx` - Hide actions by permission
6. `client/src/components/ReviewInterface.tsx` - Permission checks
7. `client/src/components/MainNavigation.tsx` - Filter menu by permission
8. `client/src/components/DesktopAppLayout.tsx` - Hide apps by permission
9. `client/src/components/ApplicationDashboard.tsx` - Add deal creation

---

## Line-Level Subtasks (Key Implementation Details)

### 1. Permission System Implementation

**File: `app/core/permissions.py`**
```python
# Lines 1-50: Define permission constants
PERMISSION_DOCUMENT_CREATE = "DOCUMENT_CREATE"
PERMISSION_DOCUMENT_EDIT = "DOCUMENT_EDIT"
PERMISSION_DOCUMENT_DELETE = "DOCUMENT_DELETE"
PERMISSION_DOCUMENT_VIEW = "DOCUMENT_VIEW"
# ... 30+ more permissions

# Lines 51-100: Role permission mappings
ROLE_PERMISSIONS = {
    UserRole.AUDITOR: [
        PERMISSION_DOCUMENT_VIEW,
        PERMISSION_DEAL_VIEW,
        PERMISSION_AUDIT_VIEW,
        # ... read-only permissions
    ],
    UserRole.BANKER: [
        PERMISSION_DOCUMENT_CREATE,
        PERMISSION_DOCUMENT_EDIT,
        PERMISSION_DEAL_CREATE,
        PERMISSION_TRADE_EXECUTE,
        # ... write permissions
    ],
    # ... other roles
}

# Lines 101-150: Helper functions
def has_permission(user: User, permission: str) -> bool:
    """Check if user has a specific permission."""
    # Implementation
```

**File: `app/auth/dependencies.py`**
```python
# Lines 97-120: Add PermissionChecker class
class PermissionChecker:
    def __init__(self, required_permissions: List[str]):
        self.required_permissions = required_permissions
    
    async def __call__(self, user: User = Depends(get_current_user)) -> User:
        from app.core.permissions import has_permissions
        if not has_permissions(user, self.required_permissions):
            raise HTTPException(403, "Insufficient permissions")
        return user
```

### 2. Deal Model Implementation

**File: `app/db/models.py`**
```python
# Lines 1010-1080: Add Deal model after Meeting model
class Deal(Base):
    __tablename__ = "deals"
    id = Column(Integer, primary_key=True)
    deal_id = Column(String(255), unique=True, index=True)
    applicant_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    application_id = Column(Integer, ForeignKey("applications.id"), nullable=True)
    status = Column(String(50), default="draft")
    deal_type = Column(String(50))
    deal_data = Column(JSONB)
    folder_path = Column(String(500))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    applicant = relationship("User", foreign_keys=[applicant_id])
    application = relationship("Application", foreign_keys=[application_id])
    documents = relationship("Document", backref="deal")
```

### 3. Signup Flow Implementation

**File: `app/auth/jwt_auth.py`**
```python
# Lines 620-700: Add signup endpoints
@jwt_router.post("/signup/step1", response_model=Dict[str, str])
async def signup_step1(
    request: Request,
    user_data: UserSignupStep1,
    db: Session = Depends(get_db)
):
    """Step 1: Create user account with role."""
    # Implementation

@jwt_router.post("/signup/step2")
async def signup_step2(
    request: Request,
    signup_token: str,
    profile_data: UserSignupStep2,
    files: List[UploadFile] = File(...),
    db: Session = Depends(get_db)
):
    """Step 2: Enrich profile with data and documents."""
    # Implementation
```

### 4. Frontend Permission Hook

**File: `client/src/hooks/usePermissions.ts`**
```typescript
// Lines 1-50: Permission hook implementation
export function usePermissions() {
  const { user } = useAuth();
  
  const hasPermission = (permission: string): boolean => {
    if (!user) return false;
    // Check user role permissions
    const rolePermissions = PERMISSION_MAP[user.role] || [];
    return rolePermissions.includes(permission);
  };
  
  const hasAnyPermission = (permissions: string[]): boolean => {
    return permissions.some(p => hasPermission(p));
  };
  
  return { hasPermission, hasAnyPermission, userRole: user?.role };
}
```

### 5. Credit Risk Service Implementation

**File: `app/services/credit_risk_service.py`**
```python
# Lines 1-100: Credit risk calculation service
class CreditRiskService:
    def calculate_rwa(
        self,
        exposure: Decimal,
        pd: float,
        lgd: float,
        maturity: float,
        asset_class: str
    ) -> Decimal:
        """Calculate risk-weighted assets per Basel III."""
        # IRB approach calculation
        # RWA = EAD × K × 12.5
        # K = LGD × N[(1-R)^-0.5 × G(PD) + (R/(1-R))^0.5 × G(0.999)] - PD × LGD
        # Implementation
        
    def calculate_capital_requirement(
        self,
        rwa: Decimal,
        capital_ratio: float = 0.08
    ) -> Decimal:
        """Calculate minimum capital requirement (8% of RWA)."""
        return rwa * Decimal(str(capital_ratio))
    
    def assess_creditworthiness(
        self,
        credit_agreement: CreditAgreement,
        financial_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Assess creditworthiness using internal rating model."""
        # Calculate credit score
        # Map to internal rating (AAA to D, or 1-10)
        # Return rating, score, and rationale
```

**File: `app/policies/credit_risk/basel_iii_capital.yaml`**
```yaml
# Lines 1-50: Basel III capital adequacy rules
- name: block_insufficient_capital_coverage
  when:
    all:
      - field: transaction_type
        op: eq
        value: "facility_creation"
      - field: calculated_capital_requirement
        op: gt
        value: available_tier1_capital
  action: block
  priority: 100
  description: "Block facilities that would breach minimum capital adequacy"
  category: "basel_iii"

- name: flag_high_rwa_concentration
  when:
    all:
      - field: transaction_type
        op: eq
        value: "facility_creation"
      - field: sector_concentration
        op: gt
        value: 0.25  # 25% of portfolio
  action: flag
  priority: 60
  description: "Flag high sector concentration risk"
  category: "basel_iii"
```

### 6. Policy Editor Service Implementation

**File: `app/services/policy_editor_service.py`**
```python
# Lines 1-150: Policy editor service
class PolicyEditorService:
    def create_policy(
        self,
        name: str,
        category: str,
        rules_yaml: str,
        created_by: int,
        db: Session
    ) -> Policy:
        """Create new policy with validation."""
        # Validate YAML
        validator = PolicyValidator()
        validation_result = validator.validate(rules_yaml)
        if not validation_result.valid:
            raise ValueError(f"Invalid policy YAML: {validation_result.errors}")
        
        # Create policy record
        policy = Policy(
            name=name,
            category=category,
            rules_yaml=rules_yaml,
            status="draft",
            version=1,
            created_by=created_by
        )
        db.add(policy)
        db.commit()
        return policy
    
    def test_policy(
        self,
        policy_id: int,
        test_transactions: List[Dict[str, Any]],
        db: Session
    ) -> Dict[str, Any]:
        """Test policy against sample transactions."""
        policy = db.query(Policy).filter(Policy.id == policy_id).first()
        if not policy:
            raise ValueError(f"Policy {policy_id} not found")
        
        tester = PolicyTester()
        results = tester.test_policy(policy.rules_yaml, test_transactions)
        return results
```

### 7. Policy Editor UI Component

**File: `client/src/apps/policy-editor/PolicyEditor.tsx`**
```typescript
// Lines 1-200: Policy editor main component
export function PolicyEditor({ policyId }: { policyId?: number }) {
  const [policy, setPolicy] = useState<Policy | null>(null);
  const [rules, setRules] = useState<Rule[]>([]);
  const [yamlPreview, setYamlPreview] = useState<string>("");
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  
  // Real-time YAML generation
  useEffect(() => {
    const yaml = generateYamlFromRules(rules);
    setYamlPreview(yaml);
    
    // Validate
    validatePolicy(yaml).then(result => {
      setValidationErrors(result.errors);
    });
  }, [rules]);
  
  const handleAddRule = () => {
    setRules([...rules, createEmptyRule()]);
  };
  
  const handleSave = async () => {
    const result = await savePolicy({
      name: policy?.name || "New Policy",
      category: policy?.category || "regulatory",
      rules_yaml: yamlPreview
    });
    // Handle save result
  };
  
  return (
    <div className="flex h-screen">
      <div className="w-1/2 border-r">
        <RuleBuilder rules={rules} onRulesChange={setRules} />
      </div>
      <div className="w-1/2">
        <YamlEditor yaml={yamlPreview} errors={validationErrors} />
      </div>
    </div>
  );
}
```

### 8. Rule Builder Component

**File: `client/src/apps/policy-editor/RuleBuilder.tsx`**
```typescript
// Lines 1-150: Visual rule builder
export function RuleBuilder({ rules, onRulesChange }: RuleBuilderProps) {
  const handleConditionChange = (ruleIndex: number, condition: Condition) => {
    const updatedRules = [...rules];
    updatedRules[ruleIndex].when = condition;
    onRulesChange(updatedRules);
  };
  
  return (
    <div className="space-y-4">
      {rules.map((rule, index) => (
        <div key={index} className="border p-4 rounded">
          <input
            value={rule.name}
            onChange={(e) => updateRuleField(index, "name", e.target.value)}
            placeholder="Rule name"
          />
          <ConditionBuilder
            condition={rule.when}
            onChange={(condition) => handleConditionChange(index, condition)}
          />
          <select
            value={rule.action}
            onChange={(e) => updateRuleField(index, "action", e.target.value)}
          >
            <option value="allow">Allow</option>
            <option value="block">Block</option>
            <option value="flag">Flag</option>
          </select>
        </div>
      ))}
      <Button onClick={handleAddRule}>Add Rule</Button>
    </div>
  );
}
```

---

## Testing Requirements

### Unit Tests
- Permission checking functions
- Deal state transitions
- Profile extraction
- File storage operations

### Integration Tests
- Signup flow end-to-end
- Deal creation from application
- Document attachment to deals
- Permission-based API access
- Satellite verification CDM events
- Credit risk calculation and policy evaluation
- Policy editor create/update/delete workflows
- Policy testing against sample transactions
- Policy approval workflow

### E2E Tests
- Complete user signup with profile enrichment
- Deal lifecycle from application to closure
- Permission-based UI visibility
- Chatbot with deal context
- Policy creation and activation workflow
- Credit risk assessment for new deals
- Policy testing and validation
- Policy approval and activation

---

## Configuration & Environment Variables

Add to `.env.example`:
```env
# User Seeding
SEED_DEMO_USERS=false
SEED_AUDITOR=false
SEED_BANKER=false
SEED_LAW_OFFICER=false
SEED_ACCOUNTANT=false
SEED_APPLICANT=false

# Deal Configuration
DEAL_STORAGE_PATH=./storage/deals
DEAL_AUTO_CREATE_FOLDERS=true

# Permission System
PERMISSIONS_ENABLED=true
PERMISSIONS_CACHE_TTL=3600

# Policy Editor
POLICY_EDITOR_ENABLED=true
POLICY_EDITOR_AUTO_SAVE=true
POLICY_EDITOR_AUTO_SAVE_INTERVAL=30  # seconds

# Credit Risk Model
CREDIT_RISK_ENABLED=true
CREDIT_RISK_CAPITAL_RATIO=0.08  # 8% minimum capital ratio
CREDIT_RISK_IRB_ENABLED=true
CREDIT_RISK_STRESS_TEST_ENABLED=true

# Green Finance & Enhanced Satellite Verification
GREEN_FINANCE_ENABLED=true
ENHANCED_SATELLITE_ENABLED=true
STREET_MAP_API_PROVIDER=openstreetmap  # openstreetmap, google, mapbox
VEHICLE_DETECTION_ENABLED=true
POLLUTION_MONITORING_ENABLED=true
AIR_QUALITY_API_KEY=  # Optional: API key for air quality data
METHANE_MONITORING_ENABLED=true
```

---

## Risk Mitigation

1. **Backward Compatibility**: Maintain existing role enum values, add new ones
2. **Performance**: Cache permissions, use database indexes
3. **Security**: Validate all permission checks on backend, never trust frontend
4. **Data Migration**: Create migration scripts for existing users
5. **File Storage**: Use relative paths, support cloud storage in future

---

## Success Criteria

1. ✅ Five distinct user roles with appropriate permissions
2. ✅ Multi-step signup flow with profile enrichment
3. ✅ Deal lifecycle tracking with file organization
4. ✅ Permission-based UI visibility
5. ✅ Satellite verification creates CDM events and updates deals
6. ✅ Chatbot provides deal-type specific guidance
7. ✅ All user/deal data indexed in ChromaDB
8. ✅ Configurable user seeding for demos
9. ✅ Credit risk model policies integrated (Basel III, IRB, creditworthiness)
10. ✅ Credit risk calculations (RWA, capital requirements, PD/LGD/EAD)
11. ✅ Policy editor with visual rule builder
12. ✅ Policy testing and validation tools
13. ✅ Policy approval workflow with version control
14. ✅ Policy template library with 8+ templates
15. ✅ Green finance policy rules integrated (7 YAML files)
16. ✅ Enhanced satellite verification with street map layers
17. ✅ Urban activity analysis (vehicle counting, traffic density)
18. ✅ Pollution and emissions monitoring
19. ✅ SDG alignment scoring

---

## Notes

- This plan assumes PostgreSQL database (SQLite fallback for dev)
- ChromaDB must be installed and configured
- LLM provider must be configured for profile extraction
- File storage uses local filesystem (can be extended to S3/cloud)
- All CDM events must follow FINOS CDM standards
- Permission system must be extensible for future roles
- Policy engine supports YAML-based rule definitions with `when`/`action`/`priority` structure
- Credit risk calculations follow Basel III IRB approach (can be extended to Standardized Approach)
- Policy editor requires real-time YAML validation and syntax highlighting
- Policy approval workflow integrates with existing permission system
- Credit risk policies are evaluated alongside regulatory policies in unified policy engine

### Policy Engine Architecture Notes

- **Rule Structure**: Policies use YAML format with `name`, `when` (condition tree), `action` (allow/block/flag), `priority`, `description`, and optional `category`
- **Condition Evaluation**: Supports nested `any`/`all` conditions with field operators (eq, gt, lt, in, contains, ne, etc.)
- **Transaction Context**: Policy engine receives transaction dictionaries with all relevant fields (parties, amounts, risk metrics, etc.)
- **Decision Priority**: BLOCK > FLAG > ALLOW (highest priority action wins)
- **CDM Integration**: All policy decisions generate CDM PolicyEvaluation events for audit trail

### Credit Risk Model Notes

- **Basel III Compliance**: Minimum capital ratio of 8% (configurable)
- **IRB Approach**: Supports Internal Ratings-Based approach with PD/LGD/EAD calculations
- **Risk-Weighted Assets**: Calculated using Basel III formulas
- **Credit Ratings**: Supports both external ratings (S&P, Moody's, Fitch) and internal rating scales (AAA-D or 1-10)
- **Stress Testing**: Supports scenario-based stress testing for portfolio risk assessment
- **Data Quality**: Policies enforce data quality requirements for credit risk calculations

### Policy Editor Notes

- **Visual Builder**: Drag-and-drop rule builder with real-time YAML preview
- **YAML Editor**: Full YAML editing with syntax highlighting and validation
- **Version Control**: Automatic versioning on policy updates with diff viewing
- **Testing**: Built-in policy tester with sample transaction builder
- **Templates**: Template library for common policy patterns (regulatory, credit_risk, esg, etc.)
- **Approval Workflow**: Draft → Pending Approval → Active status flow with role-based approvals
- **Audit Trail**: Complete history of policy changes, approvals, and activations

---

**Document Version**: 2.0  
**Last Updated**: 2024-12-XX  
**Author**: CreditNexus Architecture Team
