# Green Finance & OpenStreetMap Implementation Plan (No Street View)

## Executive Summary

This document provides a comprehensive implementation plan for Phase 5 enhancements to CreditNexus's satellite verification system, focusing on **OpenStreetMap integration** and **green finance policy framework** without Street View dependencies.

**Priority**: High (P0 - Critical Path)  
**Estimated Timeline**: Phase 5 (Weeks 11-13) - 14 days  
**Complexity**: High  
**Project**: Project 11 - Green Finance Policy Framework & Enhanced Satellite Verification

**Key Focus Areas:**
- ✅ OpenStreetMap integration for urban/rural classification and infrastructure mapping
- ✅ Green finance policy rules (7 YAML files)
- ✅ Air quality integration (OpenAQ API)
- ✅ Composite sustainability scoring
- ✅ Vehicle detection from satellite (selective, high-value cases)
- ✅ Pollution monitoring (methane detection via Sentinel-5P)
- ❌ **NO Street View integration** (deferred to future phase)

---

## Current State Analysis

### Existing Capabilities

CreditNexus currently uses:
- **NDVI (Normalized Difference Vegetation Index)** for vegetation health assessment
- **Sentinel-2 satellite imagery** via Sentinel Hub API
- **Land use classification** using TorchGeo ResNet-50
- **SPT (Sustainability Performance Target)** threshold-based compliance
- **Policy engine** with YAML-based rule definitions
- **CDM event generation** for policy evaluations

### Limitations Addressed by This Plan

1. **Rural Bias**: NDVI is primarily effective for agricultural/rural areas
2. **Urban Blind Spots**: Limited indicators for urban sustainability assessment
3. **Single Metric**: Relies primarily on vegetation index, missing multi-dimensional environmental factors
4. **No Activity Context**: Cannot assess business activity, traffic patterns, or commercial viability
5. **No Pollution Data**: Lacks air quality, emissions, or pollution monitoring
6. **No Temporal Activity**: Cannot detect temporal patterns (day/night, seasonal variations)

---

## Implementation Plan

### Phase 5: Green Finance & Enhanced Satellite Verification (Weeks 11-13)
**Timeline**: 14 days  
**Priority**: P0 (Critical Path)

**Overview**:  
Extend the policy engine to support comprehensive green finance policies using enhanced satellite imagery analysis including OpenStreetMap data, urban activity indicators, vehicle emissions, pollution monitoring, and multi-dimensional environmental metrics beyond NDVI.

**Critical Path Items**:
1. ✅ Project 11: Green Finance Policy Framework & Enhanced Satellite Verification (14 days)

**Deliverables**:
- Green finance policy rules (7 YAML files)
- OpenStreetMap integration for urban/rural classification
- Air quality integration (OpenAQ API)
- Composite sustainability score calculation
- Vehicle detection from satellite (selective implementation)
- Pollution and emissions monitoring (methane detection)
- Green finance dashboard and reporting

---

## Project 11: Green Finance Policy Framework & Enhanced Satellite Verification

### Activity 11.1: Green Finance Policy Rule Definitions
**Priority**: P0  
**Estimated Time**: 3 days

**Tasks**:
1. Create green finance policy YAML templates in `app/policies/green_finance/`
   - `urban_sustainability.yaml` - Urban development sustainability rules
   - `emissions_monitoring.yaml` - CO2 and air quality monitoring policies
   - `vehicle_activity.yaml` - Traffic and vehicle emission policies
   - `pollution_compliance.yaml` - Pollution threshold and compliance rules
   - `sustainable_infrastructure.yaml` - Green infrastructure verification
   - `climate_resilience.yaml` - Climate risk and resilience policies
   - `sdg_alignment.yaml` - Sustainable Development Goals alignment

2. Define green finance policy rule structure
   ```yaml
   - name: block_high_emission_urban_development
     when:
       all:
         - field: transaction_type
           op: eq
           value: "facility_creation"
         - field: location_type
           op: eq
           value: "urban"
         - field: estimated_vehicle_emissions
           op: gt
           value: 100  # tons CO2/year per km²
         - field: air_quality_index
           op: gt
           value: 150  # Unhealthy AQI threshold
     action: block
     priority: 90
     description: "Block facilities in high-emission urban areas exceeding air quality thresholds"
     category: "green_finance"
   ```

3. Create green finance field mappings
   - Map satellite-derived indicators to policy fields
   - Support multi-dimensional environmental metrics
   - Support temporal trend analysis

**Files to Create**:
- `app/policies/green_finance/__init__.py` (new file)
- `app/policies/green_finance/urban_sustainability.yaml` (new file)
- `app/policies/green_finance/emissions_monitoring.yaml` (new file)
- `app/policies/green_finance/vehicle_activity.yaml` (new file)
- `app/policies/green_finance/pollution_compliance.yaml` (new file)
- `app/policies/green_finance/sustainable_infrastructure.yaml` (new file)
- `app/policies/green_finance/climate_resilience.yaml` (new file)
- `app/policies/green_finance/sdg_alignment.yaml` (new file)

**Files to Modify**:
- `app/core/policy_config.py` (ensure green_finance category is supported - already supports categories)
- No changes needed - policy engine already supports category field

---

### Activity 11.2: OpenStreetMap Integration & Enhanced Satellite Services
**Priority**: P0  
**Estimated Time**: 5 days

**Current Implementation Context**:
- Existing verification in `app/agents/verifier.py` (lines 309-357)
- Current `verify_asset_location()` function (lines 309-357) returns basic NDVI and risk status
- API endpoint at `app/api/routes.py` line 4489 calls `verify_asset_location()`
- `LoanAsset` model in `app/models/loan_asset.py` stores verification results (lines 86-123)

**Tasks**:
1. Create OpenStreetMap service for data retrieval
   - Integrate Overpass API for querying OSM data
   - Extract road networks, building footprints, land use polygons
   - Identify commercial zones, industrial areas, residential districts
   - Map infrastructure (parks, green spaces, transportation hubs)

2. Create location classifier service
   - Classify location as urban, suburban, or rural using OSM data
   - Apply different thresholds for each type
   - Urban: Lower NDVI acceptable, focus on air quality and activity
   - Rural: Higher NDVI required, focus on vegetation and land use

3. Create air quality service
   - Integrate OpenAQ API for air quality data
   - Map AQI (Air Quality Index) to locations
   - Support temporal pollution trends
   - Cache results for performance

4. Create sustainability scorer service
   - Calculate composite sustainability score
   - Combine NDVI with urban activity metrics
   - Support location-specific thresholds

5. Extend verifier agent with enhanced satellite analysis
   - Integrate OSM data into verification workflow
   - Add air quality metrics to verification results
   - Add location classification to verification results
   - Add sustainability score to verification results

**Sub-tasks for Task 1 (OSM Integration)**:
   - **1.1**: Create `app/services/osm_service.py`
     - Overpass API client using `overpy` library
     - Query road networks within bounding box using Overpass QL
     - Query building footprints (way[building])
     - Query land use polygons (way[landuse], relation[landuse])
     - Query POIs (Points of Interest) using node[amenity], node[shop], etc.
     - Query green infrastructure (way[leisure=park], way[landuse=forest], etc.)
     - Example Overpass QL query structure:
       ```python
       query = f"""
       [out:json][timeout:25];
       (
         way["building"]({south},{west},{north},{east});
         way["highway"]({south},{west},{north},{east});
         way["landuse"]({south},{west},{north},{east});
         node["amenity"]({south},{west},{north},{east});
       );
       out body;
       >;
       out skel qt;
       """
       ```
     - Cache results using `OSM_CACHE_TTL_HOURS` setting
     - Handle rate limiting and API errors gracefully
   
   - **1.2**: Create `app/services/street_network_analyzer.py`
     - Use `osmnx` library for network analysis
     - Analyze road network density (km of roads per km²)
     - Calculate road length per area using `osmnx.graph_from_bbox()`
     - Identify road types (highway, residential, etc.) from OSM tags
     - Calculate connectivity metrics (node degree, betweenness centrality)
     - Example implementation:
       ```python
       import osmnx as ox
       
       def analyze_road_network(lat, lon, distance=1000):
           # Get graph within distance (meters)
           G = ox.graph_from_point(
               (lat, lon), 
               dist=distance,
               network_type='all'
           )
           # Calculate metrics
           road_length = sum([G[u][v][0].get('length', 0) 
                            for u, v in G.edges()]) / 1000  # km
           area_km2 = ox.utils_geo.bbox_from_point((lat, lon), dist=distance)
           density = road_length / area_km2
           return {"road_length_km": road_length, "density": density}
       ```

**Sub-tasks for Task 2 (Location Classification)**:
   - **2.1**: Create `app/services/location_classifier.py`
     - Use OSM building density to classify urban/rural
     - Use OSM road network density from `street_network_analyzer`
     - Use OSM land use data (residential, commercial, industrial tags)
     - Classification algorithm:
       ```python
       def classify_location(building_count, road_density, land_use_tags):
           # Urban: high building density + high road density
           # Suburban: medium building density + medium road density
           # Rural: low building density + low road density
           urban_score = 0
           if building_count > 100: urban_score += 1
           if road_density > 5.0: urban_score += 1  # km/km²
           if 'residential' in land_use_tags: urban_score += 0.5
           if 'commercial' in land_use_tags: urban_score += 1
           
           if urban_score >= 2.5:
               return "urban", 0.9
           elif urban_score >= 1.0:
               return "suburban", 0.7
           else:
               return "rural", 0.8
       ```
     - Return classification: "urban", "suburban", "rural"
     - Return confidence score (0.0-1.0)

**Sub-tasks for Task 3 (Air Quality)**:
   - **3.1**: Create `app/services/air_quality_service.py`
     - OpenAQ API integration using `requests` library
     - Fetch AQI data for location using OpenAQ v2 API
     - API endpoint: `https://api.openaq.org/v2/locations`
     - Support radius-based queries (default: 5km radius)
     - Cache results using `AIR_QUALITY_CACHE_TTL_HOURS` (default: 24 hours)
     - Handle API rate limits gracefully (10,000 requests/month free tier)
     - Fallback to synthetic data if API unavailable (similar to `verifier.py` line 246-282)
     - Example implementation:
       ```python
       import requests
       from datetime import datetime, timedelta
       
       def get_air_quality(lat, lon, radius=5000):
           # Check cache first
           cache_key = f"aqi_{lat:.4f}_{lon:.4f}"
           cached = cache.get(cache_key)
           if cached:
               return cached
           
           # Query OpenAQ API
           url = "https://api.openaq.org/v2/locations"
           params = {
               "coordinates": f"{lat},{lon}",
               "radius": radius,
               "limit": 1
           }
           response = requests.get(url, params=params, timeout=10)
           
           if response.status_code == 200:
               data = response.json()
               # Extract AQI from latest measurement
               aqi = calculate_aqi_from_measurements(data)
               cache.set(cache_key, aqi, ttl=86400)  # 24 hours
               return aqi
           else:
               # Fallback to synthetic data
               return generate_synthetic_aqi(lat, lon)
       ```

**Sub-tasks for Task 4 (Sustainability Scoring)**:
   - **4.1**: Create `sustainability_scorer.py`
     - Normalize NDVI to 0-1 scale
     - Normalize AQI to 0-1 scale (inverted - lower AQI = better)
     - Calculate green infrastructure score from OSM data
     - Calculate composite score with weights:
       - Vegetation Health (NDVI): 25% weight
       - Air Quality (AQI): 25% weight
       - Urban Activity (OSM-based indicators): 20% weight
       - Green Infrastructure (parks, green spaces): 15% weight
       - Pollution Levels (emissions, methane): 15% weight
     - Return score breakdown by component

**Sub-tasks for Task 5 (Verifier Integration)**:
   - **5.1**: Extend `app/agents/verifier.py` (current implementation: lines 309-357)
     - Add `get_osm_data()` method (calls `osm_service.get_osm_features()`)
     - Add `classify_location()` method (calls `location_classifier.classify()`)
     - Add `get_air_quality()` method (calls `air_quality_service.get_air_quality()`)
     - Add `calculate_sustainability_score()` method (calls `sustainability_scorer.calculate()`)
     - Update `verify_asset_location()` function (line 309) to include enhanced metrics:
       ```python
       async def verify_asset_location(
           lat: float,
           lon: float,
           threshold: float = 0.8,
           include_enhanced: bool = True  # New parameter
       ) -> dict:
           # Existing NDVI calculation (lines 327-342)
           bands = await fetch_sentinel_data(lat, lon)
           ndvi_score = calculate_ndvi(nir_band, red_band)
           risk_status = determine_risk_status(ndvi_score, threshold)
           
           result = {
               "success": True,
               "ndvi_score": ndvi_score,
               "risk_status": risk_status,
               "threshold": threshold,
               "verified_at": datetime.utcnow().isoformat(),
               "data_source": "sentinel_hub" if get_sentinel_config() else "synthetic"
           }
           
           # NEW: Enhanced metrics if enabled
           if include_enhanced:
               from app.services.osm_service import OSMService
               from app.services.location_classifier import LocationClassifier
               from app.services.air_quality_service import AirQualityService
               from app.services.sustainability_scorer import SustainabilityScorer
               
               osm_service = OSMService()
               location_classifier = LocationClassifier()
               air_quality_service = AirQualityService()
               sustainability_scorer = SustainabilityScorer()
               
               # Get OSM data
               osm_data = await osm_service.get_osm_features(lat, lon)
               
               # Classify location
               location_type, confidence = await location_classifier.classify(
                   lat, lon, osm_data
               )
               
               # Get air quality
               air_quality = await air_quality_service.get_air_quality(lat, lon)
               
               # Calculate sustainability score
               sustainability = await sustainability_scorer.calculate(
                   ndvi_score=ndvi_score,
                   air_quality=air_quality,
                   location_type=location_type,
                   osm_data=osm_data
               )
               
               # Add to result
               result.update({
                   "location_type": location_type,
                   "location_confidence": confidence,
                   "air_quality_index": air_quality.get("aqi"),
                   "composite_sustainability_score": sustainability.get("composite_score"),
                   "sustainability_components": sustainability.get("components"),
                   "osm_metrics": {
                       "building_count": osm_data.get("building_count"),
                       "road_density": osm_data.get("road_density"),
                       "green_infrastructure_coverage": osm_data.get("green_coverage")
                   }
               })
           
           return result
       ```
     - Return enhanced verification results with all metrics
     - Maintain backward compatibility (existing API calls still work)

**Files to Create**:
- `app/services/osm_service.py` - OpenStreetMap data retrieval
- `app/services/street_network_analyzer.py` - Road network analysis
- `app/services/location_classifier.py` - Location type classification (urban/rural/suburban)
- `app/services/air_quality_service.py` - Air quality data integration
- `app/services/sustainability_scorer.py` - Composite sustainability scoring

**Files to Modify**:
- `app/agents/verifier.py` (lines 309-357: extend `verify_asset_location()` function)
  - Current function signature: `async def verify_asset_location(lat: float, lon: float, threshold: float = 0.8) -> dict`
  - Add optional `include_enhanced: bool = True` parameter
  - Integrate OSM, air quality, and sustainability scoring
- `app/models/loan_asset.py` (add green finance metrics fields - see Activity 11.3)
  - Current model: lines 26-183
  - Add fields after line 123 (after `asset_metadata`)

**Dependencies**:
- `osmnx>=1.6.0` - Python library for OpenStreetMap network analysis
  - Installation: `pip install osmnx`
  - Requires: `geopandas`, `networkx`, `shapely`
- `overpy>=0.6` - Python wrapper for Overpass API
  - Installation: `pip install overpy`
  - Lightweight alternative to direct HTTP requests
- `requests` - HTTP client for API calls (already in dependencies)
- `geopandas>=0.14.0` - Geospatial data manipulation (optional, for advanced OSM analysis)
  - Required by `osmnx` for network analysis

---

### Activity 11.3: Vehicle Detection & Pollution Monitoring (Selective Implementation)
**Priority**: P1  
**Estimated Time**: 3 days

**Tasks**:
1. Create vehicle detection service (selective implementation)
   - Use high-resolution satellite imagery (0.5m-1m resolution) for flagged cases only
   - Apply computer vision models (YOLO v8) for vehicle detection
   - Count vehicles per road segment (using OSM road data)
   - Calculate vehicle density (vehicles/km²)
   - **Note**: Only implement for high-value/flagged transactions due to cost

2. Create emission calculator service
   - Combine vehicle counts with emission factors
   - Calculate per-road-segment emissions
   - Aggregate to area-level emissions
   - Correlate with air quality measurements

3. Create methane detection service
   - Use TROPOMI satellite data (Sentinel-5P) for methane detection
   - Identify methane hotspots
   - Correlate with known facilities (landfills, oil/gas operations)
   - **Note**: Coarse resolution (7km x 7km), suitable for regional monitoring

4. Create pollution monitor service
   - Aggregate air quality, vehicle emissions, and methane data
   - Calculate composite pollution metrics
   - Support temporal trend analysis

**Sub-tasks for Task 1 (Vehicle Detection)**:
   - **1.1**: Create `vehicle_detection_service.py`
     - Load YOLO v8 model (pre-trained)
     - Process high-resolution satellite imagery
     - Filter detections by OSM road segments
     - Count vehicles per road segment
     - Calculate vehicle density
     - **Implementation Note**: Only call for flagged transactions or high-risk cases
   
   - **1.2**: Create `app/ml_models/vehicle_detector.py`
     - YOLO v8 model wrapper
     - Image preprocessing
     - Post-processing (NMS, confidence filtering)
     - Return detection results

   - **1.3**: Create `app/models/vehicle_detection.py`
     - Pydantic models for vehicle detection results
     - Vehicle count, density, flow metrics

**Sub-tasks for Task 2 (Emission Calculation)**:
   - **2.1**: Create `emission_calculator.py`
     - EPA MOVES model emission factors
     - European EEA emission factors
     - Vehicle type classification (passenger, truck, bus)
     - Calculate CO2 emissions per road segment
     - Aggregate to area-level emissions

**Sub-tasks for Task 3 (Methane Detection)**:
   - **3.1**: Create `methane_detection_service.py`
     - Sentinel-5P TROPOMI data processing
     - Methane hotspot identification
     - Facility correlation (using OSM POI data)
     - Return methane concentration metrics

**Sub-tasks for Task 4 (Pollution Monitoring)**:
   - **4.1**: Create `pollution_monitor_service.py`
     - Aggregate air quality (OpenAQ)
     - Aggregate vehicle emissions (emission_calculator)
     - Aggregate methane data (methane_detection_service)
     - Calculate composite pollution score
     - Support temporal trends

**Files to Create**:
- `app/services/vehicle_detection_service.py` - Vehicle detection from satellite (selective)
- `app/services/emission_calculator.py` - Emission estimation
- `app/services/methane_detection_service.py` - Methane emission detection
- `app/services/pollution_monitor_service.py` - Pollution monitoring aggregation
- `app/ml_models/vehicle_detector.py` - Vehicle detection model wrapper
- `app/models/vehicle_detection.py` - Vehicle detection data models

**Files to Modify**:
- `app/agents/verifier.py` (add vehicle detection method - selective use only)
- `app/models/loan_asset.py` (add vehicle detection and emission fields)

**Dependencies**:
- `ultralytics` - YOLO v8 library
- `torch` - PyTorch (for YOLO model)
- `numpy` - Numerical operations (already in dependencies)
- `rasterio` - Geospatial raster I/O (for Sentinel-5P data)

**Cost Considerations**:
- Vehicle detection requires high-resolution imagery ($0.50-$2.00 per km²)
- **Recommendation**: Only use for flagged transactions (<10% of all transactions)
- Implement feature flag: `VEHICLE_DETECTION_ENABLED=true/false`
- Implement cost threshold: Only process if transaction amount > threshold

---

### Activity 11.4: Green Finance Policy Evaluation Integration
**Priority**: P0  
**Estimated Time**: 3 days

**Tasks**:
1. Extend `PolicyService` with green finance evaluation methods
   - `evaluate_green_finance_compliance()` - Full green finance assessment
   - `assess_urban_sustainability()` - Urban development sustainability scoring
   - `monitor_emissions_compliance()` - Emissions and air quality compliance
   - `evaluate_sdg_alignment()` - SDG alignment scoring

2. Enhance policy transaction context with green finance metrics
   - Add OSM-derived metrics (location_type, road_density, building_density)
   - Add air quality metrics (aqi, pm25, pm10, no2)
   - Add vehicle emissions (if available)
   - Add sustainability scores (composite, component breakdown)
   - Add green infrastructure metrics

3. Create CDM events for green finance evaluations
   - `GreenFinanceAssessment` event type
   - Store environmental metrics, sustainability scores, SDG alignment
   - Link to policy evaluation events

4. Integrate with deal lifecycle
   - Auto-evaluate green finance on deal creation
   - Re-evaluate on deal updates
   - Store green finance metrics in deal metadata

**Sub-tasks for Task 1**:
   - **1.1**: Implement `evaluate_green_finance_compliance()`
     - Load all green finance policy rules
     - Get enhanced satellite metrics (OSM, air quality, sustainability score)
     - Evaluate against green finance policy rules
     - Return comprehensive compliance assessment
     - Generate policy evaluation CDM events
   
   - **1.2**: Implement `assess_urban_sustainability()`
     - Get location classification (urban/rural/suburban)
     - Get OSM data (road density, building density, green infrastructure)
     - Get air quality data
     - Calculate urban sustainability score
     - Evaluate against urban sustainability policy rules
     - Return sustainability metrics and compliance status
   
   - **1.3**: Implement `monitor_emissions_compliance()`
     - Get air quality data (OpenAQ)
     - Get vehicle emissions (if available, selective)
     - Get methane data (Sentinel-5P, regional)
     - Evaluate against emissions monitoring policy rules
     - Return compliance status and violation details
   
   - **1.4**: Implement `evaluate_sdg_alignment()`
     - Map environmental metrics to SDG targets
     - Calculate SDG alignment scores per goal
     - Return comprehensive SDG alignment report

**Sub-tasks for Task 2**:
   - **2.1**: Extend `_cdm_to_policy_transaction()` method in `app/services/policy_service.py` (lines 198-253)
     - Current method converts CDM CreditAgreement to policy transaction format
     - Add OSM metrics: `location_type`, `road_density`, `building_density`, `green_infrastructure_coverage`
     - Add air quality metrics: `air_quality_index`, `pm25`, `pm10`, `no2`
     - Add vehicle metrics: `vehicle_density`, `estimated_vehicle_emissions` (if available)
     - Add sustainability metrics: `composite_sustainability_score`, `sustainability_components`
     - Add green infrastructure metrics: `parks_coverage`, `green_roofs_detected`
     - Example extension:
       ```python
       # In _cdm_to_policy_transaction(), after line 252, add:
       if credit_agreement.loan_assets:
           # Get enhanced metrics from first loan asset
           loan_asset = credit_agreement.loan_assets[0]
           if loan_asset.geo_lat and loan_asset.geo_lon:
               # Fetch enhanced metrics (if available)
               enhanced_metrics = get_enhanced_metrics(
                   loan_asset.geo_lat, 
                   loan_asset.geo_lon
               )
               tx.update({
                   "location_type": enhanced_metrics.get("location_type"),
                   "air_quality_index": enhanced_metrics.get("air_quality_index"),
                   "composite_sustainability_score": enhanced_metrics.get("composite_sustainability_score")
               })
       ```
   
   - **2.2**: Extend `_loan_asset_to_policy_transaction()` method in `app/services/policy_service.py` (lines 316-335)
     - Current method converts LoanAsset to policy transaction format
     - Add enhanced satellite metrics from loan asset verification
     - Include OSM classification, air quality, sustainability score
     - Example extension:
       ```python
       # In _loan_asset_to_policy_transaction(), after line 334, add:
       # Get enhanced metrics from asset metadata or verification result
       if loan_asset.asset_metadata:
           green_metrics = loan_asset.asset_metadata.get("green_finance_metrics", {})
           tx.update({
               "location_type": green_metrics.get("location_type"),
               "air_quality_index": green_metrics.get("air_quality_index"),
               "composite_sustainability_score": green_metrics.get("composite_sustainability_score"),
               "road_density": green_metrics.get("road_density"),
               "building_density": green_metrics.get("building_density")
           })
       ```

**Sub-tasks for Task 3**:
   - **3.1**: Create `generate_green_finance_assessment()` in `app/models/cdm_events.py` (after line 368)
     - Follow existing CDM event pattern (see `generate_cdm_policy_evaluation()` lines 299-368)
     - Define event structure with all environmental metrics
     - Include sustainability scores and SDG alignment
     - Link to related policy evaluation events
     - Follow CDM event model structure:
       ```python
       def generate_green_finance_assessment(
           transaction_id: str,
           location_lat: float,
           location_lon: float,
           location_type: str,
           air_quality_index: float,
           composite_sustainability_score: float,
           sustainability_components: Dict[str, float],
           sdg_alignment: Dict[str, float],
           related_event_identifiers: List[Dict[str, Any]] = None
       ) -> Dict[str, Any]:
           """Generate CDM-compliant GreenFinanceAssessment event."""
           if related_event_identifiers is None:
               related_event_identifiers = []
           
           return {
               "eventType": "GreenFinanceAssessment",
               "eventDate": datetime.datetime.now().isoformat(),
               "greenFinanceAssessment": {
                   "transactionIdentifier": {
                       "issuer": "CreditNexus_GreenFinanceService",
                       "assignedIdentifier": [{"identifier": {"value": transaction_id}}]
                   },
                   "assessmentDate": {"date": datetime.date.today().isoformat()},
                   "location": {
                       "latitude": location_lat,
                       "longitude": location_lon,
                       "locationType": location_type
                   },
                   "environmentalMetrics": {
                       "airQualityIndex": air_quality_index,
                       "compositeSustainabilityScore": composite_sustainability_score,
                       "sustainabilityComponents": sustainability_components
                   },
                   "sdgAlignment": sdg_alignment
               },
               "relatedEventIdentifier": related_event_identifiers,
               "meta": {
                   "globalKey": str(uuid.uuid4()),
                   "sourceSystem": "CreditNexus_GreenFinanceService_v1",
                   "version": 1
               }
           }
       ```
   
   - **3.2**: Store CDM events in database
     - Create database model for green finance assessments (Activity 11.5)
     - Link to deals and policy decisions
     - Support querying and reporting
     - Store in `PolicyDecision.cdm_events` JSONB field (existing pattern)

**Sub-tasks for Task 4**:
   - **4.1**: Integrate with deal creation workflow
     - Trigger green finance evaluation on deal creation
     - Store results in deal metadata
     - Create CDM events and link to deal
   
   - **4.2**: Integrate with deal update workflow
     - Re-evaluate green finance on significant deal updates
     - Update deal metadata with new metrics
     - Create new CDM events for updated assessments

**Files to Modify**:
- `app/services/policy_service.py` (add green finance methods)
- `app/models/cdm_events.py` (add green finance event generators)
- `app/services/deal_service.py` (integrate green finance evaluation)
- `app/models/loan_asset.py` (add green finance metrics fields)

**Database Changes**:
- Add fields to `LoanAsset` model in `app/models/loan_asset.py` (after line 123):
  - `location_type: Optional[str]` - "urban", "suburban", "rural"
  - `air_quality_index: Optional[float]` - AQI value
  - `composite_sustainability_score: Optional[float]` - 0-1 score
  - `green_finance_metrics: Optional[dict]` - JSONB field for all metrics
  - Example addition:
    ```python
    # After line 123 in app/models/loan_asset.py
    location_type: Optional[str] = Field(
        default=None,
        description="Location classification: urban, suburban, or rural"
    )
    air_quality_index: Optional[float] = Field(
        default=None,
        description="Air Quality Index (AQI) value"
    )
    composite_sustainability_score: Optional[float] = Field(
        default=None,
        description="Composite sustainability score (0.0 to 1.0)"
    )
    green_finance_metrics: Optional[dict] = Field(
        default=None,
        sa_column=Column(JSONB),
        description="Comprehensive green finance metrics (OSM, air quality, etc.)"
    )
    ```
- Create `GreenFinanceAssessment` model (Activity 11.5) in `app/db/models.py`

---

### Activity 11.5: Green Finance Database Models & API Endpoints
**Priority**: P1  
**Estimated Time**: 3 days

**Tasks**:
1. Create green finance database models
   - `GreenFinanceAssessment` model
   - Store assessment results with temporal trends
   - Link to deals and policy decisions

2. Create green finance data models (Pydantic)
   - Environmental metrics (emissions, air quality, pollution)
   - Urban activity metrics (vehicle counts, traffic density, OSM-based indicators)
   - Sustainability scores (composite, SDG-aligned)
   - Temporal trend data

3. Create green finance API endpoints
   - `/api/green-finance/assess` - Assess green finance compliance for a deal
   - `/api/green-finance/emissions` - Get emissions and air quality data
   - `/api/green-finance/urban-activity` - Get urban activity metrics
   - `/api/green-finance/sdg-alignment` - Calculate SDG alignment score
   - `/api/green-finance/sustainability-score` - Calculate composite sustainability score

**Sub-tasks for Task 1**:
   - **1.1**: Create `GreenFinanceAssessment` database model in `app/db/models.py`
     - Follow existing model patterns (see `User` model starting at line 148)
     - Model structure:
       ```python
       class GreenFinanceAssessment(Base):
           __tablename__ = "green_finance_assessments"
           
           id: Mapped[int] = mapped_column(primary_key=True)
           deal_id: Mapped[Optional[int]] = mapped_column(ForeignKey("deals.id"))
           loan_asset_id: Mapped[Optional[int]] = mapped_column(ForeignKey("loan_assets.id"))
           assessment_date: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
           location_lat: Mapped[float] = mapped_column(Numeric(10, 7))
           location_lon: Mapped[float] = mapped_column(Numeric(10, 7))
           location_type: Mapped[str] = mapped_column(String(20))  # "urban", "suburban", "rural"
           air_quality_index: Mapped[Optional[float]] = mapped_column(Numeric(6, 2))
           composite_sustainability_score: Mapped[Optional[float]] = mapped_column(Numeric(4, 3))
           environmental_metrics: Mapped[dict] = mapped_column(JSONB)
           urban_activity_metrics: Mapped[dict] = mapped_column(JSONB)
           sustainability_components: Mapped[dict] = mapped_column(JSONB)
           sdg_alignment: Mapped[dict] = mapped_column(JSONB)
           cdm_events: Mapped[dict] = mapped_column(JSONB)
           created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
           
           # Relationships
           deal: Mapped[Optional["Deal"]] = relationship(back_populates="green_finance_assessments")
           loan_asset: Mapped[Optional["LoanAsset"]] = relationship(back_populates="green_finance_assessments")
       ```
     - Add indexes: `Index('idx_gfa_deal_id', 'deal_id')`, `Index('idx_gfa_loan_asset_id', 'loan_asset_id')`
   
   - **1.2**: Create Alembic migration
     - Run: `alembic revision -m "add_green_finance_models"`
     - Add `GreenFinanceAssessment` table
     - Add green finance fields to `LoanAsset` table (location_type, air_quality_index, etc.)
     - Add indexes for performance
     - Migration file location: `alembic/versions/XXXX_add_green_finance_models.py`

**Sub-tasks for Task 2**:
   - **2.1**: Create `app/models/green_finance.py`
     - `EnvironmentalMetrics` - emissions, air quality, pollution
     - `UrbanActivityMetrics` - vehicle counts, traffic, OSM-based indicators
     - `SustainabilityScore` - composite score with component breakdown
     - `SDGAlignment` - per-goal scores and overall alignment
     - `GreenFinanceAssessment` - comprehensive assessment result
     - All models use Pydantic 2.0 with proper validation

**Sub-tasks for Task 3**:
   - **3.1**: Create `app/api/green_finance_routes.py`
     - Implement `/api/green-finance/assess` endpoint
       - Accept `deal_id` or `location` (lat, lon)
       - Trigger full green finance assessment
       - Return compliance status, scores, and policy decisions
       - Include CDM events in response
     
     - Implement `/api/green-finance/emissions` endpoint
       - Accept `location` (lat, lon) and optional `date_range`
       - Retrieve emissions and air quality data
       - Return formatted metrics with temporal trends
     
     - Implement `/api/green-finance/urban-activity` endpoint
       - Accept `location` (lat, lon) and optional `date_range`
       - Retrieve OSM-based activity metrics
       - Return activity metrics (road density, building density, POI counts)
     
     - Implement `/api/green-finance/sdg-alignment` endpoint
       - Accept `deal_id` or `location` (lat, lon)
       - Calculate SDG alignment scores
       - Return per-goal alignment scores and overall score
     
     - Implement `/api/green-finance/sustainability-score` endpoint
       - Accept `location` (lat, lon)
       - Calculate composite sustainability score
       - Return score breakdown by component
   
   - **3.2**: Mount green finance routes in `app/api/routes.py`
     - Import `green_finance_routes` at top of file (with other route imports)
     - Mount router with prefix `/api/green-finance` (similar to existing route mounting patterns)
     - Add authentication dependencies: `Depends(get_current_user)`
     - Example mounting (add after line 100 or with other route includes):
       ```python
       from app.api import green_finance_routes
       
       # In main FastAPI app initialization:
       app.include_router(
           green_finance_routes.router,
           prefix="/api/green-finance",
           tags=["green-finance"]
       )
       ```

**Files to Create**:
- `app/api/green_finance_routes.py` - Green finance API endpoints
- `app/models/green_finance.py` - Green finance data models
- `alembic/versions/XXXX_add_green_finance_models.py` - Database migration

**Files to Modify**:
- `app/api/routes.py` (include green finance routes)
- `app/db/models.py` (add GreenFinanceAssessment model, extend LoanAsset)

---

## File Structure Summary

### New Backend Files (Phase 5)

#### Policy Rule Files (Activity 11.1)
1. `app/policies/green_finance/__init__.py`
2. `app/policies/green_finance/urban_sustainability.yaml`
3. `app/policies/green_finance/emissions_monitoring.yaml`
4. `app/policies/green_finance/vehicle_activity.yaml`
5. `app/policies/green_finance/pollution_compliance.yaml`
6. `app/policies/green_finance/sustainable_infrastructure.yaml`
7. `app/policies/green_finance/climate_resilience.yaml`
8. `app/policies/green_finance/sdg_alignment.yaml`

#### Service Files (Activity 11.2 & 11.3)
9. `app/services/osm_service.py` - OpenStreetMap data retrieval
10. `app/services/street_network_analyzer.py` - Road network analysis
11. `app/services/location_classifier.py` - Location type classification
12. `app/services/air_quality_service.py` - Air quality data integration
13. `app/services/sustainability_scorer.py` - Composite sustainability scoring
14. `app/services/vehicle_detection_service.py` - Vehicle detection (selective)
15. `app/services/emission_calculator.py` - Emission estimation
16. `app/services/methane_detection_service.py` - Methane emission detection
17. `app/services/pollution_monitor_service.py` - Pollution monitoring aggregation

#### ML Model Files (Activity 11.3)
18. `app/ml_models/vehicle_detector.py` - Vehicle detection model wrapper

#### Data Model Files (Activity 11.3 & 11.5)
19. `app/models/vehicle_detection.py` - Vehicle detection data models
20. `app/models/green_finance.py` - Green finance data models

#### API Route Files (Activity 11.5)
21. `app/api/green_finance_routes.py` - Green finance API endpoints

#### Database Migration Files (Activity 11.5)
22. `alembic/versions/XXXX_add_green_finance_models.py` - Database migration

### Modified Backend Files (Phase 5)

#### Core Service Modifications
1. `app/agents/verifier.py` - Add enhanced satellite analysis methods
   - OSM data integration
   - Location classification
   - Air quality integration
   - Sustainability scoring
   - Vehicle detection (selective)

2. `app/services/policy_service.py` - Add green finance evaluation methods
   - `evaluate_green_finance_compliance()`
   - `assess_urban_sustainability()`
   - `monitor_emissions_compliance()`
   - `evaluate_sdg_alignment()`
   - Enhanced transaction context with green finance metrics

3. `app/services/deal_service.py` - Integrate green finance evaluation
   - Auto-evaluate green finance on deal creation
   - Re-evaluate on deal updates
   - Store green finance metrics in deal metadata

#### Data Model Modifications
4. `app/models/loan_asset.py` - Add green finance metrics fields
   - `location_type: Optional[str]`
   - `air_quality_index: Optional[float]`
   - `composite_sustainability_score: Optional[float]`
   - `green_finance_metrics: Optional[dict]` (JSONB)

5. `app/models/cdm_events.py` - Add green finance event generators
   - `generate_green_finance_assessment()`

6. `app/db/models.py` - Add green finance database models
   - `GreenFinanceAssessment` model
   - Extend `LoanAsset` with green finance fields

#### API Route Modifications
7. `app/api/routes.py` - Include green finance routes
   - Mount green finance API router

---

## Data Sources & APIs

### Free/Open Source (Primary)
- **OpenStreetMap**: Street networks, POIs, land use (Overpass API)
  - **API Endpoint**: `https://overpass-api.de/api/interpreter` (public instance)
  - **Alternative**: `https://overpass.kumi.systems/api/interpreter` (backup)
  - **Rate Limits**: No hard limits, but be respectful (max 1 request/second recommended)
  - **Query Language**: Overpass QL (documentation: https://wiki.openstreetmap.org/wiki/Overpass_API)
  - **Data Format**: JSON (default) or XML
  - **Coverage**: Global, community-maintained, updated in real-time
  
- **OpenAQ**: Air quality data (free tier: 10,000 requests/month)
  - **API Endpoint**: `https://api.openaq.org/v2/`
  - **Authentication**: Not required for free tier
  - **Rate Limits**: 10,000 requests/month (free tier)
  - **Data Sources**: 100+ countries, 15,000+ monitoring stations
  - **Parameters**: PM2.5, PM10, NO2, O3, SO2, CO
  
- **Sentinel-2**: 10m resolution satellite imagery (via Sentinel Hub)
  - **Current Implementation**: `app/agents/verifier.py` lines 139-243
  - **API**: Sentinel Hub Process API
  - **Credentials**: `SENTINELHUB_KEY` and `SENTINELHUB_SECRET` in config
  
- **Sentinel-5P**: Air quality, methane detection (free, global coverage)
  - **Resolution**: 7km x 7km (coarse, but sufficient for regional monitoring)
  - **Update Frequency**: Daily global coverage
  - **Data Source**: Copernicus Open Access Hub (free)
  
- **NASA MODIS**: Aerosol optical depth (optional supplement)
  - **Use Case**: Global coverage when OpenAQ stations unavailable
  - **API**: NASA Worldview API

### Commercial (Selective Use Only)
- **High-resolution satellite imagery**: Maxar/DigitalGlobe, Planet Labs
  - **Cost**: $0.50-$2.00 per km²
  - **Use**: Only for flagged transactions (<10% of all transactions)
  - **Feature Flag**: `VEHICLE_DETECTION_ENABLED=true/false`

---

## Configuration

Add to `app/core/config.py` (after line 123, in Settings class):
```python
# Enhanced Satellite Verification
ENHANCED_SATELLITE_ENABLED: bool = True
STREET_MAP_API_PROVIDER: str = "openstreetmap"  # Only OSM, no Google/Mapbox

# OpenStreetMap
OSM_OVERPASS_API_URL: str = "https://overpass-api.de/api/interpreter"
OSM_CACHE_ENABLED: bool = True
OSM_CACHE_TTL_HOURS: int = 24

# Air Quality
AIR_QUALITY_ENABLED: bool = True
AIR_QUALITY_API_PROVIDER: str = "openaq"  # openaq only (free)
AIR_QUALITY_API_KEY: Optional[str] = None  # Not required for OpenAQ free tier
AIR_QUALITY_CACHE_ENABLED: bool = True
AIR_QUALITY_CACHE_TTL_HOURS: int = 24

# Vehicle Detection (Selective - High Cost)
VEHICLE_DETECTION_ENABLED: bool = False  # Default: disabled, enable for high-value cases
VEHICLE_DETECTION_MODEL_PATH: str = "./models/vehicle_detector.pt"
VEHICLE_DETECTION_MIN_TRANSACTION_AMOUNT: float = 1000000.0  # Only process if amount > $1M
VEHICLE_DETECTION_USE_HIGH_RES_IMAGERY: bool = True

# Pollution Monitoring
POLLUTION_MONITORING_ENABLED: bool = True
METHANE_MONITORING_ENABLED: bool = True
METHANE_USE_SENTINEL5P: bool = True  # Free, coarse resolution

# Sustainability Scoring
SUSTAINABILITY_SCORING_ENABLED: bool = True
SUSTAINABILITY_NDVI_WEIGHT: float = 0.25
SUSTAINABILITY_AQI_WEIGHT: float = 0.25
SUSTAINABILITY_ACTIVITY_WEIGHT: float = 0.20
SUSTAINABILITY_GREEN_INFRA_WEIGHT: float = 0.15
SUSTAINABILITY_POLLUTION_WEIGHT: float = 0.15
```

Add to `.env.example`:
```env
# Enhanced Satellite Verification
ENHANCED_SATELLITE_ENABLED=true
STREET_MAP_API_PROVIDER=openstreetmap

# OpenStreetMap
OSM_OVERPASS_API_URL=https://overpass-api.de/api/interpreter
OSM_CACHE_ENABLED=true
OSM_CACHE_TTL_HOURS=24

# Air Quality
AIR_QUALITY_ENABLED=true
AIR_QUALITY_API_PROVIDER=openaq
AIR_QUALITY_CACHE_ENABLED=true
AIR_QUALITY_CACHE_TTL_HOURS=24

# Vehicle Detection (Selective - High Cost)
VEHICLE_DETECTION_ENABLED=false
VEHICLE_DETECTION_MODEL_PATH=./models/vehicle_detector.pt
VEHICLE_DETECTION_MIN_TRANSACTION_AMOUNT=1000000
VEHICLE_DETECTION_USE_HIGH_RES_IMAGERY=true

# Pollution Monitoring
POLLUTION_MONITORING_ENABLED=true
METHANE_MONITORING_ENABLED=true
METHANE_USE_SENTINEL5P=true

# Sustainability Scoring
SUSTAINABILITY_SCORING_ENABLED=true
SUSTAINABILITY_NDVI_WEIGHT=0.25
SUSTAINABILITY_AQI_WEIGHT=0.25
SUSTAINABILITY_ACTIVITY_WEIGHT=0.20
SUSTAINABILITY_GREEN_INFRA_WEIGHT=0.15
SUSTAINABILITY_POLLUTION_WEIGHT=0.15
```

---

## Implementation Dependencies

### Python Packages to Add

Add to `pyproject.toml` or `requirements.txt`:
```txt
# OpenStreetMap
osmnx>=1.6.0  # Network analysis (requires: geopandas, networkx, shapely)
overpy>=0.6  # Overpass API wrapper (lightweight, no dependencies)

# Geospatial dependencies (required by osmnx)
geopandas>=0.14.0  # Geospatial data manipulation
networkx>=3.0  # Graph/network analysis
shapely>=2.0  # Geometric operations

# Vehicle Detection (Optional - only if VEHICLE_DETECTION_ENABLED=true)
ultralytics>=8.0.0  # YOLO v8
torch>=2.0.0  # PyTorch (for YOLO model)

# Geospatial (if not already present)
rasterio>=1.3.0  # For Sentinel-5P data processing
```

**Installation Notes**:
- `osmnx` requires system dependencies on Linux: `sudo apt-get install -y libspatialindex-dev`
- On Windows/Mac, use conda: `conda install -c conda-forge osmnx geopandas`
- `overpy` is pure Python, no system dependencies
- For production, consider using `geopandas` and `osmnx` in a Docker container with pre-installed dependencies

### Model Files to Download
- **YOLO v8 Vehicle Detection Model**: `yolov8n.pt` (nano version, ~6MB)
  - Download from: https://github.com/ultralytics/ultralytics
  - Place in: `./models/vehicle_detector.pt`
  - **Note**: Only needed if `VEHICLE_DETECTION_ENABLED=true`

---

## Success Criteria

1. ✅ OpenStreetMap integration for 100% of verification requests
2. ✅ Air quality data available for 90%+ of locations (OpenAQ coverage)
3. ✅ Composite sustainability score calculated for all deals
4. ✅ Location classification (urban/rural/suburban) for all locations
5. ✅ Green finance policies evaluated on all facility creations
6. ✅ Vehicle detection available for flagged cases only (<10% of transactions)
7. ✅ Methane detection for regional compliance monitoring
8. ✅ Green finance API endpoints functional
9. ✅ CDM events created for all green finance assessments

---

## Risk Mitigation

1. **API Costs**: 
   - Use only free APIs (OSM, OpenAQ, Sentinel-5P)
   - Vehicle detection only for flagged cases (feature flag)
   - Implement caching (24-hour cache for air quality, OSM data)

2. **Model Accuracy**: 
   - Use pre-trained YOLO v8 model (no training required)
   - Validate vehicle detection results with human review
   - Use OSM data for cross-validation

3. **Data Availability**: 
   - Fallback to synthetic data when APIs unavailable
   - Graceful degradation (return partial results if some APIs fail)
   - Cache OSM data locally for offline use

4. **Performance**: 
   - Cache OSM queries (24-hour TTL)
   - Cache air quality data (24-hour TTL)
   - Async processing for vehicle detection (background jobs)
   - Database indexes for green finance queries

5. **Privacy**: 
   - Anonymize location data in logs
   - Comply with GDPR for EU locations
   - No storage of personal data in OSM queries

---

## Timeline & Resource Allocation

### Week 11 (Days 1-5)
- **Day 1-3**: Activity 11.1 - Green Finance Policy Rule Definitions
- **Day 4-5**: Activity 11.2 (Part 1) - OSM Integration & Location Classifier

### Week 12 (Days 6-10)
- **Day 6-7**: Activity 11.2 (Part 2) - Air Quality Service & Sustainability Scorer
- **Day 8**: Activity 11.2 (Part 3) - Verifier Integration
- **Day 9-10**: Activity 11.3 - Vehicle Detection & Pollution Monitoring

### Week 13 (Days 11-14)
- **Day 11-13**: Activity 11.4 - Green Finance Policy Evaluation Integration
- **Day 14**: Activity 11.5 - Database Models & API Endpoints

---

## Testing Strategy

### Unit Tests
- OSM service: Test Overpass API queries, data parsing
- Location classifier: Test urban/rural classification accuracy
- Air quality service: Test OpenAQ API integration, caching
- Sustainability scorer: Test score calculation, normalization
- Vehicle detection: Test YOLO model inference (mock images)
- Emission calculator: Test emission factor calculations

### Integration Tests
- End-to-end verification workflow with OSM data
- Green finance policy evaluation with real metrics
- API endpoint testing with mock data
- CDM event generation validation

### Performance Tests
- OSM query performance (caching effectiveness)
- Air quality API rate limiting
- Vehicle detection processing time
- Database query performance

---

## Documentation Requirements

1. **API Documentation**: OpenAPI/Swagger docs for all green finance endpoints
2. **Service Documentation**: Docstrings for all new services
3. **Policy Documentation**: Comments in YAML files explaining rule logic
4. **Configuration Guide**: Environment variable documentation
5. **User Guide**: How to use green finance features in UI

---

## Code Reference Summary

### Key Files and Line Numbers

**Existing Implementation**:
- `app/agents/verifier.py` (lines 309-357): Current `verify_asset_location()` function
- `app/api/routes.py` (line 4489): API endpoint calling verification
- `app/models/loan_asset.py` (lines 26-183): LoanAsset model storing verification results
- `app/services/policy_service.py` (lines 198-335): Policy transaction mapping methods
- `app/models/cdm_events.py` (lines 299-368): CDM event generators (pattern to follow)
- `app/core/config.py` (lines 23-251): Settings class for configuration
- `app/core/policy_config.py` (lines 27-245): Policy rule loader

**New Files to Create**:
- `app/services/osm_service.py`: OpenStreetMap Overpass API integration
- `app/services/street_network_analyzer.py`: Road network analysis using osmnx
- `app/services/location_classifier.py`: Urban/rural/suburban classification
- `app/services/air_quality_service.py`: OpenAQ API integration
- `app/services/sustainability_scorer.py`: Composite sustainability scoring
- `app/policies/green_finance/*.yaml`: 7 green finance policy rule files
- `app/api/green_finance_routes.py`: Green finance API endpoints
- `app/models/green_finance.py`: Green finance Pydantic models

**Database Changes**:
- Add fields to `LoanAsset` model (after line 123)
- Create `GreenFinanceAssessment` model in `app/db/models.py`
- Create Alembic migration: `alembic/versions/XXXX_add_green_finance_models.py`

---

**Document Version**: 2.0  
**Last Updated**: 2024-12-XX  
**Author**: CreditNexus Architecture Team  
**Related Documents**: 
- `SATELLITE_IMAGERY_ENHANCEMENTS.md` (original plan with Street View)
- `SATELLITE_ENHANCEMENTS_FEASIBILITY_ANALYSIS.md` (feasibility analysis)
- `IMPLEMENTATION_PLAN.md` (Phase 5, Project 11)
