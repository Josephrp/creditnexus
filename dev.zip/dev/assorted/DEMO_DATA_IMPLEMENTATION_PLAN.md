# Demo Data Seeding & Management Implementation Plan

## Overview

Transform the "Verification Demo" tab into a comprehensive **Demo Data Management Dashboard** that:
- Seeds demo data using existing scripts (users, templates, policies)
- Generates AI-powered deal flow data (~12 deals)
- Creates documents at various review stages
- Uses ChromaDB seed folder + new paths for document storage
- Implements basic caching for AI generations
- Provides tracking and management UI

### Key Architecture Changes

**Verification Functionality Migration:**
- **VerificationDashboard** → Extracted into **VerificationWidget** (compact component)
- **VerificationWidget** → Embedded in **Dashboard** component as a new section
- **VerificationDashboard** → Preserved as full-page component, accessible via Ground Truth dashboard
- **DemoDataDashboard** → New component replacing VerificationDashboard in sidebar

**Benefits:**
- Verification workflow accessible directly from main Dashboard
- Full verification still available in Ground Truth dashboard
- Better UX: verification integrated into portfolio overview
- Demo data management gets dedicated sidebar tab

---

## Data Model Relationships & Generation Flow

### Line-Level Data Structure Examples

**Example 1: Complete Deal with Application**

```python
# User (Applicant)
user = {
    "id": 1,
    "email": "applicant@creditnexus.app",
    "role": "applicant",
    "display_name": "Demo Applicant"
}

# Application
application = {
    "id": 1,
    "application_type": "business",
    "status": "approved",
    "user_id": 1,
    "application_data": {
        "loan_amount": 5000000,
        "purpose": "Working capital expansion",
        "industry": "Manufacturing",
        "years_in_business": 15,
        "annual_revenue": 25000000,
        "credit_score": 750
    },
    "business_data": {
        "company_name": "Acme Manufacturing Corp",
        "tax_id": "12-3456789",
        "legal_structure": "Corporation",
        "number_of_employees": 250,
        "business_address": "123 Industrial Way, Detroit, MI 48201"
    },
    "submitted_at": "2024-10-15T10:00:00Z",
    "reviewed_at": "2024-10-16T14:30:00Z",
    "approved_at": "2024-10-20T09:15:00Z"
}

# Deal
deal = {
    "id": 1,
    "deal_id": "DEAL-2024-12-001",
    "applicant_id": 1,
    "application_id": 1,
    "status": "approved",
    "deal_type": "loan_application",
    "deal_data": {
        "loan_amount": 5000000,
        "interest_rate": 5.25,
        "term_years": 5,
        "collateral_type": "Real Estate",
        "sustainability_linked": True,
        "esg_targets": {
            "ndvi_threshold": 0.75,
            "verification_frequency": "Quarterly"
        }
    },
    "folder_path": "storage/deals/demo/DEAL-2024-12-001/",
    "created_at": "2024-10-20T09:15:00Z",
    "updated_at": "2024-10-20T09:15:00Z"
}

# Document with CDM
document = {
    "id": 1,
    "title": "Credit Agreement - Acme Manufacturing Corp",
    "borrower_name": "Acme Manufacturing Corp",
    "borrower_lei": "5493000X0ABCDEFGH12",
    "governing_law": "NY",
    "total_commitment": 5000000.00,
    "currency": "USD",
    "agreement_date": "2024-10-15",
    "sustainability_linked": True,
    "esg_metadata": {
        "esg_score": 0.82,
        "kpi_targets": ["NDVI > 0.75", "Carbon reduction 20%"],
        "verification_frequency": "Quarterly"
    },
    "uploaded_by": 2,  # Banker user ID
    "deal_id": 1,
    "created_at": "2024-10-20T10:00:00Z"
}

# CDM CreditAgreement (in DocumentVersion.extracted_data)
cdm_data = {
    "deal_id": "DEAL-2024-12-001",
    "agreement_date": "2024-10-15",
    "governing_law": "NY",
    "sustainability_linked": True,
    "parties": [
        {
            "id": "p1",
            "name": "Acme Manufacturing Corp",
            "role": "Borrower",
            "lei": "5493000X0ABCDEFGH12"
        },
        {
            "id": "p2",
            "name": "CreditNexus Bank",
            "role": "Lender"
        },
        {
            "id": "p3",
            "name": "CreditNexus Admin Services",
            "role": "Administrative Agent"
        }
    ],
    "facilities": [
        {
            "facility_name": "Term Loan Facility A",
            "commitment_amount": {
                "amount": 5000000.00,
                "currency": "USD"
            },
            "maturity_date": "2029-10-15",
            "interest_terms": {
                "rate_option": {
                    "benchmark": "SOFR",
                    "spread_bps": 325.0
                },
                "payment_frequency": {
                    "period": "Month",
                    "period_multiplier": 3
                }
            }
        }
    ],
    "esg_kpi_targets": [
        {
            "kpi_name": "NDVI Vegetation Index",
            "target_value": 0.75,
            "measurement_frequency": "Quarterly"
        }
    ]
}

# Workflow
workflow = {
    "id": 1,
    "document_id": 1,
    "state": "approved",
    "assigned_to": 3,  # Law Officer user ID
    "submitted_at": "2024-10-21T08:00:00Z",
    "approved_at": "2024-10-23T15:30:00Z",
    "approved_by": 4,  # Reviewer user ID
    "priority": "normal",
    "due_date": "2024-10-28T17:00:00Z"
}

# LoanAsset (for sustainability-linked deal)
loan_asset = {
    "id": 1,
    "loan_id": "DEAL-2024-12-001",
    "collateral_address": "123 Industrial Way, Detroit, MI 48201",
    "geo_lat": 42.3314,
    "geo_lon": -83.0458,
    "spt_data": {
        "target_type": "NDVI",
        "threshold": 0.75,
        "measurement_frequency": "Quarterly",
        "penalty_bps": 25
    },
    "spt_threshold": 0.75,
    "last_verified_score": 0.78,
    "risk_status": "COMPLIANT",
    "base_interest_rate": 5.25,
    "current_interest_rate": 5.25,
    "last_verified_at": "2024-11-15T10:00:00Z",
    "asset_metadata": {
        "verification_method": "Sentinel-2B",
        "cloud_cover": 0.05,
        "classification": "Forest",
        "confidence": 0.94
    }
}

# DealNote
deal_note = {
    "id": 1,
    "deal_id": 1,
    "user_id": 3,  # Law Officer
    "content": "Legal review complete. All clauses comply with NY regulations. Borrower has strong credit profile.",
    "note_type": "verification",
    "note_metadata": {
        "related_document_id": 1,
        "priority": "normal",
        "tags": ["legal", "credit-review"]
    },
    "created_at": "2024-10-23T15:30:00Z"
}

# PolicyDecision
policy_decision = {
    "id": 1,
    "transaction_id": "DEAL-2024-12-001",
    "decision": "ALLOW",
    "rule_applied": "check_collateral_requirements",
    "trace_id": "trace-uuid-12345",
    "document_id": 1,
    "cdm_events": {
        "eventType": "PolicyEvaluation",
        "decision": "ALLOW",
        "ruleApplied": "check_collateral_requirements"
    },
    "requires_review": False,
    "created_at": "2024-10-21T08:00:00Z"
}
```

### Complete Data Flow Diagram

```
Users (Applicants, Bankers, Law Officers, Accountants, Reviewers, Auditors)
  ↓
Applications (individual/business, various statuses)
  ↓
Deals (linked to applications, various statuses)
  ↓
Documents (linked to deals, with CDM data)
  ├─→ DocumentVersions (revision history)
  ├─→ Workflows (assigned_to, approved_by different users)
  ├─→ PolicyDecisions (policy evaluations)
  └─→ GeneratedDocuments (from templates)
       └─→ Uses LMATemplates + TemplateFieldMappings
  ↓
LoanAssets (for sustainability-linked deals)
  └─→ Verification data (NDVI, compliance status)
  ↓
DealNotes (notes from various users throughout lifecycle)
```

### Required Data Generation Specifications

**For 12 Deals, Generate:**
- **Users**: 5-8 demo users (already seeded via scripts)
- **Applications**: 12-15 applications (some deals have multiple apps)
- **Deals**: 12 deals (primary target)
- **Documents**: 18-36 documents (1-3 per deal)
- **DocumentVersions**: 24-48 versions (1-2 per document, some with revisions)
- **Workflows**: 18-36 workflows (1 per document)
- **GeneratedDocuments**: 12-24 generated docs (1-2 per approved deal)
- **LoanAssets**: 4-6 loan assets (30% of deals are sustainability-linked)
- **DealNotes**: 24-60 notes (2-5 per deal)
- **PolicyDecisions**: 18-36 decisions (1 per document in workflow)

### User Role Distribution for Assignments

- **Applicants**: Create applications and deals (5-8 users)
- **Bankers**: Upload documents, create deals, review (2-3 users)
- **Law Officers**: Review documents, approve workflows, add notes (2-3 users)
- **Accountants**: Review financial data, add notes (1-2 users)
- **Reviewers**: Approve workflows, review documents (2-3 users)
- **Auditors**: Read-only access, view all data (1-2 users)
- **Admins**: Full access, approve policies (1 user)

---

## Project 1: Demo Data Seeding Service

**Priority**: P0  
**Estimated Time**: 5 days

### Activity 1.1: Create Demo Data Service Backend

**File**: `app/services/demo_data_service.py` (NEW)

**Tasks**:
1. **Create DemoDataService class** (Lines 1-50)
   - Initialize with database session
   - Add methods: `seed_all()`, `seed_users()`, `seed_templates()`, `seed_policies()`
   - Add progress tracking with callbacks
   - Add error handling and rollback support

2. **Integrate existing seed scripts** (Lines 51-150)
   - Import and wrap `scripts.seed_demo_users.seed_demo_users()`
   - Import and wrap `scripts.seed_templates.seed_templates()`
   - Import and wrap `scripts.seed_policies.seed_policies()` (if exists)
   - Import and wrap `scripts.seed_policy_templates.seed_policy_templates()`
   - Add unified error handling

3. **Add seeding status tracking** (Lines 151-200)
   - Create `SeedingStatus` dataclass with: `stage`, `progress`, `total`, `current`, `errors`
   - Add status persistence to database (optional table: `demo_seeding_status`)
   - Add method to get current seeding status

4. **Add dry-run mode** (Lines 201-250)
   - Add `dry_run: bool` parameter to all seed methods
   - Return preview of what would be seeded without committing
   - Useful for UI preview before actual seeding

**File**: `app/api/routes.py` (MODIFY)

**Tasks**:
1. **Add demo data seeding endpoints** (Lines ~7000-7200)
   ```python
   @router.post("/demo/seed")
   @router.get("/demo/seed/status")
   @router.post("/demo/seed/users")
   @router.post("/demo/seed/templates")
   @router.post("/demo/seed/policies")
   @router.delete("/demo/seed/reset")
   ```

2. **Add request/response models** (Lines ~6950-7000)
   - `DemoSeedRequest` with `seed_users`, `seed_templates`, `seed_policies`, `dry_run`
   - `DemoSeedResponse` with `status`, `created`, `updated`, `errors`, `preview`
   - `SeedingStatusResponse` with current status

---

### Activity 1.2: AI-Powered Deal Generation with Complete Data Flow

**File**: `app/services/demo_data_service.py` (CONTINUE)

**Tasks**:
1. **Create AI deal generator** (Lines 251-400)
   - Method: `generate_deal_data(count: int, deal_types: List[str]) -> List[Dict]`
   - Use LLM to generate realistic deal scenarios
   - Include: borrower names, amounts, dates, facilities, parties
   - Ensure CDM compliance
   - Add caching layer (see Activity 1.4)

2. **Generate deal CDM data** (Lines 401-550)
   - Method: `_generate_cdm_for_deal(deal_type: str, seed: int) -> CreditAgreement`
   - Use structured LLM output with Pydantic validation
   - Generate diverse scenarios:
     - Corporate lending (various sizes)
     - Sustainability-linked loans
     - Refinancing deals
     - Restructuring deals
   - Include realistic party data (LEIs, addresses)

3. **Create complete data flow: Users → Applications → Deals** (Lines 551-750)
   - Method: `create_demo_deals(count: int = 12) -> List[Deal]`
   
   **Step 3.1: Generate Applications** (Lines 551-600)
   - For each deal, create an `Application` record:
     - `application_type`: "business" or "individual" (weighted 80% business)
     - `user_id`: Select from demo applicants (role=APPLICANT)
     - `status`: Distribute across: 20% "draft", 30% "submitted", 30% "under_review", 15% "approved", 5% "rejected"
     - `application_data`: JSONB with:
       ```json
       {
         "loan_amount": 1000000-50000000,
         "purpose": "Working capital / Expansion / Refinancing",
         "industry": "Technology / Manufacturing / Agriculture / Energy",
         "years_in_business": 2-50,
         "annual_revenue": loan_amount * 2-10,
         "credit_score": 650-850
       }
       ```
     - `business_data`: For business apps:
       ```json
       {
         "company_name": "Generated Company Name",
         "tax_id": "12-3456789",
         "legal_structure": "Corporation / LLC / Partnership",
         "number_of_employees": 10-5000,
         "business_address": "Generated Address"
       }
       ```
     - `submitted_at`: Staggered dates (30-180 days ago)
     - `reviewed_at`: If status >= "under_review", set to submitted_at + 1-7 days
     - `approved_at`: If status = "approved", set to reviewed_at + 1-14 days
     - `rejected_at`: If status = "rejected", set to reviewed_at + 1-3 days
   
   **Step 3.2: Create Deals from Applications** (Lines 601-650)
   - Use `DealService.create_deal_from_application()` pattern
   - For each application with status >= "submitted":
     - Create `Deal` record:
       - `deal_id`: Format "DEAL-{year}-{month}-{sequential}" (e.g., "DEAL-2024-12-001")
       - `applicant_id`: From application.user_id
       - `application_id`: Link to created application
       - `status`: Map from application status:
         - application "submitted" → deal "submitted"
         - application "under_review" → deal "under_review"
         - application "approved" → deal "approved"
         - application "rejected" → deal "rejected"
         - Also create some "active" and "closed" deals (10% each)
       - `deal_type`: From deal_types parameter or infer from application_data
       - `deal_data`: JSONB with:
         ```json
         {
           "loan_amount": from application_data,
           "interest_rate": 3.5-8.5,
           "term_years": 1-10,
           "collateral_type": "Real Estate / Equipment / Inventory",
           "sustainability_linked": 30% true,
           "esg_targets": if sustainability_linked
         }
         ```
       - `folder_path`: `storage/deals/demo/{deal_id}/`
       - `created_at`: From application.submitted_at
       - `updated_at`: Set to appropriate status transition date

4. **Generate deal documents with workflows** (Lines 651-850)
   - Method: `generate_deal_documents(deal_id: int, count: int) -> List[Document]`
   
   **Step 4.1: Create Documents** (Lines 651-750)
   - For each deal, create 1-3 `Document` records:
     - `title`: "Credit Agreement - {borrower_name}", "Term Sheet - {deal_id}", "Supporting Documents"
     - `borrower_name`: From CDM parties[role='Borrower'].name
     - `borrower_lei`: From CDM parties[role='Borrower'].lei (20-char alphanumeric)
     - `governing_law`: From CDM or generate: "NY", "English", "DE", "CA"
     - `total_commitment`: Sum of facilities[].commitment_amount.amount
     - `currency`: From facilities[0].commitment_amount.currency
     - `agreement_date`: From CDM agreement_date (ISO 8601)
     - `sustainability_linked`: From deal_data or CDM (30% true)
     - `esg_metadata`: If sustainability_linked:
       ```json
       {
         "esg_score": 0.65-0.95,
         "kpi_targets": ["NDVI > 0.75", "Carbon reduction 20%"],
         "verification_frequency": "Quarterly / Annual"
       }
       ```
     - `uploaded_by`: Select from demo users (banker, law_officer, accountant)
     - `deal_id`: Link to deal
     - `created_at`: Staggered dates (deal.created_at to deal.updated_at)
   
   **Step 4.2: Create DocumentVersions** (Lines 751-800)
   - For each document, create 1-2 `DocumentVersion` records:
     - `document_id`: Link to document
     - `version_number`: 1, 2 (for some documents)
     - `extracted_text`: First 5000 chars of generated document text
     - `extracted_data`: Full CDM CreditAgreement JSON
     - `extraction_status`: "success" (90%), "partial_data_missing" (10%)
     - `created_at`: Staggered (document.created_at + 0-2 days)
   
   **Step 4.3: Create Workflows** (Lines 801-850)
   - For each document, create `Workflow` record:
     - `document_id`: Link to document (unique)
     - `state`: Distribute:
       - 30% "draft"
       - 40% "under_review"
       - 20% "approved"
       - 10% "published"
     - `assigned_to`: 
       - If state = "under_review": Select from reviewers (law_officer, reviewer, admin)
       - If state = "draft": Select from creators (banker, analyst)
       - If state = "approved"/"published": Select from approvers (reviewer, admin)
     - `submitted_at`: If state >= "under_review", set to document.created_at + 1-3 days
     - `approved_at`: If state >= "approved", set to submitted_at + 1-7 days
     - `approved_by`: If state >= "approved", select from reviewers (reviewer, admin)
     - `published_at`: If state = "published", set to approved_at + 1-3 days
     - `priority`: "normal" (70%), "high" (25%), "urgent" (5%)
     - `due_date`: If state = "under_review", set to submitted_at + 7-14 days
     - `rejection_reason`: None (or generate if workflow transitions to rejected)

5. **Generate verification data (LoanAssets)** (Lines 851-950)
   - Method: `generate_loan_assets_for_deals(deal_ids: List[int]) -> List[LoanAsset]`
   - For deals with sustainability_linked documents (30% of deals):
     - Create `LoanAsset` record:
       - `loan_id`: Format "LOAN-{deal_id}" or use deal.deal_id
       - `original_text`: Extract from document.extracted_text (first 2000 chars)
       - `legal_vector`: Generate embedding using `get_embeddings_model()` (1536-dim)
       - `collateral_address`: From CDM or generate realistic address
       - `geo_lat`, `geo_lon`: Geocode address or use realistic coordinates
       - `spt_data`: From document.esg_metadata or generate:
         ```json
         {
           "target_type": "NDVI",
           "threshold": 0.70-0.85,
           "measurement_frequency": "Quarterly",
           "penalty_bps": 25-50
         }
         ```
       - `spt_threshold`: From spt_data.threshold
       - `last_verified_score`: Generate realistic NDVI (0.50-0.95)
       - `risk_status`: Calculate from last_verified_score vs spt_threshold:
         - >= threshold: "COMPLIANT"
         - >= threshold * 0.9: "WARNING"
         - < threshold * 0.9: "BREACH"
       - `base_interest_rate`: From deal.deal_data.interest_rate
       - `current_interest_rate`: base_interest_rate + (penalty_bps/100 if BREACH)
       - `penalty_bps`: From spt_data.penalty_bps if BREACH
       - `last_verified_at`: Recent date (1-30 days ago)
       - `asset_metadata`: 
         ```json
         {
           "verification_method": "Sentinel-2B",
           "cloud_cover": 0.01-0.10,
           "classification": "AnnualCrop / Forest / PermanentCrop",
           "confidence": 0.85-0.98
         }
         ```

**File**: `app/chains/deal_generation_chain.py` (NEW)

**Tasks**:
1. **Create deal generation prompt** (Lines 1-100)
   - Template for generating realistic credit agreement scenarios
   - Include industry sectors, loan sizes, terms
   - Ensure diversity in generated deals

2. **Create structured output chain** (Lines 101-200)
   - Use `with_structured_output()` for `CreditAgreement`
   - Add validation and retry logic
   - Cache generated deals by seed/hash

---

### Activity 1.3: Document Generation with Templates

**File**: `app/services/demo_data_service.py` (CONTINUE)

**Tasks**:
1. **Generate documents from templates** (Lines 951-1100)
   - Method: `generate_documents_from_templates(deal_id: int) -> List[GeneratedDocument]`
   - For each deal with approved status:
     - Load available templates from database
     - Select 1-2 templates per deal (Facility Agreement, Term Sheet)
     - Use `DocumentGenerationService.generate_document()`:
       - `template_id`: Selected template ID
       - `cdm_data`: From deal's primary document.extracted_data
       - `document_id`: Link to source document
       - `deal_id`: Link to deal
       - `user_id`: Select from demo users (banker, law_officer)
       - `field_overrides`: None (use CDM as-is)
     - Create `GeneratedDocument` records:
       - `template_id`: Template used
       - `source_document_id`: Source document ID
       - `cdm_data`: Full CDM JSON used for generation
       - `generated_content`: Generated document text (first 10000 chars)
       - `file_path`: `storage/deals/demo/{deal_id}/generated/{template_code}-{timestamp}.docx`
       - `status`: "draft" (40%), "review" (40%), "approved" (15%), "executed" (5%)
       - `generation_summary`: JSONB with:
         ```json
         {
           "fields_mapped": count,
           "ai_sections_generated": ["representations_and_warranties", "covenants"],
           "generation_time_seconds": 2.5-8.0,
           "cache_hits": 0-3
         }
         ```
       - `created_by`: User who triggered generation
       - `created_at`: Staggered dates

2. **Create review workflows for generated documents** (Lines 1101-1200)
   - Method: `create_review_workflows_for_generated(generated_doc_ids: List[int]) -> List[Workflow]`
   - For generated documents with status = "review":
     - Create `Workflow` record (similar to Step 4.3):
       - `document_id`: Link to source document (not generated doc)
       - `state`: "under_review" or "approved" based on generated_document.status
       - `assigned_to`: Select from reviewers (law_officer, reviewer)
       - `approved_by`: If approved, select from approvers
       - Add realistic timestamps

3. **Generate document versions and revision history** (Lines 1201-1300)
   - Method: `create_document_revision_history(document_ids: List[int]) -> List[DocumentVersion]`
   - For 30% of documents:
     - Create additional `DocumentVersion` records (version 2, 3):
       - `version_number`: Increment from existing
       - `extracted_text`: Modified version (simulate edits)
       - `extracted_data`: Slightly modified CDM (e.g., updated amounts, dates)
       - `extraction_status`: "success" or "partial_data_missing"
       - `created_at`: Staggered (original + 1-5 days)
   - Link versions to workflow state transitions:
     - Version 1 → draft state
     - Version 2 → under_review state (if exists)
     - Version 3 → approved state (if exists)

4. **Create deal notes from different users** (Lines 1301-1400)
   - Method: `create_deal_notes(deal_ids: List[int]) -> List[DealNote]`
   - For each deal, create 2-5 `DealNote` records:
     - `deal_id`: Link to deal
     - `user_id`: Select from various users:
       - 30% banker (deal management notes)
       - 25% law_officer (legal review notes)
       - 20% accountant (financial analysis notes)
       - 15% reviewer (approval notes)
       - 10% applicant (clarification requests)
     - `content`: Generate realistic notes:
       - "Reviewed credit agreement. Borrower credit score is strong."
       - "Legal review complete. All clauses comply with regulations."
       - "Financial analysis shows positive cash flow projections."
       - "Approved for proceeding to next stage."
       - "Request clarification on collateral valuation."
     - `note_type`: "general" (50%), "verification" (20%), "status_change" (20%), "financial" (10%)
     - `note_metadata`: JSONB with:
       ```json
       {
         "related_document_id": document_id (if applicable),
         "priority": "normal" / "high",
         "tags": ["credit-review", "legal", "financial"]
       }
       ```
     - `created_at`: Staggered across deal lifecycle
     - `updated_at`: Some notes updated (20% of notes)

5. **Create policy decisions for documents** (Lines 1401-1500)
   - Method: `create_policy_decisions_for_documents(document_ids: List[int]) -> List[PolicyDecision]`
   - For documents in workflow (state >= "submitted"):
     - Create `PolicyDecision` records:
       - `transaction_id`: From document (deal_id or generated)
       - `decision`: Distribute:
         - 70% "ALLOW"
         - 20% "FLAG"
         - 10% "BLOCK"
       - `rule_applied`: Select from policy rules:
         - "block_sanctioned_parties"
         - "flag_high_risk_jurisdiction"
         - "check_collateral_requirements"
         - "verify_esg_compliance"
       - `cdm_events`: Full CDM PolicyEvaluation event JSON
       - `trace_id`: Generate UUID
       - `document_id`: Link to document
       - `created_at`: Set to document workflow submitted_at
       - `requires_review`: True if decision = "FLAG" or "BLOCK"

---

### Activity 1.4: Caching Layer for AI Generations

**File**: `app/services/demo_data_cache.py` (NEW)

**Tasks**:
1. **Create cache service** (Lines 1-100)
   - Use SQLite or in-memory cache for demo data
   - Store: generated CDM data, deal scenarios, document content
   - Key format: `demo:{type}:{hash}` (e.g., `demo:deal:abc123`)

2. **Implement cache methods** (Lines 101-200)
   - `get_cached_deal(seed: int) -> Optional[Dict]`
   - `cache_deal(seed: int, deal_data: Dict) -> None`
   - `get_cached_cdm(deal_type: str, hash: str) -> Optional[CreditAgreement]`
   - `cache_cdm(deal_type: str, hash: str, cdm: CreditAgreement) -> None`

3. **Add cache invalidation** (Lines 201-250)
   - Method to clear all demo caches
   - Method to clear specific cache entries
   - TTL-based expiration (optional)

**File**: `app/services/demo_data_service.py` (MODIFY)

**Tasks**:
1. **Integrate caching** (Lines 251-300, 401-450)
   - Check cache before generating deals
   - Store generated deals in cache
   - Use hash of deal parameters as cache key

---

### Activity 1.5: ChromaDB Integration

**File**: `app/services/demo_data_service.py` (CONTINUE)

**Tasks**:
1. **Load documents into ChromaDB** (Lines 1501-1650)
   - Method: `index_demo_documents(document_ids: List[int]) -> int`
   - Use `DocumentRetrievalService` to index generated documents
   - Use existing `load_documents_from_directory()` from `app/utils/load_chroma_seeds.py`
   - Index documents from:
     - `storage/deals/demo/*/documents/` (new)
     - `CHROMADB_SEED_DOCUMENTS_DIR` (existing)
   - For each document:
     - Extract text from `DocumentVersion.extracted_text`
     - Generate embeddings using `get_embeddings_model()`
     - Store in ChromaDB with metadata:
       ```json
       {
         "document_id": document.id,
         "deal_id": document.deal_id,
         "borrower_name": document.borrower_name,
         "is_demo": true,
         "created_at": document.created_at.isoformat()
       }
       ```

2. **Create document storage structure** (Lines 1651-1750)
   - Create folders: `storage/deals/demo/{deal_id}/documents/`
   - Create folders: `storage/deals/demo/{deal_id}/extractions/`
   - Create folders: `storage/deals/demo/{deal_id}/generated/`
   - Create folders: `storage/deals/demo/{deal_id}/notes/`
   - Store generated documents as PDF/DOCX files:
     - Save `DocumentVersion.extracted_text` as `.txt` files
     - Save `GeneratedDocument.generated_content` as `.docx` files
     - Save CDM JSON as `.json` files in extractions folder

3. **Link to ChromaDB seed folder** (Lines 1751-1800)
   - Copy sample documents to `CHROMADB_SEED_DOCUMENTS_DIR/demo/`
   - Ensure documents are loaded on next startup
   - Add metadata tags: `demo: true`, `deal_id: {id}`, `document_type: {type}`
   - Create index file: `CHROMADB_SEED_DOCUMENTS_DIR/demo/index.json` with document mappings

---

## Project 2: Frontend Demo Management UI & Verification Integration

**Priority**: P0  
**Estimated Time**: 5 days

### Activity 2.1: Extract Verification Widget for Dashboard

**File**: `client/src/components/VerificationWidget.tsx` (NEW)

**Tasks**:
1. **Extract verification functionality** (Lines 1-150)
   - Extract core verification logic from `VerificationDashboard`
   - Create compact widget version for Dashboard embedding
   - Include: DropZone, AgentTerminal (compact), verification status
   - Remove full-page layout, use card-based design

2. **Create compact UI** (Lines 151-300)
   - Collapsible widget with expand/collapse
   - Two-column layout: Upload/Status | Map Preview
   - Compact AgentTerminal (max 5-10 log entries)
   - "View Full Verification" button to expand or navigate

3. **Add state management** (Lines 301-400)
   - Extract state from VerificationDashboard
   - Add props for external control
   - Support both embedded and standalone modes

4. **Add integration hooks** (Lines 401-500)
   - Support FDC3 context (from Dashboard)
   - Handle file uploads
   - Trigger verification workflow
   - Display results inline

**File**: `client/src/components/Dashboard.tsx` (MODIFY)

**Tasks**:
1. **Add verification widget section** (Lines ~820-900)
   - Add new section after ESG Breakdown
   - Use `PermissionGate` with `PERMISSION_SATELLITE_VIEW`
   - Embed `VerificationWidget` component
   - Add "View Full Verification" link to Ground Truth dashboard

2. **Import VerificationWidget** (Line ~36)
   - Add import statement
   - Add to component tree

3. **Add verification metrics** (Lines ~450-460)
   - Optional: Add verification status metric card
   - Show count of verified assets
   - Link to Ground Truth dashboard

### Activity 2.2: Create New DemoDataDashboard Component

**File**: `client/src/components/DemoDataDashboard.tsx` (NEW)

**Tasks**:
1. **Create main UI layout** (Lines 1-200)
   - Header: "Demo Data Management"
   - Tabs: "Seed Data", "Generated Deals", "Status", "Settings"
   - Stats cards: Users, Templates, Deals, Documents counts
   - Action buttons: "Seed All", "Generate Deals", "Reset Demo Data"

2. **Add seed data tab** (Lines 201-350)
   - Checkboxes for: Users, Templates, Policies, Permissions
   - "Dry Run" toggle
   - "Seed Selected" button
   - Progress indicator
   - Results table: Created/Updated/Errors

3. **Add generated deals tab** (Lines 351-500)
   - Table of generated deals with:
     - Deal ID, Type, Status, Borrower, Amount, Created Date
     - Actions: View, Delete, Regenerate
   - Filters: Status, Type, Date range
   - Pagination

4. **Add status tab** (Lines 501-600)
   - Real-time seeding status
   - Progress bars for each stage
   - Error log display
   - Last seeded timestamp

5. **Add settings tab** (Lines 601-700)
   - Number of deals to generate (default: 12)
   - Deal types to include
   - Document generation options
   - Cache management (clear cache button)

**File**: `client/src/components/DesktopAppLayout.tsx` (MODIFY)

**Tasks**:
1. **Update sidebar app config** (Lines 83-90)
   - Change description to "Demo Data Seeding & Management"
   - Update icon if needed

2. **Update component import** (Line 23)
   - Change from `VerificationDashboard` to `DemoDataDashboard`
   - Keep `VerificationWidget` import for Dashboard

3. **Update route mapping** (Lines 191, 303, 342, 686)
   - Keep `verification-demo` route but render `DemoDataDashboard`
   - Verification functionality now in Dashboard widget

---

### Activity 2.3: API Integration Hooks

**File**: `client/src/hooks/useDemoData.ts` (NEW)

**Tasks**:
1. **Create useDemoData hook** (Lines 1-150)
   - `seedData(options)` - Seed demo data
   - `generateDeals(count, types)` - Generate deals
   - `getSeedingStatus()` - Get current status
   - `resetDemoData()` - Clear all demo data
   - `getGeneratedDeals()` - List generated deals

2. **Add loading and error states** (Lines 151-200)
   - Loading states for each operation
   - Error handling and display
   - Success notifications

3. **Add real-time status polling** (Lines 201-250)
   - Poll `/api/demo/seed/status` every 2 seconds during seeding
   - Update UI with progress
   - Stop polling when complete

**File**: `client/src/components/DemoDataDashboard.tsx` (MODIFY)

**Tasks**:
1. **Integrate useDemoData hook** (Lines 50-100)
   - Use hook for all API calls
   - Handle loading/error states
   - Update UI based on status

**File**: `client/src/components/VerificationWidget.tsx` (MODIFY)

**Tasks**:
1. **Integrate verification API** (Lines 500-600)
   - Use existing verification endpoints
   - Handle file upload
   - Trigger `/api/loan-assets` workflow
   - Display results inline

---

### Activity 2.4: Deal and Document Views

**File**: `client/src/components/DemoDealCard.tsx` (NEW)

**Tasks**:
1. **Create deal card component** (Lines 1-150)
   - Display deal summary
   - Show status badge
   - Link to deal detail page
   - Quick actions: View, Delete

**File**: `client/src/components/DemoDataDashboard.tsx` (MODIFY)

**Tasks**:
1. **Add deal detail modal** (Lines 700-850)
   - Show deal information
   - List associated documents
   - Show workflow states
   - Display CDM data preview

2. **Add document list** (Lines 851-1000)
   - Table of documents per deal
   - Show workflow state
   - Link to document viewer
   - Actions: View, Download, Regenerate

---

## Project 3: Configuration & Templates

**Priority**: P1  
**Estimated Time**: 2 days

### Activity 3.1: Demo Data Configuration

**File**: `app/core/config.py` (MODIFY)

**Tasks**:
1. **Add demo data settings** (Lines ~140-160)
   ```python
   # Demo Data Configuration
   DEMO_DATA_ENABLED: bool = False
   DEMO_DATA_DEAL_COUNT: int = 12
   DEMO_DATA_DEAL_TYPES: List[str] = ["loan_application", "refinancing", "restructuring"]
   DEMO_DATA_STORAGE_PATH: str = "storage/deals/demo"
   DEMO_DATA_CACHE_ENABLED: bool = True
   DEMO_DATA_CACHE_TTL: int = 86400  # 24 hours
   ```

**File**: `data/demo_deal_config.json` (NEW)

**Tasks**:
1. **Create deal generation config** (Lines 1-100)
   - Template for deal scenarios
   - Industry sectors
   - Loan size ranges
   - Term variations
   - Party templates (borrowers, lenders)

2. **Add document generation config** (Lines 101-200)
   - Document types per deal
   - Template assignments
   - Workflow state distribution
   - Review assignment rules

---

### Activity 3.2: Deal Generation Templates with CDM Field Requirements

**File**: `app/prompts/demo/deal_generation.py` (NEW)

**Tasks**:
1. **Create deal generation prompt** (Lines 1-200)
   - Template for generating realistic deals
   - Include industry context
   - Ensure CDM compliance
   - Add diversity constraints
   - **Required CDM fields** (from template metadata):
     ```python
     REQUIRED_FIELDS = [
         "parties[role='Borrower'].name",
         "parties[role='Borrower'].lei",  # 20-char alphanumeric
         "facilities[0].facility_name",
         "facilities[0].commitment_amount.amount",  # 100K - 50M
         "facilities[0].commitment_amount.currency",  # USD, EUR, GBP
         "facilities[0].maturity_date",  # ISO 8601, future date
         "facilities[0].interest_terms.rate_option.benchmark",  # SOFR, LIBOR, EURIBOR
         "facilities[0].interest_terms.rate_option.spread_bps",  # 100-500 bps
         "agreement_date",  # ISO 8601, past date (30-180 days ago)
         "governing_law"  # NY, English, DE, CA
     ]
     ```
   - **Optional CDM fields** (include 70% of time):
     ```python
     OPTIONAL_FIELDS = [
         "parties[role='Administrative Agent'].name",
         "parties[role='Lender'].name",
         "sustainability_linked",  # 30% true
         "esg_kpi_targets",  # If sustainability_linked
         "deal_id",
         "loan_identification_number"
     ]
     ```

2. **Add scenario templates** (Lines 201-400)
   - **Corporate Lending** (40% of deals):
     - Industries: Technology, Manufacturing, Energy, Healthcare
     - Loan sizes: $1M - $25M
     - Terms: 3-7 years
     - Interest: SOFR + 200-400 bps
   - **Sustainability-Linked Loans** (30% of deals):
     - Include ESG KPI targets
     - NDVI thresholds: 0.70-0.85
     - Penalty structure: 25-50 bps
     - Verification frequency: Quarterly
   - **Refinancing** (20% of deals):
     - Existing loan references
     - Improved terms
     - Lower interest rates
   - **Restructuring** (10% of deals):
     - Distressed borrower scenarios
     - Modified terms
     - Extended maturities

3. **Generate party data** (Lines 401-500)
   - **Borrower** (required):
     - Name: Realistic company names (e.g., "Acme Manufacturing Corp")
     - LEI: Generate valid 20-char format (e.g., "5493000X0ABCDEFGH12")
     - Address: Realistic addresses (geocodable)
   - **Lenders** (optional, 60% include):
     - 1-5 lenders per deal
     - Names: "Bank of [City]", "CreditNexus Lending", etc.
     - LEIs: Generate if available
   - **Administrative Agent** (optional, 50% include):
     - Name: "CreditNexus Admin Services" or similar
     - Role: Administrative Agent

**File**: `app/chains/deal_generation_chain.py` (MODIFY)

**Tasks**:
1. **Load prompt templates** (Lines 1-50)
   - Load from `app/prompts/demo/deal_generation.py`
   - Support multiple scenario types
   - Include field requirements from template metadata

2. **Add structured output** (Lines 51-200)
   - Use `CreditAgreement` Pydantic model
   - Validate all required fields present
   - Validate LEI format (20 alphanumeric chars)
   - Validate dates (agreement_date < maturity_date, agreement_date not future)
   - Validate amounts (positive, reasonable ranges)
   - Validate currencies (ISO 3-letter codes)
   - Retry on validation errors (max 3 attempts)
   - Log validation failures for debugging

3. **Add template-aware generation** (Lines 201-250)
   - Check available templates from database
   - Generate CDM data that matches template requirements
   - Ensure required_fields are always present
   - Include optional_fields based on template category
   - Match governing_law to template if specified

---

## Project 4: Database & Storage

**Priority**: P1  
**Estimated Time**: 2 days

### Activity 4.1: Demo Data Tracking Table

**File**: `alembic/versions/XXXX_add_demo_data_tracking.py` (NEW)

**Tasks**:
1. **Create migration** (Lines 1-100)
   - Table: `demo_seeding_status`
   - Columns: `id`, `stage`, `progress`, `total`, `current`, `status`, `errors`, `started_at`, `completed_at`
   - Index on `status`, `stage`

2. **Add demo data tags** (Lines 101-200)
   - Add `is_demo` boolean to `deals` table (optional, or use `deal_data` JSONB)
   - Add `is_demo` boolean to `documents` table (optional, or use metadata)
   - Add indexes for filtering demo data

**File**: `app/db/models.py` (MODIFY)

**Tasks**:
1. **Add DemoSeedingStatus model** (Lines ~1200-1250)
   ```python
   class DemoSeedingStatus(Base):
       __tablename__ = "demo_seeding_status"
       id = Column(Integer, primary_key=True)
       stage = Column(String(50))  # users, templates, deals, documents
       progress = Column(Float)  # 0.0 to 1.0
       total = Column(Integer)
       current = Column(Integer)
       status = Column(String(20))  # running, completed, failed
       errors = Column(JSONB)
       started_at = Column(DateTime)
       completed_at = Column(DateTime)
   ```

---

### Activity 4.2: File Storage Structure

**File**: `app/services/demo_data_service.py` (MODIFY)

**Tasks**:
1. **Create storage structure** (Lines 1501-1600)
   - Method: `_create_deal_storage(deal_id: str) -> Path`
   - Create: `storage/deals/demo/{deal_id}/documents/`
   - Create: `storage/deals/demo/{deal_id}/extractions/`
   - Create: `storage/deals/demo/{deal_id}/generated/`
   - Create: `storage/deals/demo/{deal_id}/notes/`

2. **Store generated documents** (Lines 1601-1700)
   - Save generated DOCX files to deal folders
   - Save extracted CDM JSON to extractions folder
   - Use `FileStorageService` for consistency

---

## Project 5: Testing & Validation

**Priority**: P2  
**Estimated Time**: 2 days

### Activity 5.1: Unit Tests

**File**: `tests/test_demo_data_service.py` (NEW)

**Tasks**:
1. **Test seeding methods** (Lines 1-200)
   - Test `seed_users()` with dry-run
   - Test `seed_templates()`
   - Test error handling and rollback

2. **Test deal generation** (Lines 201-400)
   - Test `generate_deal_data()`
   - Test CDM validation
   - Test caching

3. **Test document generation** (Lines 401-600)
   - Test `generate_documents_from_templates()`
   - Test workflow creation
   - Test ChromaDB indexing

**File**: `tests/test_demo_data_api.py` (NEW)

**Tasks**:
1. **Test API endpoints** (Lines 1-300)
   - Test `/api/demo/seed` POST
   - Test `/api/demo/seed/status` GET
   - Test `/api/demo/deals` GET
   - Test error responses

---

### Activity 5.2: Integration Tests

**File**: `tests/integration/test_demo_data_workflow.py` (NEW)

**Tasks**:
1. **Test full workflow** (Lines 1-200)
   - Seed all data
   - Generate 12 deals
   - Verify documents created
   - Verify ChromaDB indexing
   - Test reset functionality

---

## Implementation Order

### Phase 1: Core Backend (Week 1)
1. ✅ Create `DemoDataService` with basic seeding
2. ✅ Add API endpoints for seeding
3. ✅ Integrate existing seed scripts
4. ✅ Add status tracking

### Phase 2: AI Generation (Week 2)
5. ✅ Create deal generation chain
6. ✅ Implement AI deal generator
7. ✅ Add caching layer
8. ✅ Generate deals and documents

### Phase 3: Frontend UI (Week 3)
9. ✅ Extract VerificationWidget from VerificationDashboard
10. ✅ Integrate VerificationWidget into Dashboard
11. ✅ Create DemoDataDashboard component
12. ✅ Add API integration hooks
13. ✅ Add deal/document views
14. ✅ Preserve full VerificationDashboard for Ground Truth

### Phase 4: Storage & Integration (Week 4)
13. ✅ Create file storage structure
14. ✅ Integrate ChromaDB
15. ✅ Add database tracking
16. ✅ Testing and validation

---

## File Summary

### New Files
- `app/services/demo_data_service.py` (~1700 lines)
- `app/services/demo_data_cache.py` (~250 lines)
- `app/chains/deal_generation_chain.py` (~200 lines)
- `app/prompts/demo/deal_generation.py` (~300 lines)
- `client/src/components/DemoDataDashboard.tsx` (~1000 lines)
- `client/src/components/VerificationWidget.tsx` (~600 lines)
- `client/src/components/DemoDealCard.tsx` (~150 lines)
- `client/src/hooks/useDemoData.ts` (~250 lines)
- `data/demo_deal_config.json` (~200 lines)
- `alembic/versions/XXXX_add_demo_data_tracking.py` (~200 lines)
- `tests/test_demo_data_service.py` (~600 lines)
- `tests/test_demo_data_api.py` (~300 lines)
- `tests/integration/test_demo_data_workflow.py` (~200 lines)

### Modified Files
- `app/api/routes.py` (+~200 lines)
- `app/core/config.py` (+~20 lines)
- `app/db/models.py` (+~50 lines)
- `client/src/components/DesktopAppLayout.tsx` (minor changes)
- `client/src/components/Dashboard.tsx` (+~100 lines for verification widget)
- `client/src/components/GroundTruthDashboard.tsx` (+~50 lines for verification link)
- `server.py` (optional: add demo data seeding on startup)

---

## Success Criteria

1. ✅ Can seed users, templates, policies via UI
2. ✅ Can generate 12 diverse deals with AI
3. ✅ Deals have associated documents at various workflow stages
4. ✅ Documents are stored in organized folder structure
5. ✅ Documents are indexed in ChromaDB
6. ✅ Caching reduces redundant AI calls
7. ✅ UI shows real-time progress
8. ✅ Can reset demo data cleanly
9. ✅ All generated data is CDM-compliant
10. ✅ Demo data is clearly tagged/identifiable

---

## Data Generation Summary

### Complete Data Set for 12 Deals

| Entity | Count | Distribution | Key Relationships |
|--------|-------|--------------|-------------------|
| **Users** | 5-8 | Seeded via existing scripts | Base for all assignments |
| **Applications** | 12-15 | 80% business, 20% individual | Linked to users (applicants) |
| **Deals** | 12 | Status: 20% draft, 30% submitted, 30% under_review, 15% approved, 5% active/closed | Linked to applications |
| **Documents** | 18-36 | 1-3 per deal | Linked to deals, uploaded by bankers/law_officers |
| **DocumentVersions** | 24-48 | 1-2 per document (30% have revisions) | Linked to documents |
| **Workflows** | 18-36 | 30% draft, 40% under_review, 20% approved, 10% published | Linked to documents, assigned to reviewers |
| **GeneratedDocuments** | 12-24 | 1-2 per approved deal | Linked to templates and source documents |
| **LoanAssets** | 4-6 | 30% of deals (sustainability-linked) | Linked to deals via loan_id |
| **DealNotes** | 24-60 | 2-5 per deal | Linked to deals, created by various users |
| **PolicyDecisions** | 18-36 | 70% ALLOW, 20% FLAG, 10% BLOCK | Linked to documents |

### User Assignment Matrix

| User Role | Applications | Deals | Documents | Workflows | Notes | Policy Decisions |
|-----------|-------------|-------|-----------|-----------|-------|------------------|
| **Applicant** | Create (100%) | Create (100%) | - | - | Create (10%) | - |
| **Banker** | Review (30%) | Create (20%) | Upload (40%) | Assign (30%) | Create (30%) | - |
| **Law Officer** | Review (20%) | Review (30%) | Upload (30%) | Assign (40%), Approve (30%) | Create (25%) | Review (50%) |
| **Accountant** | Review (10%) | Review (10%) | Upload (10%) | - | Create (20%) | Review (20%) |
| **Reviewer** | Approve (20%) | Approve (20%) | - | Assign (30%), Approve (70%) | Create (15%) | Review (30%) |
| **Auditor** | View (100%) | View (100%) | View (100%) | View (100%) | View (100%) | View (100%) |
| **Admin** | Approve (10%) | Approve (10%) | - | Approve (10%) | - | Approve (100%) |

## Estimated Total Time

- **Backend Development**: 10 days (increased due to detailed data generation)
- **Frontend Development**: 5 days (includes verification widget extraction)
- **Testing**: 2 days
- **Total**: ~17 days (3.4 weeks)

---

## Template Field Mapping Requirements

### Ensuring Generated CDM Matches Template Requirements

**File**: `app/services/demo_data_service.py` (Lines 400-450)

**Validation Logic**:
1. **Pre-generation validation** (Lines 400-420)
   - Load template from database using `TemplateRegistry.get_template()`
   - Get required_fields from template: `template.required_fields` (JSONB array)
   - Get field_mappings from template: `template.field_mappings` (relationship)
   - Validate generated CDM has all required fields before creating documents
   - Example validation:
     ```python
     required = ["parties[role='Borrower'].name", "facilities[0].commitment_amount.amount"]
     for field_path in required:
         if not _field_exists_in_cdm(cdm_data, field_path):
             raise ValueError(f"Missing required field: {field_path}")
     ```

2. **Field path resolution** (Lines 421-450)
   - Implement `_field_exists_in_cdm(cdm: CreditAgreement, path: str) -> bool`
   - Parse field paths like `"parties[role='Borrower'].name"`
   - Use `FieldPathParser` from `app/generation/mapper.py`
   - Validate field values match expected types:
     - LEI: 20 alphanumeric characters
     - Amounts: Positive Decimal
     - Dates: ISO 8601 format, valid date ranges
     - Currencies: ISO 3-letter codes

3. **Template-specific generation** (Lines 451-500)
   - For each template category, generate appropriate CDM:
     - **Facility Agreement**: Full CDM with all parties, facilities, terms
     - **Term Sheet**: Simplified CDM (borrower, facility name, amount, pricing)
     - **Confidentiality Agreement**: Minimal CDM (parties only)
   - Match `governing_law` to template if specified
   - Include `ai_generated_sections` requirements in generation context

### Template Field Mapping Examples

**From `data/templates_metadata.json` and `scripts/seed_templates.py`:**

1. **Facility Agreement Template** (`LMA-CL-FA-2024-EN`):
   - Required: Borrower name, LEI, facility name, amount, currency, maturity, benchmark, spread, agreement_date, governing_law
   - Optional: Admin Agent, Lender, sustainability_linked, ESG targets
   - AI Sections: representations_and_warranties, conditions_precedent, covenants, events_of_default

2. **Term Sheet Template** (`LMA-CL-TS-2024-EN`):
   - Required: Borrower, facility name, amount, currency, maturity, benchmark, spread
   - Optional: agreement_date, governing_law, sustainability_linked
   - AI Sections: purpose, conditions_precedent, representations, fees

**Generation Strategy**:
- Generate full CDM for Facility Agreements (all fields)
- Generate simplified CDM for Term Sheets (required only)
- Use template's `required_fields` as generation checklist
- Include optional fields based on template category and deal type

## Notes

- Use existing seed scripts as-is, wrap in service layer
- Cache AI generations to reduce costs and improve speed
- Ensure all generated data is clearly marked as demo data
- Support dry-run mode for preview before seeding
- Make demo data easy to reset/clear
- Use realistic but clearly demo data (e.g., "Demo Borrower Corp")
- Consider rate limiting for AI generation endpoints
- Add logging for all demo data operations
- **Verification functionality**: Moved to Dashboard as widget, full version still available in Ground Truth dashboard
- **VerificationDashboard**: Preserved as-is, can be accessed via Ground Truth or direct route
- **VerificationWidget**: New compact component extracted for Dashboard embedding
- **Template Compliance**: All generated CDM must validate against template required_fields before document creation
- **Data Relationships**: Maintain referential integrity across all generated entities (users → applications → deals → documents → workflows)
- **Realistic Timestamps**: Stagger all timestamps to simulate realistic deal lifecycle (30-180 days ago for creation, progressive updates)
- **User Assignments**: Distribute assignments across user roles to demonstrate multi-user workflow
