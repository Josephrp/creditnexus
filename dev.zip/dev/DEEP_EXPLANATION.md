# CreditNexus: Deep Technical Explanation

## Executive Summary

**CreditNexus** is a next-generation financial AI platform that bridges legal contracts and physical reality. It automates the extraction of structured data from credit agreement documents (PDFs/text) and verifies sustainability-linked loan covenants using satellite imagery and deep learning. The platform provides a complete workflow from document ingestion to portfolio management, with desktop interoperability via FDC3 standards.

**Core Value Proposition:** "Where Legal Text Meets Ground Truth" - Automatically extract financial terms from legal documents and verify physical asset compliance using satellite data.

---

## Part 1: What The Application Does

### Primary Functions

1. **Document Intelligence (AI Extraction)**
   - Extracts structured financial data from unstructured credit agreement PDFs/text
   - Converts extracted data into FINOS Common Domain Model (CDM) format
   - Handles both short documents (<50k chars) and long documents (>50k chars) with different strategies
   - **Multimodal Extraction**: Supports audio transcription, image OCR, and fusion of multiple sources
   - **Template-Aware Extraction**: Optimizes extraction based on document template type
   - **Comprehensive Extraction**: Extracts KYC/AML, regulatory compliance, security/intercreditor, secondary trading, crypto assets, consumer credit, restructuring, bridge loans, mezzanine finance, project finance, trade finance, asset-based lending, letters of credit, guarantees, and subordination fields

2. **Ground Truth Verification (Satellite-Based Compliance)**
   - Extracts Sustainability Performance Targets (SPTs) from loan covenants
   - Geocodes collateral addresses to lat/lon coordinates
   - Fetches Sentinel-2 satellite imagery for asset locations
   - Calculates NDVI (Normalized Difference Vegetation Index) to verify vegetation/forest cover
   - Determines compliance status (COMPLIANT, WARNING, BREACH) based on covenant thresholds
   - **Enhanced Verification**: OpenStreetMap integration, air quality monitoring, multi-dimensional environmental metrics
   - **Deep Learning Classification**: TorchGeo ResNet-50 for land use classification (Forest, Agricultural, Industrial, etc.)

3. **LMA Template Generation**
   - Generates LMA (Loan Market Association) templates from CDM data
   - Automatic field mapping from CDM to template placeholders
   - AI-powered field population for missing data
   - Template-aware extraction and generation
   - Support for multiple template categories (Facility Agreement, Term Sheet, Sustainable Finance, etc.)

4. **Policy Engine & Compliance**
   - Real-time policy evaluation using policy-as-code rules
   - Enforces financial regulations (MiCA, Basel III, FATF)
   - Policy editor with approval workflow
   - Policy testing and validation
   - CDM-compliant policy evaluation events
   - Decision types: ALLOW, BLOCK, FLAG

5. **Deal Management & Applications**
   - Application processing (individual and business)
   - Deal lifecycle management (DRAFT → SUBMITTED → UNDER_REVIEW → APPROVED → ACTIVE → CLOSED)
   - Deal-based folder structure for document organization
   - Deal notes and collaboration
   - Application-to-deal conversion workflow

6. **Workflow Management**
   - Document review/approval workflow (DRAFT → UNDER_REVIEW → APPROVED → PUBLISHED → ARCHIVED)
   - **Enhanced Role-Based Access Control**: viewer, analyst, reviewer, admin, auditor, banker, law_officer, accountant, applicant
   - **Signup Approval Workflow**: New user signups require approval
   - Version tracking for all document extractions
   - Comprehensive audit logging of all user actions
   - Assignment, priority levels, and due dates

7. **Portfolio Analytics**
   - Portfolio overview with total commitments by currency
   - ESG breakdown (sustainability-linked vs. non-sustainability)
   - Workflow distribution tracking
   - Maturity timeline visualization
   - Activity feed from audit logs
   - Credit risk assessment and capital requirements calculation

8. **Green Finance & Credit Risk**
   - Green finance assessments with SDG alignment
   - Urban sustainability evaluation
   - Emissions compliance monitoring
   - Credit risk assessment with probability of default (PD), loss given default (LGD), exposure at default (EAD)
   - Risk-weighted assets (RWA) and capital requirements calculation

9. **Desktop Interoperability (FDC3)**
   - FDC3 2.0 compliant for financial desktop connectivity
   - Supports OpenFin and Finsemble platforms
   - Intent-based communication between apps
   - Context broadcasting for real-time updates

10. **Decision Support & Chatbot**
    - AI-powered decision support chatbot
    - RAG (Retrieval Augmented Generation) with ChromaDB knowledge base
    - Template and CDM schema guidance
    - Field filling assistance

11. **Profile Extraction**
    - Extracts structured profile data from uploaded documents
    - Supports multiple roles (applicant, banker, law_officer, accountant)
    - Merges with existing profile data
    - Profile-based document pre-filling

---

## Part 2: How It Works - Deep Technical Breakdown

### Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│  Frontend (React + TypeScript + Vite)                       │
│  - Multi-app interface (Dashboard, Docu-Digitizer, etc.)   │
│  - FDC3 integration for desktop interoperability            │
│  - Real-time updates via FDC3 channels                      │
└─────────────────────────────────────────────────────────────┘
                          ↕ HTTP/REST + WebSocket
┌─────────────────────────────────────────────────────────────┐
│  FastAPI Backend (Python 3.11)                             │
│  - REST API endpoints                                       │
│  - Authentication (JWT + OAuth)                             │
│  - Request validation & routing                             │
│  - Static file serving                                      │
└─────────────────────────────────────────────────────────────┘
                          ↕
┌─────────────────────────────────────────────────────────────┐
│  Cognitive Layer (LangChain + OpenAI GPT-4o)                │
│  - Structured output binding (Pydantic)                     │
│  - Reflexion retry pattern                                  │
│  - Map-reduce for long documents                            │
│  - Legal document analysis (SPT extraction)                  │
└─────────────────────────────────────────────────────────────┘
                          ↕
┌─────────────────────────────────────────────────────────────┐
│  Geospatial Intelligence Layer                              │
│  - Geocoding (geopy/Nominatim)                             │
│  - Satellite data fetching (Sentinel Hub)                   │
│  - Deep learning classification (TorchGeo ResNet-50)        │
│  - NDVI calculation                                         │
└─────────────────────────────────────────────────────────────┘
                          ↕
┌─────────────────────────────────────────────────────────────┐
│  Validation Layer (Pydantic)                               │
│  - FINOS CDM schema enforcement                             │
│  - Business logic validators                                │
│  - Type safety & data normalization                         │
└─────────────────────────────────────────────────────────────┘
                          ↕
┌─────────────────────────────────────────────────────────────┐
│  Data Layer (PostgreSQL + SQLAlchemy)                       │
│  - Document storage with versioning                        │
│  - Workflow state machine                                   │
│  - Audit logging                                            │
│  - User management                                          │
│  - Vector store (pgvector) for semantic search             │
└─────────────────────────────────────────────────────────────┘
```

---

## Part 3: Core Components Deep Dive

### 3.1 AI-Powered Extraction Engine

**Location:** `app/chains/extraction_chain.py` + `app/chains/map_reduce_chain.py`

#### Simple Extraction Strategy (Documents < 50k characters)

**Process Flow:**

1. **Text Input**
   - User uploads PDF or pastes text
   - PDFs are parsed using PyMuPDF (`fitz`) to extract raw text
   - Text is passed to extraction chain

2. **LLM Processing**
   - Uses OpenAI GPT-4o with `temperature=0` for deterministic output
   - LangChain binds the Pydantic `ExtractionResult` model as a structured output
   - The LLM is prompted to extract:
     - **Parties**: Borrower, Lenders, Administrative Agent with LEIs
     - **Loan Facilities**: Term Loans, Revolving Credit with commitment amounts
     - **Interest Rates**: Benchmark (SOFR, EURIBOR) + spread in basis points
     - **Dates**: Agreement date, maturity dates (ISO 8601 format)
     - **Governing Law**: Jurisdiction (NY, English, Delaware, etc.)
     - **ESG Provisions**: Sustainability-linked indicators and KPI targets

3. **Reflexion Retry Pattern**
   - If Pydantic validation fails, the error is fed back to the LLM
   - The LLM corrects issues (e.g., date format, currency consistency)
   - Up to 3 retry attempts with error feedback
   - Example corrections:
     - Date format: "October 15, 2023" → "2023-10-15"
     - Spread normalization: "2.75%" → 275.0 basis points
     - Currency consistency: All facilities must use same currency

4. **Validation**
   - Pydantic validates all fields against the CDM schema
   - Business logic validators check:
     - Agreement date not in future
     - Maturity dates after agreement date
     - All facilities use same currency
     - At least one Borrower party exists
     - Spreads normalized to basis points (3.5% → 350.0)

#### Map-Reduce Strategy (Documents > 50k characters)

**Process Flow:**

1. **Document Splitting** (`app/utils/document_splitter.py`)
   - Uses `CreditAgreementSplitter` to split by Articles
   - Regex pattern matches: `ARTICLE\s+([IVX]+|\d+)`
   - Each Article becomes a chunk (max 8000 chars, min 500 chars)
   - If an Article is too long, it's split by paragraphs
   - Preserves semantic coherence by maintaining article boundaries

2. **MAP Phase**
   - Each chunk is processed independently
   - Uses `PartialCreditAgreement` model (all fields optional)
   - Extracts whatever data exists in that section
   - Processes chunks sequentially (can be parallelized)
   - Example: Article I might contain parties, Article II might contain facilities

3. **REDUCE Phase**
   - All partial extractions are merged by a reducer LLM
   - Deduplicates parties (by name matching)
   - Combines facilities
   - Selects authoritative dates (prefers preamble/Article I)
   - Produces a complete `CreditAgreement` object
   - Final validation ensures consistency

**Key Code Snippet:**
```python
# From extraction_chain.py
def extract_data_smart(text: str, force_map_reduce: bool = False) -> ExtractionResult:
    text_length = len(text)
    if force_map_reduce or text_length > MAP_REDUCE_THRESHOLD:  # 50k chars
        return extract_data_map_reduce(text)
    else:
        return extract_data(text, max_retries=3)
```

#### Multimodal Extraction Strategy

**Location:** `app/chains/audio_transcription_chain.py`, `app/chains/image_extraction_chain.py`, `app/chains/multimodal_fusion_chain.py`

CreditNexus supports extraction from multiple input sources:

1. **Audio Transcription**
   - Uses nvidia/canary-1b-v2 model for speech-to-text
   - Supports multiple languages (source_lang, target_lang)
   - Formats: WAV, MP3, M4A, OGG, FLAC, WEBM
   - Optional CDM extraction from transcription
   - Endpoint: `POST /api/audio/transcribe`

2. **Image OCR**
   - Uses Multimodal-OCR3 for text extraction from images
   - Supports multiple image uploads (multi-page documents)
   - Formats: PNG, JPEG, WEBP, GIF, BMP, TIFF
   - Combines OCR text from all images
   - Optional CDM extraction from OCR text
   - Endpoint: `POST /api/image/extract`

3. **Multimodal Fusion**
   - Combines data from multiple sources (audio, image, document, text)
   - Two fusion strategies:
     - **Deterministic**: Source priority-based conflict resolution
     - **LLM-based**: AI-powered intelligent merging
   - Tracks field sources for auditability
   - Resolves conflicts with confidence scores
   - Endpoint: `POST /api/multimodal/fuse`

**Fusion Process:**
```python
# From multimodal_fusion_chain.py
def fuse_multimodal_inputs(
    audio_cdm: Optional[Dict] = None,
    image_cdm: Optional[Dict] = None,
    document_cdm: Optional[Dict] = None,
    text_cdm: Optional[Dict] = None,
    use_llm_fusion: bool = True
) -> Dict[str, Any]:
    # Combines CDM data from all sources
    # Resolves conflicts intelligently
    # Returns unified CreditAgreement
```

#### Template-Aware Extraction

**Location:** `app/chains/template_aware_extraction.py`

- Optimizes extraction based on document template category
- Provides category-specific guidance to LLM
- Supports: Facility Agreement, Term Sheet, Sustainable Finance, Regulatory, etc.
- Improves extraction accuracy for specialized document types

---

### 3.2 Data Models & Validation

**Location:** `app/models/cdm.py`

#### FINOS CDM Structure

```python
CreditAgreement
├── agreement_date: date (ISO 8601)
├── parties: List[Party]
│   ├── id: str (unique identifier)
│   ├── name: str (legal name)
│   ├── role: str (Borrower, Lender, Administrative Agent)
│   ├── lei: Optional[str] (20-char Legal Entity Identifier)
│   └── jurisdiction: Optional[str]
├── facilities: List[LoanFacility]
│   ├── facility_name: str (e.g., "Term Loan B")
│   ├── commitment_amount: Money
│   │   ├── amount: Decimal (for precision)
│   │   └── currency: Currency (USD, EUR, GBP, JPY)
│   ├── interest_terms: InterestRatePayout
│   │   ├── rate_option: FloatingRateOption
│   │   │   ├── benchmark: str (SOFR, EURIBOR, Term SOFR)
│   │   │   └── spread_bps: float (basis points, e.g., 275.0 for 2.75%)
│   │   └── payment_frequency: Frequency
│   │       ├── period: PeriodEnum (Day, Week, Month, Year)
│   │       └── period_multiplier: int (e.g., 3 for "every 3 months")
│   └── maturity_date: date
├── governing_law: str (NY, English, Delaware, etc.)
├── sustainability_provisions (optional)
│   ├── sustainability_linked: bool
│   └── esg_kpi_targets: List[ESGKPITarget]
│       ├── kpi_type: ESGKPIType (CO2_EMISSIONS, RENEWABLE_ENERGY, NDVI, etc.)
│       ├── target_value: float
│       ├── current_value: Optional[float]
│       ├── unit: str
│       └── margin_adjustment_bps: float (penalty/reward in basis points)
├── KYC/AML Fields (optional)
│   ├── kyc_verification_date: date
│   ├── sanctions_screening_date: date
│   ├── aml_certification_date: date
│   ├── source_of_funds: str
│   └── ongoing_obligations: List[str]
├── Regulatory Compliance Fields (optional)
│   ├── fatf_compliance_statement: str
│   ├── cdd_obligations: List[str]
│   ├── suspicious_transaction_reporting: str
│   ├── sanctions_compliance: str
│   ├── capital_adequacy_certification: str
│   ├── risk_weighting: float
│   └── regulatory_capital_requirements: Money
├── Security & Intercreditor Fields (optional)
│   ├── collateral_details: str
│   ├── margin_thresholds: Money
│   ├── security_interests: List[str]
│   ├── priority_arrangements: str
│   ├── voting_mechanisms: str
│   └── standstill_provisions: str
├── Secondary Trading Fields (optional)
│   ├── transfer_provisions: str
│   ├── assignment_restrictions: List[str]
│   ├── margin_calculation_methodology: str
│   └── dispute_resolution_mechanism: str
├── Crypto & Digital Assets Fields (optional)
│   ├── crypto_asset_details: str
│   ├── digital_asset_types: List[str]
│   ├── blockchain_network: str
│   ├── wallet_addresses: List[str]
│   └── custody_arrangements: str
├── Consumer Credit Fields (optional)
│   ├── apr_disclosure: str
│   ├── cooling_off_period: int
│   └── withdrawal_rights: str
├── Restructuring Fields (optional)
│   ├── restructuring_terms: str
│   └── forbearance_period: int
├── Bridge Loan Fields (optional)
│   ├── bridge_period: int
│   └── takeout_facility_reference: str
├── Mezzanine Finance Fields (optional)
│   ├── equity_kicker: str
│   └── warrant_terms: str
├── Project Finance Fields (optional)
│   ├── project_name: str
│   ├── sponsor_details: List[str]
│   └── revenue_streams: List[str]
├── Trade Finance Fields (optional)
│   ├── lc_number: str
│   ├── beneficiary_details: str
│   └── shipping_documents: List[str]
├── Asset-Based Lending Fields (optional)
│   ├── collateral_valuation: Money
│   └── borrowing_base: Money
├── Letter of Credit Fields (optional)
│   ├── lc_type: str
│   ├── expiry_date: date
│   └── presentation_period: int
├── Guarantee Fields (optional)
│   ├── guarantor_details: List[str]
│   ├── guarantee_amount: Money
│   └── guarantee_type: str
├── Subordination Fields (optional)
│   ├── senior_debt_amount: Money
│   └── subordination_ratio: float
└── Amendment Fields (optional)
    ├── amendment_number: int
    ├── effective_date: date
    └── amended_sections: List[str]
```

#### Validation Rules

**Type Safety (Pydantic):**
- All fields must match declared types
- Dates must be valid ISO 8601 format
- LEIs must be exactly 20 alphanumeric characters
- Spreads must be between -10000 and 10000 basis points

**Business Logic Validators (`@model_validator` decorators):**
1. **Date Validation:**
   - Agreement date cannot be in the future
   - Maturity date must be after agreement date
   
2. **Currency Consistency:**
   - All facilities must use the same currency
   - Raises `ValueError` if mismatch detected

3. **Party Validation:**
   - At least one party with role containing "Borrower" must exist
   - Sets `extraction_status` to `PARTIAL` if missing

4. **Data Normalization:**
   - Percentages → basis points (automatic conversion in validators)
   - Dates → ISO 8601 format
   - Monetary amounts → Decimal for precision

**Example Validation Error:**
```python
@model_validator(mode='after')
def validate_currency_consistency(self) -> 'CreditAgreement':
    if not self.facilities:
        return self
    first_currency = self.facilities[0].commitment_amount.currency
    for facility in self.facilities[1:]:
        if facility.commitment_amount.currency != first_currency:
            raise ValueError(
                f"Currency mismatch: facility '{facility.facility_name}' uses "
                f"{facility.commitment_amount.currency}, expected {first_currency}"
            )
    return self
```

---

### 3.3 Ground Truth Protocol (Satellite Verification)

**Location:** `app/agents/analyzer.py`, `app/agents/verifier.py`, `app/agents/classifier.py`

#### Complete Verification Workflow

**Step 1: Legal Extraction** (`app/agents/analyzer.py`)

- Extracts **Sustainability Performance Targets (SPTs)** from covenant text:
  - Metric type (e.g., "NDVI Index", "Forest Cover")
  - Threshold value (e.g., 0.8 for 80%)
  - Comparison direction (greater than, less than, equal to)
  - Financial penalty (margin increase in basis points)
  - Trigger mechanism (automatic, lender discretion)

- Extracts **Collateral Address**:
  - Full address string
  - Components: street, city, state, postal code, country
  - Uses LLM to find phrases like "located at", "property situated at"

**Step 2: Geocoding** (`app/agents/verifier.py`)

- Converts text address to lat/lon coordinates
- Uses `geopy` with Nominatim geocoder
- Handles timeouts and service errors gracefully
- Example: "2847 Timber Ridge Road, Paradise, CA 95969" → (39.7596, -121.6219)

**Step 3: Satellite Data Fetching** (`app/agents/verifier.py`)

- Fetches Sentinel-2 multispectral imagery via Sentinel Hub API
- Requests NIR (Near-Infrared, Band 8) and Red (Band 4) bands
- Creates bounding box around location (default 1km x 1km)
- Uses 90-day lookback window for cloud-free imagery
- Falls back to synthetic data if Sentinel Hub unavailable

**Step 4: Deep Learning Classification** (`app/agents/classifier.py`)

- Uses TorchGeo ResNet-50 model pre-trained on Sentinel-2 data
- Self-supervised learning (MoCo) weights
- Processes 13-band multispectral data
- Classifies land use: AnnualCrop, Forest, HerbaceousVegetation, Highway, Industrial, Pasture, PermanentCrop, Residential, River, SeaLake
- Returns classification confidence score

**Step 5: NDVI Calculation** (`app/agents/verifier.py`)

- Calculates Normalized Difference Vegetation Index:
  ```
  NDVI = (NIR - Red) / (NIR + Red)
  ```
- Typical values:
  - Dense forest: 0.6 to 1.0
  - Sparse vegetation: 0.2 to 0.5
  - Bare soil: 0.1 to 0.2
  - Water: -0.3 to 0.0

**Step 6: Compliance Determination**

- Compares calculated NDVI against SPT threshold
- Determines risk status:
  - **COMPLIANT**: NDVI >= threshold
  - **WARNING**: NDVI >= threshold * 0.9 (within 10%)
  - **BREACH**: NDVI < threshold * 0.9

**Example Workflow:**
```python
# 1. Extract SPT from covenant text
spt = await extract_spt_from_text(covenant_text)
# Returns: threshold=0.8, metric="NDVI Index", penalty_bps=50

# 2. Geocode address
lat, lon = await geocode_address("2847 Timber Ridge Road, Paradise, CA")

# 3. Fetch satellite data
nir_band, red_band = await fetch_sentinel_data(lat, lon)

# 4. Calculate NDVI
ndvi_score = calculate_ndvi(nir_band, red_band)  # e.g., 0.65

# 5. Determine compliance
risk_status = determine_risk_status(ndvi_score, threshold=0.8)
# Returns: "BREACH" (0.65 < 0.8 * 0.9 = 0.72)
```

---

### 3.4 Database & Persistence

**Location:** `app/db/models.py`

#### Database Schema (PostgreSQL with SQLAlchemy ORM)

**1. Users Table**
- OAuth integration (Replit) + JWT authentication
- Roles: viewer, analyst, reviewer, admin
- Password hashing with bcrypt
- Account lockout after 5 failed login attempts (30 min lockout)
- Tracks: email, display_name, profile_image, last_login, failed_login_attempts, locked_until

**2. Documents Table**
- Stores document metadata (title, borrower, total commitment, etc.)
- Links to versions and workflow
- Fields: id, title, borrower_name, borrower_lei, governing_law, total_commitment, currency, agreement_date, sustainability_linked, esg_metadata (JSONB), uploaded_by, current_version_id

**3. DocumentVersions Table**
- Full version history (extracted_data as JSONB)
- Tracks original_text, source_filename, extraction_method (simple/map_reduce)
- Each document can have multiple versions
- Fields: id, document_id, version_number, extracted_data (JSONB), original_text, source_filename, extraction_method, created_by, created_at

**4. Workflows Table**
- State machine: `DRAFT → UNDER_REVIEW → APPROVED → PUBLISHED → ARCHIVED`
- Tracks assignments, due dates, priorities
- Records approval/rejection with timestamps
- Fields: id, document_id, state, assigned_to, submitted_at, approved_at, approved_by, published_at, rejection_reason, due_date, priority

**5. AuditLogs Table**
- Complete audit trail of all actions
- Records: user, action type, target, IP address, user agent, metadata (JSONB)
- Used for compliance and security
- Fields: id, user_id, action (CREATE, UPDATE, DELETE, APPROVE, REJECT, PUBLISH, EXPORT, LOGIN, LOGOUT, BROADCAST), target_type, target_id, action_metadata, ip_address, user_agent, occurred_at

**6. RefreshTokens Table**
- JWT refresh token tracking for secure revocation
- Fields: id, jti (JWT ID), user_id, is_revoked, expires_at, created_at, revoked_at

**7. OAuth Table**
- OAuth token storage for Replit Auth sessions
- Fields: id, user_id, provider, browser_session_key, access_token, refresh_token, token_type, expires_at, id_token

**8. StagedExtractions Table (Legacy)**
- Legacy support for pre-approval staging
- Fields: id, status (PENDING, APPROVED, REJECTED), agreement_data (JSONB), original_text, source_filename, rejection_reason, reviewed_by

**9. LMATemplates Table**
- Stores LMA template files and metadata
- Fields: id, template_code, category, title, description, file_path, is_active, created_at
- Categories: Facility Agreement, Term Sheet, Sustainable Finance, Regulatory, etc.

**10. TemplateFieldMappings Table**
- Maps CDM fields to template placeholders
- Fields: id, template_id, template_field, cdm_field, mapping_type (direct/computed/ai_generated), transformation_rule, is_required

**11. GeneratedDocuments Table**
- Tracks documents generated from templates
- Fields: id, template_id, document_id, cdm_data (JSONB), field_values (JSONB), status, generated_at

**12. Policies Table**
- Stores policy rules and metadata
- Fields: id, name, category, description, status (DRAFT/PENDING_APPROVAL/ACTIVE/ARCHIVED), created_by

**13. PolicyVersions Table**
- Version history for policies
- Fields: id, policy_id, version_number, rules_yaml, status, created_at

**14. PolicyApprovals Table**
- Policy approval workflow tracking
- Fields: id, policy_version_id, approver_id, status, comments, approved_at

**15. PolicyDecisions Table**
- Stores policy evaluation results
- Fields: id, transaction_id, decision (ALLOW/BLOCK/FLAG), rule_applied, cdm_events (JSONB), trace_id, created_at

**16. Applications Table**
- Loan application submissions
- Fields: id, user_id, application_type (INDIVIDUAL/BUSINESS), status (DRAFT/SUBMITTED/UNDER_REVIEW/APPROVED/REJECTED), application_data (JSONB), created_at

**17. Deals Table**
- Deal lifecycle management
- Fields: id, deal_id (unique), applicant_id, application_id, status, deal_type, deal_data (JSONB), folder_path, created_at

**18. DealNotes Table**
- Notes and comments on deals
- Fields: id, deal_id, user_id, note_text, created_at

**19. LoanAssets Table**
- Loan asset information for verification
- Fields: id, deal_id, address, geo_lat, geo_lon, spt_threshold, ndvi_score, risk_status, verified_at

**20. GreenFinanceAssessments Table**
- Green finance compliance assessments
- Fields: id, deal_id, loan_asset_id, assessment_data (JSONB), created_at

**21. CreditRiskAssessments Table**
- Credit risk evaluation results
- Fields: id, deal_id, risk_rating, pd, lgd, ead, rwa, capital_requirement, assessment_data (JSONB), created_at

**22. Inquiries Table**
- User inquiries and support tickets
- Fields: id, user_id, inquiry_type, status, subject, message, response, created_at

**23. Meetings Table**
- Meeting scheduling and management
- Fields: id, organizer_id, title, description, scheduled_at, location, participants (JSONB)

**24. RolePermissions Table**
- Granular permission system
- Fields: id, role, resource, action, conditions (JSONB)

**25. ClauseCache Table**
- Cache for AI-generated clauses to reduce LLM costs
- Fields: id, template_id, clause_type, generated_text, metadata (JSONB), created_at

---

### 3.5 API Layer

**Location:** `app/api/routes.py` (2,700+ lines)

#### Key Endpoints

**Extraction:**
- `POST /api/extract` - Extract from text
  - Request: `{text: str, force_map_reduce: bool}`
  - Response: `{status: str, agreement: CreditAgreement, message: str}`
  
- `POST /api/upload` - Upload PDF/TXT and extract
  - Accepts: multipart/form-data with file
  - Returns: Same as `/api/extract`

**Documents:**
- `GET /api/documents` - List with search/pagination
  - Query params: `search`, `page`, `limit`, `status`, `borrower`
  - Returns: Paginated list of documents with metadata
  
- `POST /api/documents` - Create new document
  - Request: `{title, extracted_data, source_filename, ...}`
  - Creates Document + DocumentVersion + Workflow (DRAFT state)
  
- `GET /api/documents/{id}` - Get with all versions
  - Returns: Document with all versions, workflow state, audit logs
  
- `POST /api/documents/{id}/versions` - Create new version
  - Creates new DocumentVersion, updates Document.current_version_id
  
- `DELETE /api/documents/{id}` - Delete (with permission check)
  - Requires: reviewer/admin role
  - Soft delete (sets workflow to ARCHIVED)

**Workflow:**
- `POST /api/documents/{id}/workflow/submit` - Submit for review
  - Transitions: DRAFT → UNDER_REVIEW
  - Requires: analyst/reviewer/admin role
  
- `POST /api/documents/{id}/workflow/approve` - Approve (reviewer/admin only)
  - Transitions: UNDER_REVIEW → APPROVED
  - Records: approved_at, approved_by
  
- `POST /api/documents/{id}/workflow/reject` - Reject with reason
  - Transitions: UNDER_REVIEW → DRAFT
  - Records: rejection_reason
  
- `POST /api/documents/{id}/workflow/publish` - Publish approved document
  - Transitions: APPROVED → PUBLISHED
  - Broadcasts FDC3 context update

**Analytics:**
- `GET /api/analytics/portfolio` - Portfolio overview
  - Returns: Total commitments by currency, ESG breakdown, workflow distribution
  
- `GET /api/analytics/dashboard` - Dashboard metrics with activity feed
  - Returns: Documents created this week, pending reviews, approved this week, total commitment USD, sustainability percentage, recent activity
  
- `GET /api/analytics/charts` - Time-series data for visualizations
  - Returns: Document creation trends, commitment trends, activity by type

**Export:**
- `GET /api/documents/{id}/export?format=json|csv|excel`
  - JSON: Full nested structure
  - CSV: Flattened single-row format
  - Excel: Multi-sheet workbook (Summary, Facilities, Parties)
  - Uses pandas for data manipulation

**Ground Truth Verification:**
- `POST /api/verify` - Run Ground Truth Protocol
  - Request: `{text: str}` (covenant text)
  - Returns: Legal extraction result, geocoding result, satellite data, NDVI score, compliance status

**Audit:**
- `GET /api/audit-logs` - List with filtering
  - Query params: `user_id`, `action`, `target_type`, `target_id`, `start_date`, `end_date`
  
- `GET /api/documents/{id}/audit-logs` - Document-specific logs

**Multimodal Extraction:**
- `POST /api/audio/transcribe` - Transcribe audio and extract CDM
  - Accepts: audio file (WAV, MP3, M4A, OGG, FLAC, WEBM)
  - Query params: `source_lang`, `target_lang`, `extract_cdm`
  - Returns: Transcription text, optional CDM data
  
- `POST /api/image/extract` - Extract text from images and extract CDM
  - Accepts: multiple image files (PNG, JPEG, WEBP, GIF, BMP, TIFF)
  - Query params: `extract_cdm`
  - Returns: OCR text, optional CDM data
  
- `POST /api/multimodal/fuse` - Fuse data from multiple sources
  - Request: `{audio_cdm, image_cdm, document_cdm, text_cdm, audio_text, image_text, document_text, text_input, use_llm_fusion}`
  - Returns: Unified CreditAgreement with source tracking

**LMA Template Generation:**
- `GET /api/templates` - List available templates
  - Query params: `category`, `search`
  - Returns: List of LMA templates with metadata
  
- `POST /api/templates/{id}/generate` - Generate document from template
  - Request: `{cdm_data, document_id, deal_id, field_overrides}`
  - Returns: Generated document (DOCX)
  
- `GET /api/templates/{id}/mappings` - Get field mappings for template
  - Returns: Template field mappings (CDM → template placeholders)

**Policy Engine:**
- `GET /api/policies` - List policies
  - Query params: `status`, `category`
  - Returns: List of policies with versions
  
- `POST /api/policies` - Create new policy
  - Request: `{name, category, description, rules_yaml, metadata}`
  - Returns: Created policy
  
- `POST /api/policies/{id}/test` - Test policy with transaction
  - Request: `{transaction_data}`
  - Returns: Policy evaluation result
  
- `POST /api/policies/{id}/approve` - Approve policy version
  - Requires: reviewer/admin role
  - Returns: Approval result

**Deal Management:**
- `GET /api/deals` - List deals
  - Query params: `status`, `deal_type`, `page`, `limit`
  - Returns: Paginated list of deals
  
- `POST /api/deals` - Create new deal
  - Request: `{deal_id, applicant_id, application_id, deal_type, deal_data}`
  - Returns: Created deal
  
- `GET /api/deals/{id}` - Get deal details
  - Returns: Deal with documents, notes, loan assets
  
- `POST /api/deals/{id}/notes` - Add note to deal
  - Request: `{note_text}`
  - Returns: Created note

**Applications:**
- `GET /api/applications` - List applications
  - Query params: `status`, `application_type`, `page`, `limit`
  - Returns: Paginated list of applications
  
- `POST /api/applications` - Create application
  - Request: `{application_type, application_data}`
  - Returns: Created application
  
- `POST /api/applications/{id}/create-deal` - Create deal from approved application
  - Requires: Application must be approved
  - Returns: Created deal

**Credit Risk & Green Finance:**
- `POST /api/credit-risk/assess` - Assess credit risk
  - Request: `{deal_id, borrower_data, additional_context}`
  - Returns: Risk assessment (PD, LGD, EAD, RWA, capital requirement)
  
- `POST /green-finance/assess` - Assess green finance compliance
  - Query params: `location_lat`, `location_lon`, `deal_id`, `loan_asset_id`
  - Returns: Green finance assessment with SDG alignment

**Profile Extraction:**
- `POST /api/profile/extract` - Extract profile from documents
  - Accepts: multiple files (PDF, images)
  - Form params: `role`, `existing_profile` (JSON string)
  - Returns: Structured profile data

**Decision Support:**
- `POST /api/chatbot/chat` - Chat with decision support chatbot
  - Request: `{message, conversation_history, cdm_context, deal_id}`
  - Returns: Chatbot response with sources and metadata

---

### 3.6 Frontend Architecture

**Location:** `client/src/`

#### Tech Stack
- **Framework**: React 18 + TypeScript
- **Build Tool**: Vite
- **Styling**: Tailwind CSS
- **State Management**: React Context API
- **Desktop Integration**: FDC3 SDK

#### Main Components

**1. App.tsx** - Main application shell
- Multi-app navigation (Dashboard, Docu-Digitizer, Library, Trade Blotter, GreenLens, Verification Demo, Ground Truth, Risk War Room)
- FDC3 intent handling
- Authentication state management
- Sidebar with collapsible tools
- Theme switching (light/dark)

**2. DocuDigitizer** (`apps/docu-digitizer/DocumentParser.tsx`)
- File upload (PDF/TXT) via drag-and-drop
- Text paste interface
- Extraction progress display
- Review interface for extracted data
- Save to library functionality
- FDC3 broadcast on save

**3. Dashboard** (`components/Dashboard.tsx`)
- Portfolio metrics (total commitments, ESG scores)
- Workflow distribution charts (pie/bar charts)
- Activity feed from audit logs
- Recent documents list
- Real-time updates via FDC3 channels

**4. DocumentHistory** (`components/DocumentHistory.tsx`)
- List all documents with search
- Version history viewer
- Workflow state indicators (color-coded badges)
- Export functionality (JSON/CSV/Excel)
- Filter by status, borrower, date range

**5. ReviewInterface** (`components/ReviewInterface.tsx`)
- Displays extracted data in structured format
- Edit capabilities (inline editing)
- Approve/Reject actions
- Workflow transition buttons
- Validation warnings display

**6. VerificationDashboard** (`components/VerificationDashboard.tsx`)
- Upload credit agreement PDF
- Display extracted SPT and address
- Run verification workflow
- Show satellite imagery (if available)
- Display NDVI score and compliance status
- Map view of asset location

**7. GroundTruthDashboard** (`components/GroundTruthDashboard.tsx`)
- Portfolio map view (Leaflet/React-Leaflet)
- Status indicators (Green=Compliant, Red=Breach, Yellow=Warning)
- Asset creation form
- Filter by compliance status
- Click asset to view details

**8. RiskWarRoom** (`components/RiskWarRoom.tsx`)
- Semantic search interface
- Vector search using pgvector
- FDC3 context listener for automatic focus
- Query examples: "Find all vineyards in California with NDVI < 0.6"
- Results display with compliance status

**9. GreenLens** (`apps/green-lens/GreenLens.tsx`)
- Visualizes ESG margin ratchets
- Shows how interest rate changes based on ESG performance
- Dynamic pricing calculator
- FDC3 context listener for loan data

**10. TradeBlotter** (`apps/trade-blotter/TradeBlotter.tsx`)
- LMA trade ticket interface
- Pre-fills from FDC3 context
- Generates FINOS CDM trade execution events
- Broadcasts trade data to other apps

---

### 3.7 FDC3 Desktop Interoperability

**Location:** `client/src/context/FDC3Context.tsx`, `openfin/`, `finsemble/`

#### FDC3 Integration

**FDC3 2.0 Compliance:**
- Uses OpenFin's built-in FDC3 API (`fdc3InteropApi: "2.0"`)
- Supports Finsemble platform
- App directory registration for intent discovery

**Intents Supported:**
- `ViewLoanAgreement` - Open agreement details
  - Context: `finos.creditnexus.agreement`
  
- `ApproveLoanAgreement` - Approval workflow
  - Context: `finos.creditnexus.agreement`
  
- `ViewESGAnalytics` - ESG dashboard
  - Context: `finos.creditnexus.esgData`
  
- `ExtractCreditAgreement` - Trigger extraction from external app
  - Context: `finos.creditnexus.document`
  
- `ViewPortfolio` - Portfolio overview
  - Context: `finos.creditnexus.portfolio`

**App Channels:**
- `creditnexus.workflow` - Workflow state updates
  - Broadcasts when document state changes
  
- `creditnexus.extraction` - Extraction events
  - Broadcasts when new extraction completes
  
- `creditnexus.portfolio` - Portfolio updates
  - Broadcasts when portfolio metrics change

**Custom Context Types:**
- `finos.creditnexus.agreement` - Credit agreement context
  ```typescript
  {
    type: "fdc3.creditnexus.agreement",
    id: { dealId: string, lin: string },
    agreement: CreditAgreement
  }
  ```
  
- `finos.creditnexus.document` - Document for extraction
  ```typescript
  {
    type: "fdc3.creditnexus.document",
    text: string,
    filename: string
  }
  ```
  
- `finos.creditnexus.portfolio` - Portfolio context
  ```typescript
  {
    type: "fdc3.creditnexus.portfolio",
    totalCommitment: number,
    currency: string,
    esgPercentage: number
  }
  ```
  
- `finos.creditnexus.approvalResult` - Approval results
  ```typescript
  {
    type: "fdc3.creditnexus.approvalResult",
    documentId: number,
    status: "approved" | "rejected",
    reason?: string
  }
  ```
  
- `finos.creditnexus.esgData` - ESG analytics
  ```typescript
  {
    type: "fdc3.creditnexus.esgData",
    ndviScore: number,
    complianceStatus: "COMPLIANT" | "WARNING" | "BREACH",
    threshold: number
  }
  ```

**Example FDC3 Flow:**
```typescript
// 1. User extracts document in Docu-Digitizer
const result = await extractDocument(pdfFile);

// 2. Broadcast to desktop
await fdc3.broadcast({
  type: "fdc3.creditnexus.agreement",
  id: { dealId: result.dealId, lin: result.lin },
  agreement: result.agreement
});

// 3. Trade Blotter receives intent
fdc3.addIntentListener("ViewLoanAgreement", (context) => {
  // Pre-fill trade ticket with loan data
  setTradeData(context.agreement);
});

// 4. GreenLens receives context
fdc3.addContextListener("fdc3.creditnexus.agreement", (context) => {
  // Update ESG margin ratchet visualization
  updateESGVisualization(context.agreement);
});
```

---

### 3.8 LMA Template Generation

**Location:** `app/generation/`, `app/templates/`, `app/db/models.py` (LMATemplate, TemplateFieldMapping, GeneratedDocument)

#### Template System Architecture

**1. Template Storage**
- LMA templates stored as DOCX files in `storage/templates/`
- Template metadata in `lma_templates` table
- Categories: Facility Agreement, Term Sheet, Sustainable Finance, Regulatory, etc.
- Template registry (`app/templates/registry.py`) manages template loading and caching

**2. Field Mapping System**
- Maps CDM fields to template placeholders (e.g., `[BORROWER_NAME]`, `[COMMITMENT_AMOUNT]`)
- Three mapping types:
  - **Direct**: Simple field path (e.g., `parties[role='Borrower'].name`)
  - **Computed**: Transformation rules (e.g., sum of all facility amounts)
  - **AI-Generated**: LLM-generated content for missing fields
- Field mappings stored in `template_field_mappings` table

**3. Document Generation Process**

```python
# From app/generation/service.py
def generate_document(
    template_id: int,
    cdm_data: CreditAgreement,
    field_overrides: Optional[Dict] = None
) -> GeneratedDocument:
    # 1. Load template and mappings
    template = TemplateRegistry.get_template(template_id)
    field_mapper = FieldMapper(template, template.field_mappings)
    
    # 2. Map CDM data to template fields
    mapped_fields = field_mapper.map_cdm_to_template(cdm_data)
    
    # 3. Apply field overrides if provided
    if field_overrides:
        mapped_fields.update(field_overrides)
    
    # 4. Populate missing fields with AI
    ai_populator = AIFieldPopulator(template)
    populated_fields = ai_populator.populate_missing_fields(
        cdm_data, mapped_fields
    )
    
    # 5. Render template with populated fields
    renderer = DocumentRenderer(template)
    generated_doc = renderer.render(populated_fields)
    
    # 6. Store generated document
    return GeneratedDocument(
        template_id=template_id,
        cdm_data=cdm_data.model_dump(),
        field_values=populated_fields,
        status=GeneratedDocumentStatus.DRAFT
    )
```

**4. AI Field Population**
- Uses LLM to generate missing field values
- Context-aware generation based on CDM data
- Caches generated clauses to reduce LLM costs (`clause_cache` table)
- Supports multiple generation strategies (conservative, creative, legal)

**5. Template-Aware Extraction**
- Extraction chain can optimize based on template category
- Provides category-specific guidance to LLM
- Improves extraction accuracy for specialized documents

**Key Endpoints:**
- `GET /api/templates` - List available templates
- `POST /api/templates/{id}/generate` - Generate document from template
- `GET /api/templates/{id}/mappings` - Get field mappings

---

### 3.9 Policy Engine & Compliance

**Location:** `app/services/policy_service.py`, `app/services/policy_engine_interface.py`, `app/policies/`, `app/models/cdm_events.py`

#### Policy Engine Architecture

**1. Policy-as-Code Rules**
- Policies defined in YAML files (`app/policies/*.yaml`)
- Rule structure:
  ```yaml
  - name: block_sanctioned_parties
    when:
      any:
        - field: originator.lei
          op: in
          value: ["SANCTIONED_LEI_LIST"]
    action: block
    priority: 100
    description: "Block transactions with sanctioned entities"
  ```
- Supports multiple rule types: `block`, `flag`, `allow`
- Rule priority determines evaluation order

**2. Policy Evaluation Process (CDM-Compliant)**

```python
# From app/services/policy_service.py
def evaluate_with_cdm_process(
    cdm_event: Dict[str, Any],
    credit_agreement: Optional[CreditAgreement] = None
) -> Dict[str, Any]:
    # STEP 1: VALIDATION (CDM principle)
    self._validate_cdm_event(cdm_event)
    
    # STEP 2: CALCULATION (Policy evaluation)
    policy_transaction = self._cdm_to_policy_transaction(cdm_event, credit_agreement)
    evaluation_result = self.engine.evaluate(policy_transaction)
    
    # STEP 3: EVENT CREATION (CDM event model)
    policy_event = generate_cdm_policy_evaluation(
        transaction_id=...,
        transaction_type=...,
        decision=evaluation_result["decision"],  # ALLOW/BLOCK/FLAG
        rule_applied=evaluation_result.get("rule"),
        related_event_identifiers=[...],
        evaluation_trace=evaluation_result.get("trace", [])
    )
    
    return {
        "policy_evaluation_event": policy_event,
        "decision": evaluation_result["decision"],
        "rule_applied": evaluation_result.get("rule")
    }
```

**3. Policy Evaluation Methods**
- `evaluate_facility_creation()`: For document extraction
- `evaluate_trade_execution()`: For trade execution
- `evaluate_loan_asset()`: For loan asset verification
- `evaluate_terms_change()`: For interest rate changes

**4. Policy Editor & Approval Workflow**
- Policy editor UI (`apps/policy-editor/`)
- Policy versioning (`policy_versions` table)
- Approval workflow: DRAFT → PENDING_APPROVAL → ACTIVE → ARCHIVED
- Policy testing with transaction builder
- Policy validation before activation

**5. CDM Policy Events**
- All policy decisions stored as CDM `PolicyEvaluation` events
- Events include: transaction_id, decision, rule_applied, evaluation_trace
- Linked to related events via `relatedEventIdentifier`
- Full audit trail for compliance

**Key Endpoints:**
- `GET /api/policies` - List policies
- `POST /api/policies` - Create policy
- `POST /api/policies/{id}/test` - Test policy
- `POST /api/policies/{id}/approve` - Approve policy version

---

### 3.10 Deal Management & Applications

**Location:** `app/services/deal_service.py`, `app/db/models.py` (Deal, Application, DealNote)

#### Application Processing

**1. Application Types**
- **Individual**: Personal loan applications
- **Business**: Business loan applications
- Application data stored as JSONB for flexibility

**2. Application Workflow**
```
DRAFT → SUBMITTED → UNDER_REVIEW → APPROVED/REJECTED
```

**3. Deal Creation from Application**
- Approved applications can be converted to deals
- Deal service creates:
  - Deal record with unique `deal_id`
  - Deal folder structure for document storage
  - Links application to deal

**4. Deal Lifecycle**
```
DRAFT → SUBMITTED → UNDER_REVIEW → APPROVED → ACTIVE → CLOSED
```

**5. Deal Features**
- **Deal Notes**: Collaboration via notes and comments
- **Document Organization**: Deal-based folder structure
- **Loan Assets**: Track loan assets for verification
- **Deal Types**: loan_application, debt_sale, loan_purchase, refinancing, restructuring

**6. Deal Service Methods**
```python
# From app/services/deal_service.py
class DealService:
    def create_deal_from_application(
        self, application_id: int, deal_type: Optional[str] = None
    ) -> Deal:
        # Creates deal from approved application
        # Generates unique deal_id
        # Creates folder structure
        # Links application to deal
    
    def update_deal_on_verification(
        self, deal_id: int, verification_result: Dict
    ) -> Deal:
        # Updates deal with satellite verification results
        # Creates CDM events for breaches
        # Updates loan asset risk status
```

**Key Endpoints:**
- `GET /api/applications` - List applications
- `POST /api/applications` - Create application
- `POST /api/applications/{id}/create-deal` - Create deal from application
- `GET /api/deals` - List deals
- `POST /api/deals/{id}/notes` - Add note to deal

---

### 3.11 Credit Risk & Green Finance Assessment

**Location:** `app/services/credit_risk_service.py`, `app/api/credit_risk_routes.py`, `app/api/green_finance_routes.py`

#### Credit Risk Assessment

**1. Risk Metrics Calculation**
- **Probability of Default (PD)**: Likelihood of borrower default
- **Loss Given Default (LGD)**: Expected loss if default occurs
- **Exposure at Default (EAD)**: Expected exposure at time of default
- **Risk-Weighted Assets (RWA)**: Capital requirement calculation
- **Capital Requirement**: Regulatory capital needed

**2. CDM Credit Risk Events**
- All assessments stored as CDM `CreditRiskAssessment` events
- Events include: risk_rating, PD, LGD, EAD, RWA, capital_requirement
- Linked to deals and transactions

#### Green Finance Assessment

**1. Assessment Components**
- **SDG Alignment**: UN Sustainable Development Goals alignment
- **Urban Sustainability**: Urban development sustainability metrics
- **Emissions Compliance**: CO2 emissions monitoring
- **Environmental Impact**: Multi-dimensional environmental metrics

**2. Enhanced Satellite Verification**
- OpenStreetMap integration for location context
- Air quality monitoring integration
- Multi-dimensional environmental metrics
- Sustainability scoring

**Key Endpoints:**
- `POST /api/credit-risk/assess` - Assess credit risk
- `POST /green-finance/assess` - Assess green finance compliance

---

### 3.12 Decision Support & Profile Extraction

**Location:** `app/chains/decision_support_chain.py`, `app/services/profile_extraction_service.py`

#### Decision Support Chatbot

**1. RAG Architecture**
- Uses ChromaDB vector store for knowledge base
- Retrieves relevant context from:
  - LMA template documentation
  - CDM schema documentation
  - Template field mappings
  - Historical decisions

**2. Chatbot Capabilities**
- Answers questions about LMA templates
- Provides CDM schema guidance
- Helps with template selection
- Assists with field filling
- General document generation assistance

#### Profile Extraction

**1. Profile Data Structure**
- Extracts structured profile data from documents
- Supports multiple roles: applicant, banker, law_officer, accountant
- Merges with existing profile data
- Returns `UserProfileData` model

**2. Extraction Process**
- Extracts text from uploaded files (PDF, images)
- Uses LLM to extract structured profile data
- Merges with existing profile if provided
- Returns structured profile for signup/pre-filling

**Key Endpoints:**
- `POST /api/chatbot/chat` - Chat with decision support chatbot
- `POST /api/profile/extract` - Extract profile from documents

---

### 3.13 Authentication & Security

**Location:** `app/auth/jwt_auth.py`, `app/auth/routes.py`

#### Security Features

**JWT Authentication:**
- Access tokens: 30-minute expiry
- Refresh tokens: 7-day expiry
- Token blacklisting for logout (stored in RefreshTokens table)
- HS256 algorithm for signing

**Password Security:**
- Requirements: 12+ chars, uppercase, lowercase, number, special char
- bcrypt hashing with salt rounds
- Password change tracking (password_changed_at)

**Account Protection:**
- Account lockout after 5 failed attempts
- 30-minute lockout period
- Tracks: failed_login_attempts, locked_until

**Role-Based Access Control (RBAC):**
- **viewer**: Read-only access
- **analyst**: Can create documents, submit for review
- **reviewer**: Can approve/reject, publish documents
- **admin**: Full access, user management
- **auditor**: Full oversight, read-only access to all
- **banker**: Write permissions for deals, documents
- **law_officer**: Write/edit for legal documents
- **accountant**: Write/edit for financial data
- **applicant**: Apply and track applications

**Signup Approval Workflow:**
- New user signups require approval
- Signup status: pending → approved/rejected
- Admin/reviewer can approve/reject signups
- Rejection reasons tracked

**Audit Logging:**
- All actions logged with: user, action type, target, IP address, user agent, metadata
- Used for compliance and security investigations

**Authentication Flow:**
```
1. User logs in with email/password or OAuth (Replit)
2. Server validates credentials, checks lockout status
3. Returns JWT access token + refresh token
4. Frontend stores tokens in memory (not localStorage for security)
5. Server validates JWT on protected endpoints (Bearer token in Authorization header)
6. Refresh token used to get new access token when expired
7. Logout revokes refresh token (blacklists it)
```

---

### 3.9 Workflow State Machine

**States:**
```
DRAFT → UNDER_REVIEW → APPROVED → PUBLISHED
         ↓ (reject)
       DRAFT
```

**Transitions:**

1. **Submit** (DRAFT → UNDER_REVIEW)
   - Requires: analyst/reviewer/admin role
   - Sets: submitted_at timestamp
   - Can assign to specific reviewer
   - Can set priority (low, normal, high, urgent)
   - Can set due_date

2. **Approve** (UNDER_REVIEW → APPROVED)
   - Requires: reviewer/admin role
   - Sets: approved_at, approved_by
   - Clears: rejection_reason
   - Broadcasts FDC3 context update

3. **Reject** (UNDER_REVIEW → DRAFT)
   - Requires: reviewer/admin role
   - Sets: rejection_reason (required)
   - Clears: approved_at, approved_by
   - Document returns to DRAFT for corrections

4. **Publish** (APPROVED → PUBLISHED)
   - Requires: reviewer/admin role
   - Sets: published_at
   - Document is now "live" in portfolio
   - Broadcasts FDC3 portfolio update

5. **Archive** (Any state → ARCHIVED)
   - Requires: reviewer/admin role
   - Soft delete - document hidden from normal views
   - Can be restored by admin

**Workflow Features:**
- Assignment to specific reviewers
- Priority levels (low, normal, high, urgent)
- Due dates for reviews
- Rejection reasons tracked
- Full audit trail of all transitions
- Email notifications (if configured)

---

### 3.10 Analytics & Reporting

**Portfolio Analytics:**
- Total commitments by currency (USD, EUR, GBP, JPY)
- ESG breakdown (sustainability-linked vs. non-sustainability)
- Workflow distribution (how many in each state)
- Maturity timeline (upcoming maturities)
- Recent activity feed (from audit logs)

**Dashboard Metrics:**
- Documents created this week vs. last week (trend)
- Pending reviews count
- Approved this week
- Total commitment USD
- Sustainability percentage

**Chart Data:**
- Document creation trends over time (line chart)
- Commitment trends (area chart)
- Activity by type (bar chart: create, update, approve, etc.)
- Workflow pipeline visualization (sankey diagram)

**Export Functionality:**
- **JSON**: Full nested structure (preserves all relationships)
- **CSV**: Flattened single-row format (one row per document)
- **Excel**: Multi-sheet workbook
  - Summary sheet: All document-level data
  - Facilities sheet: One row per facility (denormalized)
  - Parties sheet: One row per party (denormalized)

**Export Process:**
```python
# 1. Retrieve document version from database
version = db.query(DocumentVersion).filter_by(document_id=doc_id).first()

# 2. Flatten nested structure for tabular formats
if format == "csv" or format == "excel":
    # Create pandas DataFrames
    summary_df = flatten_document(version.extracted_data)
    facilities_df = flatten_facilities(version.extracted_data["facilities"])
    parties_df = flatten_parties(version.extracted_data["parties"])

# 3. Generate file
if format == "excel":
    with pd.ExcelWriter(buffer) as writer:
        summary_df.to_excel(writer, sheet_name="Summary")
        facilities_df.to_excel(writer, sheet_name="Facilities")
        parties_df.to_excel(writer, sheet_name="Parties")

# 4. Stream to client
return StreamingResponse(buffer, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

# 5. Log export action
log_audit_action(db, AuditAction.EXPORT, "document", doc_id, user_id)
```

---

## Part 4: Data Flow Examples

### Example 1: Document Extraction Workflow

```
1. User uploads PDF "Credit_Agreement_ACME_2023.pdf"
   ↓
2. Backend extracts text using PyMuPDF
   ↓
3. Text length = 35,000 chars → Simple extraction strategy
   ↓
4. LangChain + GPT-4o extracts structured data
   ↓
5. Pydantic validates against CDM schema
   ↓
6. If validation fails → Reflexion retry (up to 3 attempts)
   ↓
7. ExtractionResult returned:
   {
     status: "success",
     agreement: {
       agreement_date: "2023-10-15",
       parties: [
         {name: "ACME INDUSTRIES INC.", role: "Borrower", lei: "549300ABCDEF12345678"},
         {name: "GLOBAL BANK CORP.", role: "Lender", lei: "549300GHIJKL98765432"}
       ],
       facilities: [
         {
           facility_name: "Term Loan Facility",
           commitment_amount: {amount: 500000000, currency: "USD"},
           interest_terms: {
             rate_option: {benchmark: "Term SOFR", spread_bps: 275.0},
             payment_frequency: {period: "Month", period_multiplier: 3}
           },
           maturity_date: "2028-10-15"
         }
       ],
       governing_law: "NY"
     }
   }
   ↓
8. Frontend displays extracted data in ReviewInterface
   ↓
9. User reviews and clicks "Save to Library"
   ↓
10. Backend creates:
    - Document record
    - DocumentVersion record (extracted_data as JSONB)
    - Workflow record (state: DRAFT)
    - AuditLog record (action: CREATE)
   ↓
11. Frontend shows success message
```

### Example 2: Ground Truth Verification Workflow

```
1. User uploads credit agreement with sustainability covenant
   ↓
2. Legal Agent extracts SPT:
   {
     resource_target: {
       metric: "NDVI Index",
       threshold: 0.8,
       direction: "greater_than"
     },
     financial_consequence: {
       penalty_bps: 50,
       trigger_mechanism: "automatic"
     }
   }
   ↓
3. Legal Agent extracts collateral address:
   {
     full_address: "2847 Timber Ridge Road, Paradise, CA 95969",
     street: "2847 Timber Ridge Road",
     city: "Paradise",
     state: "CA",
     postal_code: "95969",
     country: "USA"
   }
   ↓
4. Geocoding converts address to coordinates:
   (39.7596, -121.6219)
   ↓
5. Sentinel Hub fetches satellite imagery:
   - Bounding box: 1km x 1km around coordinates
   - Time range: Last 90 days
   - Bands: NIR (Band 8), Red (Band 4)
   - Returns: 100x100 pixel arrays
   ↓
6. TorchGeo ResNet-50 classifies land use:
   Classification: "Forest"
   Confidence: 0.92
   ↓
7. NDVI calculation:
   NDVI = (NIR_mean - Red_mean) / (NIR_mean + Red_mean)
   NDVI = (0.65 - 0.12) / (0.65 + 0.12) = 0.69
   ↓
8. Compliance determination:
   Threshold: 0.8
   NDVI: 0.69
   Status: BREACH (0.69 < 0.8 * 0.9 = 0.72)
   ↓
9. Result returned:
   {
     success: true,
     ndvi_score: 0.69,
     risk_status: "BREACH",
     threshold: 0.8,
     classification: "Forest",
     confidence: 0.92,
     verified_at: "2024-01-15T10:30:00Z"
   }
   ↓
10. Frontend displays:
    - Map with asset location
    - NDVI score visualization
    - Compliance status (red badge: BREACH)
    - Margin penalty warning (+50 bps)
   ↓
11. FDC3 broadcast:
    {
      type: "fdc3.creditnexus.esgData",
      ndviScore: 0.69,
      complianceStatus: "BREACH",
      threshold: 0.8
    }
   ↓
12. Risk War Room automatically highlights asset
```

### Example 3: FDC3 Desktop Interoperability Flow

```
1. User extracts document in Docu-Digitizer
   ↓
2. Document saved to library
   ↓
3. Frontend broadcasts FDC3 context:
   fdc3.broadcast({
     type: "fdc3.creditnexus.agreement",
     id: { dealId: "DEAL-2023-001", lin: "LIN-12345" },
     agreement: { ... }
   })
   ↓
4. Trade Blotter receives context:
   - Listens for "fdc3.creditnexus.agreement"
   - Pre-fills trade ticket:
     * Borrower: "ACME INDUSTRIES INC."
     * Facility: "Term Loan Facility"
     * Amount: $500,000,000
     * Currency: USD
   ↓
5. GreenLens receives context:
   - Listens for "fdc3.creditnexus.agreement"
   - Checks if sustainability_linked: true
   - Displays ESG margin ratchet visualization
   - Shows current NDVI score and compliance status
   ↓
6. User clicks "Approve" in ReviewInterface
   ↓
7. Backend transitions workflow: UNDER_REVIEW → APPROVED
   ↓
8. Backend broadcasts on workflow channel:
   fdc3.broadcastOnChannel("creditnexus.workflow", {
     type: "fdc3.creditnexus.approvalResult",
     documentId: 123,
     status: "approved"
   })
   ↓
9. All apps listening to workflow channel update:
   - Dashboard: Updates pending reviews count
   - DocumentHistory: Updates document status badge
   - Trade Blotter: Enables trade execution button
```

---

## Part 5: Key Technologies & Dependencies

### Backend Stack
- **FastAPI**: Modern Python web framework for APIs
- **SQLAlchemy 2.0**: ORM for database operations
- **PostgreSQL**: Primary database with JSONB support
- **pgvector**: Vector similarity search extension
- **Pydantic 2.0**: Data validation and settings management
- **LangChain**: LLM orchestration framework
- **OpenAI GPT-4o**: Large language model for extraction
- **PyMuPDF (fitz)**: PDF text extraction
- **TorchGeo**: Geospatial deep learning library
- **Sentinel Hub**: Satellite imagery API
- **geopy**: Geocoding library
- **bcrypt**: Password hashing
- **PyJWT**: JWT token handling
- **Alembic**: Database migrations

### Frontend Stack
- **React 18**: UI framework
- **TypeScript**: Type-safe JavaScript
- **Vite**: Build tool and dev server
- **Tailwind CSS**: Utility-first CSS framework
- **FDC3 SDK**: Desktop interoperability
- **React-Leaflet**: Map visualization
- **Axios**: HTTP client

### AI/ML Stack
- **OpenAI GPT-4o**: Text extraction and analysis
- **LangChain**: Structured outputs, map-reduce patterns
- **TorchGeo ResNet-50**: Land use classification
- **Sentinel-2**: Multispectral satellite imagery
- **NumPy**: Numerical computations
- **OpenAI Embeddings**: Vector generation for semantic search

### Security Stack
- **JWT**: Token-based authentication
- **bcrypt**: Password hashing
- **OAuth2 PKCE**: Replit authentication
- **Role-Based Access Control**: Permission system
- **Audit Logging**: Compliance tracking

### Data Standards
- **FINOS Common Domain Model (CDM)**: Financial data standardization
- **FDC3 2.0**: Desktop interoperability standard
- **ISO 8601**: Date format standard

---

## Part 6: Deployment & Configuration

### Environment Variables

**Required:**
- `OPENAI_API_KEY`: OpenAI API key for GPT-4o access

**Optional:**
- `DATABASE_URL`: PostgreSQL connection string (default: SQLite for dev)
- `SESSION_SECRET`: Secret key for session middleware
- `JWT_SECRET_KEY`: Secret key for JWT signing
- `JWT_ALGORITHM`: JWT algorithm (default: HS256)
- `SENTINELHUB_KEY`: Sentinel Hub API key
- `SENTINELHUB_SECRET`: Sentinel Hub API secret
- `REPLIT_DEPLOYMENT`: Set to "1" for production mode

### Database Setup

```bash
# Initialize database
alembic upgrade head

# Create initial admin user (via API or script)
POST /api/auth/register
{
  "email": "admin@example.com",
  "password": "SecurePassword123!",
  "display_name": "Admin User",
  "role": "admin"
}
```

### Running the Application

**Backend:**
```bash
# Development
uvicorn server:app --reload --host 127.0.0.1 --port 8000

# Production
uvicorn server:app --host 0.0.0.0 --port 8000
```

**Frontend:**
```bash
cd client
npm install
npm run dev  # Development (port 5173)
npm run build  # Production build
```

### OpenFin Deployment

1. Replace `${APP_URL}` in `openfin/app.json` with actual URL
2. Host `openfin/app.json` at accessible URL
3. Launch OpenFin with manifest URL:
   ```bash
   openfin --launch --config https://your-app.com/openfin/app.json
   ```

---

## Part 7: Future Enhancements & Roadmap

### Planned Features

1. **Real-Time Collaboration**
   - WebSocket support for live document editing
   - Multi-user review sessions
   - Real-time FDC3 context updates

2. **Advanced Analytics**
   - Machine learning for risk prediction
   - Portfolio optimization recommendations
   - ESG scoring algorithms

3. **Enhanced Ground Truth**
   - Multi-temporal NDVI analysis (trend detection)
   - Integration with other satellite providers (Landsat, MODIS)
   - Automated breach notifications

4. **Document Intelligence**
   - OCR for scanned PDFs
   - Table extraction from financial statements
   - Multi-document relationship mapping

5. **Compliance & Reporting**
   - Regulatory report generation
   - Automated compliance checks
   - Integration with regulatory systems

---

## Conclusion

CreditNexus is a sophisticated financial AI platform that combines:
- **AI-powered document extraction** using state-of-the-art LLMs
- **Satellite-based verification** using deep learning and geospatial intelligence
- **Workflow management** with role-based access control
- **Desktop interoperability** via FDC3 standards
- **Portfolio analytics** with real-time updates

The platform bridges the gap between legal contracts and physical reality, enabling financial institutions to automate credit agreement processing and verify sustainability-linked loan compliance using satellite data.

**Key Innovation:** The "Ground Truth Protocol" - automatically verifying loan covenant compliance by comparing satellite-derived metrics (NDVI) against contractually specified thresholds, enabling real-time risk assessment and automated margin adjustments.

---

*Built with ❤️ by the CreditNexus Team - "Trust, but Verify (from Space)."*

