# LMA Template System - Detailed Implementation Plan

## Overview

This document provides a comprehensive, structured implementation plan for integrating LMA document template generation into CreditNexus. The plan is organized by Projects, Activities, File-level Tasks, and Line-level Subtasks.

> **Note:** For multimodal input support (audio, images, documents) and decision support chatbot, see `LMA_MULTIMODAL_ENHANCEMENT.md`

---

## Template Inventory (Dummy/Generated Data)

### Template Categories and Counts

| Category | Template Count | Key Templates |
|----------|---------------|---------------|
| **Facility Agreements** | 45 | Corporate Lending, REF, Leveraged, Investment Grade, Bilateral |
| **Term Sheets** | 12 | Corporate, REF, Leveraged, Bilateral |
| **Confidentiality Agreements** | 9 | Primary Syndication, Master, Agent/Broker variants |
| **Secondary Trading** | 35 | Trade Confirmations, Assignments, Participations |
| **Security & Intercreditor** | 12 | Security Agreements, Intercreditor Agreements |
| **Origination Documents** | 15 | Mandate Letters, Commitment Letters, Coordinator Letters |
| **Sustainable Finance** | 25 | SLL, Use of Proceeds, SF Resources |
| **Regional Documents** | 22 | German, French, Spanish, African variants |
| **Regulatory** | 14 | BRRD, NPL Directive, Tax (DAC 6, FATCA) |
| **Restructuring** | 5 | Amendment Agreements, Waiver Letters |
| **Supporting Documents** | 110 | Guidance Notes, User Guides, Riders, Glossaries |
| **TOTAL** | **304** | |

### Sample Template Metadata (Generated)

```json
{
  "templates": [
    {
      "id": "LMA-CL-FA-2024-EN",
      "code": "CL-FA-EN",
      "name": "Corporate Lending Facility Agreement (English Law)",
      "category": "Facility Agreement",
      "subcategory": "Corporate Lending - Syndicated",
      "governing_law": "English",
      "version": "2024.1",
      "file_path": "templates/facility_agreements/corporate_lending/english/CL-FA-EN-2024.1.docx",
      "required_cdm_fields": [
        "parties[role='Borrower'].name",
        "parties[role='Borrower'].lei",
        "facilities[0].facility_name",
        "facilities[0].commitment_amount.amount",
        "facilities[0].commitment_amount.currency",
        "facilities[0].maturity_date",
        "facilities[0].interest_terms.rate_option.benchmark",
        "facilities[0].interest_terms.rate_option.spread_bps",
        "agreement_date",
        "governing_law"
      ],
      "optional_cdm_fields": [
        "parties[role='Administrative Agent']",
        "parties[role='Lender']",
        "sustainability_linked",
        "esg_kpi_targets",
        "deal_id",
        "loan_identification_number"
      ],
      "ai_generated_sections": [
        "representations_and_warranties",
        "conditions_precedent",
        "covenants",
        "events_of_default",
        "governing_law_clause"
      ],
      "estimated_generation_time_seconds": 25
    },
    {
      "id": "LMA-CL-TS-2024-EN",
      "code": "CL-TS-EN",
      "name": "Corporate Lending Term Sheet (English Law)",
      "category": "Term Sheet",
      "subcategory": "Corporate Lending",
      "governing_law": "English",
      "version": "2024.1",
      "file_path": "templates/term_sheets/corporate_lending/english/CL-TS-EN-2024.1.docx",
      "required_cdm_fields": [
        "parties[role='Borrower'].name",
        "facilities[0].facility_name",
        "facilities[0].commitment_amount.amount",
        "facilities[0].commitment_amount.currency",
        "facilities[0].maturity_date",
        "facilities[0].interest_terms.rate_option.benchmark",
        "facilities[0].interest_terms.rate_option.spread_bps"
      ],
      "optional_cdm_fields": [
        "agreement_date",
        "governing_law",
        "sustainability_linked"
      ],
      "ai_generated_sections": [
        "purpose",
        "conditions_precedent",
        "representations",
        "fees"
      ],
      "estimated_generation_time_seconds": 15
    },
    {
      "id": "LMA-REF-FA-2024-EN",
      "code": "REF-FA-EN",
      "name": "Real Estate Finance Facility Agreement (English Law)",
      "category": "Facility Agreement",
      "subcategory": "Real Estate Finance",
      "governing_law": "English",
      "version": "2024.1",
      "file_path": "templates/facility_agreements/real_estate/english/REF-FA-EN-2024.1.docx",
      "required_cdm_fields": [
        "parties[role='Borrower'].name",
        "facilities[0].facility_name",
        "facilities[0].commitment_amount.amount",
        "facilities[0].commitment_amount.currency",
        "facilities[0].maturity_date",
        "facilities[0].interest_terms.rate_option.benchmark",
        "facilities[0].interest_terms.rate_option.spread_bps"
      ],
      "optional_cdm_fields": [
        "sustainability_linked",
        "esg_kpi_targets"
      ],
      "ai_generated_sections": [
        "property_description",
        "security_package",
        "valuation_requirements",
        "representations_and_warranties",
        "conditions_precedent"
      ],
      "estimated_generation_time_seconds": 30
    },
    {
      "id": "LMA-CONF-PS-2024",
      "code": "CONF-PS",
      "name": "Confidentiality and No Front Running - Primary Syndication",
      "category": "Confidentiality Agreement",
      "subcategory": "Primary Syndication",
      "governing_law": "English",
      "version": "2024.1",
      "file_path": "templates/confidentiality/primary_syndication/CONF-PS-2024.1.docx",
      "required_cdm_fields": [
        "parties[role='Borrower'].name"
      ],
      "optional_cdm_fields": [
        "deal_id"
      ],
      "ai_generated_sections": [
        "confidentiality_obligations",
        "no_front_running_undertaking",
        "permitted_disclosures"
      ],
      "estimated_generation_time_seconds": 10
    },
    {
      "id": "LMA-SLL-FA-2024-EN",
      "code": "SLL-FA-EN",
      "name": "Sustainability-Linked Loan Facility Agreement (English Law)",
      "category": "Facility Agreement",
      "subcategory": "Sustainable Finance",
      "governing_law": "English",
      "version": "2024.1",
      "file_path": "templates/facility_agreements/sustainable/sll/english/SLL-FA-EN-2024.1.docx",
      "required_cdm_fields": [
        "parties[role='Borrower'].name",
        "facilities[0].facility_name",
        "facilities[0].commitment_amount.amount",
        "facilities[0].commitment_amount.currency",
        "facilities[0].maturity_date",
        "sustainability_linked",
        "esg_kpi_targets"
      ],
      "optional_cdm_fields": [
        "deal_id"
      ],
      "ai_generated_sections": [
        "spt_definitions",
        "spt_measurement_methodology",
        "margin_adjustment_mechanism",
        "reporting_requirements",
        "verification_process"
      ],
      "estimated_generation_time_seconds": 40
    }
  ]
}
```

---

## Project Structure

### PROJECT 1: Template Infrastructure & Data Models
**Duration:** 2 weeks  
**Priority:** Critical

### PROJECT 2: CDM Mapping & Field Population Engine
**Duration:** 3 weeks  
**Priority:** Critical

### PROJECT 3: Document Generation & Rendering
**Duration:** 2 weeks  
**Priority:** Critical

### PROJECT 4: Frontend Document Generator App
**Duration:** 3 weeks  
**Priority:** High

### PROJECT 5: Workflow Integration & Enhancements
**Duration:** 2 weeks  
**Priority:** High

### PROJECT 6: Existing Feature Enhancements
**Duration:** 2 weeks  
**Priority:** Medium

### PROJECT 7: Testing & Documentation
**Duration:** 1 week  
**Priority:** High

---

## PROJECT 1: Template Infrastructure & Data Models

### Activity 1.1: Database Schema Design

#### Task 1.1.1: Create Alembic Migration for Template Tables
**File:** `alembic/versions/xxx_add_lma_templates_tables.py`

**Subtasks:**
1. Line 1-10: Import required modules (alembic, sqlalchemy, JSONB)
2. Line 11-20: Define `upgrade()` function
3. Line 21-30: Create `lma_templates` table with columns:
   - `id` (Integer, primary key)
   - `template_code` (String(50), unique, not null)
   - `name` (String(255), not null)
   - `category` (String(100), not null)
   - `subcategory` (String(100))
   - `governing_law` (String(50))
   - `version` (String(20), not null)
   - `file_path` (Text, not null)
   - `metadata` (JSONB)
   - `required_fields` (JSONB)
   - `optional_fields` (JSONB)
   - `ai_generated_sections` (JSONB)
   - `created_at`, `updated_at` (DateTime)
4. Line 31-40: Create `generated_documents` table with columns:
   - `id` (Integer, primary key)
   - `template_id` (Integer, foreign key to lma_templates)
   - `source_document_id` (Integer, foreign key to documents, nullable)
   - `cdm_data` (JSONB, not null)
   - `generated_content` (Text)
   - `file_path` (Text)
   - `status` (String(50), default 'draft')
   - `generation_summary` (JSONB)
   - `created_by` (Integer, foreign key to users)
   - `created_at`, `updated_at` (DateTime)
5. Line 41-50: Create `template_field_mappings` table with columns:
   - `id` (Integer, primary key)
   - `template_id` (Integer, foreign key to lma_templates)
   - `template_field` (String(255), not null)
   - `cdm_field` (String(255), not null)
   - `mapping_type` (String(50)) - 'direct', 'computed', 'ai_generated'
   - `transformation_rule` (Text)
   - `is_required` (Boolean, default False)
   - `created_at` (DateTime)
6. Line 51-60: Create indexes on:
   - `lma_templates.template_code`
   - `lma_templates.category`
   - `generated_documents.template_id`
   - `generated_documents.source_document_id`
   - `generated_documents.status`
   - `template_field_mappings.template_id`
7. Line 61-70: Define `downgrade()` function to drop tables
8. Line 71-80: Add table comments and constraints

#### Task 1.1.2: Create SQLAlchemy Models
**File:** `app/db/models.py`

**Subtasks:**
1. Line 1-10: Import required modules (Base, Column, Integer, String, Text, DateTime, ForeignKey, JSONB, relationship)
2. Line 11-20: Add `LMATemplate` class after `Workflow` class:
   - Define `__tablename__ = "lma_templates"`
   - Add all columns matching migration
   - Add `to_dict()` method
3. Line 21-30: Add `GeneratedDocument` class:
   - Define `__tablename__ = "generated_documents"`
   - Add relationships to `LMATemplate`, `Document`, `User`
   - Add `to_dict()` method
4. Line 31-40: Add `TemplateFieldMapping` class:
   - Define `__tablename__ = "template_field_mappings"`
   - Add relationship to `LMATemplate`
   - Add `to_dict()` method
5. Line 41-50: Add enum classes:
   - `TemplateCategory` (Facility Agreement, Term Sheet, etc.)
   - `GeneratedDocumentStatus` (draft, review, approved, executed)
   - `MappingType` (direct, computed, ai_generated)

### Activity 1.2: Template Storage System

#### Task 1.2.1: Create Template Storage Module
**File:** `app/templates/storage.py`

**Subtasks:**
1. Line 1-15: Import modules (os, pathlib, logging, Optional, List)
2. Line 16-25: Define `TEMPLATE_BASE_PATH` constant
3. Line 26-35: Create `TemplateStorage` class with `__init__()` method
4. Line 36-45: Implement `get_template_path(template_code: str, version: str) -> str`:
   - Construct path from template_code and version
   - Validate file exists
   - Return absolute path
5. Line 46-55: Implement `list_templates(category: Optional[str] = None) -> List[dict]`:
   - Scan template directory structure
   - Return list of available templates with metadata
6. Line 56-65: Implement `load_template(template_code: str, version: str) -> bytes`:
   - Read template file as binary
   - Return file content
7. Line 66-75: Implement `save_generated_document(content: bytes, filename: str) -> str`:
   - Save to `storage/generated/` directory
   - Return file path
8. Line 76-85: Implement `get_generated_document_path(document_id: int) -> str`:
   - Construct path from document_id
   - Return absolute path

#### Task 1.2.2: Create Template Registry
**File:** `app/templates/registry.py`

**Subtasks:**
1. Line 1-15: Import modules (Session, List, Optional, Dict)
2. Line 16-25: Create `TemplateRegistry` class
3. Line 26-35: Implement `get_template(db: Session, template_id: int) -> LMATemplate`:
   - Query database for template
   - Raise 404 if not found
   - Return template object
4. Line 36-45: Implement `list_templates(db: Session, category: Optional[str] = None) -> List[LMATemplate]`:
   - Query with optional category filter
   - Return list of templates
5. Line 46-55: Implement `get_template_by_code(db: Session, code: str) -> Optional[LMATemplate]`:
   - Query by template_code
   - Return template or None
6. Line 56-65: Implement `register_template(db: Session, template_data: dict) -> LMATemplate`:
   - Create new LMATemplate instance
   - Save to database
   - Return created template
7. Line 66-75: Implement `get_required_fields(template: LMATemplate) -> List[str]`:
   - Parse required_fields JSONB
   - Return list of CDM field paths

### Activity 1.3: Seed Template Data

#### Task 1.3.1: Create Template Seeder Script
**File:** `scripts/seed_templates.py`

**Subtasks:**
1. Line 1-20: Import modules (sys, pathlib, json, Session)
2. Line 21-30: Load template metadata from JSON file
3. Line 31-40: Create function `seed_templates(db: Session, templates_data: List[dict])`:
   - Iterate through templates
   - Check if template exists by code
   - Create if doesn't exist
4. Line 41-50: Create function `seed_field_mappings(db: Session, template_id: int, mappings: List[dict])`:
   - Create TemplateFieldMapping records
   - Link to template
5. Line 51-60: Main execution block:
   - Connect to database
   - Load seed data
   - Call seed functions
   - Commit transaction

#### Task 1.3.2: Create Dummy Template Files
**File:** `scripts/generate_dummy_templates.py`

**Subtasks:**
1. Line 1-15: Import modules (docx, pathlib, json)
2. Line 16-25: Create function `generate_dummy_facility_agreement(output_path: str)`:
   - Create new Document()
   - Add title: "FACILITY AGREEMENT"
   - Add placeholder sections with [PLACEHOLDER] tags
3. Line 26-35: Add sections:
   - "[BORROWER_NAME]"
   - "[FACILITY_NAME]"
   - "[COMMITMENT_AMOUNT]"
   - "[CURRENCY]"
   - "[MATURITY_DATE]"
   - "[BENCHMARK]"
   - "[SPREAD]"
   - "[AGREEMENT_DATE]"
4. Line 36-45: Add AI-generated section placeholders:
   - "[REPRESENTATIONS_AND_WARRANTIES]"
   - "[CONDITIONS_PRECEDENT]"
   - "[COVENANTS]"
5. Line 46-55: Save document to output_path
6. Line 56-65: Create similar functions for:
   - Term Sheet
   - Confidentiality Agreement
   - REF Facility Agreement
   - SLL Facility Agreement
7. Line 66-75: Main execution:
   - Create directory structure
   - Generate all dummy templates
   - Save to `storage/templates/` directory

---

## PROJECT 2: CDM Mapping & Field Population Engine

### Activity 2.1: CDM to Template Field Mapper

#### Task 2.1.1: Create Field Mapper Core
**File:** `app/generation/mapper.py`

**Subtasks:**
1. Line 1-20: Import modules (CreditAgreement, Dict, List, Optional, Any, Decimal, date)
2. Line 21-30: Create `FieldMapper` class with `__init__(template: LMATemplate)`:
   - Store template reference
   - Load field mappings from database
3. Line 31-40: Implement `map_cdm_to_template(cdm_data: CreditAgreement) -> Dict[str, Any]`:
   - Initialize result dictionary
   - Iterate through field mappings
   - Call appropriate mapping function based on mapping_type
4. Line 41-50: Implement `_map_direct_field(cdm_data: CreditAgreement, cdm_field_path: str) -> Any`:
   - Parse field path (e.g., "parties[role='Borrower'].name")
   - Navigate CDM structure
   - Return value or None
5. Line 51-60: Implement `_map_computed_field(cdm_data: CreditAgreement, transformation_rule: str) -> Any`:
   - Evaluate transformation rule
   - Handle common computations (spread percentage, total commitment, etc.)
   - Return computed value
6. Line 61-70: Implement `_format_date(date_value: date) -> str`:
   - Format as "DD MMMM YYYY" (e.g., "15 January 2024")
   - Return formatted string
7. Line 71-80: Implement `_format_currency(amount: Decimal, currency: str) -> str`:
   - Format with thousand separators
   - Add currency symbol
   - Return formatted string
8. Line 81-90: Implement `_format_spread(spread_bps: float) -> str`:
   - Convert basis points to percentage
   - Format as "X.XX%" or "XXX bps"
   - Return formatted string
9. Line 91-100: Implement `_format_payment_frequency(frequency: Frequency) -> str`:
   - Convert to human-readable (e.g., "Quarterly", "Semi-annually")
   - Return formatted string
10. Line 101-110: Implement `validate_required_fields(cdm_data: CreditAgreement) -> List[str]`:
    - Check all required fields are present
    - Return list of missing fields

#### Task 2.1.2: Create Field Path Parser
**File:** `app/generation/field_parser.py`

**Subtasks:**
1. Line 1-15: Import modules (re, List, Any, Optional)
2. Line 16-25: Create `FieldPathParser` class
3. Line 26-35: Implement `parse_field_path(path: str) -> List[str]`:
   - Split path by dots
   - Handle array accessors (e.g., "[role='Borrower']")
   - Return list of path segments
4. Line 36-45: Implement `get_nested_value(obj: Any, path: str) -> Optional[Any]`:
   - Parse path
   - Navigate object structure
   - Handle list filtering (e.g., parties[role='Borrower'])
   - Return value or None
5. Line 46-55: Implement `set_nested_value(obj: Any, path: str, value: Any) -> None`:
   - Parse path
   - Navigate to target location
   - Set value
6. Line 56-65: Add helper methods:
   - `_extract_list_filter(segment: str) -> Dict[str, str]`
   - `_filter_list(items: List, filter_dict: Dict) -> Optional[Any]`

### Activity 2.2: AI Field Population Engine

#### Task 2.2.1: Create AI Populator Core
**File:** `app/generation/populator.py`

**Subtasks:**
1. Line 1-20: Import modules (ChatOpenAI, ChatPromptTemplate, CreditAgreement, Dict, List, Optional)
2. Line 21-30: Create `AIFieldPopulator` class with `__init__()`:
   - Initialize LLM (GPT-4o)
   - Load prompt templates
3. Line 31-40: Implement `populate_ai_fields(cdm_data: CreditAgreement, template: LMATemplate, mapped_fields: Dict) -> Dict[str, str]`:
   - Get list of AI-generated sections from template
   - Iterate through sections
   - Call `_generate_section()` for each
   - Return dictionary of generated content
4. Line 41-50: Implement `_generate_section(section_name: str, cdm_data: CreditAgreement, template: LMATemplate) -> str`:
   - Load section-specific prompt template
   - Format prompt with CDM data
   - Call LLM
   - Return generated text
5. Line 51-60: Implement `_generate_representations(cdm_data: CreditAgreement, governing_law: str) -> str`:
   - Load representations prompt
   - Include borrower info, facility details
   - Generate standard LMA representations
   - Return formatted text
6. Line 61-70: Implement `_generate_conditions_precedent(cdm_data: CreditAgreement, governing_law: str) -> str`:
   - Load CP prompt
   - Generate standard conditions precedent list
   - Format as numbered list
   - Return formatted text
7. Line 71-80: Implement `_generate_covenants(cdm_data: CreditAgreement) -> str`:
   - Load covenants prompt
   - Generate financial and non-financial covenants
   - Return formatted text
8. Line 81-90: Implement `_generate_esg_clauses(cdm_data: CreditAgreement) -> str`:
   - Check if sustainability_linked
   - Load ESG prompt
   - Generate SPT definitions, measurement methodology
   - Generate margin adjustment mechanism
   - Return formatted text
9. Line 91-100: Implement `_generate_events_of_default(cdm_data: CreditAgreement, governing_law: str) -> str`:
   - Load EoD prompt
   - Generate standard events of default
   - Return formatted text

#### Task 2.2.2: Create Prompt Templates
**File:** `app/prompts/templates/facility_agreement.py`

**Subtasks:**
1. Line 1-15: Import ChatPromptTemplate
2. Line 16-25: Define `REPRESENTATIONS_PROMPT`:
   - System message: "You are a legal document drafting assistant..."
   - User message template with CDM fields
   - Instructions for LMA-compliant language
3. Line 26-35: Define `CONDITIONS_PRECEDENT_PROMPT`:
   - Template for generating CP list
   - Include governing law considerations
4. Line 36-45: Define `COVENANTS_PROMPT`:
   - Template for financial/non-financial covenants
5. Line 46-55: Define `ESG_SPT_PROMPT`:
   - Template for sustainability-linked loan clauses
   - Include SPT definitions, measurement, margin adjustment
6. Line 56-65: Define `EVENTS_OF_DEFAULT_PROMPT`:
   - Template for EoD section
7. Line 66-75: Export all prompts as dictionary

#### Task 2.2.3: Create Prompt Loader
**File:** `app/prompts/templates/loader.py`

**Subtasks:**
1. Line 1-15: Import modules (pathlib, importlib, Dict)
2. Line 16-25: Create `PromptLoader` class
3. Line 26-35: Implement `load_prompts_for_template(template_category: str) -> Dict[str, ChatPromptTemplate]`:
   - Map category to prompt module
   - Import module dynamically
   - Return dictionary of prompts
4. Line 36-45: Add prompt module mapping:
   - "Facility Agreement" → facility_agreement.py
   - "Term Sheet" → term_sheet.py
   - "Confidentiality Agreement" → confidentiality.py
   - etc.

---

## PROJECT 3: Document Generation & Rendering

### Activity 3.1: Document Renderer

#### Task 3.1.1: Create Word Document Renderer
**File:** `app/generation/renderer.py`

**Subtasks:**
1. Line 1-20: Import modules (docx, pathlib, Dict, Optional, BytesIO)
2. Line 21-30: Create `DocumentRenderer` class
3. Line 31-40: Implement `render_template(template_path: str, field_values: Dict[str, str]) -> Document`:
   - Load template document
   - Replace placeholders with field values
   - Return modified document
4. Line 41-50: Implement `_replace_placeholders(doc: Document, field_values: Dict[str, str]) -> None`:
   - Iterate through paragraphs
   - Find placeholder patterns (e.g., "[BORROWER_NAME]")
   - Replace with actual values
5. Line 51-60: Implement `_replace_in_tables(doc: Document, field_values: Dict[str, str]) -> None`:
   - Iterate through tables
   - Replace placeholders in cells
6. Line 61-70: Implement `_replace_in_headers_footers(doc: Document, field_values: Dict[str, str]) -> None`:
   - Process section headers/footers
   - Replace placeholders
7. Line 71-80: Implement `save_document(doc: Document, output_path: str) -> str`:
   - Save to output path
   - Return file path
8. Line 81-90: Implement `export_to_pdf(doc: Document, output_path: str) -> str`:
   - Convert Word to PDF (using docx2pdf or similar)
   - Return PDF path

#### Task 3.1.2: Create Document Generation Service
**File:** `app/generation/service.py`

**Subtasks:**
1. Line 1-20: Import modules (Session, CreditAgreement, LMATemplate, FieldMapper, AIFieldPopulator, DocumentRenderer)
2. Line 21-30: Create `DocumentGenerationService` class
3. Line 31-40: Implement `generate_document(db: Session, template_id: int, cdm_data: CreditAgreement, user_id: int) -> GeneratedDocument`:
   - Get template from database
   - Validate CDM data has required fields
   - Create FieldMapper instance
   - Map CDM to template fields
4. Line 41-50: Continue generation:
   - Create AIFieldPopulator instance
   - Generate AI fields
   - Merge mapped and AI-generated fields
5. Line 51-60: Continue generation:
   - Load template file
   - Create DocumentRenderer instance
   - Render document with field values
6. Line 61-70: Continue generation:
   - Save generated document
   - Create GeneratedDocument record
   - Link to source document if provided
   - Return GeneratedDocument
7. Line 71-80: Implement `get_generation_summary(field_values: Dict, ai_fields: Dict) -> Dict`:
   - Count populated fields
   - Count AI-generated fields
   - Identify missing required fields
   - Return summary dictionary

---

## PROJECT 4: Frontend Document Generator App

### Activity 4.1: Document Generator App Shell

#### Task 4.1.1: Create Main Component
**File:** `client/src/apps/document-generator/DocumentGenerator.tsx`

**Subtasks:**
1. Line 1-30: Import React, useState, useEffect, API client, types
2. Line 31-40: Define component props interface
3. Line 41-50: Create state variables:
   - `selectedTemplate`, `cdmData`, `generatedDocument`, `loading`, `error`
4. Line 51-60: Implement `useEffect` to load templates on mount
5. Line 61-70: Implement `handleTemplateSelect(templateId: number)`:
   - Set selected template
   - Load template requirements
   - Initialize CDM data form
6. Line 71-80: Implement `handleGenerate()`:
   - Validate CDM data
   - Call generation API
   - Handle response
   - Update state
7. Line 81-90: Render main layout:
   - Template selector sidebar
   - Main content area
   - CDM data input form
   - Generation button
8. Line 91-100: Add error handling and loading states

#### Task 4.1.2: Create Template Selector Component
**File:** `client/src/apps/document-generator/TemplateSelector.tsx`

**Subtasks:**
1. Line 1-20: Import React, useState, API client
2. Line 21-30: Define props interface with `onSelect` callback
3. Line 31-40: Create state for templates list, search filter, category filter
4. Line 41-50: Implement `useEffect` to fetch templates
5. Line 51-60: Render template list with:
   - Search input
   - Category filter dropdown
   - Template cards (name, category, version)
6. Line 61-70: Add template selection handler
7. Line 71-80: Style with Tailwind CSS

#### Task 4.1.3: Create CDM Data Input Form
**File:** `client/src/apps/document-generator/DataInputForm.tsx`

**Subtasks:**
1. Line 1-30: Import React, useState, form components
2. Line 21-30: Define props interface with `onDataChange` callback
3. Line 31-40: Create form state matching CDM structure
4. Line 41-50: Implement form sections:
   - Parties section (Borrower, Lenders, Agents)
   - Facilities section (name, amount, currency, maturity, interest)
   - Agreement details (date, governing law)
   - ESG section (if sustainability-linked)
5. Line 51-60: Add form validation
6. Line 61-70: Implement `handleSubmit()`
7. Line 71-80: Render form with Tailwind styling

### Activity 4.2: Document Preview & Export

#### Task 4.2.1: Create Document Preview Component
**File:** `client/src/apps/document-generator/DocumentPreview.tsx`

**Subtasks:**
1. Line 1-20: Import React, useState
2. Line 21-30: Define props interface
3. Line 31-40: Implement document preview using iframe or PDF viewer
4. Line 41-50: Add download button
5. Line 51-60: Add edit button (returns to form)
6. Line 61-70: Style preview container

#### Task 4.2.2: Create Export Dialog
**File:** `client/src/apps/document-generator/ExportDialog.tsx`

**Subtasks:**
1. Line 1-20: Import React, useState, Dialog component
2. Line 21-30: Define props interface
3. Line 31-40: Create export options:
   - Format selection (Word, PDF)
   - Include tracked changes toggle
4. Line 41-50: Implement export handler
5. Line 51-60: Render dialog with options

---

## PROJECT 5: Workflow Integration & Enhancements

### Activity 5.1: Workflow Integration

#### Task 5.1.1: Enhance Document Model
**File:** `app/db/models.py`

**Subtasks:**
1. Line 102-110: Add to `Document` class:
   - `is_generated` (Boolean, default False)
   - `template_id` (Integer, foreign key to lma_templates, nullable)
   - `source_cdm_data` (JSONB, nullable) - CDM data used for generation
2. Line 111-120: Add relationship:
   - `template = relationship("LMATemplate", foreign_keys=[template_id])`
   - `generated_document = relationship("GeneratedDocument", back_populates="source_document")`

#### Task 5.1.2: Update Document Creation Endpoint
**File:** `app/api/routes.py`

**Subtasks:**
1. Line 511-520: Modify `create_document()` to handle generated documents:
   - Check if request includes `template_id`
   - Set `is_generated = True`
   - Store `template_id` and `source_cdm_data`
2. Line 521-530: Create workflow with appropriate initial state
3. Line 531-540: Link to GeneratedDocument if applicable

#### Task 5.1.3: Add Generation Endpoint
**File:** `app/api/routes.py`

**Subtasks:**
1. Line 2000-2010: Create `POST /api/templates/generate` endpoint:
   - Accept `template_id`, `cdm_data`, optional `source_document_id`
   - Call DocumentGenerationService
   - Create Document record
   - Create GeneratedDocument record
   - Return generated document
2. Line 2011-2020: Add validation:
   - Check template exists
   - Validate CDM data structure
   - Check required fields present
3. Line 2021-2030: Add error handling and logging

### Activity 5.2: Workflow Enhancements

#### Task 5.2.1: Add Template-Specific Workflow States
**File:** `app/db/models.py`

**Subtasks:**
1. Line 27-34: Extend `WorkflowState` enum:
   - Add `GENERATED = "generated"` (optional intermediate state)
2. Line 197-230: Update workflow transitions to handle generated documents

#### Task 5.2.2: Enhance Workflow Actions Component
**File:** `client/src/components/WorkflowActions.tsx`

**Subtasks:**
1. Line 42-50: Add check for generated documents:
   - Show "Review Generated Document" button if `is_generated`
   - Link to document preview
2. Line 51-60: Add template information display:
   - Show template name and version
   - Show generation summary
3. Line 61-70: Add "Regenerate" action for generated documents in DRAFT state

---

## PROJECT 6: Existing Feature Enhancements

### Activity 6.1: Docu-Digitizer Enhancement

#### Task 6.1.1: Add "Generate from Template" Action
**File:** `client/src/apps/docu-digitizer/DocumentParser.tsx`

**Subtasks:**
1. Line 18-30: Add new prop `onGenerateFromTemplate?: (cdmData: CreditAgreementData) => void`
2. Line 200-210: Add "Generate Document from Template" button after extraction
3. Line 211-220: On click:
   - Pass extracted CDM data to callback
   - Navigate to Document Generator app
   - Pre-populate form with extracted data
4. Line 221-230: Add visual indicator that generation is available

### Activity 6.2: Document Library Enhancement

#### Task 6.2.1: Add Template Filter
**File:** `client/src/components/DocumentHistory.tsx`

**Subtasks:**
1. Line 45-55: Add filter state for template category
2. Line 56-65: Add template filter dropdown in UI
3. Line 66-75: Update API call to include template filter
4. Line 76-85: Display template badge for generated documents

#### Task 6.2.2: Add Template Comparison View
**File:** `client/src/components/DocumentHistory.tsx`

**Subtasks:**
1. Line 200-210: Add "Compare with Template" action for generated documents
2. Line 211-220: Open side-by-side comparison view:
   - Left: Generated document
   - Right: Original template
3. Line 221-230: Highlight differences/changes

### Activity 6.3: Dashboard Enhancement

#### Task 6.3.1: Add Template Usage Metrics
**File:** `client/src/components/Dashboard.tsx`

**Subtasks:**
1. Line 100-110: Add template usage statistics:
   - Most used templates
   - Generation success rate
   - Average generation time
2. Line 111-120: Add chart for template usage over time
3. Line 121-130: Add "Quick Generate" section with recent templates

### Activity 6.4: FDC3 Integration Enhancement

#### Task 6.4.1: Add Template Generation Intent
**File:** `client/src/context/FDC3Context.tsx`

**Subtasks:**
1. Line 100-110: Add new intent handler `GenerateLMATemplate`:
   - Accept CDM data from context
   - Open Document Generator app
   - Pre-populate with CDM data
2. Line 111-120: Add new context type `finos.creditnexus.templateGeneration`:
   - Include template_id, cdm_data, source_document_id
3. Line 121-130: Register intent in FDC3 provider

#### Task 6.4.2: Add Template Context Broadcasting
**File:** `client/src/apps/document-generator/DocumentGenerator.tsx`

**Subtasks:**
1. Line 100-110: After successful generation:
   - Broadcast `finos.creditnexus.generatedDocument` context
   - Include document_id, template_id, generation_summary
2. Line 111-120: Listen for CDM data context from other apps
3. Line 121-130: Auto-populate form when context received

---

## PROJECT 7: Testing & Documentation

### Activity 7.1: Unit Tests

#### Task 7.1.1: Test Field Mapper
**File:** `tests/test_field_mapper.py`

**Subtasks:**
1. Line 1-20: Import pytest, FieldMapper, CreditAgreement
2. Line 21-30: Create test fixtures for sample CDM data
3. Line 31-40: Test `map_cdm_to_template()` with complete CDM data
4. Line 41-50: Test direct field mapping
5. Line 51-60: Test computed field mapping (spread, dates, currency)
6. Line 61-70: Test missing required fields validation
7. Line 71-80: Test field path parsing with complex paths

#### Task 7.1.2: Test AI Populator
**File:** `tests/test_ai_populator.py`

**Subtasks:**
1. Line 1-20: Import pytest, AIFieldPopulator, mock LLM
2. Line 21-30: Mock OpenAI API responses
3. Line 31-40: Test `populate_ai_fields()` with standard facility agreement
4. Line 41-50: Test ESG clause generation for SLL
5. Line 51-60: Test representations generation
6. Line 61-70: Test conditions precedent generation

#### Task 7.1.3: Test Document Renderer
**File:** `tests/test_renderer.py`

**Subtasks:**
1. Line 1-20: Import pytest, DocumentRenderer, pathlib
2. Line 21-30: Create test template file
3. Line 31-40: Test placeholder replacement in paragraphs
4. Line 41-50: Test placeholder replacement in tables
5. Line 51-60: Test document saving
6. Line 61-70: Test PDF export

### Activity 7.2: Integration Tests

#### Task 7.2.1: Test Generation Workflow
**File:** `tests/test_generation_workflow.py`

**Subtasks:**
1. Line 1-20: Import pytest, FastAPI test client, database fixtures
2. Line 21-30: Test full generation workflow:
   - Create template in database
   - Generate document from CDM data
   - Verify document created
   - Verify workflow state
3. Line 31-40: Test generation with missing required fields
4. Line 41-50: Test generation with ESG data
5. Line 51-60: Test document retrieval and download

### Activity 7.3: Documentation

#### Task 7.3.1: Create API Documentation
**File:** `docs/api/template-generation.md`

**Subtasks:**
1. Document all new API endpoints
2. Include request/response examples
3. Document error codes
4. Include authentication requirements

#### Task 7.3.2: Create User Guide
**File:** `docs/user-guide/template-generation.md`

**Subtasks:**
1. Step-by-step guide for generating documents
2. Screenshots of UI
3. Common use cases
4. Troubleshooting guide

---

## Existing Features Enhancement Summary

### Features to Enhance:

1. **Docu-Digitizer** (`client/src/apps/docu-digitizer/`)
   - **Enhancement:** Add "Generate from Template" button after extraction
   - **Benefit:** Seamless flow from extraction to generation
   - **Implementation:** Add callback prop, navigate to Document Generator

2. **Document Library** (`client/src/components/DocumentHistory.tsx`)
   - **Enhancement:** Template filter, template badges, comparison view
   - **Benefit:** Better organization and visibility of generated documents
   - **Implementation:** Add filter state, API parameter, UI badges

3. **Dashboard** (`client/src/components/Dashboard.tsx`)
   - **Enhancement:** Template usage metrics, quick generate section
   - **Benefit:** Visibility into template usage, faster access
   - **Implementation:** New API endpoint for metrics, chart component

4. **Workflow Engine** (`app/api/routes.py`, `app/db/models.py`)
   - **Enhancement:** Support for generated documents, template-specific states
   - **Benefit:** Proper workflow management for generated docs
   - **Implementation:** Extend Document model, update workflow logic

5. **FDC3 Integration** (`client/src/context/FDC3Context.tsx`)
   - **Enhancement:** Template generation intent, context broadcasting
   - **Benefit:** Desktop interoperability for template generation
   - **Implementation:** New intent handler, context types

6. **Analytics** (`app/api/routes.py`)
   - **Enhancement:** Template usage statistics
   - **Benefit:** Insights into template adoption
   - **Implementation:** New analytics endpoint, aggregation queries

---

## Implementation Timeline

### Week 1-2: PROJECT 1 (Template Infrastructure)
- Database schema and migrations
- Template storage system
- Template registry
- Seed dummy templates

### Week 3-5: PROJECT 2 (CDM Mapping & AI)
- Field mapper implementation
- AI field population engine
- Prompt templates
- Testing

### Week 6-7: PROJECT 3 (Document Generation)
- Document renderer
- Generation service
- API endpoints
- Testing

### Week 8-10: PROJECT 4 (Frontend)
- Document Generator app
- Template selector
- CDM input form
- Preview and export

### Week 11-12: PROJECT 5 (Workflow Integration)
- Workflow enhancements
- Document model updates
- Integration testing

### Week 13-14: PROJECT 6 (Feature Enhancements)
- Docu-Digitizer enhancement
- Document Library enhancements
- Dashboard enhancements
- FDC3 enhancements

### Week 15: PROJECT 7 (Testing & Documentation)
- Unit tests
- Integration tests
- API documentation
- User guide

**Total Duration:** 15 weeks (~3.5 months)

---

## Success Criteria

1. ✅ Can generate Facility Agreement from CDM data
2. ✅ Can generate Term Sheet from CDM data
3. ✅ AI-populated fields are LMA-compliant
4. ✅ Generated documents enter workflow
5. ✅ Integration with existing Document Library
6. ✅ FDC3 interoperability working
7. ✅ All tests passing (>80% coverage)
8. ✅ Documentation complete

---

## Risk Mitigation

| Risk | Mitigation |
|------|------------|
| Template file format changes | Version control, template validation |
| AI generation quality | Human review workflow, prompt refinement |
| Performance (generation time) | Caching, async processing, progress indicators |
| Missing CDM fields | Validation, user prompts, default values |
| Template licensing | Clear attribution, usage tracking |

---

**Document Version:** 1.0  
**Last Updated:** 2024-01-XX  
**Status:** Ready for Implementation

