# LMA Template System - Multimodal Input Enhancement Plan

## Executive Summary

This document extends the LMA Template Implementation Plan to support **multimodal inputs** (audio recordings, images, existing documents) that are processed through LangChain to generate LMA-compliant templates. Additionally, it adds a **decision support chatbot** for interactive template generation guidance.

**Key Enhancement:** Users can now provide inputs from multiple sources (meeting recordings, uploaded images, existing documents) which are intelligently combined using LangChain to populate LMA templates.

---

## 1. Generate Button Placement in User Flows

### 1.1 Document Parser Flow

**Current Flow:**
```
Upload PDF/Text → Extract → Review → Save to Library
```

**Enhanced Flow with Generate:**
```
Upload PDF/Text → Extract → Review → [Generate from Template] → Save to Library
```

**Generate Button Placement:**
- **Location:** After successful extraction, in the review interface
- **Component:** `client/src/apps/docu-digitizer/DocumentParser.tsx`
- **Line:** ~200-250 (after extracted data display)
- **UI:** Button next to "Save to Library" button
- **Action:** Opens Document Generator with pre-populated CDM data

**Implementation:**
```tsx
// In DocumentParser.tsx, after extraction success
{extractedData && (
  <div className="flex gap-2 mt-4">
    <Button onClick={handleSaveToLibrary}>Save to Library</Button>
    <Button 
      onClick={() => handleGenerateFromTemplate(extractedData)}
      variant="outline"
    >
      <FileText className="mr-2 h-4 w-4" />
      Generate LMA Document
    </Button>
  </div>
)}
```

### 1.2 Document Library Flow

**Current Flow:**
```
View Documents → Select Document → View Details
```

**Enhanced Flow:**
```
View Documents → Select Document → View Details → [Generate New Version] → Template Selection
```

**Generate Button Placement:**
- **Location:** In document detail view, action bar
- **Component:** `client/src/components/DocumentHistory.tsx`
- **Line:** ~150-200 (in document detail modal/card)
- **UI:** "Generate from Template" button in action menu
- **Action:** Opens Document Generator with document's CDM data

**Implementation:**
```tsx
// In DocumentHistory.tsx, document action menu
<DropdownMenu>
  <DropdownMenuItem onClick={() => handleGenerateFromDocument(doc.id)}>
    <FileText className="mr-2 h-4 w-4" />
    Generate LMA Document
  </DropdownMenuItem>
</DropdownMenu>
```

### 1.3 Dashboard Flow

**Current Flow:**
```
Dashboard → View Metrics → Navigate to Apps
```

**Enhanced Flow:**
```
Dashboard → [Quick Generate] → Template Selection → Multimodal Input
```

**Generate Button Placement:**
- **Location:** Dashboard quick actions section
- **Component:** `client/src/components/Dashboard.tsx`
- **Line:** ~100-150 (in quick actions card)
- **UI:** "Quick Generate" card with recent templates
- **Action:** Opens Document Generator with template pre-selected

**Implementation:**
```tsx
// In Dashboard.tsx, quick actions section
<Card>
  <CardHeader>Quick Actions</CardHeader>
  <CardContent>
    <Button onClick={() => navigateToGenerator()}>
      <Sparkles className="mr-2 h-4 w-4" />
      Generate LMA Document
    </Button>
  </CardContent>
</Card>
```

### 1.4 Multimodal Input Flow (New)

**New Flow:**
```
Document Generator → [Upload Audio/Image/Document] → Process → Combine → Generate
```

**Generate Button Placement:**
- **Location:** In Document Generator app, after multimodal inputs processed
- **Component:** `client/src/apps/document-generator/DocumentGenerator.tsx`
- **Line:** ~300-350 (after input processing section)
- **UI:** Primary "Generate Document" button (disabled until inputs processed)
- **Action:** Triggers multimodal processing chain, then generation

---

## 2. Multimodal Input Architecture

### 2.1 Input Types Supported

1. **Audio Recordings**
   - Meeting recordings (MP3, WAV, M4A)
   - Phone call recordings
   - Voice memos
   - Real-time recording via browser

2. **Images**
   - Screenshots of documents
   - Photos of whiteboards/meeting notes
   - Scanned documents (JPG, PNG, PDF)
   - Handwritten notes

3. **Existing Documents**
   - Previously extracted credit agreements
   - Term sheets from Library
   - Related documents (via search/retrieval)

4. **Text Input**
   - Manual entry
   - Pasted text
   - Chat messages (from chatbot)

### 2.2 Processing Pipeline

```
┌─────────────────────────────────────────────────────────────┐
│                    Multimodal Input Layer                    │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │  Audio   │  │  Image   │  │ Document │  │   Text    │   │
│  │  Input   │  │  Input   │  │  Input   │  │  Input   │   │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘   │
│       │             │             │             │          │
│       ▼             ▼             ▼             ▼          │
│  ┌──────────────────────────────────────────────────────┐   │
│  │         LangChain Processing Chains                  │   │
│  │  - Audio Transcription Chain                         │   │
│  │  - Image OCR/Extraction Chain                        │   │
│  │  - Document Retrieval Chain                          │   │
│  │  - Text Extraction Chain                             │   │
│  └────────────────────┬─────────────────────────────────┘   │
│                       │                                      │
│                       ▼                                      │
│  ┌──────────────────────────────────────────────────────┐   │
│  │         Multimodal Fusion Chain                      │   │
│  │  - Combine all extracted data                        │   │
│  │  - Resolve conflicts/duplicates                      │   │
│  │  - Fill CDM structure                                │   │
│  └────────────────────┬─────────────────────────────────┘   │
│                       │                                      │
│                       ▼                                      │
│  ┌──────────────────────────────────────────────────────┐   │
│  │         CDM Validation & Enhancement                 │   │
│  │  - Validate against CDM schema                       │   │
│  │  - AI enhancement for missing fields                 │   │
│  └────────────────────┬─────────────────────────────────┘   │
│                       │                                      │
│                       ▼                                      │
│  ┌──────────────────────────────────────────────────────┐   │
│  │         Template Generation                          │   │
│  │  - Map CDM to template                               │   │
│  │  - Generate document                                 │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## 3. LangChain Implementation

### 3.1 Audio Transcription Chain

**File:** `app/chains/audio_transcription_chain.py`

**Implementation:**
```python
from langchain_openai import ChatOpenAI, Whisper
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from app.models.cdm import CreditAgreement

def create_audio_transcription_chain():
    """Transcribe audio and extract CDM-relevant information."""
    
    # Step 1: Transcribe audio using Whisper
    whisper = Whisper(api_key=settings.OPENAI_API_KEY)
    
    # Step 2: Extract structured data from transcription
    llm = ChatOpenAI(model="gpt-4o", temperature=0)
    parser = PydanticOutputParser(pydantic_object=CreditAgreement)
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are extracting loan agreement terms from a meeting transcription. Extract structured data following the CDM schema."),
        ("user", "Transcription:\n{transcription}\n\nExtract loan terms and return as CDM-compliant JSON.")
    ])
    
    chain = whisper | prompt | llm | parser
    return chain

def process_audio_file(audio_file: bytes, filename: str) -> CreditAgreement:
    """Process audio file and return CDM data."""
    chain = create_audio_transcription_chain()
    result = chain.invoke({"audio": audio_file, "filename": filename})
    return result
```

### 3.2 Image OCR & Extraction Chain

**File:** `app/chains/image_extraction_chain.py`

**Implementation:**
```python
from langchain_openai import ChatOpenAI
from langchain_community.utilities import ImageCaptioning
from langchain_core.prompts import ChatPromptTemplate
from PIL import Image
import base64

def create_image_extraction_chain():
    """Extract text and structured data from images."""
    
    llm = ChatOpenAI(model="gpt-4o", temperature=0)
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are analyzing loan document images. Extract text via OCR and identify loan terms (borrower, amount, rates, dates). Return structured CDM data."),
        ("user", [
            {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,{image_base64}"}},
            {"type": "text", "text": "Extract loan agreement terms from this image and return as CDM-compliant JSON."}
        ])
    ])
    
    chain = prompt | llm.with_structured_output(CreditAgreement)
    return chain

def process_image_file(image_file: bytes, filename: str) -> CreditAgreement:
    """Process image file and return CDM data."""
    # Convert to base64
    image_base64 = base64.b64encode(image_file).decode('utf-8')
    
    chain = create_image_extraction_chain()
    result = chain.invoke({"image_base64": image_base64})
    return result
```

### 3.3 Document Retrieval Chain

**File:** `app/chains/document_retrieval_chain.py`

**Implementation:**
```python
from langchain_community.vectorstores import ChromaDB
from langchain_openai import OpenAIEmbeddings
from langchain.chains import RetrievalQA
from langchain_core.prompts import ChatPromptTemplate

def create_document_retrieval_chain():
    """Retrieve relevant documents from library and extract CDM data."""
    
    # Initialize vector store with existing documents
    embeddings = OpenAIEmbeddings()
    vectorstore = ChromaDB(
        collection_name="credit_agreements",
        embedding_function=embeddings
    )
    
    # Create retrieval chain
    retriever = vectorstore.as_retriever(search_kwargs={"k": 5})
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are retrieving and extracting loan terms from similar documents. Use retrieved context to fill missing CDM fields."),
        ("user", "Query: {query}\n\nRetrieved Documents:\n{context}\n\nExtract and merge CDM data.")
    ])
    
    llm = ChatOpenAI(model="gpt-4o", temperature=0)
    chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=retriever,
        return_source_documents=True
    )
    
    return chain

def retrieve_similar_documents(query: str, limit: int = 5) -> List[CreditAgreement]:
    """Retrieve similar documents and extract their CDM data."""
    chain = create_document_retrieval_chain()
    results = chain.invoke({"query": query})
    return results
```

### 3.4 Multimodal Fusion Chain

**File:** `app/chains/multimodal_fusion_chain.py`

**Implementation:**
```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from typing import List, Optional
from app.models.cdm import CreditAgreement

def create_multimodal_fusion_chain():
    """Combine data from multiple sources into unified CDM structure."""
    
    llm = ChatOpenAI(model="gpt-4o", temperature=0)
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", """You are combining loan agreement data from multiple sources (audio transcription, images, existing documents, text).
        
        Rules:
        1. Prioritize explicit values over inferred ones
        2. Resolve conflicts by preferring most recent or most authoritative source
        3. Fill missing fields from available sources
        4. Ensure all data is CDM-compliant
        5. Flag any inconsistencies for user review
        
        Return a complete, validated CreditAgreement."""),
        ("user", """Combine the following data sources:
        
        Audio Transcription Data:
        {audio_data}
        
        Image Extraction Data:
        {image_data}
        
        Retrieved Document Data:
        {document_data}
        
        Manual Text Input:
        {text_data}
        
        Merge into a single, complete CDM structure.""")
    ])
    
    chain = prompt | llm.with_structured_output(CreditAgreement)
    return chain

def fuse_multimodal_inputs(
    audio_data: Optional[CreditAgreement] = None,
    image_data: Optional[CreditAgreement] = None,
    document_data: Optional[List[CreditAgreement]] = None,
    text_data: Optional[CreditAgreement] = None
) -> CreditAgreement:
    """Fuse multiple CDM data sources into one."""
    
    chain = create_multimodal_fusion_chain()
    
    result = chain.invoke({
        "audio_data": audio_data.model_dump_json() if audio_data else "None",
        "image_data": image_data.model_dump_json() if image_data else "None",
        "document_data": [d.model_dump_json() for d in document_data] if document_data else "None",
        "text_data": text_data.model_dump_json() if text_data else "None"
    })
    
    return result
```

---

## 4. Decision Support Chatbot

### 4.1 Chatbot Architecture

**File:** `app/chains/decision_support_chain.py`

**Purpose:** Interactive chatbot that helps users:
- Select appropriate LMA templates
- Fill missing CDM fields
- Resolve data conflicts
- Provide guidance on template generation
- Answer questions about LMA standards

**Implementation:**
```python
from langchain_openai import ChatOpenAI
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain
from langchain_core.prompts import ChatPromptTemplate
from langchain_community.vectorstores import ChromaDB
from typing import List, Dict, Optional

class DecisionSupportChatbot:
    """Chatbot for LMA template generation decision support."""
    
    def __init__(self):
        self.llm = ChatOpenAI(model="gpt-4o", temperature=0.3)
        self.memory = ConversationBufferMemory(
            memory_key="chat_history",
            return_messages=True
        )
        
        # Load LMA template knowledge base
        self.template_kb = self._load_template_knowledge_base()
        
        # Load CDM schema knowledge
        self.cdm_kb = self._load_cdm_knowledge_base()
        
    def _load_template_knowledge_base(self):
        """Load LMA template metadata into vector store."""
        # Embed template descriptions, use cases, requirements
        embeddings = OpenAIEmbeddings()
        # ... load template metadata
        return vectorstore
    
    def _load_cdm_knowledge_base(self):
        """Load CDM schema documentation into vector store."""
        # Embed CDM field descriptions, validation rules
        embeddings = OpenAIEmbeddings()
        # ... load CDM docs
        return vectorstore
    
    def create_chat_chain(self, current_cdm_data: Optional[CreditAgreement] = None):
        """Create conversational chain with context."""
        
        # Combine knowledge bases
        retriever = self._create_combined_retriever()
        
        prompt = ChatPromptTemplate.from_messages([
            ("system", """You are a helpful assistant for LMA document template generation.

            Your role:
            1. Help users select appropriate LMA templates
            2. Guide users in filling CDM fields
            3. Answer questions about LMA standards
            4. Resolve data conflicts
            5. Provide template generation guidance

            Current CDM Data:
            {cdm_data}

            Use the knowledge base to provide accurate, helpful responses.
            Always reference LMA standards when relevant."""),
            ("user", "{question}"),
            ("assistant", "{answer}")
        ])
        
        chain = ConversationalRetrievalChain.from_llm(
            llm=self.llm,
            retriever=retriever,
            memory=self.memory,
            combine_docs_chain_kwargs={"prompt": prompt}
        )
        
        return chain
    
    def chat(self, message: str, cdm_data: Optional[CreditAgreement] = None) -> str:
        """Process user message and return response."""
        chain = self.create_chat_chain(cdm_data)
        response = chain.invoke({
            "question": message,
            "cdm_data": cdm_data.model_dump_json() if cdm_data else "None"
        })
        return response["answer"]
    
    def suggest_template(self, cdm_data: CreditAgreement) -> List[Dict]:
        """Suggest appropriate templates based on CDM data."""
        query = f"Facility type: {cdm_data.facilities[0].facility_name if cdm_data.facilities else 'Unknown'}, Governing law: {cdm_data.governing_law}, Sustainability: {cdm_data.sustainability_linked}"
        
        chain = self.create_chat_chain(cdm_data)
        response = chain.invoke({
            "question": f"Based on this loan data, which LMA templates are most appropriate? {query}"
        })
        
        # Parse response to extract template suggestions
        return self._parse_template_suggestions(response)
    
    def fill_missing_fields(self, cdm_data: CreditAgreement) -> CreditAgreement:
        """Use chatbot to help fill missing required fields."""
        missing = self._identify_missing_fields(cdm_data)
        
        if not missing:
            return cdm_data
        
        chain = self.create_chat_chain(cdm_data)
        response = chain.invoke({
            "question": f"What information do I need to provide for these missing fields: {', '.join(missing)}?"
        })
        
        # Guide user through filling fields
        return self._interactive_field_filling(cdm_data, missing, chain)
```

### 4.2 Frontend Chatbot Component

**File:** `client/src/apps/document-generator/ChatbotPanel.tsx`

**Implementation:**
```tsx
import { useState, useRef, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send, Bot, User } from 'lucide-react';

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export function ChatbotPanel({ cdmData, onSuggestion }: ChatbotPanelProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: ChatMessage = {
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetchWithAuth('/api/chatbot/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: input,
          cdm_data: cdmData,
          chat_history: messages
        })
      });

      const data = await response.json();
      const assistantMessage: ChatMessage = {
        role: 'assistant',
        content: data.response,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);

      // Handle template suggestions
      if (data.template_suggestions) {
        onSuggestion?.(data.template_suggestions);
      }
    } catch (error) {
      console.error('Chat error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <h3 className="flex items-center gap-2">
          <Bot className="h-5 w-5" />
          Template Generation Assistant
        </h3>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col">
        <div className="flex-1 overflow-y-auto mb-4 space-y-4">
          {messages.map((msg, idx) => (
            <div key={idx} className={`flex gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              {msg.role === 'assistant' && <Bot className="h-4 w-4 mt-1" />}
              <div className={`p-2 rounded-lg ${msg.role === 'user' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}>
                {msg.content}
              </div>
              {msg.role === 'user' && <User className="h-4 w-4 mt-1" />}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask about templates, CDM fields, or LMA standards..."
          />
          <Button onClick={handleSend} disabled={isLoading}>
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
```

---

## 5. Enhanced Implementation Plan

### PROJECT 8: Multimodal Input Processing (NEW - 3 weeks)

#### Activity 8.1: Audio Processing

**Task 8.1.1: Create Audio Transcription Chain**
- **File:** `app/chains/audio_transcription_chain.py`
- **Subtasks:**
  1. Install Whisper API client
  2. Create transcription function
  3. Create CDM extraction from transcription
  4. Add error handling for audio formats
  5. Add progress tracking for long recordings

**Task 8.1.2: Audio Upload Endpoint**
- **File:** `app/api/routes.py`
- **Subtasks:**
  1. Add `POST /api/audio/transcribe` endpoint
  2. Accept audio files (MP3, WAV, M4A)
  3. Call transcription chain
  4. Return CDM data
  5. Add file size limits

**Task 8.1.3: Real-time Recording Component**
- **File:** `client/src/apps/document-generator/AudioRecorder.tsx`
- **Subtasks:**
  1. Use MediaRecorder API
  2. Add record/stop/playback controls
  3. Upload to backend
  4. Show transcription progress
  5. Display extracted CDM data

#### Activity 8.2: Image Processing

**Task 8.2.1: Create Image Extraction Chain**
- **File:** `app/chains/image_extraction_chain.py`
- **Subtasks:**
  1. Use GPT-4 Vision for OCR
  2. Extract structured data from images
  3. Handle multiple images
  4. Support various formats (JPG, PNG, PDF)
  5. Add image preprocessing

**Task 8.2.2: Image Upload Endpoint**
- **File:** `app/api/routes.py`
- **Subtasks:**
  1. Add `POST /api/image/extract` endpoint
  2. Accept image files
  3. Call image extraction chain
  4. Return CDM data
  5. Add image size/format validation

**Task 8.2.3: Image Upload Component**
- **File:** `client/src/apps/document-generator/ImageUploader.tsx`
- **Subtasks:**
  1. Drag-and-drop image upload
  2. Image preview
  3. Multiple image support
  4. Show extraction progress
  5. Display extracted data

#### Activity 8.3: Document Retrieval

**Task 8.3.1: Create Retrieval Chain**
- **File:** `app/chains/document_retrieval_chain.py`
- **Subtasks:**
  1. Set up ChromaDB vector store
  2. Index existing documents
  3. Create retrieval chain
  4. Add similarity search
  5. Return relevant CDM data

**Task 8.3.2: Retrieval Endpoint**
- **File:** `app/api/routes.py`
- **Subtasks:**
  1. Add `POST /api/documents/retrieve` endpoint
  2. Accept query string
  3. Return similar documents
  4. Include CDM data
  5. Add relevance scoring

**Task 8.3.3: Document Search Component**
- **File:** `client/src/apps/document-generator/DocumentSearch.tsx`
- **Subtasks:**
  1. Search input
  2. Display search results
  3. Select documents to include
  4. Show CDM preview
  5. Add to fusion pipeline

#### Activity 8.4: Multimodal Fusion

**Task 8.4.1: Create Fusion Chain**
- **File:** `app/chains/multimodal_fusion_chain.py`
- **Subtasks:**
  1. Implement fusion logic
  2. Conflict resolution
  3. Data merging
  4. Validation
  5. Return unified CDM

**Task 8.4.2: Fusion Endpoint**
- **File:** `app/api/routes.py`
- **Subtasks:**
  1. Add `POST /api/multimodal/fuse` endpoint
  2. Accept multiple CDM sources
  3. Call fusion chain
  4. Return unified CDM
  5. Add conflict reporting

**Task 8.4.3: Fusion UI Component**
- **File:** `client/src/apps/document-generator/MultimodalInputPanel.tsx`
- **Subtasks:**
  1. Show all input sources
  2. Display extracted data
  3. Show conflicts
  4. Allow manual resolution
  5. Trigger fusion

### PROJECT 9: Decision Support Chatbot (NEW - 2 weeks)

#### Activity 9.1: Backend Chatbot

**Task 9.1.1: Create Chatbot Chain**
- **File:** `app/chains/decision_support_chain.py`
- **Subtasks:**
  1. Implement DecisionSupportChatbot class
  2. Load knowledge bases
  3. Create conversational chain
  4. Add memory management
  5. Implement template suggestions

**Task 9.1.2: Chatbot Endpoints**
- **File:** `app/api/routes.py`
- **Subtasks:**
  1. Add `POST /api/chatbot/chat` endpoint
  2. Add `POST /api/chatbot/suggest-templates` endpoint
  3. Add `POST /api/chatbot/fill-fields` endpoint
  4. Add session management
  5. Add rate limiting

**Task 9.1.3: Knowledge Base Setup**
- **File:** `scripts/setup_chatbot_kb.py`
- **Subtasks:**
  1. Load LMA template metadata
  2. Load CDM schema docs
  3. Create embeddings
  4. Store in vector DB
  5. Index for retrieval

#### Activity 9.2: Frontend Chatbot

**Task 9.2.1: Chatbot Panel Component**
- **File:** `client/src/apps/document-generator/ChatbotPanel.tsx`
- **Subtasks:**
  1. Create chat interface
  2. Message display
  3. Input handling
  4. API integration
  5. Template suggestion display

**Task 9.2.2: Integrate with Document Generator**
- **File:** `client/src/apps/document-generator/DocumentGenerator.tsx`
- **Subtasks:**
  1. Add chatbot panel to layout
  2. Connect to CDM data
  3. Handle suggestions
  4. Update form from chatbot
  5. Show chatbot in sidebar

### PROJECT 10: Enhanced Document Generator UI (NEW - 2 weeks)

#### Activity 10.1: Multimodal Input UI

**Task 10.1.1: Input Tabs Component**
- **File:** `client/src/apps/document-generator/InputTabs.tsx`
- **Subtasks:**
  1. Create tabbed interface
  2. Audio tab
  3. Image tab
  4. Document tab
  5. Text tab

**Task 10.1.2: Processing Status Component**
- **File:** `client/src/apps/document-generator/ProcessingStatus.tsx`
- **Subtasks:**
  1. Show processing progress
  2. Display extracted data
  3. Show conflicts
  4. Allow editing
  5. Trigger fusion

**Task 10.1.3: Enhanced Generate Button**
- **File:** `client/src/apps/document-generator/DocumentGenerator.tsx`
- **Subtasks:**
  1. Add multimodal processing before generation
  2. Show processing steps
  3. Enable/disable based on inputs
  4. Show generation progress
  5. Display result

---

## 6. Updated User Flows

### 6.1 Complete Multimodal Flow

```
1. User opens Document Generator
   ↓
2. User selects template (or chatbot suggests)
   ↓
3. User provides inputs:
   - Uploads meeting recording
   - Uploads image of term sheet
   - Searches for similar documents
   - Enters text manually
   ↓
4. System processes all inputs:
   - Transcribes audio → CDM
   - Extracts from image → CDM
   - Retrieves documents → CDM
   - Processes text → CDM
   ↓
5. Fusion chain combines all CDM data
   ↓
6. User reviews/edits unified CDM
   ↓
7. Chatbot helps fill missing fields
   ↓
8. User clicks "Generate Document"
   ↓
9. System generates LMA template
   ↓
10. User reviews and exports
```

### 6.2 Chatbot-Assisted Flow

```
1. User starts with partial information
   ↓
2. Opens chatbot panel
   ↓
3. Asks: "What template should I use for a $100M corporate loan?"
   ↓
4. Chatbot suggests templates
   ↓
5. User selects template
   ↓
6. Chatbot asks about missing fields
   ↓
7. User provides answers (text/audio/image)
   ↓
8. Chatbot updates CDM data
   ↓
9. User confirms and generates
```

---

## 7. API Endpoints Summary

### New Endpoints:

1. **Audio Processing**
   - `POST /api/audio/transcribe` - Transcribe audio to CDM
   - `POST /api/audio/record` - Real-time recording

2. **Image Processing**
   - `POST /api/image/extract` - Extract CDM from image
   - `POST /api/image/batch` - Process multiple images

3. **Document Retrieval**
   - `POST /api/documents/retrieve` - Search similar documents
   - `GET /api/documents/{id}/cdm` - Get document CDM data

4. **Multimodal Fusion**
   - `POST /api/multimodal/fuse` - Combine multiple CDM sources
   - `GET /api/multimodal/conflicts` - Get conflict report

5. **Chatbot**
   - `POST /api/chatbot/chat` - Chat message
   - `POST /api/chatbot/suggest-templates` - Template suggestions
   - `POST /api/chatbot/fill-fields` - Help fill missing fields
   - `GET /api/chatbot/session/{id}` - Get chat history

---

## 8. Updated Timeline

**Original:** 15 weeks  
**With Multimodal:** 20 weeks

### Additional Projects:
- **Week 16-18:** PROJECT 8 (Multimodal Input Processing)
- **Week 19-20:** PROJECT 9 (Decision Support Chatbot)
- **Week 21-22:** PROJECT 10 (Enhanced UI) + Integration Testing

**New Total:** 22 weeks (~5.5 months)

---

## 9. Dependencies

### New Libraries Required:

**Backend:**
- `openai-whisper` or `whisper` - Audio transcription
- `Pillow` - Image processing
- `chromadb` - Vector database for retrieval
- `langchain-community` - Additional LangChain integrations

**Frontend:**
- `react-audio-recorder` - Audio recording
- `react-dropzone` - File uploads
- `react-markdown` - Chat message rendering

---

## 10. Success Metrics

1. ✅ Can process audio recordings and extract CDM data
2. ✅ Can extract CDM data from images
3. ✅ Can retrieve and use similar documents
4. ✅ Can fuse multiple input sources
5. ✅ Chatbot provides helpful template suggestions
6. ✅ Chatbot helps fill missing fields
7. ✅ Generate button accessible from all relevant flows
8. ✅ Multimodal processing time < 60 seconds

---

**Document Version:** 2.0  
**Last Updated:** 2024-01-XX  
**Status:** Enhanced with Multimodal Support




