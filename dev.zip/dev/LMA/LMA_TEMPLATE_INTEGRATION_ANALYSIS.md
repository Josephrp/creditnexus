# LMA Template Integration Analysis for CreditNexus

## Executive Summary

This document provides a comprehensive analysis of integrating Loan Market Association (LMA) document templates into CreditNexus. The system will enable AI-powered generation of LMA-compliant loan documentation by filling out LMA templates using structured data from the FINOS Common Domain Model (CDM).

**Key Insight:** CreditNexus currently extracts structured data FROM documents. This integration adds the reverse capability: generating documents FROM structured data, specifically using LMA's industry-standard templates.

---

## 1. Comprehensive List of Paywalled LMA Templates

Based on the LMA Documentation Hub (https://www.lma.eu.com/documents-guidelines/documents), the following templates are available (paywalled for non-members):

### 1.1 Primary Facility Agreements

#### Corporate Lending - Syndicated
- **Corporate Lending Facility Agreement** (LMA.Automate available)
  - Investment Grade Facility Agreement (base template)
  - Corporate Lending Facility Agreement (hybrid investment grade/leveraged)
  - Multi-currency options
  - Governing law: English, NY, Delaware

#### Corporate Lending - Bilateral
- **Bilateral Corporate Lending Facility Agreement** (LMA.Automate available)
  - Single lender structure
  - Stripped syndication language
  - Acquisition finance variants

#### Real Estate Finance (REF)
- **REF Facility Agreement** (LMA.Automate available)
- **REF Term Sheet** (LMA.Automate available)
- **REF Security Agreement** (LMA.Automate available)
- Investment Grade Real Estate (3 variants)
- Real Estate Finance (32 variants total)
- German Real Estate Documents (4 variants)

#### Leveraged Finance
- **Leveraged Facility Agreement** (28 variants)
  - Term Loan B structures
  - Revolving credit facilities
  - Mezzanine facilities
  - Unitranche structures

#### Investment Grade
- **Investment Grade Facility Agreement** (13 variants)
  - Multi-currency revolving facilities
  - Term loan facilities
  - Swingline facilities

### 1.2 Term Sheets

- **Corporate Lending Term Sheet** (LMA.Automate available)
- **Bilateral Corporate Lending Term Sheet** (LMA.Automate available)
- **REF Term Sheet** (LMA.Automate available)
- Leveraged Finance Term Sheets (10 variants)
- Investment Grade Term Sheets
- Fund Finance Term Sheets

### 1.3 Origination & Syndication Documents

#### Mandate Letters
- **Mandate Letter** (LMA.Automate available)
- Coordinator Letters (3 variants)
- Commitment Letters (2 variants)
- Duty of Care Agreements (1 variant)
- No Front Running Letters (1 variant)

#### Confidentiality Agreements
- **Confidentiality and No Front Running - Primary Syndication** (LMA.Automate available)
- **Confidentiality Undertaking - Potential Lenders To Credit Protection Providers** (LMA.Automate available)
- **Confidentiality Letter (Disclosing Party)** (LMA.Automate available)
- **Confidentiality Letter (Recipient)** (LMA.Automate available)
- **Confidentiality Letter (Disclosing Party's Agent/Broker)** (LMA.Automate available)
- **Confidentiality Letter (Recipient's Agent/Broker)** (LMA.Automate available)
- **Master Confidentiality Undertaking** (LMA.Automate available)
- **Master Confidentiality Undertaking For Admin/Settlement Service Providers** (LMA.Automate available)
- Additional Confidentiality Agreements (9 total variants)

### 1.4 Secondary Market Documents

#### Trade Confirmations
- **Secondary Trade Confirmations** (LMA.Automate available)
- Trade Confirmations and Recaps (4 variants)
- Secondary Statements and Notices (4 variants)
- Secondary Terms and Conditions (2 variants)

#### Transfer/Assignment Documents
- Transfer/Assignment Agreements (3 variants)
- Participation Agreements (7 variants)
- Netting Agreements (2 variants)

### 1.5 Security & Intercreditor Documents

- **Intercreditor Agreements** (7 variants)
  - Senior/Subordinated structures
  - Pari passu structures
  - Unitranche intercreditor
- **Security Agreements** (3 variants)
- **Shareholder Security Agreements** (1 variant)
- **Subordination Agreements** (1 variant)

### 1.6 Specialized Finance Documents

#### Fund Finance
- **Fund Finance Documents** (1 category)
  - Subscription Facilities
  - Capital Call Facilities

#### Commodities Finance
- **Borrowing Base Documents** (3 variants)
- **PXF (Pre-Export Finance) Documents** (4 variants)

#### Export Finance
- **Export Finance Documents** (11 variants)
  - ECA-backed facilities
  - Buyer credit facilities

#### Credit Risk Insurance
- **Credit Risk Insurance Documents** (2 variants)

### 1.7 Regional & Jurisdictional Documents

#### German Documents
- **Schuldscheindarlehen Documents** (6 variants)
- German Investment Grade (3 variants)
- German Real Estate (4 variants)

#### French Documents
- **French Facility Agreements** (4 variants)

#### Spanish Documents
- **Spanish Facility Agreements** (multiple variants)

#### African Documents
- **Africa Documents (excl South Africa)** (5 variants)
- **South African Documents** (10 variants)

### 1.8 Sustainable Finance Documents

#### Sustainability-Linked Loans
- **Sustainability Linked Documents** (6 variants)
  - Sustainability Performance Targets (SPT)
  - Margin adjustment mechanisms
  - KPI monitoring frameworks

#### Use of Proceeds
- **Use of Proceeds Documents** (7 variants)
  - Green loan frameworks
  - Social bond frameworks

#### Sustainable Finance Resources
- **SF Resources** (9 variants)
  - Guidance notes
  - Best practice documents

### 1.9 Regulatory & Compliance Documents

#### BRRD (Bank Recovery and Resolution Directive)
- **Article 55 BRRD Documents** (4 variants)
  - Bail-in provisions
  - Resolution clauses

#### NPL Directive
- **NPL Directive Documents** (10 variants)
  - Non-performing loan frameworks

#### Tax Documents
- **DAC 6 Documents** (1 variant)
- **FATCA Documents** (3 variants)

### 1.10 Restructuring Documents

- **Restructuring Documents** (4 variants)
  - Amendment and restatement agreements
  - Waiver letters
  - Standstill agreements

### 1.11 Supporting Documents

#### Guidance Notes
- **Guidance Notes** (47 variants)
  - Market practice guidance
  - Legal interpretation notes

#### Drafting Guides
- **Drafting Guides** (2 variants)
  - Best practice drafting
  - Common pitfalls

#### User Guides
- **User Guides** (42 variants)
  - Template usage instructions
  - Field-by-field guidance

#### Riders
- **Riders** (20 variants)
  - Additional clauses
  - Market-specific provisions

#### Glossaries
- **Glossaries** (multiple)
  - Term definitions
  - Market terminology

### 1.11 LMA.Automate Templates (Premium)

The following templates are available in **LMA.Automate** (automated questionnaire-based generation):

1. **Bilateral Corporate Lending Facility Agreement**
2. **Bilateral Corporate Lending Term Sheet**
3. **Corporate Lending Facility Agreement**
4. **Corporate Lending Term Sheet**
5. **Mandate Letter**
6. **Confidentiality Undertakings** (all variants)
7. **Secondary Trade Confirmations**
8. **Real Estate Finance (REF) Facility Agreement**
9. **REF Term Sheet**
10. **REF Security Agreement**

**Note:** LMA.Automate Premium includes additional features:
- Document editing and version control
- House style conversion
- Collaboration tools
- Data extraction and analytics
- API integrations (DocuSign, iManage)

---

## 2. Use Cases: Where LMA Templates Are Used in Loan Markets

### 2.1 Primary Market (Loan Origination)

#### 2.1.1 Deal Origination
- **Use Case:** Investment bank originates a new syndicated loan
- **Templates Used:**
  - Mandate Letter (appointment of arranger)
  - Confidentiality Agreements (during syndication)
  - Term Sheet (initial deal terms)
  - Facility Agreement (final executed document)
- **Workflow:**
  1. Mandate letter sent to borrower
  2. Confidentiality agreements with potential lenders
  3. Term sheet negotiation
  4. Facility agreement drafting and execution

#### 2.1.2 Bilateral Lending
- **Use Case:** Single bank provides loan to corporate borrower
- **Templates Used:**
  - Bilateral Corporate Lending Facility Agreement
  - Bilateral Corporate Lending Term Sheet
- **Workflow:**
  1. Term sheet negotiation
  2. Facility agreement execution

#### 2.1.3 Real Estate Finance
- **Use Case:** Property developer secures financing for acquisition/development
- **Templates Used:**
  - REF Facility Agreement
  - REF Term Sheet
  - REF Security Agreement (property collateral)
- **Workflow:**
  1. Term sheet
  2. Facility agreement
  3. Security agreement (property mortgage)

#### 2.1.4 Leveraged Buyout (LBO)
- **Use Case:** Private equity firm acquires company using debt
- **Templates Used:**
  - Leveraged Facility Agreement (Term Loan B)
  - Intercreditor Agreement (senior/subordinated)
  - Security Agreements
- **Workflow:**
  1. Facility agreement for senior debt
  2. Intercreditor agreement (if multiple debt tranches)
  3. Security package documentation

### 2.2 Secondary Market (Loan Trading)

#### 2.2.1 Loan Assignment
- **Use Case:** Lender sells loan to another institution
- **Templates Used:**
  - Transfer/Assignment Agreement
  - Trade Confirmation
  - Secondary Terms and Conditions
- **Workflow:**
  1. Trade confirmation (initial trade)
  2. Assignment agreement (legal transfer)
  3. Notice to borrower/agent

#### 2.2.2 Loan Participation
- **Use Case:** Lender sells economic interest without legal transfer
- **Templates Used:**
  - Participation Agreement
  - Trade Confirmation
- **Workflow:**
  1. Trade confirmation
  2. Participation agreement execution

### 2.3 Loan Administration

#### 2.3.1 Amendment & Waiver
- **Use Case:** Borrower requests amendment to existing facility
- **Templates Used:**
  - Amendment and Restatement Agreement
  - Waiver Letter
- **Workflow:**
  1. Borrower request
  2. Lender consent
  3. Amendment documentation

#### 2.3.2 Restructuring
- **Use Case:** Distressed borrower negotiates debt restructuring
- **Templates Used:**
  - Restructuring Documents
  - Standstill Agreement
  - Amendment Agreements
- **Workflow:**
  1. Standstill agreement (temporary relief)
  2. Restructuring negotiations
  3. Amendment/restatement of facility

### 2.4 Sustainable Finance

#### 2.4.1 Sustainability-Linked Loan (SLL)
- **Use Case:** Borrower obtains loan with ESG performance targets
- **Templates Used:**
  - Sustainability Linked Facility Agreement
  - Sustainability Performance Target (SPT) documentation
- **Workflow:**
  1. ESG KPI target definition
  2. Facility agreement with SPT provisions
  3. Ongoing monitoring and margin adjustments

#### 2.4.2 Green Loan
- **Use Case:** Borrower obtains loan for green projects
- **Templates Used:**
  - Use of Proceeds Facility Agreement
  - Green Loan Framework documentation
- **Workflow:**
  1. Project eligibility assessment
  2. Facility agreement with use of proceeds restrictions
  3. Ongoing reporting requirements

### 2.5 Specialized Finance

#### 2.5.1 Fund Finance
- **Use Case:** Private equity fund obtains subscription line facility
- **Templates Used:**
  - Fund Finance Facility Agreement
  - Subscription Facility Agreement
- **Workflow:**
  1. Fund structure analysis
  2. Facility agreement (secured by capital commitments)
  3. Ongoing capital call monitoring

#### 2.5.2 Commodities Finance
- **Use Case:** Trader obtains financing secured by commodity inventory
- **Templates Used:**
  - Borrowing Base Facility Agreement
  - PXF (Pre-Export Finance) Agreement
- **Workflow:**
  1. Inventory valuation
  2. Borrowing base facility agreement
  3. Ongoing inventory monitoring

---

## 3. Integration Architecture: LMA Template System in CreditNexus

### 3.1 System Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    CreditNexus Frontend                     │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Document Generator App (New)                        │   │
│  │  - Template Selection                                │   │
│  │  - Data Input Form (CDM-based)                      │   │
│  │  - AI-Powered Field Population                      │   │
│  │  - Document Preview                                  │   │
│  │  - Export (Word/PDF)                                 │   │
│  └──────────────────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Existing Apps                                        │   │
│  │  - Docu-Digitizer (Extract → CDM)                    │   │
│  │  - Trade Blotter                                     │   │
│  │  - GreenLens (ESG)                                   │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                          ↕ HTTP/REST + FDC3
┌─────────────────────────────────────────────────────────────┐
│                  FastAPI Backend (Python)                    │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Template Management Service                         │   │
│  │  - Template Storage (LMA templates)                  │   │
│  │  - Template Metadata                                 │   │
│  │  - Version Control                                   │   │
│  └──────────────────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Document Generation Service                          │   │
│  │  - CDM → Template Mapping                             │   │
│  │  - AI Field Population (LLM)                          │   │
│  │  - Document Rendering (Word/PDF)                      │   │
│  └──────────────────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Existing Services                                   │   │
│  │  - Extraction Chain (Text → CDM)                     │   │
│  │  - Workflow Engine                                    │   │
│  │  - Analytics                                          │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                          ↕
┌─────────────────────────────────────────────────────────────┐
│              Data Layer (PostgreSQL + File Storage)         │
│  - Documents (existing)                                     │
│  - Templates (new: LMA template files)                     │
│  - Template Instances (generated documents)                 │
│  - CDM Data (existing)                                      │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 Data Flow: CDM → LMA Template

```
┌─────────────────┐
│  CDM Data       │
│  (CreditAgreement)│
└────────┬────────┘
         │
         ▼
┌─────────────────────────────────┐
│  CDM → Template Mapper          │
│  - Maps CDM fields to template  │
│    placeholders                 │
│  - Handles missing fields       │
│  - Applies business rules       │
└────────┬─────────────────────────┘
         │
         ▼
┌─────────────────────────────────┐
│  AI Field Population Engine     │
│  - LLM fills complex clauses    │
│  - Legal language generation    │
│  - Compliance checking          │
└────────┬─────────────────────────┘
         │
         ▼
┌─────────────────────────────────┐
│  Template Renderer              │
│  - Word document generation     │
│  - PDF export                   │
│  - Formatting preservation      │
└────────┬─────────────────────────┘
         │
         ▼
┌─────────────────────────────────┐
│  Generated LMA Document         │
│  - Ready for review/execution   │
│  - Stored in Document Library   │
└─────────────────────────────────┘
```

### 3.3 New Components Required

#### 3.3.1 Backend Components

**1. Template Management Module** (`app/templates/`)
```
app/templates/
├── __init__.py
├── models.py              # Template metadata models
├── storage.py             # Template file storage (S3/local)
├── registry.py            # Template registry and lookup
└── versioning.py          # Template version management
```

**2. Document Generation Module** (`app/generation/`)
```
app/generation/
├── __init__.py
├── mapper.py              # CDM → Template field mapping
├── populator.py           # AI-powered field population
├── renderer.py            # Word/PDF document rendering
└── validator.py           # Generated document validation
```

**3. Template Prompt Library** (`app/prompts/templates/`)
```
app/prompts/templates/
├── __init__.py
├── facility_agreement.py  # Prompts for facility agreements
├── term_sheet.py          # Prompts for term sheets
├── confidentiality.py     # Prompts for confidentiality docs
└── intercreditor.py       # Prompts for intercreditor docs
```

#### 3.3.2 Frontend Components

**1. Document Generator App** (`client/src/apps/document-generator/`)
```
client/src/apps/document-generator/
├── DocumentGenerator.tsx      # Main component
├── TemplateSelector.tsx        # Template selection UI
├── DataInputForm.tsx          # CDM data input form
├── FieldMapper.tsx            # Manual field mapping
├── DocumentPreview.tsx        # Preview generated doc
└── ExportDialog.tsx           # Export options
```

**2. Template Library View** (`client/src/components/TemplateLibrary.tsx`)
- Browse available LMA templates
- Filter by category (Facility Agreement, Term Sheet, etc.)
- View template metadata and requirements

#### 3.3.3 Database Schema Extensions

**New Tables:**

```sql
-- Template metadata
CREATE TABLE lma_templates (
    id SERIAL PRIMARY KEY,
    template_code VARCHAR(50) UNIQUE NOT NULL,  -- e.g., "LMA-CL-FA-2024"
    name VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,             -- Facility Agreement, Term Sheet, etc.
    subcategory VARCHAR(100),                   -- Corporate Lending, REF, etc.
    governing_law VARCHAR(50),                  -- English, NY, etc.
    version VARCHAR(20) NOT NULL,
    file_path TEXT NOT NULL,                    -- Path to template file
    metadata JSONB,                            -- Template-specific metadata
    required_fields JSONB,                     -- Required CDM fields
    optional_fields JSONB,                     -- Optional CDM fields
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Generated document instances
CREATE TABLE generated_documents (
    id SERIAL PRIMARY KEY,
    template_id INTEGER REFERENCES lma_templates(id),
    source_document_id INTEGER REFERENCES documents(id),  -- If generated from existing doc
    cdm_data JSONB NOT NULL,                    -- CDM data used for generation
    generated_content TEXT,                     -- Generated document text
    file_path TEXT,                            -- Path to generated file
    status VARCHAR(50) DEFAULT 'draft',       -- draft, review, approved, executed
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Template field mappings
CREATE TABLE template_field_mappings (
    id SERIAL PRIMARY KEY,
    template_id INTEGER REFERENCES lma_templates(id),
    template_field VARCHAR(255) NOT NULL,      -- Field name in template
    cdm_field VARCHAR(255) NOT NULL,          -- CDM field path
    mapping_type VARCHAR(50),                 -- direct, computed, ai_generated
    transformation_rule TEXT,                 -- Optional transformation
    is_required BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW()
);
```

---

## 4. CDM Compliance: Mapping CDM to LMA Templates

### 4.1 CDM Model Structure (Current)

```python
CreditAgreement
├── agreement_date: date
├── parties: List[Party]
│   ├── id, name, role, lei, jurisdiction
├── facilities: List[LoanFacility]
│   ├── facility_name
│   ├── commitment_amount: Money (amount, currency)
│   ├── interest_terms: InterestRatePayout
│   │   ├── rate_option: FloatingRateOption (benchmark, spread_bps)
│   │   └── payment_frequency: Frequency
│   └── maturity_date: date
├── governing_law: str
├── sustainability_linked: bool
├── esg_kpi_targets: List[ESGKPITarget]
│   ├── kpi_type, target_value, unit, margin_adjustment_bps
├── deal_id: str
└── loan_identification_number: str
```

### 4.2 CDM → LMA Template Field Mapping

#### 4.2.1 Facility Agreement Mapping

| LMA Template Field | CDM Source | Mapping Type | Notes |
|-------------------|------------|--------------|-------|
| `[BORROWER_NAME]` | `parties[role="Borrower"].name` | Direct | First borrower if multiple |
| `[BORROWER_LEI]` | `parties[role="Borrower"].lei` | Direct | Optional |
| `[FACILITY_NAME]` | `facilities[0].facility_name` | Direct | Primary facility |
| `[COMMITMENT_AMOUNT]` | `facilities[0].commitment_amount.amount` | Direct | Formatted with currency |
| `[CURRENCY]` | `facilities[0].commitment_amount.currency` | Direct | USD, EUR, GBP, JPY |
| `[MATURITY_DATE]` | `facilities[0].maturity_date` | Direct | Formatted as DD MMMM YYYY |
| `[BENCHMARK]` | `facilities[0].interest_terms.rate_option.benchmark` | Direct | SOFR, EURIBOR, etc. |
| `[SPREAD]` | `facilities[0].interest_terms.rate_option.spread_bps` | Computed | Convert bps to percentage |
| `[PAYMENT_FREQUENCY]` | `facilities[0].interest_terms.payment_frequency` | Computed | Format: "Quarterly", "Semi-annually" |
| `[AGREEMENT_DATE]` | `agreement_date` | Direct | Formatted as DD MMMM YYYY |
| `[GOVERNING_LAW]` | `governing_law` | Direct | English, NY, Delaware |
| `[LENDERS]` | `parties[role="Lender"]` | Computed | List of lender names |
| `[ADMINISTRATIVE_AGENT]` | `parties[role="Administrative Agent"].name` | Direct | Optional |
| `[SUSTAINABILITY_LINKED]` | `sustainability_linked` | Direct | Boolean flag |
| `[ESG_KPIS]` | `esg_kpi_targets` | AI Generated | Generate SPT clauses |
| `[DEAL_ID]` | `deal_id` | Direct | Optional |
| `[LIN]` | `loan_identification_number` | Direct | Optional |

#### 4.2.2 Term Sheet Mapping

| LMA Template Field | CDM Source | Mapping Type | Notes |
|-------------------|------------|--------------|-------|
| `[BORROWER]` | `parties[role="Borrower"].name` | Direct | |
| `[FACILITY_TYPE]` | `facilities[0].facility_name` | Computed | Extract type: "Term Loan", "Revolving" |
| `[TOTAL_COMMITMENT]` | Sum of `facilities[].commitment_amount.amount` | Computed | Total across all facilities |
| `[PRICING]` | `facilities[0].interest_terms.rate_option` | Computed | Format: "SOFR + 250 bps" |
| `[TENOR]` | `facilities[0].maturity_date - agreement_date` | Computed | Calculate years/months |
| `[PURPOSE]` | N/A | AI Generated | Generate from context or user input |
| `[CONDITIONS_PRECEDENT]` | N/A | AI Generated | Standard LMA conditions |
| `[REPRESENTATIONS]` | N/A | AI Generated | Standard LMA representations |

#### 4.2.3 Confidentiality Agreement Mapping

| LMA Template Field | CDM Source | Mapping Type | Notes |
|-------------------|------------|--------------|-------|
| `[DISCLOSING_PARTY]` | `parties[role="Borrower"].name` | Direct | |
| `[RECIPIENT_PARTY]` | User input or `parties[role="Lender"].name` | Direct/Input | |
| `[DEAL_NAME]` | `deal_id` or generated | Computed | |
| `[EFFECTIVE_DATE]` | Current date | System | |

### 4.3 AI-Powered Field Population

For fields that cannot be directly mapped from CDM, use AI to generate appropriate content:

#### 4.3.1 Complex Clauses

**Example: Representations and Warranties**
- **Input:** CDM data + template context
- **AI Task:** Generate standard LMA representations based on:
  - Facility type (corporate, real estate, leveraged)
  - Governing law
  - Borrower jurisdiction
- **Output:** Formatted legal text matching LMA style

#### 4.3.2 Conditions Precedent

**Example: CP List**
- **Input:** Facility type, governing law, borrower jurisdiction
- **AI Task:** Generate standard conditions precedent checklist
- **Output:** Numbered list of conditions (legal opinions, corporate authorizations, etc.)

#### 4.3.3 ESG/SPT Clauses

**Example: Sustainability Performance Targets**
- **Input:** `esg_kpi_targets` from CDM
- **AI Task:** Generate SPT clause with:
  - KPI definitions
  - Measurement methodology
  - Margin adjustment mechanism
  - Reporting requirements
- **Output:** Formatted SPT clause matching LMA Sustainable Finance templates

### 4.4 CDM Extensions for Template Generation

To support comprehensive template generation, consider extending the CDM model:

```python
class CreditAgreementExtended(CreditAgreement):
    """Extended CDM model for template generation."""
    
    # Additional fields for template generation
    deal_purpose: Optional[str] = Field(
        None,
        description="Purpose of the loan (e.g., 'General corporate purposes', 'Acquisition financing')"
    )
    
    security_package: Optional[List[Security]] = Field(
        None,
        description="Security/collateral package"
    )
    
    conditions_precedent: Optional[List[str]] = Field(
        None,
        description="Conditions precedent to drawdown"
    )
    
    representations: Optional[List[str]] = Field(
        None,
        description="Borrower representations and warranties"
    )
    
    covenants: Optional[List[Covenant]] = Field(
        None,
        description="Financial and non-financial covenants"
    )
    
    events_of_default: Optional[List[str]] = Field(
        None,
        description="Events of default"
    )
    
    fees: Optional[List[Fee]] = Field(
        None,
        description="Upfront fees, commitment fees, etc."
    )
```

---

## 5. Implementation Plan

> **Note:** For detailed implementation plan with projects, activities, tasks, and subtasks, see `LMA_TEMPLATE_IMPLEMENTATION_PLAN.md`

### 5.1 Phase 1: Foundation (Weeks 1-4)

**Backend:**
1. Create template storage infrastructure
   - File storage for LMA templates (Word documents)
   - Template metadata database schema
   - Template registry API

2. Implement basic CDM → Template mapper
   - Direct field mapping
   - Simple computed fields (date formatting, currency formatting)
   - Template placeholder replacement

3. Create document generation endpoint
   - `POST /api/templates/generate`
   - Accepts: template_id, cdm_data
   - Returns: generated document (Word/PDF)

**Frontend:**
1. Create Document Generator app shell
   - Basic UI structure
   - Template selector component
   - CDM data input form

### 5.2 Phase 2: AI Integration (Weeks 5-8)

**Backend:**
1. Implement AI field population
   - LLM prompts for complex clauses
   - Template-specific prompt libraries
   - Field validation and compliance checking

2. Enhanced mapping engine
   - AI-powered field inference
   - Missing field detection and suggestions
   - Multi-facility handling

**Frontend:**
1. AI-powered field suggestions
   - Auto-populate fields using AI
   - Field completion assistance
   - Validation feedback

### 5.3 Phase 3: Advanced Features (Weeks 9-12)

**Backend:**
1. Template versioning and updates
2. Multi-template workflows (e.g., Term Sheet → Facility Agreement)
3. Document comparison (generated vs. executed)
4. Compliance checking against LMA standards

**Frontend:**
1. Document preview and editing
2. Side-by-side comparison view
3. Template library browser
4. Export options (Word, PDF, tracked changes)

### 5.4 Phase 4: Integration & Workflow (Weeks 13-16)

**Backend:**
1. Integration with existing workflow engine
   - Generated documents enter review workflow
   - Link generated docs to source CDM data
   - Version tracking

2. FDC3 integration
   - Broadcast generated document context
   - Receive CDM data from other apps
   - Document generation intents

**Frontend:**
1. Workflow integration
   - Submit generated doc for review
   - Track approval status
   - Link to source documents

2. FDC3 integration
   - Document generation intents
   - Context sharing with other apps

---

## 6. Technical Implementation Details

### 6.1 Template Storage

**Option 1: File System Storage**
- Store LMA templates as Word documents in `storage/templates/`
- Organize by category: `facility_agreements/`, `term_sheets/`, etc.
- Pros: Simple, direct access
- Cons: Version control, backup complexity

**Option 2: Object Storage (S3/MinIO)**
- Store templates in S3-compatible storage
- Metadata in PostgreSQL
- Pros: Scalable, versioned, backup-friendly
- Cons: Additional infrastructure

**Recommendation:** Start with file system, migrate to S3 for production.

### 6.2 Document Rendering

**Library: `python-docx` + `docx2pdf`**
- Read Word templates
- Replace placeholders with CDM data
- Generate Word output
- Convert to PDF if needed

**Alternative: `python-docx-template`**
- Jinja2-style templating in Word
- More flexible placeholder system
- Better for complex documents

**Recommendation:** Use `python-docx-template` for flexibility.

### 6.3 AI Field Population

**Approach:**
1. Identify fields requiring AI generation
2. Load template-specific prompt templates
3. Construct prompt with CDM context
4. Call LLM (GPT-4o) for generation
5. Validate output against LMA standards
6. Insert into document

**Prompt Structure:**
```
You are a legal document drafting assistant specializing in LMA loan documentation.

Template: [Template Name]
Governing Law: [English/NY]
Facility Type: [Corporate Lending/REF/Leveraged]

CDM Data:
[Relevant CDM fields]

Task: Generate [specific clause/section] that:
- Matches LMA standard form language
- Is appropriate for [governing law] jurisdiction
- Incorporates the following terms: [key terms from CDM]

Output: [Format requirements]
```

### 6.4 CDM Validation for Templates

Before generating a document, validate that CDM data contains required fields:

```python
def validate_cdm_for_template(cdm_data: CreditAgreement, template: LMATemplate) -> ValidationResult:
    """Validate CDM data has all required fields for template."""
    required_fields = template.required_fields
    missing = []
    
    for field_path in required_fields:
        if not get_nested_field(cdm_data, field_path):
            missing.append(field_path)
    
    if missing:
        return ValidationResult(
            valid=False,
            missing_fields=missing,
            message=f"Missing required fields: {', '.join(missing)}"
        )
    
    return ValidationResult(valid=True)
```

---

## 7. Compliance & Legal Considerations

### 7.1 LMA Template Usage

**Important:** LMA templates are proprietary and paywalled. To use them in CreditNexus:

1. **LMA Membership Required:** Users must be LMA members to access templates
2. **Template Licensing:** Ensure proper licensing for template usage
3. **Attribution:** Generated documents should include LMA template attribution
4. **Version Control:** Track which LMA template version was used

### 7.2 Generated Document Disclaimer

Generated documents should include:

```
This document was generated using LMA template [Template Code] version [Version].
The document has been automatically populated with data and may require legal review
before execution. CreditNexus and LMA do not warrant the accuracy or completeness
of the generated content.
```

### 7.3 Data Privacy

- CDM data used for generation is stored in `generated_documents` table
- Link to source documents for audit trail
- User access controls (who can generate documents)
- Audit logging of all generation activities

---

## 8. Integration Points in CreditNexus

### 8.1 Existing Systems Integration

#### 8.1.1 Document Library
- **Integration:** Generated documents stored alongside extracted documents
- **Workflow:** Generated docs enter same review/approval workflow
- **UI:** Document Library shows both extracted and generated documents

#### 8.1.2 Docu-Digitizer App
- **Reverse Flow:** Extract document → Generate new version from template
- **Use Case:** User extracts terms from executed document, generates new facility agreement with updated terms

#### 8.1.3 Workflow Engine
- **Integration:** Generated documents start in DRAFT state
- **Workflow:** DRAFT → UNDER_REVIEW → APPROVED → PUBLISHED
- **Approval:** Legal/compliance review of generated documents

#### 8.1.4 Analytics Dashboard
- **Metrics:** Track template usage, generation success rates
- **Reports:** Most used templates, generation trends

### 8.2 FDC3 Integration

**New Intents:**
- `GenerateLMATemplate` - Generate document from template
- `ViewGeneratedDocument` - View generated document

**New Context Types:**
- `finos.creditnexus.template` - Template selection context
- `finos.creditnexus.generatedDocument` - Generated document context

**Channels:**
- `creditnexus.generation` - Document generation events

### 8.3 API Endpoints

**New Endpoints:**

```python
# Template Management
GET    /api/templates                    # List available templates
GET    /api/templates/{id}               # Get template metadata
GET    /api/templates/{id}/requirements  # Get required CDM fields

# Document Generation
POST   /api/templates/generate           # Generate document from template
GET    /api/generated-documents          # List generated documents
GET    /api/generated-documents/{id}     # Get generated document
POST   /api/generated-documents/{id}/export  # Export as Word/PDF

# Field Mapping
GET    /api/templates/{id}/mappings      # Get CDM field mappings
POST   /api/templates/{id}/mappings      # Customize mappings
```

---

## 9. Example Use Case: End-to-End Flow

### 9.1 Scenario: New Syndicated Loan Facility

**Step 1: Extract Existing Document (Optional)**
- User uploads executed facility agreement PDF
- Docu-Digitizer extracts data → CDM format
- CDM data stored in Document Library

**Step 2: Generate New Facility Agreement**
- User opens Document Generator app
- Selects "Corporate Lending Facility Agreement" template
- System loads CDM data (or user inputs manually)
- AI populates template fields:
  - Direct mapping: Borrower name, commitment amount, maturity date
  - Computed: Spread percentage, payment frequency description
  - AI-generated: Representations, conditions precedent, covenants

**Step 3: Review Generated Document**
- Document preview shown in UI
- User can edit fields manually
- System highlights AI-generated sections for review

**Step 4: Submit for Review**
- Generated document enters workflow (DRAFT → UNDER_REVIEW)
- Assigned to legal/compliance reviewer
- Reviewer approves or requests changes

**Step 5: Export and Execution**
- Approved document exported as Word (with tracked changes)
- Sent to borrower/counterparties for negotiation
- Final executed version uploaded back to CreditNexus

**Step 6: Link and Track**
- Generated document linked to source CDM data
- Version history maintained
- Changes tracked in audit log

---

## 10. Success Metrics

### 10.1 Technical Metrics
- Template generation success rate (>95%)
- Field population accuracy (>90% for direct mappings)
- AI-generated clause quality (legal review approval rate)
- Document generation time (<30 seconds for standard templates)

### 10.2 Business Metrics
- Template usage frequency
- User adoption rate
- Time saved vs. manual drafting
- Document approval rate (generated vs. manually drafted)

### 10.3 Compliance Metrics
- LMA template version compliance
- Generated document legal review findings
- Template attribution accuracy

---

## 11. Risks & Mitigations

### 11.1 Legal Risks
- **Risk:** Generated documents may contain errors or non-compliant language
- **Mitigation:** 
  - Clear disclaimers on generated documents
  - Mandatory legal review workflow
  - AI-generated sections clearly marked
  - Version control and audit trail

### 11.2 Template Licensing Risks
- **Risk:** Unauthorized use of LMA templates
- **Mitigation:**
  - LMA membership verification
  - Template access controls
  - Usage tracking and reporting

### 11.3 Data Quality Risks
- **Risk:** Incomplete or incorrect CDM data leads to poor document quality
- **Mitigation:**
  - CDM validation before generation
  - Missing field detection and warnings
  - User review and editing capabilities

### 11.4 AI Generation Risks
- **Risk:** AI generates non-standard or incorrect legal language
- **Mitigation:**
  - Template-specific prompt engineering
  - Output validation against LMA standards
  - Human-in-the-loop review process

---

## 12. Conclusion

The integration of LMA templates into CreditNexus creates a powerful bidirectional document workflow:

1. **Extract:** CreditNexus extracts structured data FROM loan documents (existing)
2. **Generate:** CreditNexus generates loan documents FROM structured data (new)

This enables:
- **Efficiency:** Automated document generation from standardized data
- **Consistency:** LMA-compliant documents using industry standards
- **Compliance:** CDM-compliant data model ensures interoperability
- **Workflow:** Seamless integration with existing review/approval processes

The system maintains CDM compliance by:
- Using CDM as the source of truth for document generation
- Mapping CDM fields to LMA template placeholders
- Extending CDM where needed for template-specific requirements
- Storing generated documents with CDM metadata for traceability

**Next Steps:**
1. Obtain LMA template access/licenses
2. Implement Phase 1 (Foundation)
3. Pilot with select LMA templates (Facility Agreement, Term Sheet)
4. Gather user feedback and iterate
5. Expand to full template library

---

## Appendix A: Template Categories Summary

| Category | Count | Key Templates |
|----------|-------|---------------|
| Facility Agreements | 32+ | Corporate Lending, REF, Leveraged, Investment Grade |
| Term Sheets | 10+ | Corporate, REF, Leveraged |
| Confidentiality Agreements | 9 | Primary Syndication, Master, Agent/Broker variants |
| Secondary Trading | 32+ | Trade Confirmations, Assignments, Participations |
| Security & Intercreditor | 11+ | Security Agreements, Intercreditor Agreements |
| Origination | 11+ | Mandate Letters, Commitment Letters |
| Sustainable Finance | 22+ | SLL, Use of Proceeds, SF Resources |
| Regional | 20+ | German, French, Spanish, African |
| Regulatory | 13+ | BRRD, NPL Directive, Tax (DAC 6, FATCA) |
| Supporting | 100+ | Guidance Notes, User Guides, Riders |

**Total:** 236+ LMA documents available

---

## Appendix B: CDM Field Mapping Reference

### B.1 Party Fields

```python
# Borrower
parties[role="Borrower"][0].name → [BORROWER_NAME]
parties[role="Borrower"][0].lei → [BORROWER_LEI]
parties[role="Borrower"][0].jurisdiction → [BORROWER_JURISDICTION]

# Lenders
[parties[role="Lender"] for p in parties] → [LENDERS_LIST]
parties[role="Lender"][0].name → [LEAD_LENDER]

# Agents
parties[role="Administrative Agent"].name → [ADMIN_AGENT]
parties[role="Security Agent"].name → [SECURITY_AGENT]
```

### B.2 Facility Fields

```python
# Primary Facility (first facility)
facilities[0].facility_name → [FACILITY_NAME]
facilities[0].commitment_amount.amount → [COMMITMENT_AMOUNT]
facilities[0].commitment_amount.currency → [CURRENCY]
facilities[0].maturity_date → [MATURITY_DATE]

# Interest Terms
facilities[0].interest_terms.rate_option.benchmark → [BENCHMARK]
facilities[0].interest_terms.rate_option.spread_bps → [SPREAD_BPS]
facilities[0].interest_terms.payment_frequency.period → [PAYMENT_PERIOD]
facilities[0].interest_terms.payment_frequency.period_multiplier → [PAYMENT_FREQUENCY]

# Multiple Facilities
len(facilities) → [FACILITY_COUNT]
sum(f.commitment_amount.amount for f in facilities) → [TOTAL_COMMITMENT]
```

### B.3 ESG Fields

```python
sustainability_linked → [IS_SLL]  # Boolean
esg_kpi_targets[0].kpi_type → [ESG_KPI_TYPE]
esg_kpi_targets[0].target_value → [ESG_TARGET_VALUE]
esg_kpi_targets[0].margin_adjustment_bps → [ESG_MARGIN_ADJUSTMENT]
```

---

## Appendix C: Sample API Request/Response

### C.1 Generate Document Request

```json
POST /api/templates/generate
{
  "template_id": 1,
  "cdm_data": {
    "agreement_date": "2024-01-15",
    "parties": [
      {
        "id": "borrower-1",
        "name": "Acme Corporation",
        "role": "Borrower",
        "lei": "5493000X8X8X8X8X8X8"
      },
      {
        "id": "lender-1",
        "name": "Bank of Example",
        "role": "Lender"
      }
    ],
    "facilities": [
      {
        "facility_name": "Term Loan A",
        "commitment_amount": {
          "amount": "100000000.00",
          "currency": "USD"
        },
        "interest_terms": {
          "rate_option": {
            "benchmark": "SOFR",
            "spread_bps": 250.0
          },
          "payment_frequency": {
            "period": "Month",
            "period_multiplier": 3
          }
        },
        "maturity_date": "2029-01-15"
      }
    ],
    "governing_law": "NY",
    "sustainability_linked": false
  },
  "options": {
    "format": "word",
    "include_tracked_changes": false
  }
}
```

### C.2 Generate Document Response

```json
{
  "status": "success",
  "generated_document_id": 123,
  "template_used": {
    "id": 1,
    "name": "Corporate Lending Facility Agreement",
    "version": "2024.1"
  },
  "generation_summary": {
    "fields_populated": 45,
    "fields_ai_generated": 12,
    "fields_manual_required": 3,
    "warnings": [
      "Missing borrower jurisdiction - using default",
      "ESG KPI targets not provided for sustainability-linked loan"
    ]
  },
  "document_url": "/api/generated-documents/123/download",
  "workflow_state": "draft"
}
```

---

**Document Version:** 1.0  
**Last Updated:** 2024-01-XX  
**Author:** CreditNexus Development Team

