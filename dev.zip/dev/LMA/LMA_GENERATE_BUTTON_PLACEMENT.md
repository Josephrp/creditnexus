# Generate Button Placement Guide

## Overview

This document specifies exactly where "Generate LMA Document" buttons should be placed in the CreditNexus user interface to enable seamless template generation from any point in the workflow.

---

## 1. Document Parser App

### Location: After Successful Extraction
**File:** `client/src/apps/docu-digitizer/DocumentParser.tsx`  
**Line:** ~200-250 (after extracted data display)

### Implementation:
```tsx
// After extraction success, in the review section
{extractedData && (
  <div className="flex gap-2 mt-4">
    <Button onClick={handleSaveToLibrary}>
      <Save className="mr-2 h-4 w-4" />
      Save to Library
    </Button>
    <Button 
      onClick={() => handleGenerateFromTemplate(extractedData)}
      variant="outline"
      className="border-blue-500 text-blue-500 hover:bg-blue-50"
    >
      <FileText className="mr-2 h-4 w-4" />
      Generate LMA Document
    </Button>
  </div>
)}
```

### User Flow:
1. User uploads PDF/text
2. System extracts CDM data
3. User reviews extracted data
4. **Generate button appears here** → Opens Document Generator with pre-populated CDM
5. User can also save to library

### Visual Design:
- Position: Right side of action buttons, after "Save to Library"
- Style: Outline button with blue accent
- Icon: FileText icon
- Tooltip: "Generate LMA document from extracted data"

---

## 2. Document Library

### Location A: Document List Item Actions
**File:** `client/src/components/DocumentHistory.tsx`  
**Line:** ~150-200 (in document card/row actions)

### Implementation:
```tsx
// In document list item, action menu
<DropdownMenu>
  <DropdownMenuTrigger>
    <Button variant="ghost" size="sm">
      <MoreVertical className="h-4 w-4" />
    </Button>
  </DropdownMenuTrigger>
  <DropdownMenuContent>
    <DropdownMenuItem onClick={() => handleViewDocument(doc.id)}>
      <Eye className="mr-2 h-4 w-4" />
      View Details
    </DropdownMenuItem>
    <DropdownMenuItem onClick={() => handleGenerateFromDocument(doc.id)}>
      <FileText className="mr-2 h-4 w-4" />
      Generate LMA Document
    </DropdownMenuItem>
    <DropdownMenuItem onClick={() => handleExport(doc.id)}>
      <Download className="mr-2 h-4 w-4" />
      Export
    </DropdownMenuItem>
  </DropdownMenuContent>
</DropdownMenu>
```

### Location B: Document Detail View
**File:** `client/src/components/DocumentHistory.tsx`  
**Line:** ~300-350 (in document detail modal/card action bar)

### Implementation:
```tsx
// In document detail view, action bar
<div className="flex gap-2 p-4 border-t">
  <Button onClick={() => handleGenerateFromDocument(doc.id)}>
    <FileText className="mr-2 h-4 w-4" />
    Generate LMA Document
  </Button>
  <Button variant="outline" onClick={() => handleExport(doc.id)}>
    <Download className="mr-2 h-4 w-4" />
    Export
  </Button>
</div>
```

### User Flow:
1. User views document list
2. User selects document
3. **Generate button in action menu** → Opens Document Generator with document's CDM data
4. Or user opens detail view → **Generate button in action bar**

### Visual Design:
- Position: In action menu (three-dot menu) or action bar
- Style: Menu item or primary button
- Icon: FileText icon
- Tooltip: "Generate new LMA document from this document's data"

---

## 3. Dashboard

### Location: Quick Actions Section
**File:** `client/src/components/Dashboard.tsx`  
**Line:** ~100-150 (in quick actions card)

### Implementation:
```tsx
// In Dashboard quick actions section
<Card>
  <CardHeader>
    <h3 className="text-lg font-semibold">Quick Actions</h3>
  </CardHeader>
  <CardContent className="grid grid-cols-2 gap-4">
    <Button 
      onClick={() => navigateToGenerator()}
      className="h-20 flex flex-col items-center justify-center"
    >
      <Sparkles className="h-6 w-6 mb-2" />
      <span>Generate LMA Document</span>
    </Button>
    <Button 
      variant="outline"
      onClick={() => setActiveApp('document-parser')}
      className="h-20 flex flex-col items-center justify-center"
    >
      <FileText className="h-6 w-6 mb-2" />
      <span>Extract Document</span>
    </Button>
  </CardContent>
</Card>
```

### User Flow:
1. User lands on dashboard
2. User sees quick actions
3. **Generate button in quick actions** → Opens Document Generator
4. User can start fresh or select template

### Visual Design:
- Position: Quick actions card, prominent placement
- Style: Large button with icon and text
- Icon: Sparkles icon (suggests AI generation)
- Size: Larger than normal buttons (h-20)

---

## 4. Document Generator App (Internal)

### Location: After Multimodal Input Processing
**File:** `client/src/apps/document-generator/DocumentGenerator.tsx`  
**Line:** ~300-350 (after input processing section)

### Implementation:
```tsx
// After all inputs processed and CDM data ready
<div className="sticky bottom-0 bg-white border-t p-4">
  <div className="flex items-center justify-between">
    <div className="text-sm text-gray-600">
      {cdmData ? (
        <span className="text-green-600">✓ Ready to generate</span>
      ) : (
        <span className="text-yellow-600">⚠ Missing required fields</span>
      )}
    </div>
    <Button 
      onClick={handleGenerate}
      disabled={!canGenerate}
      size="lg"
      className="px-8"
    >
      <Sparkles className="mr-2 h-5 w-5" />
      Generate Document
    </Button>
  </div>
</div>
```

### User Flow:
1. User selects template
2. User provides inputs (audio, image, document, text)
3. System processes inputs
4. CDM data is populated
5. **Generate button enabled** → Generates document
6. User reviews and exports

### Visual Design:
- Position: Sticky footer, always visible
- Style: Large primary button
- Icon: Sparkles icon
- State: Disabled until inputs processed and required fields filled
- Feedback: Shows readiness status

---

## 5. Workflow Actions (For Generated Documents)

### Location: Workflow Action Menu
**File:** `client/src/components/WorkflowActions.tsx`  
**Line:** ~100-150 (in workflow action buttons)

### Implementation:
```tsx
// For generated documents in DRAFT state
{workflow.state === 'draft' && document.is_generated && (
  <Button 
    onClick={() => handleRegenerate(document.id)}
    variant="outline"
    className="mr-2"
  >
    <RefreshCw className="mr-2 h-4 w-4" />
    Regenerate
  </Button>
)}
```

### User Flow:
1. User has generated document in DRAFT state
2. User wants to regenerate with changes
3. **Regenerate button** → Opens Document Generator with current CDM data
4. User makes changes and regenerates

### Visual Design:
- Position: In workflow action bar, before other actions
- Style: Outline button
- Icon: RefreshCw icon
- Condition: Only shown for generated documents in DRAFT state

---

## 6. Chatbot Panel (Within Document Generator)

### Location: Chatbot Suggestion Response
**File:** `client/src/apps/document-generator/ChatbotPanel.tsx`  
**Line:** ~200-250 (in chatbot message rendering)

### Implementation:
```tsx
// When chatbot suggests a template
{message.template_suggestions && (
  <div className="mt-2 space-y-2">
    {message.template_suggestions.map((template) => (
      <Button
        key={template.id}
        onClick={() => handleSelectTemplate(template.id)}
        variant="outline"
        size="sm"
        className="w-full justify-start"
      >
        <FileText className="mr-2 h-4 w-4" />
        {template.name}
        <span className="ml-auto text-xs text-gray-500">
          Use this template
        </span>
      </Button>
    ))}
  </div>
)}
```

### User Flow:
1. User asks chatbot about templates
2. Chatbot suggests templates
3. **Template buttons in chat** → Selects template and pre-fills form
4. User can then generate

### Visual Design:
- Position: In chatbot message, as clickable template cards
- Style: Outline buttons with template info
- Icon: FileText icon
- Action: Selects template and updates form

---

## 7. Navigation Menu

### Location: Main Navigation
**File:** `client/src/App.tsx`  
**Line:** ~50-100 (in main apps list)

### Implementation:
```tsx
// Add to mainApps array
const mainApps: { id: AppView; name: string; icon: React.ReactNode; description: string }[] = [
  {
    id: 'dashboard',
    name: 'Dashboard',
    icon: <LayoutDashboard className="h-5 w-5" />,
    description: 'Portfolio overview & analytics',
  },
  {
    id: 'document-parser',
    name: 'Document Parser',
    icon: <FileText className="h-5 w-5" />,
    description: 'Extract & digitize credit agreements',
  },
  {
    id: 'document-generator',  // NEW
    name: 'Document Generator',
    icon: <Sparkles className="h-5 w-5" />,
    description: 'Generate LMA documents from templates',
  },
  {
    id: 'library',
    name: 'Library',
    icon: <BookOpen className="h-5 w-5" />,
    description: 'Saved documents & history',
  },
];
```

### User Flow:
1. User sees main navigation
2. **Document Generator** appears as main app
3. User clicks → Opens Document Generator
4. User can start generation workflow

### Visual Design:
- Position: Main navigation, between Document Parser and Library
- Style: Main app card with icon and description
- Icon: Sparkles icon
- Description: "Generate LMA documents from templates"

---

## 8. FDC3 Intent Handler

### Location: FDC3 Context Handler
**File:** `client/src/context/FDC3Context.tsx`  
**Line:** ~200-250 (in intent processing)

### Implementation:
```tsx
// Add new intent handler
case 'GenerateLMATemplate': {
  const templateCtx = context as TemplateGenerationContext;
  if (templateCtx.cdm_data) {
    setViewData(templateCtx.cdm_data);
    setActiveApp('document-generator');
    // Pre-select template if provided
    if (templateCtx.template_id) {
      setSelectedTemplate(templateCtx.template_id);
    }
  }
  break;
}
```

### User Flow:
1. External app sends FDC3 intent with CDM data
2. CreditNexus receives intent
3. **Opens Document Generator** with pre-populated data
4. User can generate immediately

### Visual Design:
- Position: Programmatic (no UI button)
- Trigger: FDC3 intent from external app
- Action: Opens Document Generator with context

---

## Summary: All Generate Button Locations

| Location | Component | Line | Trigger | Action |
|----------|-----------|------|---------|--------|
| **Document Parser** | DocumentParser.tsx | ~200-250 | After extraction | Open Generator with extracted CDM |
| **Document Library (List)** | DocumentHistory.tsx | ~150-200 | Action menu | Open Generator with document CDM |
| **Document Library (Detail)** | DocumentHistory.tsx | ~300-350 | Action bar | Open Generator with document CDM |
| **Dashboard** | Dashboard.tsx | ~100-150 | Quick actions | Open Generator (fresh start) |
| **Document Generator** | DocumentGenerator.tsx | ~300-350 | After inputs processed | Generate document |
| **Workflow Actions** | WorkflowActions.tsx | ~100-150 | For generated docs | Regenerate document |
| **Chatbot Panel** | ChatbotPanel.tsx | ~200-250 | Template suggestions | Select template |
| **Main Navigation** | App.tsx | ~50-100 | Main menu | Open Generator app |
| **FDC3 Intent** | FDC3Context.tsx | ~200-250 | External app | Open Generator with context |

---

## Implementation Priority

1. **High Priority:**
   - Document Generator internal button (required for core functionality)
   - Document Parser button (seamless extraction → generation flow)
   - Main Navigation entry (discoverability)

2. **Medium Priority:**
   - Document Library buttons (convenience)
   - Dashboard quick action (quick access)
   - Workflow regenerate button (iteration support)

3. **Low Priority:**
   - Chatbot template suggestions (enhanced UX)
   - FDC3 intent handler (desktop interoperability)

---

**Document Version:** 1.0  
**Last Updated:** 2024-01-XX  
**Status:** Ready for Implementation




