# Quantitative Intelligence & Business Intelligence Workflows - IMPROVED Implementation Plan

## Executive Summary

This **IMPROVED** plan verifies existing design patterns and provides detailed LangChain prompts, agents, tools, CDM event integration, deal flow triggers, and data write operations for integrating three vendor repositories into CreditNexus.

**Key Improvements**:
- ✅ Verified against existing repository design patterns
- ✅ Specific LangChain prompts, agents, and tools using Python
- ✅ CDM event integration points for all workflows
- ✅ Deal flow timeline triggers and state transitions
- ✅ Data write operations following existing patterns
- ✅ TypeScript code vendoring strategy (direct integration where possible)

---

## Design Pattern Verification

### Verified Patterns

1. **LangChain Chain Pattern** (`.cursor/rules/chains.mdc`)
   - ✅ Use `create_*_chain()` factory functions
   - ✅ Use `get_chat_model()` from `app.core.llm_client`
   - ✅ Bind Pydantic models with `with_structured_output()`
   - ✅ Temperature=0 for deterministic extraction
   - ✅ Map-reduce for documents >50k characters

2. **Service Layer Pattern** (`.cursor/rules/service-layer.mdc`)
   - ✅ Services in `app/services/` directory
   - ✅ Inject database session via constructor
   - ✅ Return domain models, not database models
   - ✅ Generate CDM events for state changes
   - ✅ Use `log_audit_action()` for all operations

3. **CDM Compliance** (`.cursor/rules/cdm-compliance.mdc`)
   - ✅ All events must include `eventType`, `eventDate`, `meta.globalKey`
   - ✅ Use `generate_cdm_policy_evaluation()` for policy decisions
   - ✅ Link events via `relatedEventIdentifier`
   - ✅ Store full CDM events in JSONB columns

4. **Deal Flow State Machine** (`app/services/deal_service.py`)
   - ✅ Valid transitions defined in `VALID_TRANSITIONS`
   - ✅ Generate CDM events on status changes
   - ✅ Create `PolicyDecision` records for audit
   - ✅ Re-index in ChromaDB after updates

5. **Workflow State Machine** (`app/db/models.py`)
   - ✅ States: DRAFT → UNDER_REVIEW → APPROVED → PUBLISHED
   - ✅ Workflow transitions trigger policy evaluation
   - ✅ Audit logging for all transitions

---

## Project 1: Accounting Document Extraction Chain

### Activity 1.2: Create Accounting Extraction Chain (IMPROVED)

**File**: `app/chains/accounting_extraction_chain.py`

**LangChain Chain Implementation**:
```python
"""LangChain orchestration for extracting structured accounting data.

Follows existing chain patterns from app/chains/extraction_chain.py
"""

import logging
from typing import Optional
from decimal import Decimal
from pydantic import ValidationError

from langchain_core.language_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate

from app.core.llm_client import get_chat_model
from app.models.accounting_document import (
    AccountingDocument,
    BalanceSheet,
    IncomeStatement,
    CashFlowStatement,
    TaxReturn,
    AccountingExtractionResult
)

logger = logging.getLogger(__name__)

# Threshold for map-reduce (same as existing extraction chain)
MAP_REDUCE_THRESHOLD = 50000


def create_accounting_extraction_chain() -> BaseChatModel:
    """
    Create and configure the LangChain accounting extraction chain.
    
    Follows existing pattern from create_extraction_chain():
    - Uses LLM client abstraction
    - Temperature=0 for deterministic extraction
    - Binds Pydantic model as structured output
    
    Returns:
        BaseChatModel instance configured with structured output
        bound to AccountingExtractionResult Pydantic model.
    """
    # Use global LLM configuration (set at startup)
    llm = get_chat_model(temperature=0)  # Deterministic extraction
    
    # Bind the Pydantic model as a structured output tool
    structured_llm = llm.with_structured_output(AccountingExtractionResult)
    
    return structured_llm


def create_accounting_extraction_prompt() -> ChatPromptTemplate:
    """
    Create prompt template for accounting document extraction.
    
    Follows existing pattern from create_extraction_prompt():
    - System prompt with clear extraction responsibilities
    - User prompt with placeholder for document text
    - Emphasizes quantitative accuracy and CDM compliance
    """
    system_prompt = """You are an expert Financial Accountant and Quantitative Data Analyst. Your task is to extract comprehensive structured data from accounting documents with absolute numerical accuracy.

CORE EXTRACTION RESPONSIBILITIES:

1. BALANCE SHEET EXTRACTION:
   - Extract Assets:
     * Current Assets: Cash, Accounts Receivable, Inventory, Prepaid Expenses
     * Non-Current Assets: Property/Plant/Equipment, Intangible Assets, Investments
   - Extract Liabilities:
     * Current Liabilities: Accounts Payable, Short-term Debt, Accrued Expenses
     * Non-Current Liabilities: Long-term Debt, Deferred Tax Liabilities
   - Extract Equity:
     * Common Stock, Retained Earnings, Additional Paid-in Capital
   - VALIDATION: Total Assets MUST equal Total Liabilities + Total Equity
   - All amounts must use Decimal type (never float)
   - All amounts must include currency code (USD, EUR, GBP, etc.)

2. INCOME STATEMENT EXTRACTION:
   - Extract Revenue:
     * Gross Revenue, Net Revenue, Revenue by Segment (if available)
   - Extract Cost of Goods Sold (COGS):
     * Direct costs, Materials, Labor
   - Extract Operating Expenses:
     * SG&A, R&D, Depreciation, Amortization
   - Extract Other Income/Expenses:
     * Interest Income, Interest Expense, Tax Expense
   - Extract Net Income:
     * Net Income Before Tax, Net Income After Tax
   - VALIDATION: Revenue - COGS - Operating Expenses - Other Expenses = Net Income
   - Extract Earnings Per Share (EPS) if available

3. CASH FLOW STATEMENT EXTRACTION:
   - Extract Operating Activities:
     * Net Income, Depreciation, Changes in Working Capital, Cash from Operations
   - Extract Investing Activities:
     * Capital Expenditures, Asset Sales, Investments
   - Extract Financing Activities:
     * Debt Issuance/Repayment, Equity Issuance, Dividends Paid
   - Extract Net Change in Cash:
     * Beginning Cash, Ending Cash, Net Change
   - VALIDATION: Operating + Investing + Financing = Net Change in Cash

4. TAX RETURN EXTRACTION:
   - Extract Filing Information:
     * Filing Status (Single, Married Filing Jointly, etc.)
     * Tax Year, Filing Date
   - Extract Income:
     * Adjusted Gross Income (AGI), Taxable Income
   - Extract Deductions:
     * Standard Deduction, Itemized Deductions, Business Deductions
   - Extract Tax Liability:
     * Federal Tax Owed, State Tax Owed, Tax Credits
   - Extract Refund/Payment:
     * Tax Withheld, Estimated Payments, Refund Amount, Amount Owed

5. REPORTING PERIOD EXTRACTION:
   - Extract Period Type: Annual, Quarterly, Monthly, Year-to-Date
   - Extract Period Dates: Start Date (ISO 8601), End Date (ISO 8601)
   - Extract Fiscal Year if different from calendar year
   - Extract Comparative Period Data if available (prior year, prior quarter)

6. QUANTITATIVE VALIDATION:
   - Balance Sheet: Assets = Liabilities + Equity (must balance)
   - Income Statement: Revenue - Expenses = Net Income
   - Cash Flow: Operating + Investing + Financing = Net Change in Cash
   - Tax Return: Income - Deductions = Taxable Income
   - If validation fails, mark extraction_status as "partial_data_missing"

7. EXTRACTION STATUS:
   - success: All data extracted and validated correctly
   - partial_data_missing: Some fields missing or validation failed
   - irrelevant_document: Not an accounting document

CRITICAL RULES:
- If a field is not explicitly stated, return None/Null. Do not guess or infer values.
- All monetary amounts MUST use Decimal type (never float)
- All dates MUST be in ISO 8601 format (YYYY-MM-DD)
- All amounts MUST include currency code
- For percentages, convert to decimal (e.g., 5% = 0.05)
- Preserve original text structure when possible for audit purposes
- If text appears corrupted or unreadable, mark appropriate fields as missing
- Handle multi-period documents (e.g., quarterly statements with 4 quarters)
- Extract footnotes and notes if they contain quantitative data
"""

    user_prompt = """Extract accounting data from the following document text:

Document Text:
{text}

Document Type (if known): {document_type}

Extract all available quantitative data and return it in the structured format.
"""

    prompt = ChatPromptTemplate.from_messages([
        ("system", system_prompt),
        ("user", user_prompt)
    ])
    
    return prompt


def extract_accounting_data(
    text: str,
    document_type: Optional[str] = None,
    max_retries: int = 3
) -> AccountingExtractionResult:
    """
    Extract structured accounting data from unstructured text.
    
    Follows existing pattern from extract_data():
    - Implements Reflexion retry pattern
    - Handles validation errors with feedback
    - Logs extraction attempts
    
    Args:
        text: The raw text content of an accounting document
        document_type: Optional document type hint (balance_sheet, income_statement, etc.)
        max_retries: Maximum number of validation retries (default: 3)
        
    Returns:
        An AccountingExtractionResult Pydantic model instance
        
    Raises:
        ValueError: If extraction fails after retries
    """
    prompt = create_accounting_extraction_prompt()
    structured_llm = create_accounting_extraction_chain()
    extraction_chain = prompt | structured_llm
    
    last_error: Exception | None = None
    
    for attempt in range(max_retries):
        try:
            logger.info(f"Accounting extraction attempt {attempt + 1}/{max_retries}...")
            
            if attempt == 0:
                # First attempt: normal extraction
                result = extraction_chain.invoke({
                    "text": text,
                    "document_type": document_type or "unknown"
                })
            else:
                # Retry attempts: include validation error feedback
                error_feedback = f"""
Previous extraction attempt failed with validation error:
{str(last_error)}

Please correct the following issues:
1. Review the validation error above
2. Ensure all dates are valid and in ISO 8601 format (YYYY-MM-DD)
3. Ensure all monetary amounts use Decimal type
4. Verify balance sheet equation: Assets = Liabilities + Equity
5. Verify income statement equation: Revenue - Expenses = Net Income
6. Verify cash flow equation: Operating + Investing + Financing = Net Change in Cash

Original Document Text:
{text}
"""
                result = extraction_chain.invoke({
                    "text": error_feedback,
                    "document_type": document_type or "unknown"
                })
            
            # Validate quantitative relationships
            if result.agreement:
                validation_errors = _validate_accounting_data(result.agreement)
                if validation_errors:
                    logger.warning(f"Quantitative validation errors: {validation_errors}")
                    if result.extraction_status == "success":
                        result.extraction_status = "partial_data_missing"
            
            logger.info("Accounting extraction completed successfully")
            return result
            
        except ValidationError as e:
            last_error = e
            logger.warning(f"Validation error on attempt {attempt + 1}: {e}")
            
            if attempt < max_retries - 1:
                logger.info("Retrying with validation feedback...")
                continue
            raise ValueError(f"Accounting extraction failed validation after {max_retries} attempts: {e}") from e
            
        except Exception as e:
            logger.error(f"Unexpected error during accounting extraction: {e}")
            raise ValueError(f"Accounting extraction failed: {e}") from e


def _validate_accounting_data(document: AccountingDocument) -> List[str]:
    """
    Validate quantitative relationships in accounting data.
    
    Returns list of validation error messages (empty if valid).
    """
    errors = []
    
    if isinstance(document, BalanceSheet):
        # Validate: Assets = Liabilities + Equity
        total_assets = document.total_assets
        total_liabilities_equity = document.total_liabilities + document.total_equity
        if total_assets and total_liabilities_equity:
            if abs(total_assets - total_liabilities_equity) > Decimal('0.01'):
                errors.append(
                    f"Balance sheet does not balance: "
                    f"Assets ({total_assets}) != Liabilities + Equity ({total_liabilities_equity})"
                )
    
    elif isinstance(document, IncomeStatement):
        # Validate: Revenue - Expenses = Net Income
        revenue = document.total_revenue
        expenses = document.total_expenses
        net_income = document.net_income
        if revenue and expenses and net_income:
            calculated_net = revenue - expenses
            if abs(calculated_net - net_income) > Decimal('0.01'):
                errors.append(
                    f"Income statement does not balance: "
                    f"Revenue ({revenue}) - Expenses ({expenses}) = {calculated_net}, "
                    f"but Net Income is {net_income}"
                )
    
    elif isinstance(document, CashFlowStatement):
        # Validate: Operating + Investing + Financing = Net Change
        operating = document.cash_from_operations
        investing = document.cash_from_investing
        financing = document.cash_from_financing
        net_change = document.net_change_in_cash
        if all([operating, investing, financing, net_change]):
            calculated_change = operating + investing + financing
            if abs(calculated_change - net_change) > Decimal('0.01'):
                errors.append(
                    f"Cash flow statement does not balance: "
                    f"Operating ({operating}) + Investing ({investing}) + Financing ({financing}) = {calculated_change}, "
                    f"but Net Change is {net_change}"
                )
    
    return errors


def extract_accounting_data_smart(
    text: str,
    document_type: Optional[str] = None,
    force_map_reduce: bool = False,
    max_retries: int = 3
) -> AccountingExtractionResult:
    """
    Extract accounting data with automatic strategy selection.
    
    Follows existing pattern from extract_data_smart():
    - Automatically chooses between simple and map-reduce
    - Uses map-reduce for documents >50k characters
    
    Args:
        text: The raw text content
        document_type: Optional document type hint
        force_map_reduce: If True, always use map-reduce
        max_retries: Maximum number of validation retries
        
    Returns:
        AccountingExtractionResult instance
    """
    text_length = len(text)
    
    if force_map_reduce or text_length > MAP_REDUCE_THRESHOLD:
        logger.info(f"Document length ({text_length} chars) exceeds threshold, using Map-Reduce strategy")
        return extract_accounting_data_map_reduce(text, document_type)
    else:
        logger.info(f"Document length ({text_length} chars) within threshold, using simple extraction")
        return extract_accounting_data(text, document_type, max_retries)
```

### Activity 1.4: Add Accounting Document API Endpoint (IMPROVED)

**File**: `app/api/routes.py`

**CDM Event Integration**:
```python
@router.post("/extract/accounting")
async def extract_accounting_document(
    file: UploadFile = File(...),
    document_type: Optional[str] = Query(None, description="Document type: balance_sheet, income_statement, cash_flow, tax_return"),
    deal_id: Optional[int] = Query(None, description="Optional deal ID to attach document"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    policy_service: Optional[PolicyService] = Depends(get_policy_service)
):
    """
    Extract accounting data from uploaded document.
    
    Follows existing pattern from extract_document():
    - File upload handling
    - Extraction chain invocation
    - Policy evaluation integration
    - CDM event generation
    - Audit logging
    - Deal attachment
    """
    try:
        # Read file content
        content = await file.read()
        text = extract_text_from_file(content, file.filename)
        
        # Extract accounting data
        from app.chains.accounting_extraction_chain import extract_accounting_data_smart
        result = extract_accounting_data_smart(text, document_type=document_type)
        
        if not result.agreement:
            raise HTTPException(
                status_code=400,
                detail={
                    "status": "error",
                    "message": "Failed to extract accounting data",
                    "extraction_status": result.extraction_status
                }
            )
        
        # Create document record
        doc = Document(
            title=f"Accounting Document: {document_type or 'Unknown'}",
            uploaded_by=current_user.id,
            deal_id=deal_id,
            source_filename=file.filename,
            original_text=text[:10000],  # Store first 10k chars
            extraction_status=result.extraction_status.value,
            cdm_data=result.agreement.model_dump() if result.agreement else None
        )
        db.add(doc)
        db.flush()
        
        # Policy evaluation (if enabled)
        policy_evaluation_event = None
        if policy_service and result.agreement:
            try:
                # Evaluate accounting document for compliance
                # Note: May need new policy evaluation method for accounting documents
                policy_result = policy_service.evaluate_accounting_document(
                    accounting_document=result.agreement,
                    document_id=doc.id
                )
                
                # Create CDM PolicyEvaluation event
                from app.models.cdm_events import generate_cdm_policy_evaluation
                policy_evaluation_event = generate_cdm_policy_evaluation(
                    transaction_id=doc.id,  # Use document ID as transaction ID
                    transaction_type="accounting_document_extraction",
                    decision=policy_result.decision,
                    rule_applied=policy_result.rule_applied,
                    related_event_identifiers=[],
                    evaluation_trace=policy_result.trace,
                    matched_rules=policy_result.matched_rules
                )
                
                # Store policy decision
                from app.services.policy_audit import log_policy_decision
                log_policy_decision(
                    db=db,
                    policy_decision=policy_result,
                    transaction_id=str(doc.id),
                    transaction_type="accounting_document_extraction",
                    cdm_events=[policy_evaluation_event] if policy_evaluation_event else [],
                    document_id=doc.id,
                    user_id=current_user.id
                )
                
                # Handle BLOCK decision
                if policy_result.decision == "BLOCK":
                    raise HTTPException(
                        status_code=403,
                        detail={
                            "status": "blocked",
                            "reason": policy_result.rule_applied,
                            "cdm_event": policy_evaluation_event
                        }
                    )
                
            except Exception as e:
                logger.warning(f"Policy evaluation failed for accounting document: {e}")
                # Continue without policy evaluation
        
        # Create CDM event for accounting document extraction
        from app.models.cdm_events import generate_cdm_observation
        extraction_event = generate_cdm_observation(
            trade_id=str(doc.id),  # Use document ID
            satellite_hash="",  # Not applicable for accounting docs
            ndvi_score=0.0,  # Not applicable
            status="EXTRACTED"
        )
        # Modify event type to AccountingDocumentExtraction
        extraction_event["eventType"] = "AccountingDocumentExtraction"
        extraction_event["accountingDocument"] = {
            "documentId": doc.id,
            "documentType": document_type or "unknown",
            "extractionStatus": result.extraction_status.value,
            "extractedData": result.agreement.model_dump() if result.agreement else None
        }
        
        # Store CDM events
        cdm_events = [extraction_event]
        if policy_evaluation_event:
            cdm_events.append(policy_evaluation_event)
        
        # Attach to deal if provided
        if deal_id:
            try:
                deal_service = DealService(db)
                deal_service.attach_document_to_deal(
                    deal_id=deal_id,
                    document_id=doc.id,
                    user_id=current_user.id
                )
            except Exception as e:
                logger.warning(f"Failed to attach document to deal: {e}")
        
        # Audit logging
        log_audit_action(
            db=db,
            action=AuditAction.CREATE,
            target_type="document",
            target_id=doc.id,
            user_id=current_user.id,
            metadata={
                "document_type": "accounting",
                "accounting_type": document_type,
                "extraction_status": result.extraction_status.value,
                "deal_id": deal_id
            }
        )
        
        db.commit()
        db.refresh(doc)
        
        return {
            "status": "success",
            "document_id": doc.id,
            "accounting_data": result.agreement.model_dump() if result.agreement else None,
            "extraction_status": result.extraction_status.value,
            "cdm_events": cdm_events
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Error extracting accounting document: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"Failed to extract accounting document: {str(e)}"}
        )
```

### Activity 1.5: Database Schema Updates (IMPROVED)

**File**: `alembic/versions/XXXX_add_accounting_documents.py`

**Following existing database patterns**:
```python
"""Add accounting documents table

Revision ID: XXXX
Revises: YYYY
Create Date: 2024-XX-XX XX:XX:XX.XXXXXX
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers
revision = 'XXXX'
down_revision = 'YYYY'
branch_labels = None
depends_on = None


def upgrade():
    # Create accounting_documents table
    op.create_table(
        'accounting_documents',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('document_id', sa.Integer(), sa.ForeignKey('documents.id'), nullable=False),
        sa.Column('document_type', sa.String(50), nullable=False),  # balance_sheet, income_statement, etc.
        sa.Column('extracted_data', postgresql.JSONB(), nullable=True),  # Full accounting document structure
        sa.Column('reporting_period_start', sa.Date(), nullable=True),
        sa.Column('reporting_period_end', sa.Date(), nullable=True),
        sa.Column('period_type', sa.String(20), nullable=True),  # quarterly, annual, monthly
        sa.Column('currency', sa.String(10), nullable=True),  # ISO currency code
        sa.Column('created_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(), server_default=sa.text('now()'), onupdate=sa.text('now()'), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('document_id')  # One accounting document per document
    )
    
    # Create indexes for efficient querying
    op.create_index('ix_accounting_documents_document_id', 'accounting_documents', ['document_id'])
    op.create_index('ix_accounting_documents_document_type', 'accounting_documents', ['document_type'])
    op.create_index('ix_accounting_documents_period_type', 'accounting_documents', ['period_type'])
    op.create_index('ix_accounting_documents_reporting_period', 'accounting_documents', ['reporting_period_start', 'reporting_period_end'])
    
    # Add foreign key constraint
    op.create_foreign_key(
        'fk_accounting_documents_document_id',
        'accounting_documents',
        'documents',
        ['document_id'],
        ['id'],
        ondelete='CASCADE'
    )


def downgrade():
    op.drop_table('accounting_documents')
```

---

## Project 2: DeepResearch Orchestrator Integration

### Activity 2.1: Port DeepResearch Agent Core (IMPROVED)

**Strategy**: Instead of porting TypeScript to Python, we can **vendor in the TypeScript code directly** and create a Python wrapper service that calls the TypeScript implementation via Node.js subprocess or HTTP API.

**Option A: Direct TypeScript Integration (Recommended)**
- Keep TypeScript code in `app/vendors/node-DeepResearch/`
- Create Python service wrapper that calls TypeScript via subprocess
- Use existing Node.js infrastructure if available

**Option B: Python Port (If TypeScript integration not feasible)**
- Port core logic to Python following LangChain patterns
- Use LangGraph for workflow orchestration (similar to PeopleHub)

**File**: `app/agents/deep_research_agent.py` (Python wrapper) OR `app/services/deep_research_service.py` (Full Python port)

**LangChain Agent Implementation** (if porting to Python):
```python
"""DeepResearch orchestrator agent using LangChain.

Ports node-DeepResearch iterative research pattern to Python using LangChain.
Follows existing agent patterns from app/agents/analyzer.py
"""

import logging
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from enum import Enum

from langchain_core.language_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.tools import Tool
from langchain.agents import create_react_agent, AgentExecutor

from app.core.llm_client import get_chat_model
from app.models.cdm_events import generate_cdm_policy_evaluation

logger = logging.getLogger(__name__)


class ResearchAction(str, Enum):
    """Research actions following DeepResearch pattern."""
    SEARCH = "search"
    READ = "read"
    ANSWER = "answer"
    REFLECT = "reflect"
    CODING = "coding"


@dataclass
class KnowledgeItem:
    """Knowledge item accumulated during research."""
    question: str
    answer: str
    references: List[str]
    type: str  # 'url', 'qa', 'side-info', 'coding'
    updated: Optional[str] = None


@dataclass
class ResearchContext:
    """Research context tracking."""
    token_budget: int = 1000000
    visited_urls: List[str] = None
    knowledge_items: List[KnowledgeItem] = None
    searched_queries: List[str] = None
    all_urls: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.visited_urls is None:
            self.visited_urls = []
        if self.knowledge_items is None:
            self.knowledge_items = []
        if self.searched_queries is None:
            self.searched_queries = []
        if self.all_urls is None:
            self.all_urls = {}


def create_deep_research_agent() -> AgentExecutor:
    """
    Create DeepResearch agent using LangChain ReAct pattern.
    
    Follows existing agent patterns:
    - Uses get_chat_model() for LLM
    - Creates ReAct agent with tools
    - Returns AgentExecutor for execution
    """
    llm = get_chat_model(temperature=0.7)  # Slightly higher for reasoning
    
    # Create tools for research actions
    tools = [
        create_search_tool(),
        create_read_url_tool(),
        create_answer_evaluator_tool(),
        create_query_rewriter_tool()
    ]
    
    # Create ReAct agent
    agent = create_react_agent(llm, tools)
    
    # Create executor
    executor = AgentExecutor(
        agent=agent,
        tools=tools,
        verbose=True,
        max_iterations=20,  # Limit iterations to prevent infinite loops
        handle_parsing_errors=True
    )
    
    return executor


def create_search_tool() -> Tool:
    """Create search tool for web search."""
    def search_web(query: str) -> str:
        """Search the web for information."""
        # Implementation: Use Jina Search, DuckDuckGo, or other search API
        # This would integrate with existing search infrastructure
        logger.info(f"Searching web for: {query}")
        # Placeholder - implement actual search
        return f"Search results for: {query}"
    
    return Tool(
        name="web_search",
        description="Search the web for information. Use this when you need to find information about a topic.",
        func=search_web
    )


def create_read_url_tool() -> Tool:
    """Create URL reading tool."""
    def read_url(url: str) -> str:
        """Read content from a URL."""
        # Implementation: Use Jina Reader or similar
        logger.info(f"Reading URL: {url}")
        # Placeholder - implement actual URL reading
        return f"Content from: {url}"
    
    return Tool(
        name="read_url",
        description="Read content from a URL. Use this to get detailed information from a webpage.",
        func=read_url
    )


def create_answer_evaluator_tool() -> Tool:
    """Create answer evaluation tool."""
    def evaluate_answer(question: str, answer: str) -> str:
        """Evaluate if an answer is complete and accurate."""
        # Implementation: Use LLM to evaluate answer quality
        logger.info(f"Evaluating answer for question: {question}")
        # Placeholder - implement actual evaluation
        return "Answer evaluation: Complete"
    
    return Tool(
        name="evaluate_answer",
        description="Evaluate if an answer is complete and accurate. Use this to check answer quality.",
        func=evaluate_answer
    )


def create_query_rewriter_tool() -> Tool:
    """Create query rewriter tool."""
    def rewrite_query(original_query: str, context: str) -> str:
        """Rewrite a search query based on context."""
        # Implementation: Use LLM to rewrite queries
        logger.info(f"Rewriting query: {original_query}")
        # Placeholder - implement actual rewriting
        return original_query
    
    return Tool(
        name="rewrite_query",
        description="Rewrite a search query to improve search results. Use this to refine queries.",
        func=rewrite_query
    )


async def research_query(
    question: str,
    context: Optional[ResearchContext] = None,
    deal_id: Optional[int] = None,
    workflow_id: Optional[int] = None
) -> Dict[str, Any]:
    """
    Execute DeepResearch query with CDM event integration.
    
    Args:
        question: Research question
        context: Optional research context
        deal_id: Optional deal ID for CDM event linking
        workflow_id: Optional workflow ID for CDM event linking
        
    Returns:
        Research result with answer, knowledge items, and CDM events
    """
    if context is None:
        context = ResearchContext()
    
    # Create agent
    agent = create_deep_research_agent()
    
    # Execute research
    result = await agent.ainvoke({
        "input": question,
        "context": context
    })
    
    # Generate CDM event for research completion
    research_event = {
        "eventType": "ResearchQuery",
        "eventDate": datetime.datetime.now().isoformat(),
        "researchQuery": {
            "query": question,
            "answer": result.get("output", ""),
            "knowledgeItems": [item.__dict__ for item in context.knowledge_items],
            "visitedUrls": context.visited_urls,
            "searchedQueries": context.searched_queries
        },
        "meta": {
            "globalKey": str(uuid.uuid4()),
            "sourceSystem": "CreditNexus_DeepResearch_v1",
            "version": 1
        }
    }
    
    # Link to deal/workflow if provided
    if deal_id:
        research_event["relatedEventIdentifier"] = [{
            "eventIdentifier": {
                "issuer": "CreditNexus",
                "assignedIdentifier": [{"identifier": {"value": f"DEAL_{deal_id}"}}]
            }
        }]
    
    return {
        "answer": result.get("output", ""),
        "knowledge_items": context.knowledge_items,
        "visited_urls": context.visited_urls,
        "cdm_event": research_event
    }
```

### Activity 2.4: Create DeepResearch API Endpoints (IMPROVED)

**File**: `app/api/routes.py`

**CDM Event Integration & Deal Flow Triggers**:
```python
@router.post("/deep-research/query")
async def deep_research_query(
    request: DeepResearchQueryRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    policy_service: Optional[PolicyService] = Depends(get_policy_service)
):
    """
    Execute DeepResearch query with CDM event integration.
    
    Triggers:
    - Creates ResearchQuery CDM event
    - Links to deal/workflow if provided
    - Stores research result in database
    - Updates deal timeline if deal_id provided
    """
    try:
        from app.agents.deep_research_agent import research_query
        
        # Execute research
        result = await research_query(
            question=request.query,
            deal_id=request.deal_id,
            workflow_id=request.workflow_id
        )
        
        # Store research result
        research_result = DeepResearchResult(
            research_id=str(uuid.uuid4()),
            query=request.query,
            answer=result["answer"],
            knowledge_items=result["knowledge_items"],
            visited_urls=result["visited_urls"],
            deal_id=request.deal_id,
            workflow_id=request.workflow_id,
            status="completed",
            created_at=datetime.utcnow(),
            completed_at=datetime.utcnow()
        )
        db.add(research_result)
        db.flush()
        
        # Update deal timeline if deal_id provided
        if request.deal_id:
            try:
                deal_service = DealService(db)
                # Add research event to deal timeline
                deal_service.add_timeline_event(
                    deal_id=request.deal_id,
                    event_type="research_query",
                    event_data={
                        "research_id": research_result.research_id,
                        "query": request.query,
                        "answer": result["answer"][:500]  # First 500 chars
                    },
                    user_id=current_user.id
                )
            except Exception as e:
                logger.warning(f"Failed to update deal timeline: {e}")
        
        # Audit logging
        log_audit_action(
            db=db,
            action=AuditAction.CREATE,
            target_type="research_query",
            target_id=research_result.id,
            user_id=current_user.id,
            metadata={
                "query": request.query,
                "deal_id": request.deal_id,
                "workflow_id": request.workflow_id
            }
        )
        
        db.commit()
        
        return {
            "status": "success",
            "research_id": research_result.research_id,
            "answer": result["answer"],
            "knowledge_items": result["knowledge_items"],
            "cdm_event": result["cdm_event"]
        }
        
    except Exception as e:
        db.rollback()
        logger.error(f"Error executing research query: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"Research query failed: {str(e)}"}
        )
```

---

## Project 3: PeopleHub Business Intelligence

### Activity 3.1: Port PeopleHub Research Graph (IMPROVED)

**Strategy**: Port TypeScript LangGraph workflow to Python LangGraph, following existing patterns.

**File**: `app/workflows/peoplehub_research_graph.py`

**LangGraph Implementation**:
```python
"""PeopleHub research workflow using LangGraph.

Ports TypeScript LangGraph workflow to Python following existing patterns.
"""

import logging
from typing import Optional, Dict, Any, List
from datetime import datetime

from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langchain_core.messages import HumanMessage, AIMessage

from app.core.llm_client import get_chat_model
from app.models.business_intelligence import (
    BusinessProfile,
    IndividualProfile,
    PsychometricProfile,
    AuditReport
)

logger = logging.getLogger(__name__)


class ResearchState(TypedDict):
    """Research state following PeopleHub pattern."""
    person_name: str
    linkedin_url: str
    linkedin_data: Optional[Dict[str, Any]]
    search_query: Optional[str]
    search_results: List[Dict[str, Any]]
    scraped_contents: List[Dict[str, Any]]
    web_summaries: List[Dict[str, Any]]
    final_report: Optional[str]
    errors: List[str]
    status: str


def create_peoplehub_research_graph() -> StateGraph:
    """
    Create PeopleHub research graph using LangGraph.
    
    Follows PeopleHub workflow:
    1. Fetch LinkedIn profile
    2. Generate search query
    3. Execute search
    4. Scrape web pages (parallel)
    5. Summarize content (parallel)
    6. Aggregate data
    7. Write report
    """
    workflow = StateGraph(ResearchState)
    
    # Add nodes
    workflow.add_node("start", start_node)
    workflow.add_node("fetch_linkedin", fetch_linkedin_node)
    workflow.add_node("generate_search_query", generate_search_query_node)
    workflow.add_node("execute_search", execute_search_node)
    workflow.add_node("scrape_web_page", scrape_web_page_node)
    workflow.add_node("summarize_content", summarize_content_node)
    workflow.add_node("aggregate_data", aggregate_data_node)
    workflow.add_node("write_report", write_report_node)
    
    # Define edges
    workflow.set_entry_point("start")
    workflow.add_edge("start", "fetch_linkedin")
    workflow.add_edge("start", "execute_search")  # Parallel execution
    workflow.add_edge("fetch_linkedin", "aggregate_data")
    workflow.add_conditional_edges(
        "execute_search",
        route_to_scraping,
        {
            "scrape": "scrape_web_page",
            "skip": "aggregate_data"
        }
    )
    workflow.add_conditional_edges(
        "scrape_web_page",
        route_to_summarization,
        {
            "summarize": "summarize_content",
            "skip": "aggregate_data"
        }
    )
    workflow.add_edge("summarize_content", "aggregate_data")
    workflow.add_edge("aggregate_data", "write_report")
    workflow.add_edge("write_report", END)
    
    return workflow.compile()


def start_node(state: ResearchState) -> ResearchState:
    """Initialize research state."""
    return {
        **state,
        "status": "Initializing research...",
        "errors": [],
        "search_results": [],
        "scraped_contents": [],
        "web_summaries": []
    }


def fetch_linkedin_node(state: ResearchState) -> ResearchState:
    """Fetch LinkedIn profile data."""
    # Implementation: Use Bright Data LinkedIn API or similar
    # This would integrate with existing LinkedIn scraping infrastructure
    logger.info(f"Fetching LinkedIn profile: {state['linkedin_url']}")
    # Placeholder - implement actual LinkedIn fetching
    return {
        **state,
        "linkedin_data": {},
        "status": "Fetched LinkedIn profile"
    }


def generate_search_query_node(state: ResearchState) -> ResearchState:
    """Generate search query from person name and LinkedIn data."""
    llm = get_chat_model(temperature=0.7)
    
    prompt = f"""Generate a Google search query to find information about {state['person_name']}.
    
LinkedIn Data:
{state.get('linkedin_data', {})}

Generate a search query that will find:
- Recent projects and achievements
- News articles and press releases
- Professional publications
- Industry recognition

Return only the search query, nothing else.
"""
    
    response = llm.invoke(prompt)
    search_query = response.content.strip()
    
    return {
        **state,
        "search_query": search_query,
        "status": "Generated search query"
    }


def execute_search_node(state: ResearchState) -> ResearchState:
    """Execute web search."""
    # Implementation: Use Google Search API, Bright Data, or similar
    logger.info(f"Executing search: {state.get('search_query', '')}")
    # Placeholder - implement actual search
    return {
        **state,
        "search_results": [],
        "status": "Executed search"
    }


def scrape_web_page_node(state: ResearchState) -> ResearchState:
    """Scrape web page content."""
    # Implementation: Use web scraping library
    logger.info("Scraping web pages")
    # Placeholder - implement actual scraping
    return {
        **state,
        "scraped_contents": [],
        "status": "Scraped web pages"
    }


def summarize_content_node(state: ResearchState) -> ResearchState:
    """Summarize scraped content."""
    llm = get_chat_model(temperature=0)
    
    summaries = []
    for content in state.get("scraped_contents", []):
        prompt = f"""Summarize the following content about {state['person_name']}:

Content:
{content.get('content', '')}

Focus on:
- Professional achievements
- Recent projects
- Industry recognition
- Key skills and expertise

Return a concise summary.
"""
        response = llm.invoke(prompt)
        summaries.append({
            "url": content.get("url", ""),
            "summary": response.content,
            "key_points": [],
            "mentions_person": True,
            "confidence": 0.8
        })
    
    return {
        **state,
        "web_summaries": summaries,
        "status": "Summarized content"
    }


def aggregate_data_node(state: ResearchState) -> ResearchState:
    """Aggregate all research data."""
    # Deduplicate and merge data
    web_summaries = state.get("web_summaries", [])
    linkedin_data = state.get("linkedin_data", {})
    
    return {
        **state,
        "status": "Aggregated data"
    }


def write_report_node(state: ResearchState) -> ResearchState:
    """Generate final research report."""
    llm = get_chat_model(temperature=0.7)
    
    prompt = f"""Generate a comprehensive research report about {state['person_name']}.

LinkedIn Data:
{state.get('linkedin_data', {})}

Web Summaries:
{state.get('web_summaries', [])}

Generate a report covering:
1. Professional Background
2. Recent Projects and Achievements
3. Technical Expertise
4. Industry Reputation
5. Sources

Format as Markdown.
"""
    
    response = llm.invoke(prompt)
    report = response.content
    
    return {
        **state,
        "final_report": report,
        "status": "Report ready"
    }


def route_to_scraping(state: ResearchState) -> str:
    """Route to scraping if search results available."""
    if state.get("search_results"):
        return "scrape"
    return "skip"


def route_to_summarization(state: ResearchState) -> str:
    """Route to summarization if scraped content available."""
    if state.get("scraped_contents"):
        return "summarize"
    return "skip"
```

### Activity 3.3: Create Psychometric Analysis Service (IMPROVED)

**File**: `app/services/psychometric_analysis_service.py`

**LangChain Chain for Psychometric Analysis**:
```python
"""Psychometric analysis service using LangChain.

Analyzes individuals for psychometric traits, buying behaviors, and savings behaviors.
"""

import logging
from typing import Optional, Dict, Any, List
from decimal import Decimal

from langchain_core.language_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate

from app.core.llm_client import get_chat_model
from app.models.business_intelligence import (
    PsychometricProfile,
    BuyingBehaviorProfile,
    SavingsBehaviorProfile
)

logger = logging.getLogger(__name__)


def create_psychometric_analysis_chain() -> BaseChatModel:
    """
    Create LangChain chain for psychometric analysis.
    
    Follows existing chain pattern:
    - Uses get_chat_model()
    - Binds Pydantic model as structured output
    """
    llm = get_chat_model(temperature=0.3)  # Lower temperature for more consistent analysis
    structured_llm = llm.with_structured_output(PsychometricProfile)
    return structured_llm


def create_psychometric_analysis_prompt() -> ChatPromptTemplate:
    """Create prompt for psychometric analysis."""
    system_prompt = """You are an expert Psychometric Analyst specializing in financial behavior analysis. Your task is to analyze an individual's psychometric profile, buying behaviors, and savings behaviors based on their professional data, LinkedIn profile, and web research.

PSYCHOMETRIC ANALYSIS RESPONSIBILITIES:

1. BIG FIVE PERSONALITY TRAITS:
   - Openness to Experience (0.0-1.0): Creativity, curiosity, willingness to try new things
   - Conscientiousness (0.0-1.0): Organization, dependability, self-discipline
   - Extraversion (0.0-1.0): Sociability, assertiveness, emotional expressiveness
   - Agreeableness (0.0-1.0): Trust, altruism, kindness, affection
   - Neuroticism (0.0-1.0): Emotional stability, anxiety, moodiness

2. RISK TOLERANCE ASSESSMENT:
   - Conservative: Prefers low-risk, stable investments
   - Moderate: Balanced approach to risk
   - Aggressive: Willing to take high risks for high returns
   - Assess based on: Career choices, investment history, financial decisions

3. DECISION-MAKING STYLE:
   - Analytical: Data-driven, methodical
   - Intuitive: Gut-feel, quick decisions
   - Collaborative: Seeks input from others
   - Independent: Makes decisions alone

4. BUYING BEHAVIOR ANALYSIS:
   - Purchase Frequency: How often they make significant purchases
   - Average Transaction Value: Typical spending amount
   - Preferred Categories: Types of products/services they buy
   - Decision Factors: Price, quality, brand, convenience, etc.
   - Impulse Buying Tendency: Low, Moderate, High

5. SAVINGS BEHAVIOR ANALYSIS:
   - Savings Rate: Percentage of income saved (if inferable)
   - Investment Preferences: Stocks, bonds, real estate, crypto, etc.
   - Financial Goals: Short-term, medium-term, long-term
   - Emergency Fund: Likely presence and adequacy
   - Retirement Planning: Engagement level

6. CREDIT CHECK DATA POINTS:
   - Payment History Indicators: Based on professional reliability
   - Credit Utilization Patterns: Inferred from spending behavior
   - Debt Management: Likely approach to debt
   - Financial Stability: Job stability, income growth trajectory

CRITICAL RULES:
- Base analysis ONLY on available data (LinkedIn, web research, professional history)
- Use 0.0-1.0 scale for personality traits (0.5 = average)
- If data is insufficient, mark fields as None rather than guessing
- Provide confidence scores (0.0-1.0) for each assessment
- Focus on financial behavior indicators relevant to credit assessment
- Consider cultural and professional context in analysis
"""

    user_prompt = """Analyze the psychometric profile, buying behaviors, and savings behaviors for the following individual:

Person Name: {person_name}

LinkedIn Data:
{linkedin_data}

Web Research Summaries:
{web_summaries}

Professional History:
{professional_history}

Provide a comprehensive psychometric analysis with confidence scores.
"""

    prompt = ChatPromptTemplate.from_messages([
        ("system", system_prompt),
        ("user", user_prompt)
    ])
    
    return prompt


async def analyze_individual(
    person_name: str,
    linkedin_data: Optional[Dict[str, Any]] = None,
    web_summaries: Optional[List[Dict[str, Any]]] = None,
    professional_history: Optional[Dict[str, Any]] = None
) -> PsychometricProfile:
    """
    Analyze individual for psychometric traits and behaviors.
    
    Args:
        person_name: Name of the individual
        linkedin_data: LinkedIn profile data
        web_summaries: Web research summaries
        professional_history: Professional history data
        
    Returns:
        PsychometricProfile with analysis results
    """
    chain = create_psychometric_analysis_chain()
    prompt = create_psychometric_analysis_prompt()
    
    result = await chain.ainvoke({
        "person_name": person_name,
        "linkedin_data": linkedin_data or {},
        "web_summaries": web_summaries or [],
        "professional_history": professional_history or {}
    })
    
    return result
```

### Activity 3.4: Create Business Intelligence API (IMPROVED)

**File**: `app/api/routes.py`

**CDM Event Integration & Deal Flow Triggers**:
```python
@router.post("/business-intelligence/research-person")
async def research_person(
    request: PersonResearchRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    policy_service: Optional[PolicyService] = Depends(get_policy_service)
):
    """
    Research person and generate business intelligence report.
    
    Triggers:
    - Creates PersonResearch CDM event
    - Links to deal if provided
    - Updates deal timeline
    - Generates audit report
    """
    try:
        from app.workflows.peoplehub_research_graph import create_peoplehub_research_graph
        from app.services.psychometric_analysis_service import analyze_individual
        
        # Execute research workflow
        graph = create_peoplehub_research_graph()
        initial_state = {
            "person_name": request.person_name,
            "linkedin_url": request.linkedin_url,
            "linkedin_data": None,
            "search_query": None,
            "search_results": [],
            "scraped_contents": [],
            "web_summaries": [],
            "final_report": None,
            "errors": [],
            "status": "initializing"
        }
        
        result = await graph.ainvoke(initial_state)
        
        # Perform psychometric analysis
        psychometric_profile = await analyze_individual(
            person_name=request.person_name,
            linkedin_data=result.get("linkedin_data"),
            web_summaries=result.get("web_summaries")
        )
        
        # Store individual profile
        individual_profile = IndividualProfile(
            person_name=request.person_name,
            linkedin_url=request.linkedin_url,
            profile_data={
                "linkedin_data": result.get("linkedin_data"),
                "web_summaries": result.get("web_summaries"),
                "research_report": result.get("final_report")
            },
            deal_id=request.deal_id
        )
        db.add(individual_profile)
        db.flush()
        
        # Store psychometric profile
        psychometric = PsychometricProfile(
            individual_profile_id=individual_profile.id,
            psychometric_data=psychometric_profile.model_dump(),
            buying_behavior=psychometric_profile.buying_behavior.model_dump() if psychometric_profile.buying_behavior else None,
            savings_behavior=psychometric_profile.savings_behavior.model_dump() if psychometric_profile.savings_behavior else None
        )
        db.add(psychometric)
        db.flush()
        
        # Generate audit report
        audit_report = AuditReport(
            report_type="individual",
            profile_id=individual_profile.id,
            report_data={
                "research_report": result.get("final_report"),
                "psychometric_profile": psychometric_profile.model_dump(),
                "credit_check_data": _extract_credit_check_data(psychometric_profile)
            },
            deal_id=request.deal_id
        )
        db.add(audit_report)
        db.flush()
        
        # Generate CDM event
        from app.models.cdm_events import generate_cdm_observation
        research_event = generate_cdm_observation(
            trade_id=str(individual_profile.id),
            satellite_hash="",
            ndvi_score=0.0,
            status="RESEARCHED"
        )
        research_event["eventType"] = "PersonResearch"
        research_event["personResearch"] = {
            "profile_id": individual_profile.id,
            "person_name": request.person_name,
            "research_report": result.get("final_report"),
            "psychometric_profile": psychometric_profile.model_dump()
        }
        
        # Link to deal if provided
        if request.deal_id:
            research_event["relatedEventIdentifier"] = [{
                "eventIdentifier": {
                    "issuer": "CreditNexus",
                    "assignedIdentifier": [{"identifier": {"value": f"DEAL_{request.deal_id}"}}]
                }
            }]
            
            # Update deal timeline
            try:
                deal_service = DealService(db)
                deal_service.add_timeline_event(
                    deal_id=request.deal_id,
                    event_type="person_research",
                    event_data={
                        "profile_id": individual_profile.id,
                        "person_name": request.person_name,
                        "audit_report_id": audit_report.id
                    },
                    user_id=current_user.id
                )
            except Exception as e:
                logger.warning(f"Failed to update deal timeline: {e}")
        
        # Audit logging
        log_audit_action(
            db=db,
            action=AuditAction.CREATE,
            target_type="person_research",
            target_id=individual_profile.id,
            user_id=current_user.id,
            metadata={
                "person_name": request.person_name,
                "deal_id": request.deal_id
            }
        )
        
        db.commit()
        
        return {
            "status": "success",
            "profile_id": individual_profile.id,
            "audit_report_id": audit_report.id,
            "research_report": result.get("final_report"),
            "psychometric_profile": psychometric_profile.model_dump(),
            "cdm_event": research_event
        }
        
    except Exception as e:
        db.rollback()
        logger.error(f"Error researching person: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"Person research failed: {str(e)}"}
        )


def _extract_credit_check_data(psychometric_profile: PsychometricProfile) -> Dict[str, Any]:
    """Extract credit check relevant data from psychometric profile."""
    return {
        "risk_tolerance": psychometric_profile.risk_tolerance,
        "conscientiousness": psychometric_profile.big_five_traits.get("conscientiousness") if psychometric_profile.big_five_traits else None,
        "savings_rate": psychometric_profile.savings_behavior.savings_rate if psychometric_profile.savings_behavior else None,
        "payment_history_indicators": "reliable" if psychometric_profile.conscientiousness and psychometric_profile.conscientiousness > 0.7 else "unknown"
    }
```

---

## Deal Flow Timeline Triggers

### Integration Points

1. **Document Extraction Triggers**:
   - When accounting document extracted → Update deal timeline
   - When extraction completes → Trigger policy evaluation
   - When policy evaluation completes → Update deal status if needed

2. **Research Query Triggers**:
   - When research query completes → Add to deal timeline
   - When research reveals risk factors → Trigger policy evaluation
   - When research completes → Update deal notes

3. **Business Intelligence Triggers**:
   - When person research completes → Add to deal timeline
   - When psychometric analysis reveals concerns → Trigger policy evaluation
   - When audit report generated → Attach to deal

4. **Quantitative Analysis Triggers**:
   - When analysis completes → Add to deal timeline
   - When analysis reveals financial concerns → Trigger policy evaluation
   - When analysis completes → Update deal risk assessment

### Implementation Pattern

```python
# In each service method, after completing operation:
if deal_id:
    try:
        deal_service = DealService(db)
        deal_service.add_timeline_event(
            deal_id=deal_id,
            event_type="operation_type",
            event_data={
                "operation_id": operation_id,
                "result": result_summary
            },
            user_id=current_user.id
        )
    except Exception as e:
        logger.warning(f"Failed to update deal timeline: {e}")
```

---

## Data Write Operations

### Following Existing Patterns

1. **Database Writes**:
   - Use `db.add()` for new records
   - Use `db.flush()` to get IDs before foreign key relationships
   - Use `db.commit()` at end of transaction
   - Use `db.rollback()` on errors

2. **CDM Event Storage**:
   - Store full CDM events in JSONB columns
   - Use `PolicyDecision` table for policy evaluations
   - Use `file_storage.store_cdm_event()` for file-based storage

3. **Audit Logging**:
   - Use `log_audit_action()` for all state-changing operations
   - Include metadata with operation details
   - Link to user, deal, workflow as appropriate

4. **ChromaDB Indexing**:
   - Use `add_document()` for document indexing
   - Use `add_deal()` for deal indexing
   - Re-index after updates

---

## TypeScript Code Vendoring Strategy

### Option 1: Direct Integration (Recommended for node-DeepResearch)

**Structure**:
```
app/
├── vendors/
│   ├── node-DeepResearch/          # Vendor in TypeScript code directly
│   │   ├── src/
│   │   ├── package.json
│   │   └── tsconfig.json
│   └── pepolehub/                  # Vendor in TypeScript code directly
│       ├── src/
│       ├── package.json
│       └── tsconfig.json
└── services/
    ├── deep_research_service.py    # Python wrapper calling TypeScript
    └── peoplehub_service.py        # Python wrapper calling TypeScript
```

**Python Wrapper Pattern**:
```python
import subprocess
import json
from typing import Dict, Any

class DeepResearchService:
    """Python wrapper for TypeScript DeepResearch implementation."""
    
    def __init__(self):
        self.node_path = "app/vendors/node-DeepResearch"
    
    async def research(self, query: str) -> Dict[str, Any]:
        """Call TypeScript DeepResearch implementation."""
        # Option A: Subprocess call
        result = subprocess.run(
            ["node", f"{self.node_path}/src/cli.ts", query],
            capture_output=True,
            text=True
        )
        return json.loads(result.stdout)
        
        # Option B: HTTP API (if TypeScript runs as service)
        # async with httpx.AsyncClient() as client:
        #     response = await client.post(
        #         "http://localhost:3001/research",
        #         json={"query": query}
        #     )
        #     return response.json()
```

### Option 2: Python Port (For LangAlpha)

**Strategy**: Port Python code directly, adapting to existing patterns.

**Structure**:
```
app/
├── agents/
│   └── langalpha_agents.py         # Ported Python agents
├── workflows/
│   └── langalpha_graph.py           # Ported LangGraph workflow
└── services/
    └── quantitative_analysis_service.py  # Service layer
```

---

## Summary of Improvements

1. ✅ **Verified Design Patterns**: All implementations follow existing repository patterns
2. ✅ **Specific LangChain Components**: Detailed prompts, chains, and agents using Python
3. ✅ **CDM Event Integration**: All operations generate and store CDM events
4. ✅ **Deal Flow Triggers**: Timeline updates and state transitions integrated
5. ✅ **Data Write Operations**: Following existing database and audit patterns
6. ✅ **TypeScript Vendoring**: Strategy for direct integration where possible

This improved plan provides concrete implementation details aligned with existing codebase patterns.
