# CreditNexus Security Scanning & Compliance Implementation Plan

**Version:** 1.0  
**Date:** 2024-12-XX  
**Status:** Planning Phase

---

## Executive Summary

This document provides a comprehensive security assessment and implementation plan for CreditNexus, a financial AI platform that processes sensitive credit agreements, handles user authentication, and manages financial data. The plan includes:

1. **Project Architecture Analysis** - Understanding current security posture
2. **Security Scanning Tools Research** - Recommended tools for comprehensive coverage
3. **Why Multiple Scanners Matter** - Defense-in-depth strategy
4. **CI/CD Security Integration** - Automated security checks on every push
5. **Data Storage & Compliance Assessment** - Current state analysis
6. **Complete Implementation Plan** - Projects, activities, file-level todos, and line-level subtasks

---

## Table of Contents

1. [Project Architecture & Security Analysis](#1-project-architecture--security-analysis)
2. [Security Scanning Tools Research](#2-security-scanning-tools-research)
3. [Why Multiple Scanners Are Critical](#3-why-multiple-scanners-are-critical)
4. [CI/CD Security Workflow Design](#4-cicd-security-workflow-design)
5. [Data Storage & Compliance Assessment](#5-data-storage--compliance-assessment)
6. [Implementation Plan](#6-implementation-plan)
   - [Project 1: SAST Integration](#project-1-sast-integration)
   - [Project 2: Dependency Vulnerability Scanning](#project-2-dependency-vulnerability-scanning)
   - [Project 3: Secrets Detection](#project-3-secrets-detection)
   - [Project 4: Code Quality & Security Linting](#project-4-code-quality--security-linting)
   - [Project 5: DAST Integration](#project-5-dast-integration)
   - [Project 6: Security Compliance Hardening](#project-6-security-compliance-hardening)
7. [File-Level Implementation Tasks](#7-file-level-implementation-tasks)
8. [Line-Level Security Fixes](#8-line-level-security-fixes)

---

## 1. Project Architecture & Security Analysis

### 1.1 Technology Stack

**Backend:**
- **Framework:** FastAPI (Python 3.10+)
- **Database:** PostgreSQL (production) / SQLite (development)
- **ORM:** SQLAlchemy 2.0
- **Authentication:** JWT (python-jose), bcrypt for password hashing
- **AI/ML:** LangChain, OpenAI GPT-4o, TorchGeo, HuggingFace
- **Package Manager:** uv (Python), npm (Node.js)

**Frontend:**
- **Framework:** React 18, TypeScript
- **Build Tool:** Vite
- **Styling:** Tailwind CSS
- **Desktop Integration:** FDC3 2.0

### 1.2 Security Architecture Analysis

#### Current Security Measures (Positive Findings)

1. **Authentication & Authorization:**
   - ✅ JWT-based authentication with access/refresh tokens
   - ✅ Bcrypt password hashing (with SHA-256 pre-hashing for long passwords)
   - ✅ Account lockout after 5 failed attempts (30-minute lockout)
   - ✅ Password strength requirements (12+ chars, uppercase, lowercase, number, special char)
   - ✅ Token blacklisting via database (RefreshToken model)
   - ✅ Role-based access control (UserRole enum)

2. **Secret Management:**
   - ✅ Pydantic SecretStr for API keys in config
   - ✅ Environment variable-based configuration
   - ✅ `.env` file support (not committed to git)

3. **Data Validation:**
   - ✅ Pydantic 2.0 models for request/response validation
   - ✅ SQLAlchemy 2.0 with type hints
   - ✅ Input validation in API routes

4. **Audit Logging:**
   - ✅ Comprehensive audit trail (AuditLog model)
   - ✅ IP address and user agent tracking
   - ✅ Action metadata storage

#### Security Concerns Identified

1. **CORS Configuration:**
   - ⚠️ **CRITICAL:** `allow_origins=["*"]` allows any origin (server.py:461)
   - ⚠️ **CRITICAL:** `allow_credentials=True` with wildcard origins is insecure
   - **Risk:** CSRF attacks, unauthorized API access

2. **Session Security:**
   - ⚠️ **HIGH:** Session secret generated at runtime if not set (server.py:447)
   - ⚠️ **MEDIUM:** `same_site="lax"` should be "strict" for financial apps
   - **Risk:** Session hijacking, CSRF

3. **JWT Secret Management:**
   - ⚠️ **HIGH:** JWT secrets fallback to random generation (jwt_auth.py:34-35)
   - ⚠️ **HIGH:** No key rotation mechanism
   - **Risk:** Token forgery if secrets are compromised

4. **Database Security:**
   - ⚠️ **MEDIUM:** SQLite fallback in development (config.py:194-203)
   - ⚠️ **LOW:** No connection encryption enforcement
   - **Risk:** Data exposure in transit

5. **File Upload Security:**
   - ⚠️ **MEDIUM:** File size limit (20MB) but no file type validation beyond PDF
   - ⚠️ **MEDIUM:** No virus/malware scanning
   - **Risk:** Malicious file uploads

6. **API Security:**
   - ⚠️ **MEDIUM:** No rate limiting implemented
   - ⚠️ **MEDIUM:** No request size limits beyond file uploads
   - **Risk:** DoS attacks, resource exhaustion

7. **Dependency Vulnerabilities:**
   - ⚠️ **HIGH:** No automated dependency scanning in CI/CD
   - ⚠️ **MEDIUM:** Many dependencies without version pinning
   - **Risk:** Known vulnerabilities in dependencies

8. **Secrets in Code:**
   - ⚠️ **HIGH:** No automated secrets scanning
   - ⚠️ **MEDIUM:** Hardcoded debug logging paths (jwt_auth.py:255, 282, etc.)
   - **Risk:** Accidental secret exposure

9. **Error Handling:**
   - ⚠️ **LOW:** Some error messages may leak system information
   - **Risk:** Information disclosure

10. **Frontend Security:**
    - ⚠️ **MEDIUM:** No Content Security Policy (CSP) headers
    - ⚠️ **LOW:** Tokens stored in localStorage (XSS risk)
    - **Risk:** XSS attacks, token theft

### 1.3 Data Storage Analysis

#### Sensitive Data Identified

1. **User Data:**
   - Password hashes (bcrypt) - ✅ Encrypted
   - Email addresses - ⚠️ Plain text
   - Profile data (phone, address, company) - ⚠️ JSONB, not encrypted
   - Wallet addresses - ⚠️ Plain text

2. **Financial Data:**
   - Credit agreements (PDFs) - ⚠️ Stored in `storage/deals/`
   - CDM events (JSON) - ⚠️ Stored in database JSONB
   - Policy decisions - ⚠️ Stored in database
   - Deal information - ⚠️ Stored in database

3. **Authentication Data:**
   - JWT tokens - ✅ Short-lived (30 min access, 7 day refresh)
   - Refresh tokens - ✅ Stored in database with revocation
   - Session cookies - ⚠️ 7-day expiration

4. **API Keys & Secrets:**
   - OpenAI API key - ✅ SecretStr in config
   - SentinelHub credentials - ✅ SecretStr in config
   - Twilio credentials - ⚠️ Optional, stored in config
   - JWT secrets - ⚠️ Environment variables (no rotation)

#### Data Storage Locations

1. **Database (PostgreSQL/SQLite):**
   - User accounts, passwords, profiles
   - Documents, workflows, policy decisions
   - Audit logs
   - CDM events

2. **File System:**
   - `storage/deals/` - Credit agreement PDFs
   - `storage/generated/` - Generated documents
   - `storage/templates/` - LMA templates
   - `chroma_db/` - Vector database for document retrieval

3. **Environment Variables:**
   - `.env` file (not in git)
   - System environment variables

#### Compliance Considerations

1. **GDPR (EU):**
   - ⚠️ No data retention policies
   - ⚠️ No right-to-deletion implementation
   - ⚠️ No data export functionality
   - ⚠️ Profile data not encrypted at rest

2. **Financial Regulations:**
   - ✅ Audit logging implemented
   - ⚠️ No encryption at rest for sensitive financial data
   - ⚠️ No data backup/restore procedures documented

3. **DORA (EU):**
   - ⚠️ No documented incident response plan
   - ⚠️ No security testing in CI/CD
   - ⚠️ No vulnerability management process

---

## 2. Security Scanning Tools Research

### 2.1 Recommended Security Scanning Tools

#### Static Application Security Testing (SAST)

**1. Bandit (Python)**
- **Purpose:** Python-specific security linter
- **Strengths:** Fast, lightweight, Python-focused
- **Integration:** CLI tool, CI/CD friendly
- **License:** Apache 2.0
- **Installation:** `pip install bandit[toml]`
- **Usage:** `bandit -r app/ -f json -o bandit-report.json`

**2. Semgrep**
- **Purpose:** Fast, customizable static analysis
- **Strengths:** Multi-language, custom rules, fast scans
- **Integration:** GitHub Actions, GitLab CI, Jenkins
- **License:** LGPL 2.1 (OSS) / Commercial
- **Installation:** `pip install semgrep` or Docker
- **Usage:** `semgrep --config=auto app/`

**3. SonarQube / SonarCloud**
- **Purpose:** Comprehensive code quality and security
- **Strengths:** Deep analysis, security hotspots, technical debt
- **Integration:** GitHub, GitLab, Azure DevOps
- **License:** Community (free) / Commercial
- **Installation:** Docker or cloud service
- **Usage:** SonarCloud (free for OSS) or self-hosted

**4. Pylint with Security Plugins**
- **Purpose:** Code quality with security focus
- **Strengths:** Extensible, IDE integration
- **Integration:** Pre-commit hooks, CI/CD
- **License:** GPL 2.0
- **Installation:** `pip install pylint pylint-plugin-security`

#### Software Composition Analysis (SCA)

**1. Safety (Python)**
- **Purpose:** Check Python dependencies for known vulnerabilities
- **Strengths:** Fast, PyPI-focused, free
- **Integration:** CLI, CI/CD
- **License:** MIT
- **Installation:** `pip install safety`
- **Usage:** `safety check --json`

**2. pip-audit**
- **Purpose:** Audit Python dependencies (official PyPA tool)
- **Strengths:** Official tool, comprehensive database
- **Integration:** CLI, CI/CD
- **License:** Apache 2.0
- **Installation:** `pip install pip-audit`
- **Usage:** `pip-audit --format json`

**3. Snyk**
- **Purpose:** Comprehensive dependency and container scanning
- **Strengths:** Multi-language, container scanning, license compliance
- **Integration:** GitHub, GitLab, CI/CD
- **License:** Free tier / Commercial
- **Installation:** `npm install -g snyk` or Docker
- **Usage:** `snyk test --json`

**4. Dependabot (GitHub)**
- **Purpose:** Automated dependency updates and security alerts
- **Strengths:** Native GitHub integration, automated PRs
- **Integration:** GitHub native
- **License:** Free for GitHub repos
- **Usage:** Configure via `.github/dependabot.yml`

**5. OWASP Dependency-Check**
- **Purpose:** Detect known vulnerabilities in dependencies
- **Strengths:** Multi-language, comprehensive database
- **Integration:** CLI, Maven, Gradle, CI/CD
- **License:** Apache 2.0
- **Installation:** CLI or Maven plugin
- **Usage:** `dependency-check.sh --scan app/ --format JSON`

#### Secrets Detection

**1. GitGuardian**
- **Purpose:** Detect secrets in code and git history
- **Strengths:** Comprehensive patterns, git history scanning
- **Integration:** GitHub, GitLab, CI/CD
- **License:** Free tier / Commercial
- **Installation:** GitHub App or CLI
- **Usage:** `ggshield scan path app/`

**2. TruffleHog**
- **Purpose:** Find secrets in git repositories
- **Strengths:** High accuracy, git history scanning
- **Integration:** CLI, GitHub Actions
- **License:** Apache 2.0
- **Installation:** `pip install trufflehog` or Docker
- **Usage:** `trufflehog filesystem app/ --json`

**3. detect-secrets**
- **Purpose:** Prevent secrets from entering codebase
- **Strengths:** Pre-commit hooks, baseline management
- **Integration:** Pre-commit, CI/CD
- **License:** Apache 2.0
- **Installation:** `pip install detect-secrets`
- **Usage:** `detect-secrets scan --baseline .secrets.baseline`

#### Dynamic Application Security Testing (DAST)

**1. OWASP ZAP (Zed Attack Proxy)**
- **Purpose:** Find vulnerabilities in running web applications
- **Strengths:** Free, comprehensive, CI/CD integration
- **Integration:** GitHub Actions, Jenkins, Docker
- **License:** Apache 2.0
- **Installation:** Docker or CLI
- **Usage:** `zap-baseline.py -t http://localhost:8000`

**2. Nuclei**
- **Purpose:** Fast vulnerability scanner with templates
- **Strengths:** Community templates, fast scans
- **Integration:** CLI, CI/CD
- **License:** MIT
- **Installation:** `go install` or binary
- **Usage:** `nuclei -u http://localhost:8000 -json`

#### Code Quality & Linting

**1. Ruff (Python)**
- **Purpose:** Fast Python linter (already in project)
- **Strengths:** Very fast, replaces multiple tools
- **Integration:** Pre-commit, CI/CD
- **License:** MIT
- **Usage:** `ruff check app/ --output-format json`

**2. ESLint with Security Plugins (Frontend)**
- **Purpose:** JavaScript/TypeScript security linting
- **Strengths:** Extensible, IDE integration
- **Integration:** Pre-commit, CI/CD
- **License:** MIT
- **Installation:** `npm install eslint-plugin-security`
- **Usage:** `npm run lint`

**3. TypeScript Compiler Security Checks**
- **Purpose:** Type safety prevents many security issues
- **Strengths:** Built-in, no additional setup
- **Integration:** Build process
- **Usage:** `tsc --noEmit --strict`

### 2.2 Tool Selection Matrix

| Tool Category | Primary Tool | Secondary Tool | Rationale |
|--------------|-------------|---------------|-----------|
| **Python SAST** | Bandit | Semgrep | Bandit is Python-specific, Semgrep provides broader coverage |
| **Dependency Scanning** | pip-audit | Safety | pip-audit is official PyPA tool, Safety as backup |
| **Secrets Detection** | detect-secrets | TruffleHog | detect-secrets for prevention, TruffleHog for detection |
| **Frontend SAST** | ESLint + Security Plugin | TypeScript strict mode | Already in project, add security rules |
| **DAST** | OWASP ZAP | Nuclei | ZAP is comprehensive, Nuclei is fast for quick checks |
| **Code Quality** | Ruff | SonarQube | Ruff already in project, SonarQube for deep analysis |

---

## 3. Why Multiple Scanners Are Critical

### 3.1 Defense-in-Depth Principle

Security is not a single-point solution. Multiple scanners provide:

1. **Comprehensive Coverage:**
   - **SAST tools** find issues in source code (e.g., Bandit finds hardcoded passwords)
   - **SCA tools** find issues in dependencies (e.g., pip-audit finds vulnerable packages)
   - **DAST tools** find issues in running applications (e.g., ZAP finds SQL injection)
   - **Secrets scanners** find accidentally committed credentials

2. **Reduced False Negatives:**
   - Tool A might miss an issue that Tool B catches
   - Example: Bandit might miss a dependency vulnerability that pip-audit finds
   - Example: Static analysis might miss a runtime issue that ZAP finds

3. **Reduced False Positives:**
   - Cross-verification: If 3 tools flag the same issue, it's likely real
   - Tool-specific quirks: Some tools have known false positives that others don't

4. **Different Analysis Approaches:**
   - **Pattern Matching:** Bandit uses regex patterns (fast, but limited)
   - **AST Analysis:** Semgrep analyzes abstract syntax trees (deeper, but slower)
   - **Taint Analysis:** SonarQube tracks data flow (comprehensive, but complex)
   - **Runtime Testing:** ZAP actually attacks the application (real-world, but requires running app)

5. **Compliance Requirements:**
   - Many regulations (DORA, PCI-DSS) require multiple security testing approaches
   - Auditors expect layered security testing
   - Insurance may require multiple scanning tools

### 3.2 Real-World Example

**Scenario:** A developer accidentally commits an API key.

- **GitGuardian:** ✅ Detects it immediately (secrets scanner)
- **Bandit:** ❌ Misses it (not a code pattern issue)
- **pip-audit:** ❌ Misses it (not a dependency issue)
- **ZAP:** ❌ Misses it (not a runtime vulnerability)

**Without GitGuardian:** The secret would be in git history forever.

**Scenario:** A dependency has a known vulnerability.

- **pip-audit:** ✅ Detects it (SCA tool)
- **Bandit:** ❌ Misses it (not in source code)
- **GitGuardian:** ❌ Misses it (not a secret)
- **ZAP:** ⚠️ Might detect if it's exploitable at runtime

**Without pip-audit:** The vulnerability would go unnoticed until exploited.

### 3.3 Cost-Benefit Analysis

**Cost of Multiple Scanners:**
- **Time:** ~5-10 minutes per CI run (parallel execution)
- **Maintenance:** ~1 hour/month to update configurations
- **False Positives:** ~30 minutes/week to triage

**Benefit:**
- **Early Detection:** Catch issues before production
- **Compliance:** Meet regulatory requirements
- **Reputation:** Avoid security incidents
- **Cost Savings:** Prevent breaches (average cost: $4.45M per IBM 2023 report)

**ROI:** Extremely positive. The cost of a single security incident far exceeds the cost of running multiple scanners.

---

## 4. CI/CD Security Workflow Design

### 4.1 Workflow Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Push to main branch                       │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        ▼
        ┌───────────────────────────────┐
        │   Checkout & Setup            │
        │   - Python 3.11               │
        │   - Node.js 20                │
        │   - uv, npm                   │
        └───────────────┬───────────────┘
                        │
        ┌───────────────┴───────────────┐
        │                               │
        ▼                               ▼
┌───────────────┐              ┌───────────────┐
│  Backend      │              │  Frontend     │
│  Security     │              │  Security     │
│  Checks       │              │  Checks       │
└───────┬───────┘              └───────┬───────┘
        │                               │
        ├─ Bandit (SAST)               ├─ ESLint Security
        ├─ Semgrep (SAST)              ├─ TypeScript Check
        ├─ pip-audit (SCA)             ├─ npm audit
        ├─ Safety (SCA backup)         └─ Dependency Check
        ├─ detect-secrets
        ├─ Ruff Security
        └─ Dependency Check
                        │
        ┌───────────────┴───────────────┐
        │                               │
        ▼                               ▼
┌───────────────┐              ┌───────────────┐
│  Integration  │              │  Artifact    │
│  Tests     │              │  Security      │
│  (if app   │              │  Scan         │
│   running) │              │  (optional)    │
└─────────────┘              └───────────────┘
        │
        ▼
┌───────────────────────────────┐
│   Security Report Generation  │
│   - SARIF upload              │
│   - GitHub Security tab        │
│   - Summary comment           │
└───────────────────────────────┘
        │
        ▼
┌───────────────────────────────┐
│   Gate Decision               │
│   - Block if critical         │
│   - Warn if high/medium       │
│   - Allow if low/info         │
└───────────────────────────────┘
```

### 4.2 Security Check Stages

#### Stage 1: Pre-Build Security (Fast Failures)

**Purpose:** Catch issues before building/running tests

1. **Secrets Detection** (30 seconds)
   - `detect-secrets scan`
   - Fail if new secrets found

2. **Dependency Vulnerability Scan** (1-2 minutes)
   - `pip-audit --format json`
   - `npm audit --json`
   - Fail if critical vulnerabilities

3. **Code Quality & Security Linting** (1-2 minutes)
   - `ruff check app/ --output-format json`
   - `npm run lint`
   - Warn on security issues, fail on critical

#### Stage 2: Build-Time Security (SAST)

**Purpose:** Analyze source code for security issues

1. **Python SAST** (2-3 minutes)
   - `bandit -r app/ -f json`
   - `semgrep --config=auto app/ --json`

2. **Frontend SAST** (1-2 minutes)
   - `eslint --ext .ts,.tsx src/ --format json`
   - TypeScript strict mode checks

#### Stage 3: Post-Build Security (DAST - Optional)

**Purpose:** Test running application (if test environment available)

1. **OWASP ZAP Baseline Scan** (5-10 minutes)
   - Only if test server is running
   - `zap-baseline.py -t http://test-server:8000`

#### Stage 4: Reporting & Gating

**Purpose:** Aggregate results and make go/no-go decision

1. **SARIF Upload**
   - Upload all results to GitHub Security tab
   - Enable security alerts

2. **Summary Report**
   - Comment on PR with summary
   - Link to detailed reports

3. **Gate Decision**
   - **Block:** Critical vulnerabilities
   - **Warn:** High/Medium vulnerabilities (allow merge with approval)
   - **Info:** Low/Info findings (allow merge)

### 4.3 GitHub Actions Workflow File

See implementation in Project 1 for complete workflow file.

---

## 5. Data Storage & Compliance Assessment

### 5.1 Data Classification

#### Category 1: Highly Sensitive (Encryption Required)

- **Password Hashes:** ✅ Encrypted (bcrypt)
- **JWT Secrets:** ⚠️ Should be in secure key management (Vault, AWS Secrets Manager)
- **API Keys:** ⚠️ Should be in secure key management
- **Financial Data (CDM Events):** ⚠️ Should be encrypted at rest
- **Credit Agreement PDFs:** ⚠️ Should be encrypted at rest

#### Category 2: Sensitive (Access Control Required)

- **User Email Addresses:** ⚠️ Plain text, should be encrypted
- **Profile Data (phone, address):** ⚠️ JSONB, should be encrypted
- **Wallet Addresses:** ⚠️ Plain text (acceptable, but monitor)
- **Audit Logs:** ⚠️ Plain text (acceptable for audit trail)

#### Category 3: Internal (Standard Protection)

- **Document Metadata:** ⚠️ Standard database protection
- **Workflow States:** ⚠️ Standard database protection
- **Template Data:** ⚠️ Standard database protection

### 5.2 Encryption Status

#### At Rest Encryption

- **Database:** ⚠️ **NOT ENFORCED** - Relies on database server encryption
- **File Storage:** ⚠️ **NOT ENFORCED** - Files stored in plain text
- **Backups:** ⚠️ **NOT DOCUMENTED** - No backup encryption policy

#### In Transit Encryption

- **API:** ✅ HTTPS required (FastAPI with uvicorn)
- **Database:** ⚠️ **NOT ENFORCED** - Should use SSL/TLS
- **File Uploads:** ✅ HTTPS (via FastAPI)

### 5.3 Access Control Assessment

#### Database Access

- ⚠️ **NO ROW-LEVEL SECURITY** - All users can access all data (relies on application logic)
- ⚠️ **NO COLUMN-LEVEL ENCRYPTION** - Sensitive columns not encrypted
- ✅ **SQL INJECTION PROTECTION** - SQLAlchemy ORM prevents most SQL injection

#### File System Access

- ⚠️ **NO ACCESS CONTROL** - Files accessible to anyone with file system access
- ⚠️ **NO ENCRYPTION** - Files stored in plain text
- ⚠️ **NO BACKUP ENCRYPTION** - Backups not encrypted

### 5.4 Compliance Gap Analysis

#### GDPR Compliance

| Requirement | Status | Gap |
|------------|--------|-----|
| Data encryption at rest | ❌ | No encryption for sensitive data |
| Right to access | ❌ | No API endpoint for data export |
| Right to deletion | ❌ | No soft-delete or hard-delete implementation |
| Data portability | ❌ | No data export functionality |
| Breach notification | ⚠️ | No automated breach detection |
| Privacy by design | ⚠️ | Some data stored unnecessarily |

#### DORA Compliance (EU Financial Regulation)

| Requirement | Status | Gap |
|------------|--------|-----|
| Security testing | ❌ | No security testing in CI/CD |
| Vulnerability management | ❌ | No vulnerability management process |
| Incident response | ❌ | No documented incident response plan |
| Business continuity | ❌ | No documented BCP |
| Third-party risk | ⚠️ | No third-party risk assessment |

#### PCI-DSS (If handling payments)

| Requirement | Status | Gap |
|------------|--------|-----|
| Encryption at rest | ❌ | Not implemented |
| Access controls | ⚠️ | Basic RBAC, no MFA |
| Audit logging | ✅ | Comprehensive audit logs |
| Vulnerability scanning | ❌ | Not automated |

### 5.5 Data Retention & Lifecycle

- ⚠️ **NO RETENTION POLICIES** - Data kept indefinitely
- ⚠️ **NO ARCHIVAL STRATEGY** - All data in active database
- ⚠️ **NO DELETION POLICIES** - No automated cleanup

---

## 6. Implementation Plan

### Project 1: SAST Integration

**Objective:** Integrate static application security testing into CI/CD pipeline

**Duration:** 2-3 days

**Activities:**
1. Install and configure Bandit
2. Install and configure Semgrep
3. Create GitHub Actions workflow
4. Configure SARIF upload
5. Set up security alerts

**File-Level Todos:**
- `.github/workflows/security-scan.yml` - Create new workflow
- `pyproject.toml` - Add security dev dependencies
- `.bandit` - Create Bandit configuration
- `.semgrep.yml` - Create Semgrep configuration
- `SECURITY.md` - Create security policy document

**Line-Level Subtasks:**
- `.github/workflows/security-scan.yml:1-50` - Workflow setup and checkout
- `.github/workflows/security-scan.yml:51-100` - Python SAST jobs
- `.github/workflows/security-scan.yml:101-150` - Frontend SAST jobs
- `.github/workflows/security-scan.yml:151-200` - SARIF upload and reporting
- `pyproject.toml:89-97` - Add `bandit[toml]`, `semgrep` to dev dependencies

---

### Project 2: Dependency Vulnerability Scanning

**Objective:** Automatically scan Python and Node.js dependencies for vulnerabilities

**Duration:** 1-2 days

**Activities:**
1. Install pip-audit and Safety
2. Configure npm audit
3. Add dependency scanning to CI/CD
4. Set up Dependabot
5. Configure automated PRs for updates

**File-Level Todos:**
- `.github/workflows/security-scan.yml` - Add dependency scanning jobs
- `.github/dependabot.yml` - Create Dependabot configuration
- `pyproject.toml` - Pin dependency versions
- `package.json` - Pin dependency versions (if not already)

**Line-Level Subtasks:**
- `.github/workflows/security-scan.yml:201-250` - Python dependency scanning
- `.github/workflows/security-scan.yml:251-300` - Node.js dependency scanning
- `.github/dependabot.yml:1-50` - Python dependencies configuration
- `.github/dependabot.yml:51-100` - Node.js dependencies configuration

---

### Project 3: Secrets Detection

**Objective:** Prevent secrets from being committed to the repository

**Duration:** 1 day

**Activities:**
1. Install detect-secrets
2. Create secrets baseline
3. Add pre-commit hook
4. Add CI/CD check
5. Scan existing codebase

**File-Level Todos:**
- `.pre-commit-config.yaml` - Create pre-commit configuration
- `.secrets.baseline` - Create secrets baseline
- `.github/workflows/security-scan.yml` - Add secrets detection job
- `.gitignore` - Ensure .secrets.baseline is tracked

**Line-Level Subtasks:**
- `.pre-commit-config.yaml:1-20` - detect-secrets hook configuration
- `.github/workflows/security-scan.yml:301-350` - Secrets detection job
- `app/auth/jwt_auth.py:255-330` - Remove hardcoded debug logging paths

---

### Project 4: Code Quality & Security Linting

**Objective:** Enhance existing linting with security-focused rules

**Duration:** 1 day

**Activities:**
1. Configure Ruff security rules
2. Add ESLint security plugin
3. Update TypeScript strict mode
4. Add security linting to CI/CD

**File-Level Todos:**
- `pyproject.toml` - Update Ruff configuration with security rules
- `client/eslint.config.js` - Add security plugin
- `client/tsconfig.json` - Enable strict mode
- `.github/workflows/security-scan.yml` - Add linting jobs

**Line-Level Subtasks:**
- `pyproject.toml:113-128` - Add security-related Ruff rules
- `client/eslint.config.js` - Add `eslint-plugin-security` configuration
- `client/tsconfig.json` - Set `strict: true`, `noImplicitAny: true`

---

### Project 5: DAST Integration

**Objective:** Test running application for runtime vulnerabilities

**Duration:** 2-3 days

**Activities:**
1. Set up test environment in CI/CD
2. Install and configure OWASP ZAP
3. Add DAST scanning job
4. Configure ZAP baseline scan
5. Add results to security report

**File-Level Todos:**
- `.github/workflows/security-scan.yml` - Add DAST job
- `docker-compose.test.yml` - Create test environment (optional)
- `.zap-baseline.conf` - ZAP baseline configuration

**Line-Level Subtasks:**
- `.github/workflows/security-scan.yml:351-450` - DAST job with ZAP
- `.zap-baseline.conf:1-50` - ZAP baseline rules configuration

---

### Project 6: Security Compliance Hardening

**Objective:** Fix identified security issues and improve compliance posture

**Duration:** 1-2 weeks

**Activities:**
1. Fix CORS configuration
2. Implement rate limiting
3. Add file upload validation
4. Implement encryption at rest (optional, complex)
5. Add data retention policies
6. Document security procedures

**File-Level Todos:**
- `server.py` - Fix CORS, add rate limiting
- `app/api/routes.py` - Add file validation
- `app/core/config.py` - Add security settings
- `docs/SECURITY.md` - Security documentation
- `app/services/encryption_service.py` - Create encryption service (if needed)

**Line-Level Subtasks:**
- `server.py:459-465` - Fix CORS: Replace `["*"]` with specific origins
- `server.py:450-457` - Fix session: Set `same_site="strict"`
- `app/api/routes.py:83-100` - Add file type validation beyond PDF
- `app/api/routes.py:81` - Add rate limiting decorator
- `app/core/config.py` - Add `ALLOWED_ORIGINS`, `RATE_LIMIT_ENABLED` settings

---

## 7. File-Level Implementation Tasks

### 7.1 New Files to Create

1. **`.github/workflows/security-scan.yml`**
   - Complete CI/CD security workflow
   - All security scanning jobs
   - SARIF upload and reporting

2. **`.github/dependabot.yml`**
   - Dependabot configuration for automated updates

3. **`.pre-commit-config.yaml`**
   - Pre-commit hooks for secrets detection
   - Code quality checks

4. **`.secrets.baseline`**
   - Baseline for detect-secrets
   - Tracks known false positives

5. **`.bandit`**
   - Bandit configuration file
   - Excludes, severity levels

6. **`.semgrep.yml`**
   - Semgrep configuration
   - Custom rules if needed

7. **`.zap-baseline.conf`**
   - OWASP ZAP baseline configuration
   - Rules to include/exclude

8. **`SECURITY.md`**
   - Security policy document
   - Vulnerability reporting process

9. **`docs/SECURITY.md`**
   - Security documentation
   - Compliance information

### 7.2 Files to Modify

1. **`pyproject.toml`**
   - Add security dev dependencies
   - Update Ruff configuration

2. **`client/package.json`**
   - Add security ESLint plugin
   - Update scripts if needed

3. **`client/eslint.config.js`**
   - Add security plugin configuration

4. **`client/tsconfig.json`**
   - Enable strict mode

5. **`server.py`**
   - Fix CORS configuration
   - Fix session security
   - Add rate limiting

6. **`app/api/routes.py`**
   - Add file validation
   - Add rate limiting

7. **`app/core/config.py`**
   - Add security-related settings

8. **`app/auth/jwt_auth.py`**
   - Remove hardcoded debug paths
   - Improve JWT secret management

9. **`.gitignore`**
   - Ensure security reports are ignored
   - Keep `.secrets.baseline` tracked

---

## 8. Line-Level Security Fixes

### 8.1 Critical Security Fixes

#### Fix 1: CORS Configuration (server.py:459-465)

**Current Code:**
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # ❌ SECURITY ISSUE
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

**Fixed Code:**
```python
from app.core.config import settings

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,  # ✅ Specific origins
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
    expose_headers=["X-Total-Count"],
)
```

**File:** `server.py`  
**Lines:** 459-465  
**Priority:** CRITICAL

#### Fix 2: Session Security (server.py:450-457)

**Current Code:**
```python
app.add_middleware(
    SessionMiddleware,
    secret_key=session_secret,
    session_cookie="creditnexus_session",
    max_age=86400 * 7,
    same_site="lax",  # ⚠️ Should be "strict"
    https_only=is_production,
)
```

**Fixed Code:**
```python
app.add_middleware(
    SessionMiddleware,
    secret_key=session_secret,
    session_cookie="creditnexus_session",
    max_age=86400 * 7,
    same_site="strict",  # ✅ Stricter CSRF protection
    https_only=True,  # ✅ Always enforce HTTPS
    secure=True,  # ✅ Secure cookie flag
)
```

**File:** `server.py`  
**Lines:** 450-457  
**Priority:** HIGH

#### Fix 3: JWT Secret Management (app/auth/jwt_auth.py:34-35)

**Current Code:**
```python
JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY", secrets.token_urlsafe(32))
JWT_REFRESH_SECRET_KEY = os.environ.get("JWT_REFRESH_SECRET_KEY", secrets.token_urlsafe(32))
```

**Fixed Code:**
```python
JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY")
JWT_REFRESH_SECRET_KEY = os.environ.get("JWT_REFRESH_SECRET_KEY")

if not JWT_SECRET_KEY or not JWT_REFRESH_SECRET_KEY:
    raise RuntimeError(
        "JWT_SECRET_KEY and JWT_REFRESH_SECRET_KEY must be set in production. "
        "Generate secure keys: python -c 'import secrets; print(secrets.token_urlsafe(32))'"
    )
```

**File:** `app/auth/jwt_auth.py`  
**Lines:** 34-35  
**Priority:** HIGH

#### Fix 4: Remove Debug Logging (app/auth/jwt_auth.py:255-330)

**Current Code:**
```python
# #region agent log
import json
log_data = {
    "sessionId": "debug-session",
    "runId": "login-debug",
    "hypothesisId": "B",
    "location": "jwt_auth.py:255",
    "message": "create_refresh_token called",
    "data": {"user_id": data.get("sub")},
    "timestamp": int(datetime.utcnow().timestamp() * 1000)
}
try:
    with open(r"c:\Users\MeMyself\creditnexus\.cursor\debug.log", "a") as f:
        f.write(json.dumps(log_data) + "\n")
except:
    pass
# #endregion
```

**Fixed Code:**
```python
# Remove all debug logging blocks
# Use proper logging instead:
import logging
logger = logging.getLogger(__name__)
logger.debug("create_refresh_token called", extra={"user_id": data.get("sub")})
```

**File:** `app/auth/jwt_auth.py`  
**Lines:** 255-330, 732-988 (multiple instances)  
**Priority:** MEDIUM

#### Fix 5: File Upload Validation (app/api/routes.py:83-100)

**Current Code:**
```python
def extract_text_from_pdf(file_content: bytes) -> str:
    """Extract text from a PDF file using PyMuPDF."""
    import fitz
    
    file_size_mb = len(file_content) / (1024 * 1024)
    if file_size_mb > MAX_FILE_SIZE_MB:
        raise ValueError(f"File too large ({file_size_mb:.1f} MB). Maximum size is {MAX_FILE_SIZE_MB} MB.")
    # No file type validation beyond size
```

**Fixed Code:**
```python
import magic  # python-magic library

def extract_text_from_pdf(file_content: bytes) -> str:
    """Extract text from a PDF file using PyMuPDF."""
    import fitz
    
    # Validate file type using magic bytes
    file_type = magic.from_buffer(file_content, mime=True)
    if file_type != "application/pdf":
        raise ValueError(f"Invalid file type: {file_type}. Only PDF files are allowed.")
    
    # Validate PDF structure
    try:
        doc = fitz.open(stream=file_content, filetype="pdf")
        doc.close()
    except Exception as e:
        raise ValueError(f"Invalid PDF file: {str(e)}")
    
    file_size_mb = len(file_content) / (1024 * 1024)
    if file_size_mb > MAX_FILE_SIZE_MB:
        raise ValueError(f"File too large ({file_size_mb:.1f} MB). Maximum size is {MAX_FILE_SIZE_MB} MB.")
    
    # Continue with extraction...
```

**File:** `app/api/routes.py`  
**Lines:** 83-100  
**Priority:** MEDIUM

### 8.2 Medium Priority Fixes

#### Fix 6: Add Rate Limiting

**File:** `server.py`  
**Lines:** After line 465  
**Priority:** MEDIUM

**Add:**
```python
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Apply rate limiting to API routes
@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    # Skip rate limiting for health checks
    if request.url.path == "/api/health":
        return await call_next(request)
    return await limiter(request)(call_next)
```

#### Fix 7: Add Security Headers

**File:** `server.py`  
**Lines:** After line 465  
**Priority:** MEDIUM

**Add:**
```python
from fastapi.middleware.trustedhost import TrustedHostMiddleware

app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["creditnexus.com", "*.creditnexus.com", "localhost", "127.0.0.1"]
)

@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Content-Security-Policy"] = "default-src 'self'"
    return response
```

### 8.3 Low Priority Improvements

#### Fix 8: Improve Error Messages

**File:** `app/api/routes.py`  
**Lines:** Various error handlers  
**Priority:** LOW

**Change:** Ensure error messages don't leak system information

#### Fix 9: Add Input Sanitization

**File:** `app/api/routes.py`  
**Lines:** All input endpoints  
**Priority:** LOW

**Add:** Input sanitization for user-provided data

---

## 9. Implementation Timeline

### Week 1: Foundation
- **Day 1-2:** Project 1 (SAST Integration)
- **Day 3:** Project 2 (Dependency Scanning)
- **Day 4:** Project 3 (Secrets Detection)
- **Day 5:** Project 4 (Code Quality)

### Week 2: Advanced & Fixes
- **Day 1-2:** Project 5 (DAST Integration)
- **Day 3-5:** Project 6 (Security Hardening - Critical fixes)

### Week 3: Compliance & Documentation
- **Day 1-2:** Complete remaining security fixes
- **Day 3:** Security documentation
- **Day 4:** Compliance documentation
- **Day 5:** Review and testing

---

## 10. Success Metrics

### Security Metrics

1. **Vulnerability Detection:**
   - Zero critical vulnerabilities in dependencies
   - <5 high-severity findings per scan
   - 100% of secrets detected before commit

2. **Compliance:**
   - All security scans passing in CI/CD
   - Security documentation complete
   - Audit trail for all security changes

3. **Response Time:**
   - Critical vulnerabilities fixed within 24 hours
   - High vulnerabilities fixed within 7 days
   - Medium vulnerabilities fixed within 30 days

### Process Metrics

1. **CI/CD Integration:**
   - 100% of security scans automated
   - <10 minutes total scan time
   - Security reports generated automatically

2. **Developer Experience:**
   - Pre-commit hooks prevent 90% of issues
   - Clear security documentation
   - Easy-to-fix security findings

---

## 11. Maintenance & Ongoing Work

### Daily
- Review security scan results
- Triage new vulnerabilities
- Update dependency baselines

### Weekly
- Review and update security rules
- Analyze false positive rates
- Update security documentation

### Monthly
- Review and update dependencies
- Security training for developers
- Compliance audit

### Quarterly
- Full security assessment
- Penetration testing (optional)
- Security policy review

---

## 12. Resources & References

### Documentation
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [Bandit Documentation](https://bandit.readthedocs.io/)
- [Semgrep Documentation](https://semgrep.dev/docs/)
- [OWASP ZAP Documentation](https://www.zaproxy.org/docs/)

### Tools
- [GitHub Security Advisories](https://github.com/advisories)
- [Snyk Vulnerability Database](https://snyk.io/vuln/)
- [CVE Database](https://cve.mitre.org/)

### Compliance
- [GDPR Compliance Guide](https://gdpr.eu/)
- [DORA Regulation](https://www.eba.europa.eu/regulation-and-policy/operational-risk/digital-operational-resilience-act-dora)
- [PCI-DSS Requirements](https://www.pcisecuritystandards.org/)

---

## Appendix A: Complete File List

### Files to Create
1. `.github/workflows/security-scan.yml`
2. `.github/dependabot.yml`
3. `.pre-commit-config.yaml`
4. `.secrets.baseline`
5. `.bandit`
6. `.semgrep.yml`
7. `.zap-baseline.conf`
8. `SECURITY.md`
9. `docs/SECURITY.md`

### Files to Modify
1. `pyproject.toml`
2. `client/package.json`
3. `client/eslint.config.js`
4. `client/tsconfig.json`
5. `server.py`
6. `app/api/routes.py`
7. `app/core/config.py`
8. `app/auth/jwt_auth.py`
9. `.gitignore`

---

## Appendix B: Security Scan Commands Reference

### Python SAST
```bash
# Bandit
bandit -r app/ -f json -o bandit-report.json

# Semgrep
semgrep --config=auto app/ --json -o semgrep-report.json
```

### Dependency Scanning
```bash
# pip-audit
pip-audit --format json -o pip-audit-report.json

# Safety
safety check --json -o safety-report.json
```

### Secrets Detection
```bash
# detect-secrets
detect-secrets scan --baseline .secrets.baseline

# TruffleHog
trufflehog filesystem app/ --json
```

### Frontend Security
```bash
# npm audit
npm audit --json > npm-audit-report.json

# ESLint
npm run lint -- --format json -o eslint-report.json
```

### DAST
```bash
# OWASP ZAP
zap-baseline.py -t http://localhost:8000 -J zap-report.json
```

---

**End of Document**
