# CreditNexus Filing & Signature LangChain Integration

## Overview

This document defines the LangChain chains, prompts, and Pydantic models required for AI-assisted filing and signature functionality in CreditNexus. All chains follow existing repository patterns and use the LLM client abstraction.

---

## Table of Contents

1. [Pydantic Models](#pydantic-models)
2. [LangChain Chains](#langchain-chains)
3. [Prompt Templates](#prompt-templates)
4. [Integration Patterns](#integration-patterns)
5. [Configuration](#configuration)

---

## Pydantic Models

### 1. Filing Requirement Evaluation Models

**File**: `app/models/filing_requirements.py`

```python
"""Pydantic models for filing requirement evaluation."""

from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field
from decimal import Decimal


class FilingRequirement(BaseModel):
    """Represents a filing requirement for an agreement."""
    authority: str = Field(..., description="Filing authority (e.g., 'SEC', 'Companies House')")
    jurisdiction: str = Field(..., description="Jurisdiction code (e.g., 'US', 'UK', 'FR', 'DE')")
    agreement_type: str = Field(..., description="Type of agreement (e.g., 'facility_agreement', 'disclosure')")
    filing_system: str = Field(..., description="Filing system ('companies_house_api', 'manual_ui')")
    deadline: datetime = Field(..., description="Filing deadline")
    required_fields: List[str] = Field(default_factory=list, description="Required fields for filing")
    api_available: bool = Field(default=False, description="Whether API filing is available")
    api_endpoint: Optional[str] = Field(None, description="API endpoint if available")
    penalty: Optional[str] = Field(None, description="Penalty for late filing")
    language_requirement: Optional[str] = Field(None, description="Required language for filing")
    form_type: Optional[str] = Field(None, description="Form type (e.g., '8-K', 'MR01')")
    priority: str = Field(default="medium", description="Priority: 'critical', 'high', 'medium', 'low'")


class FilingRequirementEvaluation(BaseModel):
    """Result of filing requirement evaluation."""
    required_filings: List[FilingRequirement] = Field(default_factory=list)
    compliance_status: str = Field(..., description="'compliant', 'non_compliant', 'pending'")
    missing_fields: List[str] = Field(default_factory=list)
    deadline_alerts: List[Dict[str, Any]] = Field(default_factory=list)
    trace_id: str = Field(..., description="Policy evaluation trace ID")
    metadata: Dict[str, Any] = Field(default_factory=dict)
```

### 2. Filing Form Data Generation Models

**File**: `app/models/filing_forms.py`

```python
"""Pydantic models for filing form data generation."""

from typing import List, Optional, Dict, Any
from datetime import date, datetime
from pydantic import BaseModel, Field
from decimal import Decimal


class FilingFormField(BaseModel):
    """Represents a single form field."""
    field_name: str = Field(..., description="Form field name")
    field_value: Any = Field(..., description="Field value")
    field_type: str = Field(..., description="Field type: 'text', 'date', 'number', 'select', 'file'")
    required: bool = Field(default=True)
    validation_rules: Optional[Dict[str, Any]] = Field(None, description="Validation rules")
    help_text: Optional[str] = Field(None, description="Help text for user")


class FilingFormData(BaseModel):
    """Pre-filled form data for manual filing."""
    jurisdiction: str = Field(..., description="Jurisdiction code")
    authority: str = Field(..., description="Filing authority")
    form_type: str = Field(..., description="Form type")
    fields: List[FilingFormField] = Field(default_factory=list)
    document_references: List[str] = Field(default_factory=list, description="Document IDs to attach")
    submission_url: Optional[str] = Field(None, description="URL to submission portal")
    instructions: Optional[str] = Field(None, description="Submission instructions")
    language: str = Field(default="en", description="Form language")
```

### 3. Signature Request Models

**File**: `app/models/signature_requests.py`

```python
"""Pydantic models for signature request generation."""

from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field


class Signer(BaseModel):
    """Represents a document signer."""
    name: str = Field(..., description="Signer full name")
    email: str = Field(..., description="Signer email address")
    role: str = Field(..., description="Signer role (e.g., 'Borrower', 'Lender', 'Guarantor')")
    signing_order: int = Field(default=0, description="Order in which signer must sign (0 = parallel)")
    required: bool = Field(default=True, description="Whether signature is required")


class SignatureRequestGeneration(BaseModel):
    """AI-generated signature request configuration."""
    signers: List[Signer] = Field(default_factory=list)
    signing_workflow: str = Field(default="parallel", description="'parallel' or 'sequential'")
    expiration_days: int = Field(default=30, description="Days until signature request expires")
    reminder_enabled: bool = Field(default=True, description="Enable email reminders")
    reminder_days: List[int] = Field(default_factory=lambda: [7, 3, 1], description="Days before expiration to send reminders")
    message: Optional[str] = Field(None, description="Custom message for signers")
    metadata: Dict[str, Any] = Field(default_factory=dict)
```

---

## LangChain Chains

### 1. Filing Requirement Evaluation Chain

**File**: `app/chains/filing_requirement_chain.py`

```python
"""LangChain chain for evaluating filing requirements from CDM data."""

import logging
from typing import Optional, Dict, Any
from pydantic import ValidationError

from langchain_core.language_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate

from app.core.llm_client import get_chat_model
from app.models.filing_requirements import FilingRequirementEvaluation
from app.models.cdm import CreditAgreement

logger = logging.getLogger(__name__)


def create_filing_requirement_chain() -> BaseChatModel:
    """Create and configure the LangChain filing requirement evaluation chain.
    
    Uses the LLM client abstraction to support multiple providers.
    Temperature set to 0 for deterministic evaluation.
    
    Returns:
        A BaseChatModel instance configured with structured output
        bound to the FilingRequirementEvaluation Pydantic model.
    """
    llm = get_chat_model(temperature=0)
    structured_llm = llm.with_structured_output(FilingRequirementEvaluation)
    return structured_llm


def create_filing_requirement_prompt() -> ChatPromptTemplate:
    """Create the prompt template for filing requirement evaluation.
    
    Returns:
        A ChatPromptTemplate with system and user message templates.
    """
    system_prompt = """You are an expert Regulatory Compliance Analyst specializing in credit agreement filing requirements across multiple jurisdictions.

Your task is to analyze a Credit Agreement (CDM format) and determine:
1. Which regulatory filings are required based on jurisdiction, agreement type, and deal characteristics
2. Filing deadlines and priority levels
3. Required fields for each filing
4. Whether API filing is available or manual filing is required
5. Compliance status and missing information

JURISDICTIONS YOU MUST EVALUATE:
- **US (United States)**: SEC EDGAR filings (8-K, 10-Q, 10-K), state-level filings
- **UK (United Kingdom)**: Companies House filings (MR01 charges, annual returns)
- **FR (France)**: AMF filings, Commercial Court registrations
- **DE (Germany)**: BaFin filings, Commercial Register entries

AGREEMENT TYPES:
- facility_agreement: Credit facility agreements
- disclosure: Regulatory disclosures
- security_agreement: Security/charge registrations
- intercreditor: Intercreditor agreements
- term_sheet: Term sheet filings (if required)

FILING REQUIREMENT DETERMINATION RULES:

1. **US SEC Filings**:
   - 8-K required for material credit agreements (typically >$100M or >10% of assets)
   - Deadline: 4 business days after agreement execution
   - Required fields: Company name, CIK, agreement date, total commitment, parties
   - Filing system: manual_ui (no direct API)
   - Form type: "8-K"

2. **UK Companies House**:
   - MR01 required for charges/security interests
   - Deadline: 21 days after charge creation
   - Required fields: Company number, charge creation date, persons entitled, property charged, amount secured
   - Filing system: companies_house_api (API available)
   - Form type: "MR01"

3. **France AMF/Court**:
   - Required for material credit agreements (typically >€150M)
   - Deadline: Varies by agreement type (typically 15-30 days)
   - Required fields: Company name, SIREN, agreement date, total commitment
   - Filing system: manual_ui
   - Language requirement: French
   - Form type: "Declaration de prêt"

4. **Germany BaFin/Register**:
   - Required for material credit agreements (typically >€150M)
   - Deadline: Varies by agreement type (typically 15-30 days)
   - Required fields: Company name, HRB number, agreement date, total commitment
   - Filing system: manual_ui
   - Language requirement: German
   - Form type: "Kreditvertrag Anmeldung"

PRIORITY LEVELS:
- **critical**: Deadline within 7 days
- **high**: Deadline within 30 days
- **medium**: Deadline within 90 days
- **low**: Deadline beyond 90 days

COMPLIANCE STATUS:
- **compliant**: All required filings identified and all required fields present
- **non_compliant**: Required filings identified but required fields missing
- **pending**: Filings identified but not yet submitted

CRITICAL RULES:
- Only identify filings that are ACTUALLY REQUIRED by law/regulation
- Consider agreement amount thresholds (materiality)
- Consider jurisdiction of borrower and lenders
- Extract exact deadlines from regulatory rules
- Identify missing required fields accurately
- Set appropriate priority based on deadline proximity
- Return empty list if no filings required (don't guess)
"""

    user_prompt = """Credit Agreement (CDM Format):
{cdm_data}

Additional Context:
- Document ID: {document_id}
- Deal ID: {deal_id}
- Agreement Type: {agreement_type}
- Current Date: {current_date}

Evaluate filing requirements for this credit agreement. Identify all required filings, deadlines, and missing information."""

    prompt = ChatPromptTemplate.from_messages([
        ("system", system_prompt),
        ("user", user_prompt)
    ])
    
    return prompt


def evaluate_filing_requirements(
    credit_agreement: CreditAgreement,
    document_id: Optional[int] = None,
    deal_id: Optional[int] = None,
    agreement_type: str = "facility_agreement",
    max_retries: int = 3
) -> FilingRequirementEvaluation:
    """Evaluate filing requirements for a credit agreement.
    
    Args:
        credit_agreement: CreditAgreement CDM model instance
        document_id: Optional document ID
        deal_id: Optional deal ID
        agreement_type: Type of agreement
        max_retries: Maximum retry attempts
        
    Returns:
        FilingRequirementEvaluation instance
        
    Raises:
        ValueError: If evaluation fails after retries
    """
    prompt = create_filing_requirement_prompt()
    structured_llm = create_filing_requirement_chain()
    evaluation_chain = prompt | structured_llm
    
    from datetime import datetime
    from app.models.cdm import CreditAgreement
    
    # Convert CreditAgreement to dict for prompt
    cdm_data = credit_agreement.model_dump_json(indent=2)
    
    last_error: Exception | None = None
    
    for attempt in range(max_retries):
        try:
            logger.info(f"Filing requirement evaluation attempt {attempt + 1}/{max_retries}...")
            
            result = evaluation_chain.invoke({
                "cdm_data": cdm_data,
                "document_id": str(document_id) if document_id else "N/A",
                "deal_id": str(deal_id) if deal_id else "N/A",
                "agreement_type": agreement_type,
                "current_date": datetime.utcnow().isoformat()
            })
            
            logger.info("Filing requirement evaluation completed successfully")
            return result
            
        except ValidationError as e:
            last_error = e
            logger.warning(f"Validation error on attempt {attempt + 1}: {e}")
            
            if attempt < max_retries - 1:
                logger.info("Retrying with validation feedback...")
                continue
            raise ValueError(f"Filing requirement evaluation failed validation after {max_retries} attempts: {e}") from e
            
        except Exception as e:
            logger.error(f"Unexpected error during filing requirement evaluation: {e}")
            raise ValueError(f"Filing requirement evaluation failed: {e}") from e
```

### 2. Filing Form Data Generation Chain

**File**: `app/chains/filing_form_generation_chain.py`

```python
"""LangChain chain for generating pre-filled form data for manual filings."""

import logging
from typing import Optional, Dict, Any
from pydantic import ValidationError

from langchain_core.language_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate

from app.core.llm_client import get_chat_model
from app.models.filing_forms import FilingFormData
from app.models.cdm import CreditAgreement
from app.models.filing_requirements import FilingRequirement

logger = logging.getLogger(__name__)


def create_filing_form_chain() -> BaseChatModel:
    """Create and configure the LangChain filing form generation chain.
    
    Returns:
        A BaseChatModel instance configured with structured output
        bound to the FilingFormData Pydantic model.
    """
    llm = get_chat_model(temperature=0)
    structured_llm = llm.with_structured_output(FilingFormData)
    return structured_llm


def create_filing_form_prompt() -> ChatPromptTemplate:
    """Create the prompt template for filing form data generation.
    
    Returns:
        A ChatPromptTemplate with system and user message templates.
    """
    system_prompt = """You are an expert Regulatory Filing Specialist. Your task is to generate pre-filled form data for manual regulatory filings based on credit agreement (CDM) data and filing requirements.

Your responsibilities:
1. Extract relevant data from the credit agreement (CDM format)
2. Map CDM fields to jurisdiction-specific form fields
3. Format data according to form field requirements (dates, numbers, text)
4. Identify required vs optional fields
5. Provide helpful instructions for manual submission
6. Generate submission URLs when available

JURISDICTION-SPECIFIC FORM MAPPINGS:

**US SEC 8-K Form**:
- Company Name → "Company Name" (text)
- CIK (if available) → "CIK" (text)
- Agreement Date → "Agreement Date" (date: YYYY-MM-DD)
- Total Commitment → "Total Commitment" (number with currency)
- Borrower Name → "Borrower" (text)
- Lender Names → "Lenders" (text, comma-separated)
- Governing Law → "Governing Law" (text)
- Form Type: "8-K"
- Submission URL: "https://www.sec.gov/edgar/searchedgar/companysearch.html"

**France AMF Declaration**:
- Company Name → "Nom de la société" (text, French)
- SIREN (if available) → "Numéro SIREN" (text)
- Agreement Date → "Date de l'accord" (date: DD/MM/YYYY)
- Total Commitment → "Montant total" (number with currency: EUR)
- Borrower Name → "Emprunteur" (text, French)
- Lender Names → "Prêteurs" (text, comma-separated, French)
- Form Type: "Declaration de prêt"
- Language: "fr"
- Submission URL: "https://www.amf-france.org/..."

**Germany BaFin Registration**:
- Company Name → "Firmenname" (text, German)
- HRB Number (if available) → "HRB-Nummer" (text)
- Agreement Date → "Vertragsdatum" (date: DD.MM.YYYY)
- Total Commitment → "Gesamtbetrag" (number with currency: EUR)
- Borrower Name → "Kreditnehmer" (text, German)
- Lender Names → "Kreditgeber" (text, comma-separated, German)
- Form Type: "Kreditvertrag Anmeldung"
- Language: "de"
- Submission URL: "https://www.bafin.de/..."

CRITICAL RULES:
- Map CDM fields accurately to form fields
- Format dates according to jurisdiction conventions
- Use appropriate language (English for US/UK, French for FR, German for DE)
- Include all required fields from FilingRequirement
- Mark optional fields appropriately
- Provide clear field names and help text
- Include document references for attachments
- Generate accurate submission URLs
- Handle missing data gracefully (use None/null for missing fields)
"""

    user_prompt = """Credit Agreement (CDM Format):
{cdm_data}

Filing Requirement:
- Authority: {authority}
- Jurisdiction: {jurisdiction}
- Form Type: {form_type}
- Required Fields: {required_fields}
- Deadline: {deadline}

Additional Context:
- Document ID: {document_id}
- Deal ID: {deal_id}

Generate pre-filled form data for this filing requirement. Map CDM data to form fields accurately."""

    prompt = ChatPromptTemplate.from_messages([
        ("system", system_prompt),
        ("user", user_prompt)
    ])
    
    return prompt


def generate_filing_form_data(
    credit_agreement: CreditAgreement,
    filing_requirement: FilingRequirement,
    document_id: Optional[int] = None,
    deal_id: Optional[int] = None,
    max_retries: int = 3
) -> FilingFormData:
    """Generate pre-filled form data for a filing requirement.
    
    Args:
        credit_agreement: CreditAgreement CDM model instance
        filing_requirement: FilingRequirement instance
        document_id: Optional document ID
        deal_id: Optional deal ID
        max_retries: Maximum retry attempts
        
    Returns:
        FilingFormData instance
        
    Raises:
        ValueError: If generation fails after retries
    """
    prompt = create_filing_form_prompt()
    structured_llm = create_filing_form_chain()
    generation_chain = prompt | structured_llm
    
    cdm_data = credit_agreement.model_dump_json(indent=2)
    
    last_error: Exception | None = None
    
    for attempt in range(max_retries):
        try:
            logger.info(f"Filing form generation attempt {attempt + 1}/{max_retries}...")
            
            result = generation_chain.invoke({
                "cdm_data": cdm_data,
                "authority": filing_requirement.authority,
                "jurisdiction": filing_requirement.jurisdiction,
                "form_type": filing_requirement.form_type or "N/A",
                "required_fields": ", ".join(filing_requirement.required_fields),
                "deadline": filing_requirement.deadline.isoformat(),
                "document_id": str(document_id) if document_id else "N/A",
                "deal_id": str(deal_id) if deal_id else "N/A"
            })
            
            logger.info("Filing form generation completed successfully")
            return result
            
        except ValidationError as e:
            last_error = e
            logger.warning(f"Validation error on attempt {attempt + 1}: {e}")
            
            if attempt < max_retries - 1:
                logger.info("Retrying with validation feedback...")
                continue
            raise ValueError(f"Filing form generation failed validation after {max_retries} attempts: {e}") from e
            
        except Exception as e:
            logger.error(f"Unexpected error during filing form generation: {e}")
            raise ValueError(f"Filing form generation failed: {e}") from e
```

### 3. Signature Request Generation Chain

**File**: `app/chains/signature_request_chain.py`

```python
"""LangChain chain for generating signature request configurations."""

import logging
from typing import Optional, List, Dict, Any
from pydantic import ValidationError

from langchain_core.language_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate

from app.core.llm_client import get_chat_model
from app.models.signature_requests import SignatureRequestGeneration
from app.models.cdm import CreditAgreement

logger = logging.getLogger(__name__)


def create_signature_request_chain() -> BaseChatModel:
    """Create and configure the LangChain signature request generation chain.
    
    Returns:
        A BaseChatModel instance configured with structured output
        bound to the SignatureRequestGeneration Pydantic model.
    """
    llm = get_chat_model(temperature=0)
    structured_llm = llm.with_structured_output(SignatureRequestGeneration)
    return structured_llm


def create_signature_request_prompt() -> ChatPromptTemplate:
    """Create the prompt template for signature request generation.
    
    Returns:
        A ChatPromptTemplate with system and user message templates.
    """
    system_prompt = """You are an expert Document Signing Specialist. Your task is to analyze a credit agreement (CDM format) and determine:
1. Who needs to sign the document (signers)
2. Signing order (parallel vs sequential)
3. Appropriate expiration period
4. Reminder schedule

SIGNER IDENTIFICATION RULES:

1. **Required Signers** (always required):
   - Borrower: The primary borrower party (role: "Borrower")
   - Administrative Agent: The administrative agent (role: "Administrative Agent")
   - Lenders: All parties with role "Lender" (if syndicated)

2. **Optional Signers** (if present in agreement):
   - Guarantors: Parties with role "Guarantor"
   - Security Trustee: Party with role "Security Trustee"
   - Facility Agent: Party with role "Facility Agent"

3. **Signing Order**:
   - **Parallel**: All signers can sign simultaneously (default for most agreements)
   - **Sequential**: Signers must sign in order (e.g., Borrower first, then Lenders)
   - Use sequential only if explicitly required by agreement terms

4. **Expiration Period**:
   - Standard agreements: 30 days
   - Time-sensitive deals: 14 days
   - Complex multi-party agreements: 45 days

5. **Reminder Schedule**:
   - Standard: Reminders at 7, 3, and 1 days before expiration
   - Time-sensitive: Reminders at 3 and 1 days before expiration

EXTRACTION RULES:
- Extract signer names from party.name field
- Extract signer emails from party.contact.email (if available) or use placeholder format: "{name.lower().replace(' ', '.')}@example.com"
- Extract signer roles from party.roles list
- Determine signing order from agreement structure (typically parallel unless specified)
- Set appropriate expiration based on agreement urgency

CRITICAL RULES:
- Only include parties that actually need to sign (Borrower, Lenders, Agents)
- Do not include parties that are not signatories (e.g., observers, advisors)
- Use parallel signing unless agreement explicitly requires sequential
- Set reasonable expiration periods (14-45 days)
- Include all required signers (Borrower, Administrative Agent, at least one Lender)
- Mark all identified signers as required=True
- Generate appropriate email addresses if not available in CDM data
"""

    user_prompt = """Credit Agreement (CDM Format):
{cdm_data}

Additional Context:
- Document Type: {document_type}
- Agreement Date: {agreement_date}
- Urgency: {urgency}
- Custom Message (optional): {custom_message}

Analyze this credit agreement and generate a signature request configuration. Identify all required signers, determine signing workflow, and set appropriate expiration and reminders."""

    prompt = ChatPromptTemplate.from_messages([
        ("system", system_prompt),
        ("user", user_prompt)
    ])
    
    return prompt


def generate_signature_request(
    credit_agreement: CreditAgreement,
    document_type: str = "facility_agreement",
    urgency: str = "standard",
    custom_message: Optional[str] = None,
    max_retries: int = 3
) -> SignatureRequestGeneration:
    """Generate signature request configuration from credit agreement.
    
    Args:
        credit_agreement: CreditAgreement CDM model instance
        document_type: Type of document
        urgency: Urgency level ("standard", "time_sensitive", "complex")
        custom_message: Optional custom message for signers
        max_retries: Maximum retry attempts
        
    Returns:
        SignatureRequestGeneration instance
        
    Raises:
        ValueError: If generation fails after retries
    """
    prompt = create_signature_request_prompt()
    structured_llm = create_signature_request_chain()
    generation_chain = prompt | structured_llm
    
    cdm_data = credit_agreement.model_dump_json(indent=2)
    
    # Determine expiration and reminders based on urgency
    urgency_config = {
        "standard": {"expiration": 30, "reminders": [7, 3, 1]},
        "time_sensitive": {"expiration": 14, "reminders": [3, 1]},
        "complex": {"expiration": 45, "reminders": [14, 7, 3, 1]}
    }
    config = urgency_config.get(urgency, urgency_config["standard"])
    
    last_error: Exception | None = None
    
    for attempt in range(max_retries):
        try:
            logger.info(f"Signature request generation attempt {attempt + 1}/{max_retries}...")
            
            result = generation_chain.invoke({
                "cdm_data": cdm_data,
                "document_type": document_type,
                "agreement_date": credit_agreement.agreement_date.isoformat() if credit_agreement.agreement_date else "N/A",
                "urgency": urgency,
                "custom_message": custom_message or "N/A"
            })
            
            # Override expiration and reminders based on urgency
            result.expiration_days = config["expiration"]
            result.reminder_days = config["reminders"]
            result.message = custom_message or result.message
            
            logger.info("Signature request generation completed successfully")
            return result
            
        except ValidationError as e:
            last_error = e
            logger.warning(f"Validation error on attempt {attempt + 1}: {e}")
            
            if attempt < max_retries - 1:
                logger.info("Retrying with validation feedback...")
                continue
            raise ValueError(f"Signature request generation failed validation after {max_retries} attempts: {e}") from e
            
        except Exception as e:
            logger.error(f"Unexpected error during signature request generation: {e}")
            raise ValueError(f"Signature request generation failed: {e}") from e
```

---

## Prompt Templates

### Prompt Template Organization

Following the existing pattern in `app/prompts/templates/`, create:

**File**: `app/prompts/templates/filing.py`

```python
"""Prompt templates for filing-related AI operations."""

from langchain_core.prompts import ChatPromptTemplate

# Filing requirement evaluation prompt (detailed version for policy engine integration)
FILING_REQUIREMENT_EVALUATION_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are an expert Regulatory Compliance Analyst..."""),  # Full system prompt from chain
    ("user", "Credit Agreement (CDM): {cdm_data}\n\nEvaluate filing requirements.")
])

# Filing form generation prompt (detailed version)
FILING_FORM_GENERATION_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are an expert Regulatory Filing Specialist..."""),  # Full system prompt from chain
    ("user", "Generate form data for: {filing_requirement}")
])

# Export prompts dictionary
FILING_PROMPTS = {
    "filing_requirement_evaluation": FILING_REQUIREMENT_EVALUATION_PROMPT,
    "filing_form_generation": FILING_FORM_GENERATION_PROMPT,
}
```

**File**: `app/prompts/templates/signature.py`

```python
"""Prompt templates for signature-related AI operations."""

from langchain_core.prompts import ChatPromptTemplate

# Signature request generation prompt
SIGNATURE_REQUEST_GENERATION_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are an expert Document Signing Specialist..."""),  # Full system prompt from chain
    ("user", "Generate signature request for: {cdm_data}")
])

# Export prompts dictionary
SIGNATURE_PROMPTS = {
    "signature_request_generation": SIGNATURE_REQUEST_GENERATION_PROMPT,
}
```

---

## Integration Patterns

### 1. Service Layer Integration

**File**: `app/services/filing_service.py` (add to existing)

```python
from app.chains.filing_requirement_chain import evaluate_filing_requirements
from app.chains.filing_form_generation_chain import generate_filing_form_data

class FilingService:
    def determine_filing_requirements(
        self,
        document_id: int,
        agreement_type: str,
        jurisdiction: str,
        deal_id: Optional[int] = None
    ) -> List[FilingRequirement]:
        """Determine filing requirements using AI chain."""
        # Load CDM data
        document = self.db.query(Document).filter(Document.id == document_id).first()
        credit_agreement = CreditAgreement(**document.source_cdm_data)
        
        # Use LangChain chain for evaluation
        evaluation = evaluate_filing_requirements(
            credit_agreement=credit_agreement,
            document_id=document_id,
            deal_id=deal_id,
            agreement_type=agreement_type
        )
        
        return evaluation.required_filings
    
    def prepare_manual_filing(
        self,
        document_id: int,
        filing_requirement: FilingRequirement
    ) -> DocumentFiling:
        """Prepare manual filing with AI-generated form data."""
        # Load CDM data
        document = self.db.query(Document).filter(Document.id == document_id).first()
        credit_agreement = CreditAgreement(**document.source_cdm_data)
        
        # Use LangChain chain for form generation
        form_data = generate_filing_form_data(
            credit_agreement=credit_agreement,
            filing_requirement=filing_requirement,
            document_id=document_id,
            deal_id=document.deal_id
        )
        
        # Create DocumentFiling record with pre-filled form data
        filing = DocumentFiling(
            document_id=document_id,
            filing_payload=form_data.model_dump(),
            # ... other fields
        )
        
        return filing
```

### 2. Signature Service Integration

**File**: `app/services/signature_service.py` (add to existing)

```python
from app.chains.signature_request_chain import generate_signature_request

class SignatureService:
    def request_signature(
        self,
        document_id: int,
        signers: Optional[List[Dict[str, str]]] = None,
        auto_detect_signers: bool = True,
        urgency: str = "standard"
    ) -> DocumentSignature:
        """Request signatures with optional AI-assisted signer detection."""
        # Load CDM data
        document = self.db.query(Document).filter(Document.id == document_id).first()
        credit_agreement = CreditAgreement(**document.source_cdm_data)
        
        # Use AI chain to detect signers if not provided
        if auto_detect_signers and not signers:
            signature_config = generate_signature_request(
                credit_agreement=credit_agreement,
                document_type="facility_agreement",
                urgency=urgency
            )
            signers = [
                {
                    "name": signer.name,
                    "email": signer.email,
                    "role": signer.role
                }
                for signer in signature_config.signers
            ]
        
        # Continue with DigiSigner API integration...
        # ...
```

---

## Configuration

### Environment Variables

Add to `app/core/config.py`:

```python
class Settings(BaseSettings):
    # ... existing settings ...
    
    # LangChain Configuration for Filing/Signature
    FILING_CHAIN_TEMPERATURE: float = Field(default=0.0, description="Temperature for filing chains")
    SIGNATURE_CHAIN_TEMPERATURE: float = Field(default=0.0, description="Temperature for signature chains")
    FILING_CHAIN_MAX_RETRIES: int = Field(default=3, description="Max retries for filing chains")
    SIGNATURE_CHAIN_MAX_RETRIES: int = Field(default=3, description="Max retries for signature chains")
```

### Chain Configuration

Chains use `get_chat_model()` which respects:
- `LLM_PROVIDER` (openai, vllm, huggingface)
- `LLM_MODEL` (model name)
- `LLM_TEMPERATURE` (overridden by chain-specific temperature)

---

## Testing

### Unit Tests

**File**: `tests/test_filing_requirement_chain.py`

```python
import pytest
from app.chains.filing_requirement_chain import evaluate_filing_requirements
from app.models.cdm import CreditAgreement

def test_evaluate_filing_requirements_us():
    """Test filing requirement evaluation for US agreement."""
    agreement = CreditAgreement(...)  # US-based agreement
    
    result = evaluate_filing_requirements(
        credit_agreement=agreement,
        agreement_type="facility_agreement"
    )
    
    assert len(result.required_filings) > 0
    assert any(f.jurisdiction == "US" for f in result.required_filings)
    assert any(f.authority == "SEC" for f in result.required_filings)
```

**File**: `tests/test_filing_form_generation_chain.py`

```python
import pytest
from app.chains.filing_form_generation_chain import generate_filing_form_data

def test_generate_filing_form_data_us():
    """Test form data generation for US SEC filing."""
    agreement = CreditAgreement(...)
    requirement = FilingRequirement(
        authority="SEC",
        jurisdiction="US",
        form_type="8-K",
        # ...
    )
    
    result = generate_filing_form_data(
        credit_agreement=agreement,
        filing_requirement=requirement
    )
    
    assert result.jurisdiction == "US"
    assert result.form_type == "8-K"
    assert len(result.fields) > 0
```

---

## Summary

This LangChain integration provides:

1. **AI-Assisted Filing Requirement Evaluation**: Automatically determines required filings from CDM data
2. **Pre-filled Form Generation**: Generates jurisdiction-specific form data for manual filings
3. **Signature Request Generation**: Automatically identifies signers and configures signing workflows

All chains follow existing CreditNexus patterns:
- Use `get_chat_model()` for LLM abstraction
- Use structured outputs with Pydantic models
- Include retry logic with validation feedback
- Follow prompt template organization
- Integrate with service layer

**Next Steps**:
1. Create Pydantic models in `app/models/`
2. Implement chains in `app/chains/`
3. Create prompt templates in `app/prompts/templates/`
4. Integrate with `FilingService` and `SignatureService`
5. Add unit tests
