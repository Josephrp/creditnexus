# CreditNexus Filing & Digital Signature Implementation Plan

## Executive Summary

This document provides a comprehensive implementation plan for integrating automated filing and digital signature functionality into CreditNexus. **Key Design Decisions:**

1. ✅ **DigiSigner API** selected for digital signatures (free tier available)
2. ✅ **Companies House API** for UK filings (free API)
3. ✅ **Manual Filing UI** for US, France, and Germany (no third-party APIs)
4. ✅ **UI-based filing workflow** with pre-filled forms and tracking

It includes detailed projects, activities, file-level tasks, and line-level subtasks following the repository's established patterns.

**Priority**: High  
**Estimated Timeline**: 10-12 weeks  
**Complexity**: High

**Note**: See `FILING_SIGNATURE_IMPLEMENTATION_PLAN_ENHANCED.md` for the most detailed and up-to-date implementation plan with enhanced subtasks.

---

## Table of Contents

1. [Current State Assessment](#current-state-assessment)
2. [Architecture Overview](#architecture-overview)
3. [Implementation Projects](#implementation-projects)
4. [Database Schema Changes](#database-schema-changes)
5. [API Integration Details](#api-integration-details)
6. [Testing Strategy](#testing-strategy)
7. [Deployment Plan](#deployment-plan)

---

## Current State Assessment

### ✅ What We Have

1. **Document Generation System**
   - `DocumentGenerationService` for LMA template generation
   - `GeneratedDocument` model for tracking generated documents
   - CDM data extraction and validation

2. **Policy Engine**
   - `PolicyService` for policy evaluation
   - Policy rule loading from YAML files
   - CDM-compliant policy decisions

3. **Workflow System**
   - `Workflow` model for document approval
   - Workflow state transitions (DRAFT → UNDER_REVIEW → APPROVED → PUBLISHED)
   - Event triggers on state changes

4. **Verifier Patterns**
   - `app/agents/verifier.py` for geospatial verification
   - Async verification functions
   - Structured verification results

5. **Deal Management**
   - `Deal` model with lifecycle management
   - `DealService` for deal operations
   - Deal-document relationships

### ❌ What's Missing

1. **Digital Signature Integration**
   - No signature provider integration
   - No signature request/status tracking
   - No signed document storage

2. **Filing System Integration**
   - No filing requirement evaluation
   - No filing submission workflows
   - No deadline tracking

3. **Jurisdiction-Specific Logic**
   - No jurisdiction-based filing rules
   - No multi-language support
   - No country-specific API integrations

4. **Compliance Monitoring**
   - No automated compliance checking
   - No deadline alerts
   - No filing status tracking

---

## Architecture Overview

### System Components

```
┌─────────────────────────────────────────────────────────────┐
│                    Document Generation                       │
│                  (Existing System)                           │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              Filing Requirement Evaluation                   │
│                                                              │
│  - PolicyService.evaluate_filing_requirements()            │
│  - Filing compliance rules (YAML)                          │
│  - Jurisdiction-based logic                                │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              Digital Signature Workflow                      │
│                                                              │
│  - SignatureService.request_signature()                     │
│  - Sign.Plus API integration                               │
│  - Signature status tracking                                │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              Filing Submission Workflow                      │
│                                                              │
│  - FilingService.file_document()                            │
│  - Companies House API (UK)                                 │
│  - EDGAR Online API (US)                                    │
│  - Manual filing queue (FR, DE)                            │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              Compliance Monitoring                           │
│                                                              │
│  - Deadline tracking                                        │
│  - Compliance verifiers                                     │
│  - Alert system                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Implementation Projects

### PROJECT 1: Database Schema Extensions

**Priority**: P0 (Critical)  
**Estimated Time**: 3 days  
**Dependencies**: None

#### Activity 1.1: Create DocumentSignature Model

**File**: `app/db/models.py`

**Line-Level Subtasks**:

1. Add `DocumentSignature` class after `GeneratedDocument` class (around line 810):
   ```python
   class DocumentSignature(Base):
       """Tracks digital signatures for documents."""
       
       __tablename__ = "document_signatures"
       
       id = Column(Integer, primary_key=True, autoincrement=True)
       document_id = Column(Integer, ForeignKey("documents.id"), nullable=False, index=True)
       generated_document_id = Column(Integer, ForeignKey("generated_documents.id"), nullable=True, index=True)
       
       # Signature provider info
       signature_provider = Column(String(50), nullable=False)  # "signplus", "digisigner", etc.
       signature_request_id = Column(String(255), nullable=False, unique=True, index=True)
       signature_status = Column(String(50), nullable=False, index=True)  # "pending", "completed", "declined", "expired"
       
       # Signers
       signers = Column(JSONB, nullable=False)  # [{"name": "...", "email": "...", "role": "...", "signed_at": "..."}]
       
       # Signature metadata
       signature_provider_data = Column(JSONB, nullable=True)  # Provider-specific response data
       signed_document_url = Column(Text, nullable=True)  # URL to signed document
       signed_document_path = Column(Text, nullable=True)  # Local path if downloaded
       
       # Timestamps
       requested_at = Column(DateTime, default=datetime.utcnow, nullable=False)
       completed_at = Column(DateTime, nullable=True)
       expires_at = Column(DateTime, nullable=True)
       
       # Relationships
       document = relationship("Document", back_populates="signatures")
       generated_document = relationship("GeneratedDocument", back_populates="signatures")
       
       def to_dict(self):
           """Convert model to dictionary."""
           return {
               "id": self.id,
               "document_id": self.document_id,
               "generated_document_id": self.generated_document_id,
               "signature_provider": self.signature_provider,
               "signature_request_id": self.signature_request_id,
               "signature_status": self.signature_status,
               "signers": self.signers,
               "signature_provider_data": self.signature_provider_data,
               "signed_document_url": self.signed_document_url,
               "signed_document_path": self.signed_document_path,
               "requested_at": self.requested_at.isoformat() if self.requested_at else None,
               "completed_at": self.completed_at.isoformat() if self.completed_at else None,
               "expires_at": self.expires_at.isoformat() if self.expires_at else None,
           }
   ```

2. Add `signatures` relationship to `Document` class (around line 267):
   ```python
   signatures = relationship("DocumentSignature", back_populates="document", cascade="all, delete-orphan")
   ```

3. Add `signatures` relationship to `GeneratedDocument` class (around line 792):
   ```python
   signatures = relationship("DocumentSignature", back_populates="generated_document", cascade="all, delete-orphan")
   ```

#### Activity 1.2: Create DocumentFiling Model

**File**: `app/db/models.py`

**Line-Level Subtasks**:

1. Add `DocumentFiling` class after `DocumentSignature` class:
   ```python
   class DocumentFiling(Base):
       """Tracks regulatory filings for documents."""
       
       __tablename__ = "document_filings"
       
       id = Column(Integer, primary_key=True, autoincrement=True)
       document_id = Column(Integer, ForeignKey("documents.id"), nullable=False, index=True)
       generated_document_id = Column(Integer, ForeignKey("generated_documents.id"), nullable=True, index=True)
       deal_id = Column(Integer, ForeignKey("deals.id"), nullable=True, index=True)
       
       # Filing metadata
       agreement_type = Column(String(100), nullable=False, index=True)  # "facility_agreement", "disclosure", etc.
       jurisdiction = Column(String(50), nullable=False, index=True)  # "US", "UK", "FR", "DE", etc.
       filing_authority = Column(String(255), nullable=False)  # "SEC", "Companies House", "AMF", etc.
       
       # Filing system info
       filing_system = Column(String(50), nullable=False)  # "edgar", "companies_house", "manual", etc.
       filing_reference = Column(String(255), nullable=True, unique=True, index=True)  # External filing ID
       filing_status = Column(String(50), nullable=False, index=True)  # "pending", "submitted", "accepted", "rejected"
       
       # Filing payload
       filing_payload = Column(JSONB, nullable=True)  # Data sent to filing system
       filing_response = Column(JSONB, nullable=True)  # Response from filing system
       
       # Filing URLs
       filing_url = Column(Text, nullable=True)  # URL to view filing
       confirmation_url = Column(Text, nullable=True)  # Confirmation/receipt URL
       
       # Error handling
       error_message = Column(Text, nullable=True)
       retry_count = Column(Integer, default=0, nullable=False)
       
       # Deadline tracking
       deadline = Column(DateTime, nullable=True, index=True)
       
       # Timestamps
       filed_at = Column(DateTime, nullable=True)
       created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
       updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
       
       # Relationships
       document = relationship("Document", back_populates="filings")
       generated_document = relationship("GeneratedDocument", back_populates="filings")
       deal = relationship("Deal", back_populates="filings")
       
       def to_dict(self):
           """Convert model to dictionary."""
           return {
               "id": self.id,
               "document_id": self.document_id,
               "generated_document_id": self.generated_document_id,
               "deal_id": self.deal_id,
               "agreement_type": self.agreement_type,
               "jurisdiction": self.jurisdiction,
               "filing_authority": self.filing_authority,
               "filing_system": self.filing_system,
               "filing_reference": self.filing_reference,
               "filing_status": self.filing_status,
               "filing_payload": self.filing_payload,
               "filing_response": self.filing_response,
               "filing_url": self.filing_url,
               "confirmation_url": self.confirmation_url,
               "error_message": self.error_message,
               "retry_count": self.retry_count,
               "deadline": self.deadline.isoformat() if self.deadline else None,
               "filed_at": self.filed_at.isoformat() if self.filed_at else None,
               "created_at": self.created_at.isoformat() if self.created_at else None,
               "updated_at": self.updated_at.isoformat() if self.updated_at else None,
           }
   ```

2. Add `filings` relationship to `Document` class (around line 267):
   ```python
   filings = relationship("DocumentFiling", back_populates="document", cascade="all, delete-orphan")
   ```

3. Add `filings` relationship to `GeneratedDocument` class (around line 792):
   ```python
   filings = relationship("DocumentFiling", back_populates="generated_document", cascade="all, delete-orphan")
   ```

4. Add `filings` relationship to `Deal` class (around line 1152):
   ```python
   filings = relationship("DocumentFiling", back_populates="deal", cascade="all, delete-orphan")
   ```

#### Activity 1.3: Create Alembic Migration

**File**: `alembic/versions/XXXX_add_filing_signature_tables.py`

**Line-Level Subtasks**:

1. Create migration file with upgrade() function:
   ```python
   def upgrade() -> None:
       # Create document_signatures table
       op.create_table(
           'document_signatures',
           sa.Column('id', sa.Integer(), nullable=False),
           sa.Column('document_id', sa.Integer(), nullable=False),
           sa.Column('generated_document_id', sa.Integer(), nullable=True),
           sa.Column('signature_provider', sa.String(length=50), nullable=False),
           sa.Column('signature_request_id', sa.String(length=255), nullable=False),
           sa.Column('signature_status', sa.String(length=50), nullable=False),
           sa.Column('signers', sa.JSON(), nullable=False),
           sa.Column('signature_provider_data', sa.JSON(), nullable=True),
           sa.Column('signed_document_url', sa.Text(), nullable=True),
           sa.Column('signed_document_path', sa.Text(), nullable=True),
           sa.Column('requested_at', sa.DateTime(), nullable=False),
           sa.Column('completed_at', sa.DateTime(), nullable=True),
           sa.Column('expires_at', sa.DateTime(), nullable=True),
           sa.ForeignKeyConstraint(['document_id'], ['documents.id'], ),
           sa.ForeignKeyConstraint(['generated_document_id'], ['generated_documents.id'], ),
           sa.PrimaryKeyConstraint('id'),
           sa.UniqueConstraint('signature_request_id')
       )
       op.create_index(op.f('ix_document_signatures_document_id'), 'document_signatures', ['document_id'], unique=False)
       op.create_index(op.f('ix_document_signatures_generated_document_id'), 'document_signatures', ['generated_document_id'], unique=False)
       op.create_index(op.f('ix_document_signatures_signature_request_id'), 'document_signatures', ['signature_request_id'], unique=True)
       op.create_index(op.f('ix_document_signatures_signature_status'), 'document_signatures', ['signature_status'], unique=False)
       
       # Create document_filings table
       op.create_table(
           'document_filings',
           sa.Column('id', sa.Integer(), nullable=False),
           sa.Column('document_id', sa.Integer(), nullable=False),
           sa.Column('generated_document_id', sa.Integer(), nullable=True),
           sa.Column('deal_id', sa.Integer(), nullable=True),
           sa.Column('agreement_type', sa.String(length=100), nullable=False),
           sa.Column('jurisdiction', sa.String(length=50), nullable=False),
           sa.Column('filing_authority', sa.String(length=255), nullable=False),
           sa.Column('filing_system', sa.String(length=50), nullable=False),
           sa.Column('filing_reference', sa.String(length=255), nullable=True),
           sa.Column('filing_status', sa.String(length=50), nullable=False),
           sa.Column('filing_payload', sa.JSON(), nullable=True),
           sa.Column('filing_response', sa.JSON(), nullable=True),
           sa.Column('filing_url', sa.Text(), nullable=True),
           sa.Column('confirmation_url', sa.Text(), nullable=True),
           sa.Column('error_message', sa.Text(), nullable=True),
           sa.Column('retry_count', sa.Integer(), nullable=False),
           sa.Column('deadline', sa.DateTime(), nullable=True),
           sa.Column('filed_at', sa.DateTime(), nullable=True),
           sa.Column('created_at', sa.DateTime(), nullable=False),
           sa.Column('updated_at', sa.DateTime(), nullable=False),
           sa.ForeignKeyConstraint(['deal_id'], ['deals.id'], ),
           sa.ForeignKeyConstraint(['document_id'], ['documents.id'], ),
           sa.ForeignKeyConstraint(['generated_document_id'], ['generated_documents.id'], ),
           sa.PrimaryKeyConstraint('id'),
           sa.UniqueConstraint('filing_reference')
       )
       op.create_index(op.f('ix_document_filings_agreement_type'), 'document_filings', ['agreement_type'], unique=False)
       op.create_index(op.f('ix_document_filings_deadline'), 'document_filings', ['deadline'], unique=False)
       op.create_index(op.f('ix_document_filings_deal_id'), 'document_filings', ['deal_id'], unique=False)
       op.create_index(op.f('ix_document_filings_document_id'), 'document_filings', ['document_id'], unique=False)
       op.create_index(op.f('ix_document_filings_generated_document_id'), 'document_filings', ['generated_document_id'], unique=False)
       op.create_index(op.f('ix_document_filings_jurisdiction'), 'document_filings', ['jurisdiction'], unique=False)
       op.create_index(op.f('ix_document_filings_filing_status'), 'document_filings', ['filing_status'], unique=False)
   
   def downgrade() -> None:
       op.drop_index(op.f('ix_document_filings_filing_status'), table_name='document_filings')
       op.drop_index(op.f('ix_document_filings_jurisdiction'), table_name='document_filings')
       op.drop_index(op.f('ix_document_filings_generated_document_id'), table_name='document_filings')
       op.drop_index(op.f('ix_document_filings_document_id'), table_name='document_filings')
       op.drop_index(op.f('ix_document_filings_deal_id'), table_name='document_filings')
       op.drop_index(op.f('ix_document_filings_deadline'), table_name='document_filings')
       op.drop_index(op.f('ix_document_filings_agreement_type'), table_name='document_filings')
       op.drop_table('document_filings')
       
       op.drop_index(op.f('ix_document_signatures_signature_status'), table_name='document_signatures')
       op.drop_index(op.f('ix_document_signatures_signature_request_id'), table_name='document_signatures')
       op.drop_index(op.f('ix_document_signatures_generated_document_id'), table_name='document_signatures')
       op.drop_index(op.f('ix_document_signatures_document_id'), table_name='document_signatures')
       op.drop_table('document_signatures')
   ```

---

### PROJECT 2: Policy Engine Extensions

**Priority**: P0 (Critical)  
**Estimated Time**: 5 days  
**Dependencies**: PROJECT 1

#### Activity 2.1: Extend PolicyService with Filing Methods

**File**: `app/services/policy_service.py`

**Line-Level Subtasks**:

1. Add imports at top of file (around line 20):
   ```python
   from app.db.models import DocumentFiling, DocumentSignature
   from dataclasses import dataclass
   from typing import List, Optional
   ```

2. Add dataclasses after `PolicyDecision` class (around line 35):
   ```python
   @dataclass
   class FilingRequirement:
       """Represents a filing requirement for an agreement."""
       authority: str
       filing_system: str
       deadline: datetime
       required_fields: List[str]
       api_available: bool
       api_endpoint: Optional[str] = None
       penalty: Optional[str] = None
       language_requirement: Optional[str] = None
   
   @dataclass
   class DeadlineAlert:
       """Represents a deadline alert for a filing."""
       filing_id: int
       document_id: Optional[int]
       deal_id: Optional[int]
       authority: str
       deadline: datetime
       days_remaining: int
       urgency: str  # "critical", "high", "medium", "low"
       penalty: Optional[str] = None
   
   @dataclass
   class FilingRequirementDecision:
       """Result of filing requirement evaluation."""
       required_filings: List[FilingRequirement]
       deadline_alerts: List[DeadlineAlert]
       compliance_status: str  # "compliant", "non_compliant", "pending"
       missing_fields: List[str]
       trace_id: str
       metadata: Dict[str, Any]
   ```

3. Add `evaluate_filing_requirements()` method to `PolicyService` class (after `evaluate_terms_change()` method, around line 200):
   ```python
   def evaluate_filing_requirements(
       self,
       credit_agreement: CreditAgreement,
       document_id: Optional[int] = None,
       deal_id: Optional[int] = None
   ) -> FilingRequirementDecision:
       """Evaluate filing requirements for a credit agreement."""
       # Implementation from POLICY_ENGINE_FILING_EXTENSIONS.md
       pass
   ```

4. Add `check_filing_deadlines()` method to `PolicyService` class (after `evaluate_filing_requirements()`):
   ```python
   def check_filing_deadlines(
       self,
       deal_id: Optional[int] = None,
       document_id: Optional[int] = None,
       days_ahead: int = 7
   ) -> List[DeadlineAlert]:
       """Check for approaching filing deadlines."""
       # Implementation from POLICY_ENGINE_FILING_EXTENSIONS.md
       pass
   ```

5. Add helper methods at end of `PolicyService` class:
   ```python
   def _extract_jurisdiction(self, governing_law: Optional[str]) -> str:
       """Extract jurisdiction from governing law."""
       # Map governing_law to jurisdiction codes
       jurisdiction_map = {
           "NY": "US",
           "Delaware": "US",
           "California": "US",
           "English": "UK",
           "UK": "UK",
           "French": "FR",
           "FR": "FR",
           "German": "DE",
           "DE": "DE"
       }
       return jurisdiction_map.get(governing_law, "US")  # Default to US
   
   def _determine_agreement_type(self, credit_agreement: CreditAgreement) -> str:
       """Determine agreement type from CDM data."""
       # Logic to determine agreement type
       # For now, default to "facility_agreement"
       return "facility_agreement"
   
   def _load_compliance_rules(self, jurisdiction: str) -> List[Dict[str, Any]]:
       """Load compliance rules for a jurisdiction."""
       from app.core.policy_config import PolicyConfigLoader
       from pathlib import Path
       
       loader = PolicyConfigLoader()
       
       # Load general filing rules
       general_rules_path = Path("app/policies/filing_compliance.yaml")
       if general_rules_path.exists():
           rules = loader.load_rules_from_file(str(general_rules_path))
           # Filter by jurisdiction
           return [r for r in rules if self._rule_applies_to_jurisdiction(r, jurisdiction)]
       
       return []
   
   def _rule_applies_to_jurisdiction(self, rule: Dict[str, Any], jurisdiction: str) -> bool:
       """Check if a rule applies to a jurisdiction."""
       when = rule.get("when", {})
       all_conditions = when.get("all", [])
       
       for condition in all_conditions:
           if condition.get("field") == "jurisdiction" and condition.get("value") == jurisdiction:
               return True
       
       return False
   
   def _evaluate_triggers(self, triggers: List[Dict[str, Any]], credit_agreement: CreditAgreement) -> bool:
       """Evaluate trigger conditions for a filing requirement."""
       # Implementation of trigger evaluation logic
       # This would evaluate conditions like "total_commitment > 1000000"
       return True  # Placeholder
   
   def _calculate_deadline(self, deadline_rule: str, agreement_date: Optional[date]) -> Optional[datetime]:
       """Calculate filing deadline from rule and agreement date."""
       if not agreement_date:
           return None
       
       # Parse deadline rule (e.g., "4 business days from agreement_date")
       # For now, simple implementation
       from datetime import timedelta
       if "4 business days" in deadline_rule:
           return datetime.combine(agreement_date, datetime.min.time()) + timedelta(days=4)
       
       return None
   
   def _check_required_fields(self, required_filings: List[FilingRequirement], credit_agreement: CreditAgreement) -> List[str]:
       """Check if all required fields are present in credit agreement."""
       missing = []
       
       for filing_req in required_filings:
           for field in filing_req.required_fields:
               if not self._field_exists(credit_agreement, field):
                   missing.append(field)
       
       return missing
   
   def _field_exists(self, credit_agreement: CreditAgreement, field: str) -> bool:
       """Check if a field exists in credit agreement."""
       # Simple field existence check
       # Would need more sophisticated logic for nested fields
       return hasattr(credit_agreement, field) and getattr(credit_agreement, field, None) is not None
   
   def _generate_deadline_alerts(self, required_filings: List[FilingRequirement]) -> List[DeadlineAlert]:
       """Generate deadline alerts for required filings."""
       alerts = []
       
       for req in required_filings:
           if req.deadline:
               days_remaining = (req.deadline - datetime.utcnow()).days
               
               if days_remaining <= 7:
                   urgency = "critical" if days_remaining <= 1 else "high" if days_remaining <= 3 else "medium"
                   alerts.append(DeadlineAlert(
                       filing_id=0,  # Will be set when filing is created
                       document_id=None,
                       deal_id=None,
                       authority=req.authority,
                       deadline=req.deadline,
                       days_remaining=days_remaining,
                       urgency=urgency,
                       penalty=req.penalty
                   ))
       
       return alerts
   ```

#### Activity 2.2: Create Filing Compliance Policy Rules

**File**: `app/policies/filing_compliance.yaml`

**Line-Level Subtasks**:

1. Create new file with US filing rules:
   ```yaml
   - name: us_sec_material_agreement_filing
     when:
       all:
         - field: jurisdiction
           op: equals
           value: "US"
         - field: agreement_type
           op: in
           value: ["facility_agreement", "loan_agreement", "credit_agreement"]
         - any:
             - field: total_commitment
               op: greater_than
               value: "total_assets * 0.10"
             - field: total_commitment
               op: greater_than
               value: 1000000
             - field: material_restrictions
               op: equals
               value: true
     action: require_filing
     filing_authority: "SEC"
     filing_system: "edgar"
     filing_form: "8-K"
     deadline: "4 business days from agreement_date"
     priority: 100
     description: "SEC 8-K filing required for material credit agreements"
   
   - name: uk_companies_house_charge_filing
     when:
       all:
         - field: jurisdiction
           op: equals
           value: "UK"
         - field: security_type
           op: in
           value: ["charge", "mortgage", "security_interest"]
         - field: agreement_type
           op: in
           value: ["facility_agreement", "security_agreement", "charge_agreement"]
     action: require_filing
     filing_authority: "Companies House"
     filing_system: "companies_house_api"
     filing_form: "MR01"
     deadline: "21 days from charge_creation_date"
     priority: 100
     description: "Companies House charge registration required within 21 days"
     api_available: true
     api_endpoint: "POST /company/{company_number}/charges"
   ```

2. Add France and Germany rules (similar structure)

---

### PROJECT 3: Digital Signature Service (DigiSigner Integration)

**Priority**: P0 (Critical)  
**Estimated Time**: 5 days  
**Dependencies**: PROJECT 1

#### Activity 3.1: Create SignatureService with DigiSigner Integration

**File**: `app/services/signature_service.py`

**Line-Level Subtasks**:

1. Create new file with SignatureService class:
   ```python
   """
   Digital Signature Service for CreditNexus.
   
   Integrates with DigiSigner API for document signing workflows.
   """
   
   import logging
   import requests
   from typing import List, Dict, Any, Optional
   from datetime import datetime, timedelta
   from sqlalchemy.orm import Session
   from pathlib import Path
   
   from app.db.models import Document, DocumentSignature, GeneratedDocument
   from app.core.config import settings
   from app.services.file_storage_service import FileStorageService
   
   logger = logging.getLogger(__name__)
   
   
   class SignatureService:
       """Service for managing digital signatures via DigiSigner API."""
       
       def __init__(self, db: Session):
           """
           Initialize signature service.
           
           Args:
               db: Database session
           """
           self.db = db
           self.api_key = settings.DIGISIGNER_API_KEY
           self.base_url = "https://api.digisigner.com/v1"
           self.file_storage = FileStorageService()
           
           if not self.api_key:
               logger.warning("DigiSigner API key not configured")
       
       def _get_headers(self) -> Dict[str, str]:
           """Get API request headers."""
           return {
               "X-DigiSigner-API-Key": self.api_key.get_secret_value() if hasattr(self.api_key, 'get_secret_value') else str(self.api_key),
               "Content-Type": "application/json"
           }
       
       def _handle_api_error(self, response: requests.Response) -> None:
           """Handle API error responses."""
           if not response.ok:
               try:
                   error_data = response.json()
                   error_msg = error_data.get("error", {}).get("message", f"API error: {response.status_code}")
                   logger.error(f"DigiSigner API error: {error_msg}")
                   raise ValueError(f"DigiSigner API error: {error_msg}")
               except ValueError:
                   raise
               except Exception:
                   raise ValueError(f"DigiSigner API error: {response.status_code} - {response.text}")
       
       def request_signature(
           self,
           document_id: int,
           signers: List[Dict[str, str]],
           signature_provider: str = "signplus",
           expires_in_days: int = 30
       ) -> DocumentSignature:
           """
           Request signatures for a document.
           
           Args:
               document_id: Document ID to sign
               signers: List of signers [{"name": "...", "email": "...", "role": "..."}]
               signature_provider: Signature provider ("signplus", "digisigner", etc.)
               expires_in_days: Days until signature request expires
               
           Returns:
               DocumentSignature instance
           """
           # 1. Load document
           document = self.db.query(Document).filter(Document.id == document_id).first()
           if not document:
               raise ValueError(f"Document {document_id} not found")
           
           # 2. Upload document to signature provider
           document_url = self._upload_document(document_id, document)
           
           # 3. Create signature request
           request_id = self._create_signature_request(
               document_url=document_url,
               signers=signers,
               expires_in_days=expires_in_days
           )
           
           # 4. Create DocumentSignature record
           signature = DocumentSignature(
               document_id=document_id,
               signature_provider=signature_provider,
               signature_request_id=request_id,
               signature_status="pending",
               signers=signers,
               expires_at=datetime.utcnow() + timedelta(days=expires_in_days)
           )
           
           self.db.add(signature)
           self.db.commit()
           self.db.refresh(signature)
           
           logger.info(f"Created signature request {request_id} for document {document_id}")
           return signature
       
       def check_signature_status(self, signature_request_id: str) -> Dict[str, Any]:
           """Check status of signature request."""
           # Implementation for checking status via API
           pass
       
       def download_signed_document(self, signature_request_id: str) -> bytes:
           """Download signed document from provider."""
           # Implementation for downloading signed document
           pass
       
       def _upload_document(self, document_id: int, document: Document) -> str:
           """Upload document to signature provider."""
           # Implementation for document upload
           pass
       
       def _create_signature_request(
           self,
           document_url: str,
           signers: List[Dict[str, str]],
           expires_in_days: int
       ) -> str:
           """Create signature request via API."""
           # Implementation for API call
           pass
   ```

---

### PROJECT 4: Filing Service (Companies House + Manual UI)

**Priority**: P0 (Critical)  
**Estimated Time**: 7 days  
**Dependencies**: PROJECT 1, PROJECT 2

#### Activity 4.1: Create FilingService

**File**: `app/services/filing_service.py`

**Line-Level Subtasks**:

1. Create new file with FilingService class:
   ```python
   """
   Filing Service for CreditNexus.
   
   Handles:
   - Companies House API integration (UK - automated)
   - Manual filing UI preparation (US, FR, DE - pre-filled forms)
   - Filing status tracking
   """
   ```

2. Implement Companies House API integration:
   - Charge filing endpoint
   - Company information retrieval
   - Filing status tracking
   - Error handling and retry logic

3. Implement manual filing preparation:
   - Pre-fill form data from CDM
   - Generate filing instructions
   - Create filing records with "pending" status
   - Store manual submission URLs

4. Implement filing status tracking:
   - Update status from manual submissions
   - Track submission dates
   - Store confirmation references

---

### PROJECT 5: Verifiers Implementation

**Priority**: P1 (High)  
**Estimated Time**: 3 days  
**Dependencies**: PROJECT 2, PROJECT 3, PROJECT 4

#### Activity 5.1: Create Filing Verifier

**File**: `app/agents/filing_verifier.py`

**Line-Level Subtasks**:

1. Create new file following pattern from `app/agents/verifier.py`
2. Implement `verify_filing_compliance()` function
3. Implement helper functions

#### Activity 5.2: Create Signature Verifier

**File**: `app/agents/signature_verifier.py`

**Line-Level Subtasks**:

1. Create new file following verifier pattern
2. Implement `verify_signature_status()` function

#### Activity 5.3: Create Deadline Verifier

**File**: `app/agents/deadline_verifier.py`

**Line-Level Subtasks**:

1. Create new file following verifier pattern
2. Implement `verify_filing_deadlines()` function

---

### PROJECT 6: API Endpoints

**Priority**: P0 (Critical)  
**Estimated Time**: 3 days  
**Dependencies**: PROJECT 3, PROJECT 4, PROJECT 5

#### Activity 6.1: Add Signature Endpoints

**File**: `app/api/routes.py`

**Line-Level Subtasks**:

1. Add signature request endpoint (around line 9500, after document endpoints):
   ```python
   @router.post("/documents/{document_id}/signatures/request")
   async def request_document_signature(
       document_id: int,
       signers: List[Dict[str, str]],
       db: Session = Depends(get_db),
       current_user: User = Depends(require_auth)
   ):
       """Request signatures for a document."""
       from app.services.signature_service import SignatureService
       
       signature_service = SignatureService(db)
       signature = signature_service.request_signature(
           document_id=document_id,
           signers=signers
       )
       
       return {
           "status": "success",
           "signature": signature.to_dict()
       }
   ```

2. Add signature status endpoint
3. Add signature download endpoint

#### Activity 6.2: Add Filing Endpoints

**Line-Level Subtasks**:

1. Add filing requirement evaluation endpoint
2. Add filing submission endpoint
3. Add filing status endpoint
4. Add deadline alerts endpoint

#### Activity 6.3: Add Verification Endpoints

**Line-Level Subtasks**:

1. Add filing compliance verification endpoint
2. Add signature verification endpoint
3. Add deadline verification endpoint

---

### PROJECT 7: Background Tasks

**Priority**: P1 (High)  
**Estimated Time**: 2 days  
**Dependencies**: PROJECT 5

#### Activity 7.1: Create Deadline Monitoring Task

**File**: `app/services/background_tasks.py`

**Line-Level Subtasks**:

1. Add scheduled task for deadline checking
2. Add task for compliance verification
3. Add task for signature status updates

---

### PROJECT 8: Frontend Integration

**Priority**: P1 (High)  
**Estimated Time**: 5 days  
**Dependencies**: PROJECT 6

#### Activity 8.1: Add Signature UI Components

**File**: `client/src/components/SignatureStatus.tsx`

**Line-Level Subtasks**:

1. Create SignatureStatus component
2. Add signature request form
3. Add signature status display

#### Activity 8.2: Add Filing UI Components

**File**: `client/src/components/FilingRequirementsPanel.tsx`

**Line-Level Subtasks**:

1. Create FilingRequirementsPanel component:
   - Display list of required filings
   - Show deadline countdown with urgency indicators
   - Status badges (pending/submitted/accepted/rejected)
   - Action buttons per filing:
     - "File Automatically" (UK - Companies House API)
     - "Prepare Filing" (US, FR, DE - opens manual form)
     - "View Status" (all)
   - Jurisdiction filter
   - Status filter

2. Create ManualFilingForm component:
   - Pre-filled form fields from CDM data
   - Jurisdiction-specific fields:
     - US: SEC form fields (8-K, 10-Q, etc.)
     - FR: AMF form fields (French language)
     - DE: BaFin form fields (German language)
   - Document attachment
   - External portal link (opens in new tab)
   - Submission notes
   - Submission tracking

3. Create FilingStatusDashboard component:
   - All filings for deals/documents
   - Filtering and sorting
   - Export to CSV/PDF
   - Deadline alerts
   - Compliance status overview

4. Integrate into existing views:
   - Add "Filing Requirements" tab to DealDetail
   - Add filing status indicators to document list
   - Add filing alerts to dashboard

---

## Testing Strategy

### Unit Tests

1. Policy service filing methods
2. Signature service API integration
3. Filing service API integration
4. Verifier functions

### Integration Tests

1. End-to-end signature workflow
2. End-to-end filing workflow
3. Deadline alert system
4. Compliance verification

---

## Deployment Plan

### Phase 1: Database & Core Services (Week 1-2)
- Database schema changes
- Policy engine extensions
- Basic services

### Phase 2: API Integration (Week 3-4)
- Sign.Plus integration
- Companies House API integration
- Manual filing queue

### Phase 3: Verifiers & Background Tasks (Week 5-6)
- Verifier implementation
- Background task scheduling
- Alert system

### Phase 4: Frontend & Testing (Week 7-8)
- UI components
- Integration testing
- User acceptance testing

### Phase 5: Production Deployment (Week 9-10)
- Production deployment
- Monitoring setup
- Documentation

---

**Document Status**: ✅ Complete  
**Ready for**: Implementation
