# Enhanced Document Digitizer & User Experience Implementation Plan

## Executive Summary

This plan implements comprehensive enhancements to the document digitizer flow, CDM data editing experience, navigation flows, and signup/approval workflows. The implementation focuses on:

1. **Hydrated Clause Editor** - Integrated clause editing when documents are digitized
2. **Accordion JSON Editor** - Live JSON display alongside adaptive forms for CDM editing
3. **AI-Powered CDM Operations** - Add, remove, and edit CDM fields using multimodal input fusion
4. **Navigation Flow Improvements** - Enhanced tab hydration and state management
5. **Approval Workflows** - User signup and loan application approval/dismissal
6. **Flexible Signup Flow** - Non-restrictive, step-navigable signup with AI-first approach

---

## Project 1: Hydrated Clause Editor Integration

### Activity 1.1: Integrate Clause Editor into Document Parser

**File: `client/src/apps/docu-digitizer/DocumentParser.tsx`**

#### Task 1.1.1: Add Clause Editor State Management
- **Line 35-45**: Add state for clause editor visibility and selected clauses
  ```typescript
  const [showClauseEditor, setShowClauseEditor] = useState(false);
  const [selectedClauses, setSelectedClauses] = useState<Clause[]>([]);
  const [clauseEditorDocumentId, setClauseEditorDocumentId] = useState<number | null>(null);
  ```

#### Task 1.1.2: Import Clause Editor Component
- **Line 1-12**: Add import for ClauseEditor
  ```typescript
  import { ClauseEditor } from '@/components/ClauseEditor';
  ```

#### Task 1.1.3: Add Clause Editor Tab in Results View
- **Line 719-876**: Add new "Clauses" tab after "Facilities" tab
  ```typescript
  <TabsTrigger value="clauses">Clauses</TabsTrigger>
  ```
- **Line 865-875**: Add TabsContent for clauses
  ```typescript
  <TabsContent value="clauses">
    <Card className="border-slate-700 bg-slate-800/50">
      <CardContent className="p-6">
        {clauseEditorDocumentId ? (
          <ClauseEditor 
            documentId={clauseEditorDocumentId}
            cdmData={editableData}
            onClauseSelect={(clauses) => setSelectedClauses(clauses)}
          />
        ) : (
          <p className="text-muted-foreground">Save document to library to enable clause editing</p>
        )}
      </CardContent>
    </Card>
  </TabsContent>
  ```

#### Task 1.1.4: Update Save Handler to Set Document ID
- **Line 252-298**: Modify `handleSaveToLibrary` to capture document ID
  ```typescript
  const data = await response.json();
  if (data.document?.id) {
    setClauseEditorDocumentId(data.document.id);
    setShowClauseEditor(true);
  }
  ```

#### Task 1.1.5: Auto-show Clause Editor After Save
- **Line 284-289**: Add logic to automatically show clause editor tab after save
  ```typescript
  if (data.document?.id) {
    setClauseEditorDocumentId(data.document.id);
    // Switch to clauses tab if available
    setTimeout(() => {
      // Trigger tab change if tabs component supports it
    }, 100);
  }
  ```

---

## Project 2: Accordion JSON Editor with Adaptive Forms

### Activity 2.1: Create Accordion JSON Editor Component

**File: `client/src/components/CdmAccordionEditor.tsx`** (NEW FILE)

#### Task 2.1.1: Create Component Structure
- **Line 1-50**: Set up component with TypeScript interfaces
  ```typescript
  interface CdmAccordionEditorProps {
    cdmData: CreditAgreementData;
    onUpdate: (updatedData: CreditAgreementData) => void;
    documentId?: number;
    className?: string;
  }
  
  interface AccordionSection {
    id: string;
    title: string;
    fields: EditableField[];
    expanded: boolean;
  }
  ```

#### Task 2.1.2: Implement Accordion UI
- **Line 51-150**: Create accordion structure using shadcn/ui Accordion
  ```typescript
  import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
  
  <Accordion type="multiple" className="w-full">
    {sections.map(section => (
      <AccordionItem key={section.id} value={section.id}>
        <AccordionTrigger>{section.title}</AccordionTrigger>
        <AccordionContent>
          {/* Form fields and JSON side-by-side */}
        </AccordionContent>
      </AccordionItem>
    ))}
  </Accordion>
  ```

#### Task 2.1.3: Implement Split View (Form + JSON)
- **Line 151-250**: Create side-by-side layout
  ```typescript
  <div className="grid grid-cols-2 gap-4">
    <div className="space-y-4">
      {/* Adaptive form fields */}
    </div>
    <div className="border-l border-slate-700 pl-4">
      <Accordion>
        <AccordionItem value="json">
          <AccordionTrigger>Raw JSON</AccordionTrigger>
          <AccordionContent>
            <pre className="text-xs font-mono bg-slate-900 p-4 rounded-lg overflow-auto max-h-96">
              {JSON.stringify(localCdmData, null, 2)}
            </pre>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  </div>
  ```

#### Task 2.1.4: Implement Adaptive Form Fields
- **Line 251-400**: Create field renderer based on field type
  ```typescript
  const renderField = (field: EditableField) => {
    switch (field.type) {
      case 'string':
        return <Input ... />;
      case 'number':
        return <Input type="number" ... />;
      case 'date':
        return <Input type="date" ... />;
      case 'boolean':
        return <Checkbox ... />;
      case 'array':
        return <ArrayFieldEditor ... />;
      case 'object':
        return <NestedObjectEditor ... />;
    }
  };
  ```

#### Task 2.1.5: Implement Live JSON Sync
- **Line 401-450**: Add useEffect to sync form changes to JSON
  ```typescript
  useEffect(() => {
    setLocalCdmData(cdmData);
  }, [cdmData]);
  
  const handleFieldChange = (path: string, value: any) => {
    const updated = setNestedValue(localCdmData, path, value);
    setLocalCdmData(updated);
    onUpdate(updated);
  };
  ```

#### Task 2.1.6: Add JSON Direct Editing
- **Line 451-550**: Allow direct JSON editing with validation
  ```typescript
  const [isEditingJson, setIsEditingJson] = useState(false);
  const [jsonError, setJsonError] = useState<string | null>(null);
  
  const handleJsonChange = (jsonString: string) => {
    try {
      const parsed = JSON.parse(jsonString);
      setLocalCdmData(parsed);
      onUpdate(parsed);
      setJsonError(null);
    } catch (err) {
      setJsonError('Invalid JSON');
    }
  };
  ```

### Activity 2.2: Integrate Accordion Editor into Document Parser

**File: `client/src/apps/docu-digitizer/DocumentParser.tsx`**

#### Task 2.2.1: Replace Current Editing UI
- **Line 719-876**: Replace existing tabs content with CdmAccordionEditor
  ```typescript
  import { CdmAccordionEditor } from '@/components/CdmAccordionEditor';
  
  <TabsContent value="edit">
    <CdmAccordionEditor
      cdmData={editableData}
      onUpdate={setEditableData}
      documentId={clauseEditorDocumentId || undefined}
    />
  </TabsContent>
  ```

#### Task 2.2.2: Update Tab Structure
- **Line 720-725**: Add "Edit" tab alongside existing tabs
  ```typescript
  <TabsTrigger value="edit">Edit CDM</TabsTrigger>
  ```

---

## Project 3: AI-Powered CDM Operations with Multimodal Fusion

### Activity 3.1: Create AI CDM Operations Component

**File: `client/src/components/AiCdmOperations.tsx`** (NEW FILE)

#### Task 3.1.1: Create Component Structure
- **Line 1-50**: Set up component with props and state
  ```typescript
  interface AiCdmOperationsProps {
    cdmData: CreditAgreementData;
    multimodalSources: MultimodalSources;
    onUpdate: (updatedData: CreditAgreementData) => void;
    documentId?: number;
  }
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [operationType, setOperationType] = useState<'add' | 'remove' | 'edit' | null>(null);
  ```

#### Task 3.1.2: Implement Add CDM Button
- **Line 51-150**: Create "Add CDM" button and handler
  ```typescript
  const handleAddCdm = async () => {
    setIsProcessing(true);
    setOperationType('add');
    try {
      const response = await fetchWithAuth('/api/multimodal/fuse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...prepareFusionRequest(multimodalSources),
          operation: 'add',
          existing_cdm: cdmData,
        }),
      });
      const result = await response.json();
      onUpdate(result.agreement);
    } finally {
      setIsProcessing(false);
      setOperationType(null);
    }
  };
  ```

#### Task 3.1.3: Implement Remove CDM Button
- **Line 151-250**: Create "Remove CDM" button with field selection
  ```typescript
  const handleRemoveCdm = async (fieldPath: string) => {
    setIsProcessing(true);
    setOperationType('remove');
    try {
      const response = await fetchWithAuth('/api/cdm/remove', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          document_id: documentId,
          field_path: fieldPath,
          multimodal_context: multimodalSources,
        }),
      });
      const result = await response.json();
      onUpdate(result.cdm_data);
    } finally {
      setIsProcessing(false);
      setOperationType(null);
    }
  };
  ```

#### Task 3.1.4: Implement Edit Fields Button
- **Line 251-350**: Create "Edit Fields" button with field selection
  ```typescript
  const handleEditFields = async (fieldPath: string, newValue: any) => {
    setIsProcessing(true);
    setOperationType('edit');
    try {
      const response = await fetchWithAuth('/api/cdm/edit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          document_id: documentId,
          field_path: fieldPath,
          new_value: newValue,
          multimodal_context: multimodalSources,
          use_ai: true,
        }),
      });
      const result = await response.json();
      onUpdate(result.cdm_data);
    } finally {
      setIsProcessing(false);
      setOperationType(null);
    }
  };
  ```

#### Task 3.1.5: Create UI with Three Buttons
- **Line 351-450**: Render three distinct buttons
  ```typescript
  <div className="flex gap-2">
    <Button
      onClick={handleAddCdm}
      disabled={isProcessing && operationType !== 'add'}
      className="bg-emerald-600 hover:bg-emerald-700"
    >
      <Sparkles className="h-4 w-4 mr-2" />
      {isProcessing && operationType === 'add' ? 'Adding...' : 'Add CDM'}
    </Button>
    <Button
      onClick={() => setShowRemoveDialog(true)}
      disabled={isProcessing}
      variant="destructive"
    >
      <Trash2 className="h-4 w-4 mr-2" />
      Remove CDM
    </Button>
    <Button
      onClick={() => setShowEditDialog(true)}
      disabled={isProcessing}
      variant="outline"
    >
      <Edit2 className="h-4 w-4 mr-2" />
      Edit Fields
    </Button>
  </div>
  ```

### Activity 3.2: Create Backend API Endpoints

**File: `app/api/routes.py`**

#### Task 3.2.1: Add CDM Endpoint
- **Line 2100-2200**: Add `/api/cdm/add` endpoint
  ```python
  @router.post("/cdm/add")
  async def add_cdm_from_multimodal(
      request: AddCdmRequest,
      db: Session = Depends(get_db),
      current_user: Optional[User] = Depends(get_current_user),
  ):
      """Add CDM data using multimodal fusion."""
      from app.chains.multimodal_fusion_chain import fuse_multimodal_inputs
      
      result = fuse_multimodal_inputs(
          audio_cdm=request.audio_cdm,
          image_cdm=request.image_cdm,
          document_cdm=request.document_cdm,
          text_cdm=request.text_cdm,
          audio_text=request.audio_text,
          image_text=request.image_text,
          document_text=request.document_text,
          text_input=request.text_input,
          use_llm_fusion=True,
      )
      
      # Merge with existing CDM
      merged = merge_cdm_data(request.existing_cdm, result.agreement)
      
      return {"agreement": merged, "source_tracking": result.source_tracking}
  ```

#### Task 3.2.2: Remove CDM Endpoint
- **Line 2201-2300**: Add `/api/cdm/remove` endpoint
  ```python
  @router.post("/cdm/remove")
  async def remove_cdm_field(
      request: RemoveCdmRequest,
      db: Session = Depends(get_db),
      current_user: Optional[User] = Depends(get_current_user),
  ):
      """Remove CDM field using AI to determine what to remove."""
      # Use LLM to determine if removal is safe
      removal_decision = evaluate_field_removal(
          field_path=request.field_path,
          cdm_data=request.cdm_data,
          multimodal_context=request.multimodal_context,
      )
      
      if removal_decision.safe:
          updated = remove_nested_field(request.cdm_data, request.field_path)
          return {"cdm_data": updated}
      else:
          raise HTTPException(400, detail=removal_decision.reason)
  ```

#### Task 3.2.3: Edit CDM Endpoint
- **Line 2301-2400**: Add `/api/cdm/edit` endpoint
  ```python
  @router.post("/cdm/edit")
  async def edit_cdm_field(
      request: EditCdmRequest,
      db: Session = Depends(get_db),
      current_user: Optional[User] = Depends(get_current_user),
  ):
      """Edit CDM field using AI and multimodal context."""
      if request.use_ai:
          # Use LLM to suggest/edit field value
          edited_value = ai_edit_field(
              field_path=request.field_path,
              current_value=get_nested_value(request.cdm_data, request.field_path),
              new_value=request.new_value,
              multimodal_context=request.multimodal_context,
          )
      else:
          edited_value = request.new_value
      
      updated = set_nested_value(request.cdm_data, request.field_path, edited_value)
      return {"cdm_data": updated}
  ```

### Activity 3.3: Integrate AI Operations into Accordion Editor

**File: `client/src/components/CdmAccordionEditor.tsx`**

#### Task 3.3.1: Add AI Operations Component
- **Line 1-10**: Import AiCdmOperations
  ```typescript
  import { AiCdmOperations } from '@/components/AiCdmOperations';
  ```

#### Task 3.3.2: Add Multimodal Sources Prop
- **Line 11-20**: Update props interface
  ```typescript
  interface CdmAccordionEditorProps {
    // ... existing props
    multimodalSources?: MultimodalSources;
  }
  ```

#### Task 3.3.3: Render AI Operations
- **Line 100-150**: Add AI operations above accordion
  ```typescript
  {multimodalSources && Object.keys(multimodalSources).length > 0 && (
    <div className="mb-4">
      <AiCdmOperations
        cdmData={localCdmData}
        multimodalSources={multimodalSources}
        onUpdate={handleUpdate}
        documentId={documentId}
      />
    </div>
  )}
  ```

---

## Project 4: Navigation Flow Improvements

### Activity 4.1: Enhanced Tab State Management

**File: `client/src/apps/docu-digitizer/DocumentParser.tsx`**

#### Task 4.1.1: Add Tab State Persistence
- **Line 46-50**: Add tab state
  ```typescript
  const [activeTab, setActiveTab] = useState<string>('summary');
  const [tabHistory, setTabHistory] = useState<string[]>(['summary']);
  ```

#### Task 4.1.2: Persist Tab State in URL
- **Line 32-33**: Use searchParams for tab state
  ```typescript
  const [searchParams, setSearchParams] = useSearchParams();
  
  useEffect(() => {
    const tab = searchParams.get('tab') || 'summary';
    setActiveTab(tab);
  }, [searchParams]);
  ```

#### Task 4.1.3: Update Tab Change Handler
- **Line 719**: Add controlled tab value
  ```typescript
  <Tabs value={activeTab} onValueChange={(value) => {
    setActiveTab(value);
    setSearchParams({ tab: value });
    setTabHistory(prev => [...prev, value]);
  }}>
  ```

#### Task 4.1.4: Implement Tab Hydration
- **Line 380-442**: Enhance document loading to restore tab state
  ```typescript
  useEffect(() => {
    const documentId = searchParams.get('documentId');
    const tab = searchParams.get('tab');
    
    if (documentId && documentId !== loadedDocumentIdRef.current) {
      // Load document
      // After load, restore tab if specified
      if (tab) {
        setActiveTab(tab);
      }
    }
  }, [searchParams]);
  ```

### Activity 4.2: Cross-Vignette Navigation

**File: `client/src/components/DesktopAppLayout.tsx`**

#### Task 4.2.1: Enhance App State Persistence
- **Line 243-255**: Improve sessionStorage persistence
  ```typescript
  const setActiveApp = useCallback((value: AppView | ((prev: AppView) => AppView)) => {
    setActiveAppState((prev) => {
      const newValue = typeof value === 'function' ? value(prev) : value;
      if (typeof window !== 'undefined') {
        sessionStorage.setItem('creditnexus_activeApp', newValue);
        // Also store tab state if applicable
        sessionStorage.setItem(`creditnexus_${newValue}_tab`, activeTab || '');
      }
      return newValue;
    });
  }, [activeTab]);
  ```

#### Task 4.2.2: Restore Tab State on App Switch
- **Line 490-550**: Enhance handleAppChange
  ```typescript
  const handleAppChange = (app: AppView) => {
    // Save current tab state
    if (typeof window !== 'undefined') {
      sessionStorage.setItem(`creditnexus_${activeApp}_tab`, currentTab);
    }
    
    // Restore tab state for new app
    const savedTab = sessionStorage.getItem(`creditnexus_${app}_tab`);
    if (savedTab) {
      // Pass to app component via props or context
    }
    
    setActiveApp(app);
    // ... navigation logic
  };
  ```

---

## Project 5: Approval/Dismissal Workflows

### Activity 5.1: Enhance User Signup Approval

**File: `client/src/components/AdminSignupDashboard.tsx`**

#### Task 5.1.1: Add Approval Modal
- **Line 150-200**: Create approval confirmation modal
  ```typescript
  const [showApprovalModal, setShowApprovalModal] = useState(false);
  const [approvalUser, setApprovalUser] = useState<SignupUser | null>(null);
  
  const handleApproveClick = (user: SignupUser) => {
    setApprovalUser(user);
    setShowApprovalModal(true);
  };
  ```

#### Task 5.1.2: Add Rejection Modal with Reason
- **Line 200-250**: Enhance rejection modal
  ```typescript
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [rejectUser, setRejectUser] = useState<SignupUser | null>(null);
  ```

#### Task 5.1.3: Add Bulk Actions
- **Line 250-300**: Add bulk approve/reject
  ```typescript
  const [selectedUsers, setSelectedUsers] = useState<number[]>([]);
  
  const handleBulkApprove = async () => {
    for (const userId of selectedUsers) {
      await handleApprove(userId);
    }
  };
  ```

### Activity 5.2: Loan Application Approval Workflow

**File: `client/src/components/ApplicationDashboard.tsx`** (ENHANCE EXISTING)

#### Task 5.2.1: Add Approval Actions
- **Line 1-50**: Add approval/rejection handlers
  ```typescript
  const handleApproveApplication = async (applicationId: number) => {
    const response = await fetchWithAuth(`/api/applications/${applicationId}/approve`, {
      method: 'POST',
    });
    // Refresh list
  };
  
  const handleRejectApplication = async (applicationId: number, reason: string) => {
    const response = await fetchWithAuth(`/api/applications/${applicationId}/reject`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rejection_reason: reason }),
    });
    // Refresh list
  };
  ```

#### Task 5.2.2: Add Approval UI
- **Line 100-200**: Add approve/reject buttons to application cards
  ```typescript
  <div className="flex gap-2">
    <Button onClick={() => handleApproveApplication(app.id)}>
      <CheckCircle className="h-4 w-4 mr-2" />
      Approve
    </Button>
    <Button variant="destructive" onClick={() => setShowRejectModal(true)}>
      <XCircle className="h-4 w-4 mr-2" />
      Reject
    </Button>
  </div>
  ```

### Activity 5.3: Backend Approval Endpoints

**File: `app/api/routes.py`**

#### Task 5.3.1: Enhance Application Approval
- **Line 7338-7361**: Ensure approval endpoint exists and is complete
  ```python
  @router.post("/applications/{application_id}/approve")
  async def approve_application(
      application_id: int,
      db: Session = Depends(get_db),
      current_user: User = Depends(require_auth)
  ):
      """Approve an application (admin only)."""
      # ... existing implementation
      # Add notification logic
      # Add audit logging
  ```

---

## Project 6: Flexible Signup Flow

### Activity 6.1: Make Signup Flow Non-Restrictive

**File: `client/src/components/SignupFlow.tsx`**

#### Task 6.1.1: Remove Required Field Validation
- **Line 68-105**: Make validation optional
  ```typescript
  const validateStep1 = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    // Only validate format, not presence
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }
    
    if (formData.password && formData.password.length < 12) {
      newErrors.password = 'Password must be at least 12 characters';
    }
    // ... other format validations only
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  ```

#### Task 6.1.2: Allow Step Navigation
- **Line 107-125**: Remove validation requirement for navigation
  ```typescript
  const handleNext = () => {
    // Remove validation check - allow navigation regardless
    if (currentStep < STEPS.length) {
      setCurrentStep(currentStep + 1);
      clearError();
    }
  };
  
  const handleStepClick = (stepId: number) => {
    // Allow clicking on any step to navigate
    if (stepId >= 1 && stepId <= STEPS.length) {
      setCurrentStep(stepId);
      clearError();
    }
  };
  ```

#### Task 6.1.3: Make Steps Clickable
- **Line 380-410**: Make step indicators clickable
  ```typescript
  {STEPS.map((step, index) => (
    <div
      key={step.id}
      onClick={() => handleStepClick(step.id)}
      className={`flex items-center gap-2 cursor-pointer ${
        currentStep >= step.id ? 'text-emerald-400' : 'text-slate-500'
      }`}
    >
      {/* Step indicator */}
    </div>
  ))}
  ```

### Activity 6.2: AI-First Signup with Multimodal Input

**File: `client/src/components/SignupFlow.tsx`**

#### Task 6.2.1: Add Multimodal Input Component
- **Line 1-20**: Import multimodal components
  ```typescript
  import { MultimodalInputTabs } from '@/apps/docu-digitizer/MultimodalInputTabs';
  ```

#### Task 6.2.2: Add AI Extraction Step (Step 0)
- **Line 43-48**: Add AI step before basic info
  ```typescript
  const STEPS = [
    { id: 0, title: 'AI Profile Extraction', description: 'Extract profile data using AI' },
    { id: 1, title: 'Basic Information', description: 'Email, password, and role selection' },
    // ... rest of steps
  ];
  ```

#### Task 6.2.3: Implement AI Extraction Step
- **Line 162-200**: Add AI step rendering
  ```typescript
  case 0:
    return (
      <div className="space-y-6">
        <MultimodalInputTabs
          onAudioComplete={(result) => {
            if (result.agreement) {
              // Extract profile data from CDM
              const profileData = extractProfileFromCdm(result.agreement);
              updateFormData({ profileData });
            }
          }}
          onImageComplete={(result) => {
            // Similar for image
          }}
          onDocumentSelect={(doc) => {
            // Similar for document
          }}
          onTextInput={(text, cdm) => {
            // Similar for text
          }}
        />
        <Button onClick={handleNext}>
          Continue to Basic Info
        </Button>
      </div>
    );
  ```

#### Task 6.2.4: Pre-fill Form from AI Data
- **Line 290-305**: Pre-fill step 2 from AI data
  ```typescript
  case 2:
    return (
      <div className="space-y-6">
        {formData.profileData && Object.keys(formData.profileData).length > 0 ? (
          <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-lg mb-4">
            <p className="text-sm text-emerald-400">
              Profile data extracted from AI input. Review and edit below.
            </p>
          </div>
        ) : null}
        <ProfileEnrichment
          role={formData.role}
          formData={formData.profileData || {}}
          onChange={(data) => updateFormData({ profileData: data })}
          errors={errors}
        />
      </div>
    );
  ```

### Activity 6.3: Backend Support for Partial Signup

**File: `app/auth/jwt_auth.py`**

#### Task 6.3.1: Allow Partial User Creation
- **Line 548-600**: Modify signup_step1 to allow partial data
  ```python
  @jwt_router.post("/signup/step1", response_model=SignupTokenResponse)
  async def signup_step1(
      request: Request,
      user_data: UserSignupStep1,
      db: Session = Depends(get_db)
  ):
      """Step 1: Create user account with optional fields."""
      # Allow None/empty values
      user = User(
          email=user_data.email or f"temp_{uuid.uuid4()}@temp.com",
          password_hash=get_password_hash(user_data.password or "temp_password"),
          display_name=user_data.display_name or "Temporary User",
          role=user_data.role.value if user_data.role else "applicant",
          is_active=False,
          is_email_verified=False,
          signup_status="in_progress",  # New status
          signup_submitted_at=None,  # Not submitted yet
      )
      # ... rest of creation
  ```

#### Task 6.3.2: Add Save Progress Endpoint
- **Line 600-650**: Add endpoint to save signup progress
  ```python
  @jwt_router.post("/signup/save-progress")
  async def save_signup_progress(
      request: Request,
      progress_data: SignupProgressData,
      db: Session = Depends(get_db)
  ):
      """Save signup progress without completing signup."""
      user = db.query(User).filter(User.id == progress_data.user_id).first()
      if not user:
          raise HTTPException(404, "User not found")
      
      # Update user with partial data
      if progress_data.email:
          user.email = progress_data.email
      if progress_data.display_name:
          user.display_name = progress_data.display_name
      # ... update other fields
      
      db.commit()
      return {"status": "saved", "user_id": user.id}
  ```

---

## Implementation Timeline

### Phase 1: Core Components (Week 1-2)
- Project 1: Hydrated Clause Editor
- Project 2: Accordion JSON Editor (basic)

### Phase 2: AI Integration (Week 3-4)
- Project 3: AI-Powered CDM Operations
- Backend API endpoints

### Phase 3: Navigation & UX (Week 5)
- Project 4: Navigation Flow Improvements

### Phase 4: Workflows (Week 6)
- Project 5: Approval/Dismissal Workflows

### Phase 5: Signup Enhancement (Week 7)
- Project 6: Flexible Signup Flow

---

## Testing Checklist

### Component Testing
- [ ] Clause Editor integration
- [ ] Accordion JSON Editor
- [ ] AI CDM Operations
- [ ] Tab state persistence
- [ ] Signup flow navigation

### Integration Testing
- [ ] Multimodal fusion with CDM operations
- [ ] Approval workflows end-to-end
- [ ] Cross-vignette navigation
- [ ] Signup with AI extraction

### User Acceptance Testing
- [ ] Document digitization with clause editor
- [ ] CDM editing with JSON accordion
- [ ] AI-powered field operations
- [ ] Approval/dismissal workflows
- [ ] Flexible signup experience

---

## Dependencies

### Frontend
- shadcn/ui Accordion component
- React Router for navigation state
- Existing multimodal input components

### Backend
- Multimodal fusion chain
- CDM validation utilities
- Approval workflow services

---

## Notes

1. **State Management**: Consider using Zustand or Context API for global tab state
2. **Performance**: Lazy load accordion sections for large CDM structures
3. **Accessibility**: Ensure all new components are keyboard navigable
4. **Error Handling**: Comprehensive error boundaries for AI operations
5. **Loading States**: Clear loading indicators for all async operations

---

**Document Version**: 1.0  
**Last Updated**: 2024-12-XX  
**Author**: CreditNexus Development Team
