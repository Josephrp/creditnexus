# CreditNexus Remote Verification & MetaMask Notarization - Enhanced Implementation Plan

## Executive Summary

This enhanced plan extends CreditNexus with:
1. **SSL-enabled remote API listener** with IP whitelisting and profile-based access control
2. **Self-contained link-based verification workflow** for cross-machine deal verification (links contain all data, no messenger integration)
3. **MetaMask hot login** (automatic signup/login with authenticated MetaMask extension)
4. **MetaMask notarization** for blockchain-based transaction signing

**Key Architectural Decision**: CreditNexus generates self-contained verification links with embedded data. Links are shared by users via external channels (email, Slack, Teams, etc.). CreditNexus does NOT send messages directly.

**Priority**: High  
**Estimated Timeline**: 10-12 weeks  
**Complexity**: High  
**Team Size**: 3-4 developers

---

## Current State Assessment

### ✅ Existing Infrastructure

1. **MetaMask Frontend Integration** (Partial)
   - `client/src/context/WalletContext.tsx` - Wallet connection management
   - `client/src/sites/metamask/MetaMaskLogin.tsx` - Login UI component
   - `client/src/components/MetaMaskConnect.tsx` - Connection component
   - Auto-detection of connected wallet via `eth_accounts` (lines 49-73 in WalletContext.tsx)
   - Message signing capability (lines 170-184 in WalletContext.tsx)

2. **Backend Wallet Authentication** (Placeholder)
   - `/api/auth/wallet/nonce` endpoint (lines 7808-7834 in routes.py)
   - `/api/auth/wallet` endpoint (lines 7837-7875 in routes.py)
   - **ISSUE**: No cryptographic signature verification (line 7842: "placeholder - requires cryptographic verification")

3. **Deal Lifecycle Management**
   - `Deal` model with status transitions
   - `DealService` for deal creation and state management
   - CDM event generation

4. **Workflow System**
   - `Workflow` model for document approval
   - Role-based permissions

### ❌ Missing Components

1. **MetaMask Hot Login**
   - No automatic authentication on page load when MetaMask is connected
   - No session persistence for wallet-authenticated users
   - No automatic signup for new wallet addresses
   - No backend signature verification

2. **Remote API Listener**
   - No separate SSL-enabled port
   - No IP whitelisting
   - No profile-based access control

3. **Verification Workflow**
   - No cross-machine verification
   - No link-based verification system

4. **MetaMask Notarization**
   - No transaction signing system
   - No notarization records

---

## Architecture Enhancements

### MetaMask Hot Login Flow

```
┌─────────────────────────────────────────────────────────────┐
│              Page Load / App Initialization                 │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│         WalletContext.checkConnection()                      │
│         (Already implemented, lines 49-73)                 │
│                                                              │
│  - Calls eth_accounts to check existing connection          │
│  - If account found, sets isConnected=true                │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│         NEW: AutoAuthHook (useAutoAuth)                     │
│                                                              │
│  useEffect(() => {                                          │
│    if (isConnected && account && !user) {                  │
│      // Auto-authenticate if wallet connected              │
│      attemptAutoLogin(account)                              │
│    }                                                        │
│  }, [isConnected, account, user])                          │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│         Backend: /api/auth/wallet/auto-login               │
│                                                              │
│  1. Check if user exists by wallet_address                 │
│  2. If exists: Return JWT tokens (hot login)               │
│  3. If not: Return "signup_required" flag                  │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│         Frontend: Auto Signup Flow                          │
│                                                              │
│  If signup_required:                                       │
│    1. Prompt user for email/display_name (optional)       │
│    2. Sign message with MetaMask                           │
│    3. Send to /api/auth/wallet/signup                      │
│    4. Auto-create user account                             │
│    5. Return JWT tokens                                     │
└─────────────────────────────────────────────────────────────┘
```

---

## Implementation Plan - Detailed Breakdown

## PROJECT 1: MetaMask Hot Login & Enhanced Authentication

### Activity 1.1: Backend Cryptographic Signature Verification

**Priority**: P0 (Critical)  
**Estimated Time**: 4 days  
**Dependencies**: None

#### File-Level Task 1.1.1: Install Web3 Dependencies
**File**: `pyproject.toml`

**Line-Level Subtasks**:
1. Add `web3` dependency (line ~XX):
   ```toml
   web3 = "^6.0.0"
   ```
2. Add `eth-account` dependency (line ~XX):
   ```toml
   eth-account = "^0.8.0"
   ```
3. Run `uv sync` to install dependencies

#### File-Level Task 1.1.2: Create Cryptographic Verification Utility
**File**: `app/utils/crypto_verification.py` (NEW FILE)

**Line-Level Subtasks**:
1. Create file with imports (lines 1-10):
   ```python
   """Cryptographic signature verification for Ethereum wallets."""
   from eth_account import Account
   from eth_account.messages import encode_defunct
   from typing import Optional
   import logging
   
   logger = logging.getLogger(__name__)
   ```

2. Implement signature verification function (lines 12-35):
   ```python
   def verify_ethereum_signature(
       message: str,
       signature: str,
       wallet_address: str
   ) -> bool:
       """
       Verify Ethereum signature using eth_account.
       
       Args:
           message: Original message that was signed
           signature: Hex-encoded signature from MetaMask
           wallet_address: Expected wallet address
           
       Returns:
           True if signature is valid, False otherwise
       """
       try:
           # Encode message in Ethereum message format
           message_hash = encode_defunct(text=message)
           
           # Recover address from signature
           recovered_address = Account.recover_message(message_hash, signature=signature)
           
           # Compare addresses (case-insensitive)
           return recovered_address.lower() == wallet_address.lower()
       except Exception as e:
           logger.error(f"Signature verification failed: {e}")
           return False
   ```

3. Add EIP-712 typed data verification (lines 37-65):
   ```python
   def verify_typed_data_signature(
       domain: dict,
       types: dict,
       message: dict,
       signature: str,
       wallet_address: str
   ) -> bool:
       """Verify EIP-712 typed data signature."""
       # Implementation for typed data signing
       pass
   ```

#### File-Level Task 1.1.3: Update Wallet Authentication Endpoint
**File**: `app/api/routes.py`

**Line-Level Subtasks**:
1. Add import for crypto verification (line ~7836):
   ```python
   from app.utils.crypto_verification import verify_ethereum_signature
   ```

2. Replace placeholder verification (lines 7842-7843):
   ```python
   # OLD (line 7842):
   # """Authenticate using wallet signature (placeholder - requires cryptographic verification)."""
   # TODO: Implement cryptographic signature verification
   
   # NEW:
   """Authenticate using wallet signature with cryptographic verification."""
   ```

3. Add signature verification before user lookup (lines 7846-7850):
   ```python
   # Verify signature cryptographically
   is_valid = verify_ethereum_signature(
       message=request.message,
       signature=request.signature,
       wallet_address=request.wallet_address
   )
   
   if not is_valid:
       raise HTTPException(
           status_code=401,
           detail="Invalid signature. Signature verification failed."
       )
   ```

4. Update user creation to use verified wallet (lines 7849-7860):
   ```python
   # Find existing user by wallet address
   user = db.query(User).filter(User.wallet_address == request.wallet_address.lower()).first()
   
   if not user:
       # Auto-create user with verified wallet address
       user = User(
           email=f"{request.wallet_address[:8]}@wallet.local",
           display_name=f"Wallet {request.wallet_address[:8]}",
           wallet_address=request.wallet_address.lower(),
           role="viewer",  # Default role, can be upgraded
           is_active=True,
           is_email_verified=False  # Requires email verification for full access
       )
       db.add(user)
       db.commit()
       db.refresh(user)
       
       # Log auto-signup
       log_audit_action(
           db, AuditAction.CREATE, "user", user.id, user.id,
           metadata={"method": "wallet_auto_signup", "wallet_address": request.wallet_address}
       )
   ```

### Activity 1.2: Auto-Login Endpoint (Hot Login)

**Priority**: P0 (Critical)  
**Estimated Time**: 2 days  
**Dependencies**: Activity 1.1

#### File-Level Task 1.2.1: Create Auto-Login Endpoint
**File**: `app/api/routes.py`

**Line-Level Subtasks**:
1. Add auto-login request model (after line 7801):
   ```python
   class AutoLoginRequest(BaseModel):
       """Request model for automatic wallet login."""
       wallet_address: str = Field(..., description="Ethereum wallet address")
   ```

2. Create auto-login endpoint (after line 7834):
   ```python
   @router.post("/auth/wallet/auto-login")
   async def wallet_auto_login(
       request: AutoLoginRequest,
       db: Session = Depends(get_db)
   ):
       """
       Automatic login for users with connected MetaMask wallet.
       
       This endpoint checks if a user exists for the given wallet address
       and returns JWT tokens if found. No signature required for hot login.
       
       For security, this should only be used when:
       1. Wallet is already connected (eth_accounts returns address)
       2. User is on the same browser/session
       3. Additional verification can be done via signature on first use
       """
       wallet_address = request.wallet_address.lower()
       
       # Find existing user
       user = db.query(User).filter(User.wallet_address == wallet_address).first()
       
       if not user:
           return {
               "status": "signup_required",
               "message": "User not found. Please complete signup.",
               "wallet_address": wallet_address
           }
       
       if not user.is_active:
           raise HTTPException(
               status_code=403,
               detail="Account is deactivated"
           )
       
       # Generate JWT tokens
       from app.auth.jwt_auth import create_access_token, create_refresh_token
       
       access_token = create_access_token(user.id)
       refresh_token = create_refresh_token(user.id)
       
       # Update last login
       user.last_login = datetime.utcnow()
       db.commit()
       
       log_audit_action(
           db, AuditAction.LOGIN, "user", user.id, user.id,
           metadata={"method": "wallet_auto_login", "wallet_address": wallet_address}
       )
       
       return {
           "status": "success",
           "access_token": access_token,
           "refresh_token": refresh_token,
           "token_type": "bearer",
           "user": user.to_dict()
       }
   ```

### Activity 1.3: Frontend Auto-Auth Hook

**Priority**: P0 (Critical)  
**Estimated Time**: 3 days  
**Dependencies**: Activity 1.2

#### File-Level Task 1.3.1: Create Auto-Auth Hook
**File**: `client/src/hooks/useAutoAuth.ts` (NEW FILE)

**Line-Level Subtasks**:
1. Create hook file with imports (lines 1-15):
   ```typescript
   import { useEffect, useState } from 'react';
   import { useWallet } from '@/context/WalletContext';
   import { useAuth } from '@/context/AuthContext';
   
   interface AutoAuthState {
     attempting: boolean;
     error: string | null;
   }
   ```

2. Implement auto-auth hook (lines 17-80):
   ```typescript
   export function useAutoAuth() {
     const { isConnected, account } = useWallet();
     const { user, login } = useAuth();
     const [state, setState] = useState<AutoAuthState>({
       attempting: false,
       error: null,
     });
     
     useEffect(() => {
       // Only attempt auto-login if:
       // 1. Wallet is connected
       // 2. User is not already logged in
       // 3. We haven't attempted yet
       if (isConnected && account && !user && !state.attempting) {
         attemptAutoLogin(account);
       }
     }, [isConnected, account, user, state.attempting]);
     
     const attemptAutoLogin = async (walletAddress: string) => {
       setState({ attempting: true, error: null });
       
       try {
         const response = await fetch('/api/auth/wallet/auto-login', {
           method: 'POST',
           headers: { 'Content-Type': 'application/json' },
           body: JSON.stringify({ wallet_address: walletAddress }),
         });
         
         const data = await response.json();
         
         if (data.status === 'success') {
           // Store tokens
           localStorage.setItem('access_token', data.access_token);
           if (data.refresh_token) {
             localStorage.setItem('refresh_token', data.refresh_token);
           }
           
           // Update auth context
           await login(data.user);
         } else if (data.status === 'signup_required') {
           // Trigger signup flow (can be handled by parent component)
           setState({ attempting: false, error: null });
           return { requiresSignup: true, walletAddress };
         }
       } catch (err) {
         setState({
           attempting: false,
           error: err instanceof Error ? err.message : 'Auto-login failed',
         });
       }
       
       setState(prev => ({ ...prev, attempting: false }));
       return { requiresSignup: false };
     };
     
     return { ...state, attemptAutoLogin };
   }
   ```

#### File-Level Task 1.3.2: Integrate Auto-Auth in App Root
**File**: `client/src/App.tsx` or main app component

**Line-Level Subtasks**:
1. Import useAutoAuth hook (line ~XX):
   ```typescript
   import { useAutoAuth } from '@/hooks/useAutoAuth';
   ```

2. Call hook in App component (line ~XX):
   ```typescript
   function App() {
     // ... existing code ...
     useAutoAuth(); // Enable automatic authentication
     // ... rest of component ...
   }
   ```

#### File-Level Task 1.3.3: Enhance WalletContext for Session Persistence
**File**: `client/src/context/WalletContext.tsx`

**Line-Level Subtasks**:
1. Add session persistence check (after line 30, in useEffect):
   ```typescript
   // Check localStorage for persisted wallet connection
   useEffect(() => {
     const persistedAccount = localStorage.getItem('last_connected_wallet');
     if (persistedAccount && typeof window.ethereum !== 'undefined') {
       // Attempt to reconnect
       checkConnection();
     }
   }, []);
   ```

2. Persist wallet on connection (after line 132, in connect function):
   ```typescript
   // Persist wallet address for session recovery
   localStorage.setItem('last_connected_wallet', accounts[0]);
   ```

3. Clear on disconnect (after line 140, in disconnect function):
   ```typescript
   localStorage.removeItem('last_connected_wallet');
   ```

### Activity 1.4: Enhanced Signup Flow

**Priority**: P1 (High)  
**Estimated Time**: 2 days  
**Dependencies**: Activity 1.1

#### File-Level Task 1.4.1: Create Wallet Signup Endpoint
**File**: `app/api/routes.py`

**Line-Level Subtasks**:
1. Add signup request model (after AutoLoginRequest):
   ```python
   class WalletSignupRequest(BaseModel):
       """Request model for wallet-based signup."""
       wallet_address: str = Field(..., description="Ethereum wallet address")
       signature: str = Field(..., description="Signature of signup message")
       message: str = Field(..., description="Message that was signed")
       email: Optional[str] = Field(None, description="Optional email address")
       display_name: Optional[str] = Field(None, description="Optional display name")
   ```

2. Create signup endpoint (after auto-login endpoint):
   ```python
   @router.post("/auth/wallet/signup")
   async def wallet_signup(
       request: WalletSignupRequest,
       db: Session = Depends(get_db)
   ):
       """Sign up new user with wallet address."""
       # Verify signature
       is_valid = verify_ethereum_signature(
           message=request.message,
           signature=request.signature,
           wallet_address=request.wallet_address
       )
       
       if not is_valid:
           raise HTTPException(
               status_code=401,
               detail="Invalid signature"
           )
       
       # Check if user already exists
       existing_user = db.query(User).filter(
           User.wallet_address == request.wallet_address.lower()
       ).first()
       
       if existing_user:
           raise HTTPException(
               status_code=400,
               detail="User with this wallet address already exists"
           )
       
       # Create new user
       user = User(
           email=request.email or f"{request.wallet_address[:8]}@wallet.local",
           display_name=request.display_name or f"Wallet {request.wallet_address[:8]}",
           wallet_address=request.wallet_address.lower(),
           role="viewer",
           is_active=True,
           is_email_verified=bool(request.email)  # Auto-verify if email provided
       )
       db.add(user)
       db.commit()
       db.refresh(user)
       
       # Generate tokens
       from app.auth.jwt_auth import create_access_token, create_refresh_token
       access_token = create_access_token(user.id)
       refresh_token = create_refresh_token(user.id)
       
       log_audit_action(
           db, AuditAction.CREATE, "user", user.id, user.id,
           metadata={"method": "wallet_signup", "wallet_address": request.wallet_address}
       )
       
       return {
           "status": "success",
           "access_token": access_token,
           "refresh_token": refresh_token,
           "token_type": "bearer",
           "user": user.to_dict()
       }
   ```

---

## PROJECT 2: Remote API Listener Infrastructure

### Activity 2.1: SSL Configuration & Certificate Management

**Priority**: P0 (Critical)  
**Estimated Time**: 3 days  
**Dependencies**: None

#### File-Level Task 2.1.1: Add SSL Configuration
**File**: `app/core/config.py`

**Line-Level Subtasks**:
1. Add remote API config section (after line 112, x402 config):
   ```python
   # Remote API Configuration
   REMOTE_API_ENABLED: bool = False
   REMOTE_API_PORT: int = 8443
   REMOTE_API_HOST: str = "0.0.0.0"
   REMOTE_API_SSL_CERT_PATH: Optional[Path] = None
   REMOTE_API_SSL_KEY_PATH: Optional[Path] = None
   REMOTE_API_SSL_CERT_CHAIN_PATH: Optional[Path] = None
   REMOTE_API_SSL_VERIFY_MODE: str = "required"  # required, optional, none
   ```

2. Add field validator for SSL paths (after line 174):
   ```python
   @field_validator('REMOTE_API_SSL_CERT_PATH', 'REMOTE_API_SSL_KEY_PATH', mode='before')
   @classmethod
   def validate_ssl_paths(cls, v, info):
       """Validate SSL certificate paths if remote API is enabled."""
       if info.data.get('REMOTE_API_ENABLED') and v:
           path = Path(v) if isinstance(v, str) else v
           if not path.exists():
               raise ValueError(f"SSL certificate path does not exist: {path}")
       return Path(v) if isinstance(v, str) and v else v
   ```

#### File-Level Task 2.1.2: Create SSL Configuration Utility
**File**: `app/utils/ssl_config.py` (NEW FILE)

**Line-Level Subtasks**:
1. Create SSL context loader (lines 1-50):
   ```python
   """SSL/TLS configuration utilities for remote API."""
   import ssl
   import logging
   from pathlib import Path
   from typing import Optional
   
   logger = logging.getLogger(__name__)
   
   def load_ssl_context(
       cert_path: Path,
       key_path: Path,
       chain_path: Optional[Path] = None,
       verify_mode: str = "required"
   ) -> ssl.SSLContext:
       """
       Load SSL context from certificate files.
       
       Args:
           cert_path: Path to certificate file (.pem, .crt)
           key_path: Path to private key file (.key, .pem)
           chain_path: Optional path to certificate chain file
           verify_mode: SSL verification mode (required, optional, none)
           
       Returns:
           Configured SSLContext
       """
       if not cert_path.exists():
           raise FileNotFoundError(f"Certificate file not found: {cert_path}")
       if not key_path.exists():
           raise FileNotFoundError(f"Key file not found: {key_path}")
       
       # Create SSL context
       context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
       
       # Load certificate and key
       context.load_cert_chain(str(cert_path), str(key_path))
       
       # Load certificate chain if provided
       if chain_path and chain_path.exists():
           context.load_verify_locations(str(chain_path))
       
       # Set verification mode
       if verify_mode == "required":
           context.verify_mode = ssl.CERT_REQUIRED
       elif verify_mode == "optional":
           context.verify_mode = ssl.CERT_OPTIONAL
       else:
           context.verify_mode = ssl.CERT_NONE
       
       # Set minimum TLS version
       context.minimum_version = ssl.TLSVersion.TLSv1_2
       
       # Set cipher suites (secure defaults)
       context.set_ciphers('HIGH:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!SRP:!CAMELLIA')
       
       logger.info(f"SSL context loaded: cert={cert_path}, key={key_path}")
       return context
   ```

2. Add certificate validation function (lines 52-80):
   ```python
   def validate_certificate_expiry(cert_path: Path, days_warning: int = 30) -> tuple[bool, Optional[str]]:
       """Validate certificate expiration."""
       # Implementation using cryptography library
       pass
   ```

#### File-Level Task 2.1.3: Integrate SSL in Server Startup
**File**: `server.py`

**Line-Level Subtasks**:
1. Import SSL utilities (after line 19):
   ```python
   from app.utils.ssl_config import load_ssl_context
   ```

2. Add remote API server creation (after line 471, after router includes):
   ```python
   # Remote API Server (if enabled)
   if settings.REMOTE_API_ENABLED:
       from app.api.remote_routes import remote_router
       from app.middleware.ip_whitelist import IPWhitelistMiddleware
       
       remote_app = FastAPI(
           title="CreditNexus Remote API",
           description="Remote verification and notarization API",
           version="1.0.0"
       )
       
       # Add IP whitelist middleware
       # (Will be implemented in Activity 2.2)
       
       # Include remote routes
       remote_app.include_router(remote_router)
       
       # Store in app state for access
       app.state.remote_app = remote_app
   ```

### Activity 2.2: IP Whitelisting Middleware

**Priority**: P0 (Critical)  
**Estimated Time**: 2 days  
**Dependencies**: Activity 2.1

#### File-Level Task 2.2.1: Create IP Whitelist Middleware
**File**: `app/middleware/ip_whitelist.py` (NEW FILE)

**Line-Level Subtasks**:
1. Create middleware class (lines 1-80):
   ```python
   """IP whitelist middleware for remote API."""
   import ipaddress
   import logging
   from typing import List, Optional
   from fastapi import Request, HTTPException, status
   from starlette.middleware.base import BaseHTTPMiddleware
   
   logger = logging.getLogger(__name__)
   
   class IPWhitelistMiddleware(BaseHTTPMiddleware):
       """Middleware to whitelist IP addresses for remote API."""
       
       def __init__(self, app, allowed_ips: List[str], allowed_cidrs: List[str] = None):
           super().__init__(app)
           self.allowed_ips = set()
           self.allowed_networks = []
           
           # Parse individual IPs
           for ip in allowed_ips:
               try:
                   self.allowed_ips.add(ipaddress.ip_address(ip))
               except ValueError:
                   logger.warning(f"Invalid IP address: {ip}")
           
           # Parse CIDR blocks
           if allowed_cidrs:
               for cidr in allowed_cidrs:
                   try:
                       self.allowed_networks.append(ipaddress.ip_network(cidr, strict=False))
                   except ValueError:
                       logger.warning(f"Invalid CIDR block: {cidr}")
       
       def extract_client_ip(self, request: Request) -> str:
           """Extract client IP from request, handling proxies."""
           # Check X-Forwarded-For header (for proxies/load balancers)
           forwarded_for = request.headers.get("X-Forwarded-For")
           if forwarded_for:
               # Take first IP (original client)
               return forwarded_for.split(",")[0].strip()
           
           # Check X-Real-IP header
           real_ip = request.headers.get("X-Real-IP")
           if real_ip:
               return real_ip.strip()
           
           # Fallback to direct client
           if request.client:
               return request.client.host
           
           return "unknown"
       
       async def dispatch(self, request: Request, call_next):
           """Check IP against whitelist."""
           client_ip = self.extract_client_ip(request)
           
           if client_ip == "unknown":
               logger.warning("Could not determine client IP")
               raise HTTPException(
                   status_code=status.HTTP_403_FORBIDDEN,
                   detail="Could not determine client IP address"
               )
           
           try:
               ip_obj = ipaddress.ip_address(client_ip)
           except ValueError:
               logger.warning(f"Invalid IP address format: {client_ip}")
               raise HTTPException(
                   status_code=status.HTTP_403_FORBIDDEN,
                   detail="Invalid IP address format"
               )
           
           # Check against individual IPs
           if ip_obj in self.allowed_ips:
               return await call_next(request)
           
           # Check against CIDR blocks
           for network in self.allowed_networks:
               if ip_obj in network:
                   return await call_next(request)
           
           # IP not whitelisted
           logger.warning(f"Blocked request from non-whitelisted IP: {client_ip}")
           raise HTTPException(
               status_code=status.HTTP_403_FORBIDDEN,
               detail=f"IP address {client_ip} is not whitelisted"
           )
   ```

### Activity 2.3: Profile-Based Access Control

**Priority**: P0 (Critical)  
**Estimated Time**: 3 days  
**Dependencies**: None

#### File-Level Task 2.3.1: Create RemoteAppProfile Model
**File**: `app/db/models.py`

**Line-Level Subtasks**:
1. Add RemoteAppProfile model (after DealNote class, ~line 1200):
   ```python
   class RemoteAppProfile(Base):
       """Remote app profile for API key authentication."""
       
       __tablename__ = "remote_app_profiles"
       
       id = Column(Integer, primary_key=True, autoincrement=True)
       profile_name = Column(String(100), unique=True, nullable=False, index=True)
       api_key_hash = Column(String(255), nullable=False)  # bcrypt hash
       allowed_ips = Column(JSONB, nullable=True)  # Array of IPs/CIDRs
       permissions = Column(JSONB, nullable=False)  # {"read": bool, "verify": bool, "sign": bool}
       is_active = Column(Boolean, default=True, nullable=False)
       created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
       updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
       
       def to_dict(self):
           return {
               "id": self.id,
               "profile_name": self.profile_name,
               "allowed_ips": self.allowed_ips,
               "permissions": self.permissions,
               "is_active": self.is_active,
               "created_at": self.created_at.isoformat() if self.created_at else None,
           }
   ```

2. Create Alembic migration:
   ```bash
   uv run alembic revision -m "add_remote_app_profiles_table"
   ```

#### File-Level Task 2.3.2: Create Remote Profile Service
**File**: `app/services/remote_profile_service.py` (NEW FILE)

**Line-Level Subtasks**:
1. Implement profile service (lines 1-100):
   ```python
   """Service for managing remote app profiles."""
   from typing import Optional
   from sqlalchemy.orm import Session
   from app.db.models import RemoteAppProfile
   from app.auth.jwt_auth import verify_password, get_password_hash
   import ipaddress
   import logging
   
   logger = logging.getLogger(__name__)
   
   class RemoteProfileService:
       """Service for remote app profile management."""
       
       def __init__(self, db: Session):
           self.db = db
       
       def validate_api_key(self, api_key: str) -> Optional[RemoteAppProfile]:
           """Validate API key and return profile if valid."""
           profiles = self.db.query(RemoteAppProfile).filter(
               RemoteAppProfile.is_active == True
           ).all()
           
           for profile in profiles:
               if verify_password(api_key, profile.api_key_hash):
                   return profile
           
           return None
       
       def check_permission(self, profile: RemoteAppProfile, permission: str) -> bool:
           """Check if profile has specific permission."""
           perms = profile.permissions or {}
           return perms.get(permission, False)
       
       def validate_ip(self, profile: RemoteAppProfile, client_ip: str) -> bool:
           """Validate client IP against profile's allowed IPs."""
           if not profile.allowed_ips:
               return True  # No IP restriction
           
           try:
               ip_obj = ipaddress.ip_address(client_ip)
           except ValueError:
               return False
           
           for ip_rule in profile.allowed_ips:
               # Check individual IP
               try:
                   if ip_obj == ipaddress.ip_address(ip_rule):
                       return True
               except ValueError:
                   pass
               
               # Check CIDR block
               try:
                   network = ipaddress.ip_network(ip_rule, strict=False)
                   if ip_obj in network:
                       return True
               except ValueError:
                   pass
           
           return False
   ```

#### File-Level Task 2.3.3: Create Remote Authentication Dependency
**File**: `app/auth/remote_auth.py` (NEW FILE)

**Line-Level Subtasks**:
1. Create authentication dependency (lines 1-60):
   ```python
   """Authentication for remote API endpoints."""
   from fastapi import Header, HTTPException, Request, Depends, status
   from sqlalchemy.orm import Session
   from app.db import get_db
   from app.db.models import RemoteAppProfile
   from app.services.remote_profile_service import RemoteProfileService
   from app.middleware.ip_whitelist import IPWhitelistMiddleware
   
   async def get_remote_profile(
       api_key: str = Header(..., alias="X-API-Key"),
       request: Request,
       db: Session = Depends(get_db)
   ) -> RemoteAppProfile:
       """Dependency to authenticate remote API requests."""
       if not api_key:
           raise HTTPException(
               status_code=status.HTTP_401_UNAUTHORIZED,
               detail="X-API-Key header is required"
           )
       
       service = RemoteProfileService(db)
       profile = service.validate_api_key(api_key)
       
       if not profile:
           raise HTTPException(
               status_code=status.HTTP_401_UNAUTHORIZED,
               detail="Invalid API key"
           )
       
       # Validate IP address
       client_ip = request.client.host if request.client else "unknown"
       if not service.validate_ip(profile, client_ip):
           raise HTTPException(
               status_code=status.HTTP_403_FORBIDDEN,
               detail=f"IP address {client_ip} not allowed for this profile"
           )
       
       return profile
   ```

### Activity 2.4: Remote API Router Setup

**Priority**: P0 (Critical)  
**Estimated Time**: 2 days  
**Dependencies**: Activities 2.1, 2.2, 2.3

#### File-Level Task 2.4.1: Create Remote Routes
**File**: `app/api/remote_routes.py` (NEW FILE)

**Line-Level Subtasks**:
1. Create router with basic structure (lines 1-50):
   ```python
   """Remote API routes for verification and notarization."""
   from fastapi import APIRouter, Depends, HTTPException, status
   from sqlalchemy.orm import Session
   from app.db import get_db
   from app.db.models import RemoteAppProfile
   from app.auth.remote_auth import get_remote_profile
   
   remote_router = APIRouter(prefix="/remote", tags=["remote"])
   
   # Placeholder endpoints - will be implemented in Project 3
   @remote_router.get("/health")
   async def remote_health_check(
       profile: RemoteAppProfile = Depends(get_remote_profile)
   ):
       """Health check endpoint for remote API."""
       return {
           "status": "healthy",
           "profile": profile.profile_name
       }
   ```

2. Add verification endpoints (will be detailed in Project 3)

---

## PROJECT 3: Verification Workflow

### Activity 3.1: Verification Request Model & Service

**Priority**: P0 (Critical)  
**Estimated Time**: 3 days  
**Dependencies**: None

#### File-Level Task 3.1.1: Create VerificationRequest Model
**File**: `app/db/models.py`

**Line-Level Subtasks**:
1. Add VerificationRequest model (after RemoteAppProfile):
   ```python
   class VerificationRequest(Base):
       """Verification request for deal verification."""
       
       __tablename__ = "verification_requests"
       
       id = Column(Integer, primary_key=True, autoincrement=True)
       verification_id = Column(String(36), unique=True, nullable=False, index=True)  # UUID
       deal_id = Column(Integer, ForeignKey("deals.id", ondelete="CASCADE"), nullable=False, index=True)
       verifier_user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
       verification_link_token = Column(String(255), unique=True, nullable=False, index=True)
       status = Column(String(20), default="pending", nullable=False, index=True)  # pending, accepted, declined, expired
       expires_at = Column(DateTime, nullable=False)
       accepted_at = Column(DateTime, nullable=True)
       declined_at = Column(DateTime, nullable=True)
       declined_reason = Column(Text, nullable=True)
       verification_metadata = Column(JSONB, nullable=True)
       created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
       created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
       updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
       
       # Relationships
       deal = relationship("Deal", backref="verification_requests")
       verifier = relationship("User", foreign_keys=[verifier_user_id])
       creator = relationship("User", foreign_keys=[created_by])
   ```

2. Create Alembic migration

#### File-Level Task 3.1.2: Create Verification Service
**File**: `app/services/verification_service.py` (NEW FILE)

**Line-Level Subtasks**:
1. Implement service class (lines 1-200):
   ```python
   """Service for managing verification requests."""
   import uuid
   import secrets
   import hmac
   import hashlib
   from datetime import datetime, timedelta
   from typing import Optional, Dict, Any
   from sqlalchemy.orm import Session
   from app.db.models import VerificationRequest, Deal, User
   from app.utils.verification_tokens import generate_verification_token
   
   class VerificationService:
       def __init__(self, db: Session):
           self.db = db
       
       def create_verification_request(
           self,
           deal_id: int,
           verifier_user_id: Optional[int] = None,
           expires_in_hours: int = 72,
           created_by: Optional[int] = None
       ) -> VerificationRequest:
           """Create new verification request."""
           # Implementation details...
           pass
       
       def generate_verification_link(self, verification: VerificationRequest) -> str:
           """Generate shareable verification link."""
           # Implementation details...
           pass
       
       # ... more methods ...
   ```

---

## PROJECT 4: MetaMask Notarization

### Activity 4.1: Notarization Service

**Priority**: P0 (Critical)  
**Estimated Time**: 3 days  
**Dependencies**: Activity 1.1 (crypto verification)

#### File-Level Task 4.1.1: Create NotarizationRecord Model
**File**: `app/db/models.py`

**Line-Level Subtasks**:
1. Add NotarizationRecord model (similar structure to VerificationRequest)

#### File-Level Task 4.1.2: Create Notarization Service
**File**: `app/services/notarization_service.py` (NEW FILE)

**Line-Level Subtasks**:
1. Implement notarization service with MetaMask integration

---

## Testing Strategy

### Unit Tests
- `tests/test_crypto_verification.py` - Signature verification tests
- `tests/test_remote_auth.py` - Remote authentication tests
- `tests/test_verification_service.py` - Verification service tests
- `tests/test_notarization_service.py` - Notarization service tests

### Integration Tests
- `tests/integration/test_metamask_hot_login.py` - End-to-end hot login flow
- `tests/integration/test_verification_workflow.py` - Complete verification flow
- `tests/integration/test_notarization_flow.py` - Notarization with MetaMask

---

## Deployment Checklist

### Pre-Deployment
- [ ] SSL certificates obtained and configured
- [ ] Remote app profiles created via admin script
- [ ] IP whitelists configured
- [ ] Database migrations applied
- [ ] Environment variables set
- [ ] MetaMask integration tested in staging

### Deployment
- [ ] Remote API server started on SSL port
- [ ] Main API server running
- [ ] Both servers health-checked
- [ ] SSL certificate validation
- [ ] IP whitelisting tested
- [ ] MetaMask hot login tested
- [ ] Verification links tested
- [ ] Notarization flow tested

---

## Risk Mitigation

### Identified Risks
1. **MetaMask Extension Not Available**: Graceful fallback to email login
2. **Signature Verification Failures**: Comprehensive error handling and logging
3. **SSL Certificate Expiration**: Automated monitoring and alerts
4. **IP Whitelist Bypass**: Regular security audits, rate limiting
5. **Session Hijacking**: Secure token storage, short expiration times

### Mitigation Strategies
- Comprehensive logging and monitoring
- Regular security audits
- Automated testing in CI/CD
- Incident response plan
- Backup authentication methods

---

## PROJECT 3: Verification Workflow (Continued)

### Activity 3.2: Verification API Endpoints

**Priority**: P0 (Critical)  
**Estimated Time**: 2 days  
**Dependencies**: Activity 3.1

#### File-Level Task 3.2.1: Add Verification Endpoints to Remote Routes
**File**: `app/api/remote_routes.py`

**Line-Level Subtasks**:
1. Add verification endpoints (after health check, lines 51-150):
   ```python
   @remote_router.get("/verification/{verification_id}")
   async def get_verification_details(
       verification_id: str,
       profile: RemoteAppProfile = Depends(get_remote_profile),
       db: Session = Depends(get_db)
   ):
       """Get verification request details."""
       # Check permission
       if not profile.permissions.get("read", False):
           raise HTTPException(
               status_code=status.HTTP_403_FORBIDDEN,
               detail="Read permission required"
           )
       
       # Implementation...
       pass
   
   @remote_router.post("/verification/{verification_id}/accept")
   async def accept_verification(
       verification_id: str,
       profile: RemoteAppProfile = Depends(get_remote_profile),
       db: Session = Depends(get_db)
   ):
       """Accept verification request."""
       # Check permission
       if not profile.permissions.get("verify", False):
           raise HTTPException(
               status_code=status.HTTP_403_FORBIDDEN,
               detail="Verify permission required"
           )
       
       # Implementation...
       pass
   ```

### Activity 3.3: Link Generation & Security (Enhanced for Self-Contained Links)

**Priority**: P0 (Critical)  
**Estimated Time**: 3 days  
**Dependencies**: Activity 3.1

#### File-Level Task 3.3.1: Create Link Payload Generator (Moved to Activity 4.1)
**Note**: This task is now part of Activity 4.1 (Enhanced Link Generation). See PROJECT 4 below.

#### File-Level Task 3.3.2: Create Link Validation Endpoint
**File**: `app/api/remote_routes.py`

**Line-Level Subtasks**:
1. Add link validation endpoint (after health check):
   ```python
   @remote_router.get("/verify/{payload}")
   async def validate_verification_link(
       payload: str,
       db: Session = Depends(get_db)
   ):
       """
       Validate and parse verification link payload.
       
       This endpoint extracts all information from the encrypted payload
       without requiring database lookup. The payload is self-contained.
       """
       from app.utils.link_payload import LinkPayloadGenerator
       
       payload_generator = LinkPayloadGenerator()
       link_data = payload_generator.parse_verification_link_payload(payload)
       
       if not link_data:
           raise HTTPException(
               status_code=400,
               detail="Invalid or expired verification link"
           )
       
       # Return all data needed for verification UI
       return {
           "status": "valid",
           "verification_id": link_data["verification_id"],
           "deal_id": link_data["deal_id"],
           "deal_data": link_data["deal_data"],
           "cdm_payload": link_data["cdm_payload"],
           "verifier_info": link_data.get("verifier_info", {}),
           "expires_at": link_data["expires_at"]
       }
   ```

### Activity 3.4: Frontend Verification Interface (Self-Contained Link Support)

**Priority**: P1 (High)  
**Estimated Time**: 3 days  
**Dependencies**: Activity 3.2, Activity 4.1

#### File-Level Task 3.4.1: Create Verification Page Component
**File**: `client/src/apps/verification/VerificationPage.tsx` (NEW FILE)

**Line-Level Subtasks**:
1. Create component that loads data from link payload (lines 1-150):
   ```typescript
   import { useState, useEffect } from 'react';
   import { useParams, useNavigate } from 'react-router-dom';
   import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
   import { Button } from '@/components/ui/button';
   
   interface VerificationData {
     verification_id: string;
     deal_id: number;
     deal_data: any;
     cdm_payload: any;
     verifier_info: any;
     expires_at: string;
   }
   
   export function VerificationPage() {
     const { payload } = useParams<{ payload: string }>();
     const navigate = useNavigate();
     const [loading, setLoading] = useState(true);
     const [verification, setVerification] = useState<VerificationData | null>(null);
     const [error, setError] = useState<string | null>(null);
     
     useEffect(() => {
       if (payload) {
         loadVerificationFromPayload(payload);
       }
     }, [payload]);
     
     const loadVerificationFromPayload = async (payload: string) => {
       setLoading(true);
       setError(null);
       
       try {
         // Call endpoint to validate and parse payload
         const response = await fetch(`/api/remote/verify/${payload}`);
         
         if (!response.ok) {
           const errorData = await response.json();
           throw new Error(errorData.detail || 'Invalid verification link');
         }
         
         const data = await response.json();
         setVerification(data);
       } catch (err) {
         setError(err instanceof Error ? err.message : 'Failed to load verification');
       } finally {
         setLoading(false);
       }
     };
     
     const handleAccept = async () => {
       if (!verification) return;
       
       // Call accept endpoint
       const response = await fetch(
         `/api/remote/verification/${verification.verification_id}/accept`,
         { method: 'POST' }
       );
       
       if (response.ok) {
         // Show success and redirect
         navigate('/verification/success');
       }
     };
     
     // Render verification UI with embedded data
     // No additional API calls needed - all data is in the link
   }
   ```

---

## PROJECT 4: Self-Contained Link Generation (Replaces Messenger Integration)

**Note**: CreditNexus does NOT send messages/emails. Instead, it generates self-contained links with all necessary information embedded. These links can be shared via any external channel (email, Slack, Teams, WhatsApp, etc.) by users or external systems.

### Activity 4.1: Enhanced Link Generation with Embedded Data

**Priority**: P0 (Critical)  
**Estimated Time**: 4 days  
**Dependencies**: Activity 3.1

#### File-Level Task 4.1.1: Create Encrypted Link Payload Generator
**File**: `app/utils/link_payload.py` (NEW FILE)

**Line-Level Subtasks**:
1. Create encrypted payload generator (lines 1-150):
   ```python
   """Generate self-contained verification links with embedded data."""
   from cryptography.fernet import Fernet
   import json
   import base64
   from datetime import datetime, timedelta
   from typing import Dict, Any, Optional
   from app.core.config import settings
   import logging
   
   logger = logging.getLogger(__name__)
   
   class LinkPayloadGenerator:
       """Generate and parse encrypted link payloads."""
       
       def __init__(self):
           # Get encryption key from settings or generate
           key = getattr(settings, 'LINK_ENCRYPTION_KEY', None)
           if not key:
               # Generate key (should be set in production)
               key = Fernet.generate_key()
               logger.warning("LINK_ENCRYPTION_KEY not set, using generated key (not persistent)")
           self.cipher = Fernet(key)
       
       def generate_verification_link_payload(
           self,
           verification_id: str,
           deal_id: int,
           deal_data: Dict[str, Any],
           cdm_payload: Dict[str, Any],
           verifier_info: Optional[Dict[str, Any]] = None,
           file_references: Optional[List[Dict[str, Any]]] = None,
           expires_in_hours: int = 72
       ) -> str:
           """
           Generate encrypted payload for verification link.
           
           The payload contains all information needed for verification:
           - Verification ID
           - Deal information
           - CDM payload
           - Verifier information
           - File references (configurable via YAML whitelist)
           - Expiration timestamp
           
           Args:
               file_references: List of file metadata to include:
                   [{"document_id": 123, "filename": "agreement.pdf", "category": "legal", ...}]
           
           Returns base64url-encoded encrypted payload.
           """
           expires_at = (datetime.utcnow() + timedelta(hours=expires_in_hours)).isoformat()
           
           payload = {
               "verification_id": verification_id,
               "deal_id": deal_id,
               "deal_data": deal_data,
               "cdm_payload": cdm_payload,
               "verifier_info": verifier_info or {},
               "file_references": file_references or [],  # NEW: File references
               "expires_at": expires_at,
               "created_at": datetime.utcnow().isoformat(),
               "version": "1.0"
           }
           
           # Serialize to JSON
           json_payload = json.dumps(payload, sort_keys=True)
           
           # Encrypt
           encrypted = self.cipher.encrypt(json_payload.encode('utf-8'))
           
           # Base64url encode (URL-safe)
           encoded = base64.urlsafe_b64encode(encrypted).decode('utf-8').rstrip('=')
           
           return encoded
       
       def parse_verification_link_payload(self, payload: str) -> Optional[Dict[str, Any]]:
           """
           Parse and decrypt verification link payload.
           
           Returns None if payload is invalid or expired.
           """
           try:
               # Add padding if needed
               padding = 4 - len(payload) % 4
               if padding != 4:
                   payload += '=' * padding
               
               # Base64url decode
               encrypted = base64.urlsafe_b64decode(payload)
               
               # Decrypt
               decrypted = self.cipher.decrypt(encrypted)
               
               # Deserialize JSON
               data = json.loads(decrypted.decode('utf-8'))
               
               # Check expiration
               expires_at = datetime.fromisoformat(data['expires_at'])
               if datetime.utcnow() > expires_at:
                   logger.warning(f"Link payload expired: {data.get('verification_id')}")
                   return None
               
               return data
           except Exception as e:
               logger.error(f"Failed to parse link payload: {e}")
               return None
   ```

#### File-Level Task 4.1.2: Enhance Verification Service with Link Generation
**File**: `app/services/verification_service.py`

**Line-Level Subtasks**:
1. Update generate_verification_link method (lines 50-100):
   ```python
   def generate_verification_link(
       self,
       verification: VerificationRequest,
       base_url: Optional[str] = None
   ) -> str:
       """
       Generate self-contained verification link with embedded data.
       
       The link contains all information needed for verification:
       - Deal details
       - CDM payload
       - Verification metadata
       
       No database lookup required when link is accessed.
       """
       from app.utils.link_payload import LinkPayloadGenerator
       from app.services.deal_service import DealService
       
       # Get deal and CDM data
       deal = self.db.query(Deal).filter(Deal.id == verification.deal_id).first()
       if not deal:
           raise ValueError(f"Deal {verification.deal_id} not found")
       
       deal_service = DealService(self.db)
       deal_data = deal.to_dict()
       
       # Get CDM payload for deal
       cdm_payload = self._get_deal_cdm_payload(deal)
       
       # Generate encrypted payload
       payload_generator = LinkPayloadGenerator()
       encrypted_payload = payload_generator.generate_verification_link_payload(
           verification_id=str(verification.verification_id),
           deal_id=deal.id,
           deal_data=deal_data,
           cdm_payload=cdm_payload,
           verifier_info={
               "user_id": verification.verifier_user_id,
               "created_by": verification.created_by
           } if verification.verifier_user_id else None,
           expires_in_hours=72
       )
       
       # Generate base URL if not provided
       if not base_url:
           from app.core.config import settings
           base_url = getattr(settings, 'VERIFICATION_BASE_URL', 'https://verify.creditnexus.app')
       
       # Construct full URL
       link = f"{base_url}/verify/{encrypted_payload}"
       
       return link
   ```

#### File-Level Task 4.1.3: Create File Whitelist Configuration System
**File**: `app/core/verification_file_config.py` (NEW FILE)

**Line-Level Subtasks**:
1. Create YAML-based file whitelist loader (lines 1-150):
   ```python
   """File whitelist configuration for verification links."""
   import yaml
   import logging
   from pathlib import Path
   from typing import List, Dict, Any, Optional
   from app.core.config import Settings
   
   logger = logging.getLogger(__name__)
   
   class VerificationFileConfig:
       """Loads and manages file whitelist configuration from YAML."""
       
       def __init__(self, config_path: Optional[Path] = None):
           if not config_path:
               config_path = Path("app/config/verification_file_whitelist.yaml")
           self.config_path = config_path
           self._config: Optional[Dict[str, Any]] = None
           self._load_config()
       
       def _load_config(self):
           """Load configuration from YAML file."""
           if not self.config_path.exists():
               logger.warning(f"File whitelist config not found: {self.config_path}, using defaults")
               self._config = self._get_default_config()
               return
           
           try:
               with open(self.config_path, 'r', encoding='utf-8') as f:
                   self._config = yaml.safe_load(f) or {}
           except Exception as e:
               logger.error(f"Failed to load file whitelist config: {e}")
               self._config = self._get_default_config()
       
       def _get_default_config(self) -> Dict[str, Any]:
           """Get default configuration."""
           return {
               "enabled_categories": ["legal", "financial", "compliance"],
               "file_types": {
                   "allowed_extensions": [".pdf", ".doc", ".docx", ".txt", ".json"],
                   "max_file_size_mb": 50
               },
               "categories": {
                   "legal": {
                       "enabled": True,
                       "required": True,
                       "file_types": [".pdf", ".doc", ".docx"]
                   },
                   "financial": {
                       "enabled": True,
                       "required": False,
                       "file_types": [".pdf", ".xlsx", ".csv"]
                   },
                   "compliance": {
                       "enabled": True,
                       "required": False,
                       "file_types": [".pdf", ".doc"]
                   },
                   "supporting": {
                       "enabled": False,
                       "required": False,
                       "file_types": [".pdf", ".jpg", ".png"]
                   }
               },
               "subdirectories": {
                   "documents": {"enabled": True, "priority": 1},
                   "extractions": {"enabled": True, "priority": 2},
                   "generated": {"enabled": False, "priority": 3},
                   "notes": {"enabled": False, "priority": 4}
               }
           }
       
       def is_file_allowed(self, filename: str, category: Optional[str] = None) -> bool:
           """Check if file is allowed based on whitelist."""
           if not self._config:
               return True  # Allow all if no config
           
           # Check extension
           ext = Path(filename).suffix.lower()
           allowed_exts = self._config.get("file_types", {}).get("allowed_extensions", [])
           if ext not in allowed_exts:
               return False
           
           # Check category if specified
           if category:
               cat_config = self._config.get("categories", {}).get(category, {})
               if not cat_config.get("enabled", False):
                   return False
               cat_file_types = cat_config.get("file_types", [])
               if cat_file_types and ext not in cat_file_types:
                   return False
           
           return True
       
       def get_enabled_categories(self) -> List[str]:
           """Get list of enabled categories."""
           if not self._config:
               return []
           return [
               cat for cat, config in self._config.get("categories", {}).items()
               if config.get("enabled", False)
           ]
       
       def get_required_categories(self) -> List[str]:
           """Get list of required categories."""
           if not self._config:
               return []
           return [
               cat for cat, config in self._config.get("categories", {}).items()
               if config.get("required", False)
           ]
       
       def get_enabled_subdirectories(self) -> List[str]:
           """Get list of enabled subdirectories."""
           if not self._config:
               return ["documents"]
           return [
               subdir for subdir, config in self._config.get("subdirectories", {}).items()
               if config.get("enabled", True)
           ]
   ```

#### File-Level Task 4.1.4: Create Link Format Specification
**File**: `docs/verification-link-format.md` (NEW FILE)

**Line-Level Subtasks**:
1. Document link format with file references (lines 1-120):
   ```markdown
   # Verification Link Format Specification
   
   ## Link Structure
   
   ```
   https://verify.creditnexus.app/verify/{encrypted_payload}
   ```
   
   Where `{encrypted_payload}` is a base64url-encoded, Fernet-encrypted JSON payload.
   
   ## Payload Structure
   
   The decrypted payload contains:
   ```json
   {
     "verification_id": "uuid",
     "deal_id": 123,
     "deal_data": { ... },
     "cdm_payload": { ... },
     "verifier_info": { ... },
     "file_references": [
       {
         "document_id": 456,
         "filename": "credit_agreement.pdf",
         "category": "legal",
         "subdirectory": "documents",
         "size": 1024000,
         "download_url": "/api/deals/123/files/456"
       }
     ],
     "expires_at": "2024-12-31T23:59:59",
     "created_at": "2024-12-01T00:00:00",
     "version": "1.0"
   }
   ```
   
   ## File References
   
   Files are included based on YAML whitelist configuration:
   - Categories: legal, financial, compliance, supporting
   - File types: .pdf, .doc, .docx, .txt, .json
   - Subdirectories: documents, extractions, generated, notes
   - Configurable via `app/config/verification_file_whitelist.yaml`
   
   ## Security
   
   - Payload is encrypted using Fernet (symmetric encryption)
   - Encryption key stored in `LINK_ENCRYPTION_KEY` environment variable
   - Links expire after 72 hours (configurable)
   - Base64url encoding ensures URL-safe characters
   - File access controlled via download URLs with authentication
   
   ## Usage
   
   Links can be shared via any channel:
   - Email (user copies/pastes)
   - Slack/Teams messages
   - WhatsApp/SMS
   - QR codes
   - Any other communication method
   
   CreditNexus does NOT send these links automatically.
   ```

---

## PROJECT 5: Link Creation UI & File Configuration

**Note**: CreditNexus generates links but does NOT send messages. Users or external systems share links via their preferred channels.

### Activity 5.1: Link Generation API with File Selection

**Priority**: P0 (Critical)  
**Estimated Time**: 2 days  
**Dependencies**: Activity 4.1

#### File-Level Task 5.1.1: Create Link Generation Endpoint with File Selection
**File**: `app/api/routes.py`

**Line-Level Subtasks**:
1. Add link generation request model (after verification endpoints):
   ```python
   class GenerateVerificationLinkRequest(BaseModel):
       """Request model for generating verification link with file selection."""
       verification_id: str
       include_files: bool = True  # Whether to include files in link
       file_categories: Optional[List[str]] = None  # Specific categories to include
       file_document_ids: Optional[List[int]] = None  # Specific document IDs to include
       expires_in_hours: int = 72
   ```

2. Add link generation endpoint (after verification endpoints):
   ```python
   @router.post("/verification/{verification_id}/generate-link")
   async def generate_verification_link(
       verification_id: str,
       request: GenerateVerificationLinkRequest,
       db: Session = Depends(get_db),
       current_user: User = Depends(require_auth)
   ):
       """
       Generate self-contained verification link with configurable file inclusion.
       
       Files are included based on:
       1. YAML whitelist configuration
       2. Request parameters (categories, document IDs)
       3. File access permissions
       
       Returns a link that can be shared via any external channel.
       CreditNexus does NOT send the link - user must share it.
       """
       from app.services.verification_service import VerificationService
       from app.core.verification_file_config import VerificationFileConfig
       from app.services.file_storage_service import FileStorageService
       
       service = VerificationService(db)
       verification = service.get_verification_by_id(verification_id)
       
       if not verification:
           raise HTTPException(404, "Verification not found")
       
       # Get deal
       deal = db.query(Deal).filter(Deal.id == verification.deal_id).first()
       if not deal:
           raise HTTPException(404, "Deal not found")
       
       # Get file references if requested
       file_references = []
       if request.include_files:
           file_config = VerificationFileConfig()
           file_storage = FileStorageService()
           
           # Get deal documents
           deal_documents = file_storage.get_deal_documents(
               user_id=deal.applicant_id,
               deal_id=deal.deal_id,
               subdirectory=None  # Get from all enabled subdirectories
           )
           
           # Filter based on whitelist and request
           for doc_file in deal_documents:
               filename = doc_file["filename"]
               subdir = doc_file["subdirectory"]
               
               # Check if subdirectory is enabled
               enabled_subdirs = file_config.get_enabled_subdirectories()
               if subdir not in enabled_subdirs:
                   continue
               
               # Extract document ID from filename (format: {document_id}_{filename})
               try:
                   doc_id = int(filename.split('_')[0])
               except (ValueError, IndexError):
                   continue
               
               # Get document metadata
               document = db.query(Document).filter(Document.id == doc_id).first()
               if not document:
                   continue
               
               # Check category filter
               if request.file_categories:
                   # Assume category is stored in document metadata or inferred
                   doc_category = self._infer_document_category(document)
                   if doc_category not in request.file_categories:
                       continue
               
               # Check document ID filter
               if request.file_document_ids and doc_id not in request.file_document_ids:
                   continue
               
               # Check if file type is allowed
               if not file_config.is_file_allowed(filename):
                   continue
               
               # Add file reference
               file_references.append({
                   "document_id": doc_id,
                   "filename": filename.replace(f"{doc_id}_", ""),  # Remove prefix
                   "category": self._infer_document_category(document),
                   "subdirectory": subdir,
                   "size": doc_file["size"],
                   "download_url": f"/api/deals/{deal.id}/files/{doc_id}",
                   "title": document.title
               })
       
       # Generate self-contained link with file references
       link = service.generate_verification_link(
           verification,
           file_references=file_references if request.include_files else None
       )
       
       return {
           "status": "success",
           "link": link,
           "verification_id": verification_id,
           "expires_at": verification.expires_at.isoformat(),
           "files_included": len(file_references),
           "instructions": "Share this link via email, Slack, Teams, or any other channel"
       }
   ```

#### File-Level Task 5.1.2: Create Link Creation UI Component
**File**: `client/src/components/VerificationLinkCreator.tsx` (NEW FILE)

**Line-Level Subtasks**:
1. Create link creator component with file selection (lines 1-300):
   ```typescript
   import { useState, useEffect } from 'react';
   import { Button } from '@/components/ui/button';
   import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
   import { Checkbox } from '@/components/ui/checkbox';
   import { Copy, Check, Share2, FileText, Settings } from 'lucide-react';
   
   interface Document {
     id: number;
     title: string;
     filename: string;
     category: string;
     subdirectory: string;
     size: number;
   }
   
   interface VerificationLinkCreatorProps {
     dealId: number;
     verificationId: string;
     onLinkGenerated?: (link: string) => void;
   }
   
   export function VerificationLinkCreator({
     dealId,
     verificationId,
     onLinkGenerated
   }: VerificationLinkCreatorProps) {
     const [includeFiles, setIncludeFiles] = useState(true);
     const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
     const [selectedDocuments, setSelectedDocuments] = useState<number[]>([]);
     const [availableDocuments, setAvailableDocuments] = useState<Document[]>([]);
     const [availableCategories, setAvailableCategories] = useState<string[]>([]);
     const [loading, setLoading] = useState(false);
     const [generatedLink, setGeneratedLink] = useState<string | null>(null);
     const [copied, setCopied] = useState(false);
     
     useEffect(() => {
       loadDocuments();
       loadCategories();
     }, [dealId]);
     
     const loadDocuments = async () => {
       const response = await fetch(`/api/deals/${dealId}/documents`);
       if (response.ok) {
         const docs = await response.json();
         setAvailableDocuments(docs);
       }
     };
     
     const loadCategories = async () => {
       const response = await fetch('/api/config/verification-file-categories');
       if (response.ok) {
         const cats = await response.json();
         setAvailableCategories(cats);
         setSelectedCategories(cats); // Select all by default
       }
     };
     
     const handleGenerateLink = async () => {
       setLoading(true);
       try {
         const response = await fetch(
           `/api/verification/${verificationId}/generate-link`,
           {
             method: 'POST',
             headers: { 'Content-Type': 'application/json' },
             body: JSON.stringify({
               verification_id: verificationId,
               include_files: includeFiles,
               file_categories: includeFiles ? selectedCategories : null,
               file_document_ids: includeFiles ? selectedDocuments : null,
               expires_in_hours: 72
             })
           }
         );
         
         if (!response.ok) {
           throw new Error('Failed to generate link');
         }
         
         const data = await response.json();
         setGeneratedLink(data.link);
         onLinkGenerated?.(data.link);
       } catch (err) {
         console.error('Failed to generate link:', err);
       } finally {
         setLoading(false);
       }
     };
     
     const handleCopy = async () => {
       if (generatedLink) {
         await navigator.clipboard.writeText(generatedLink);
         setCopied(true);
         setTimeout(() => setCopied(false), 2000);
       }
     };
     
     return (
       <Card className="bg-slate-800 border-slate-700">
         <CardHeader>
           <CardTitle className="flex items-center gap-2">
             <FileText className="h-5 w-5" />
             Create Verification Link
           </CardTitle>
         </CardHeader>
         <CardContent className="space-y-6">
           {/* File Inclusion Toggle */}
           <div className="flex items-center gap-2">
             <Checkbox
               checked={includeFiles}
               onCheckedChange={setIncludeFiles}
             />
             <label>Include relevant files in verification link</label>
           </div>
           
           {/* Category Selection */}
           {includeFiles && (
             <div className="space-y-2">
               <h4 className="text-sm font-semibold">File Categories</h4>
               <div className="grid grid-cols-2 gap-2">
                 {availableCategories.map(cat => (
                   <div key={cat} className="flex items-center gap-2">
                     <Checkbox
                       checked={selectedCategories.includes(cat)}
                       onCheckedChange={(checked) => {
                         if (checked) {
                           setSelectedCategories([...selectedCategories, cat]);
                         } else {
                           setSelectedCategories(selectedCategories.filter(c => c !== cat));
                         }
                       }}
                     />
                     <label className="text-sm capitalize">{cat}</label>
                   </div>
                 ))}
               </div>
             </div>
           )}
           
           {/* Document Selection */}
           {includeFiles && availableDocuments.length > 0 && (
             <div className="space-y-2">
               <h4 className="text-sm font-semibold">Select Documents</h4>
               <div className="max-h-48 overflow-y-auto space-y-1">
                 {availableDocuments.map(doc => (
                   <div key={doc.id} className="flex items-center gap-2 p-2 hover:bg-slate-700 rounded">
                     <Checkbox
                       checked={selectedDocuments.includes(doc.id)}
                       onCheckedChange={(checked) => {
                         if (checked) {
                           setSelectedDocuments([...selectedDocuments, doc.id]);
                         } else {
                           setSelectedDocuments(selectedDocuments.filter(id => id !== doc.id));
                         }
                       }}
                     />
                     <div className="flex-1">
                       <p className="text-sm">{doc.title}</p>
                       <p className="text-xs text-slate-400">{doc.filename} • {doc.category}</p>
                     </div>
                   </div>
                 ))}
               </div>
             </div>
           )}
           
           {/* Generate Button */}
           <Button
             onClick={handleGenerateLink}
             disabled={loading}
             className="w-full"
           >
             {loading ? 'Generating...' : 'Generate Verification Link'}
           </Button>
           
           {/* Generated Link */}
           {generatedLink && (
             <div className="space-y-2 p-4 bg-slate-900 rounded border border-slate-700">
               <div className="flex gap-2">
                 <input
                   type="text"
                   value={generatedLink}
                   readOnly
                   className="flex-1 p-2 bg-slate-800 border border-slate-700 rounded text-sm"
                 />
                 <Button onClick={handleCopy} size="sm">
                   {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                 </Button>
                 {navigator.share && (
                   <Button
                     onClick={() => navigator.share({ url: generatedLink })}
                     size="sm"
                   >
                     <Share2 className="h-4 w-4" />
                   </Button>
                 )}
               </div>
               <p className="text-xs text-slate-400">
                 Copy this link and share it via email, Slack, Teams, or any other channel.
               </p>
             </div>
           )}
         </CardContent>
       </Card>
     );
   }
   ```

---

## PROJECT 6: File Whitelist Configuration Editor

### Activity 6.1: YAML Configuration Editor UI

**Priority**: P1 (High)  
**Estimated Time**: 3 days  
**Dependencies**: Activity 4.1.3

#### File-Level Task 6.1.1: Create Configuration API Endpoints
**File**: `app/api/routes.py`

**Line-Level Subtasks**:
1. Add configuration endpoints (after link generation endpoint):
   ```python
   @router.get("/config/verification-file-categories")
   async def get_verification_file_categories(
       db: Session = Depends(get_db),
       current_user: User = Depends(require_auth)
   ):
       """Get enabled file categories from YAML config."""
       from app.core.verification_file_config import VerificationFileConfig
       
       config = VerificationFileConfig()
       return {
           "categories": config.get_enabled_categories(),
           "required_categories": config.get_required_categories(),
           "subdirectories": config.get_enabled_subdirectories()
       }
   
   @router.get("/config/verification-file-whitelist")
   async def get_verification_file_whitelist_config(
       db: Session = Depends(get_db),
       current_user: User = Depends(require_auth)
   ):
       """Get full file whitelist configuration."""
       from app.core.verification_file_config import VerificationFileConfig
       import yaml
       
       config = VerificationFileConfig()
       config_path = config.config_path
       
       if not config_path.exists():
           return {"config": config._get_default_config(), "exists": False}
       
       with open(config_path, 'r', encoding='utf-8') as f:
           yaml_content = f.read()
       
       return {
           "config": yaml.safe_load(yaml_content),
           "yaml": yaml_content,
           "exists": True,
           "path": str(config_path)
       }
   
   @router.post("/config/verification-file-whitelist")
   async def update_verification_file_whitelist_config(
       request: dict,  # {"yaml": "...", "config": {...}}
       db: Session = Depends(get_db),
       current_user: User = Depends(require_auth)
   ):
       """Update file whitelist configuration."""
       # Check admin permission
       if current_user.role != "admin":
           raise HTTPException(403, "Admin permission required")
       
       from app.core.verification_file_config import VerificationFileConfig
       import yaml
       
       config = VerificationFileConfig()
       config_path = config.config_path
       
       # Ensure config directory exists
       config_path.parent.mkdir(parents=True, exist_ok=True)
       
       # Validate YAML
       try:
           yaml.safe_load(request["yaml"])
       except yaml.YAMLError as e:
           raise HTTPException(400, f"Invalid YAML: {e}")
       
       # Write to file
       with open(config_path, 'w', encoding='utf-8') as f:
           f.write(request["yaml"])
       
       # Reload config
       config._load_config()
       
       log_audit_action(
           db, AuditAction.UPDATE, "config", 0, current_user.id,
           metadata={"config_type": "verification_file_whitelist"}
       )
       
       return {"status": "success", "message": "Configuration updated"}
   ```

#### File-Level Task 6.1.2: Create Configuration Editor Component
**File**: `client/src/apps/verification-config/VerificationFileConfigEditor.tsx` (NEW FILE)

**Line-Level Subtasks**:
1. Create YAML editor component (lines 1-400):
   ```typescript
   import { useState, useEffect } from 'react';
   import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
   import { Button } from '@/components/ui/button';
   import { Textarea } from '@/components/ui/textarea';
   import { Save, RefreshCw, AlertCircle, CheckCircle } from 'lucide-react';
   
   export function VerificationFileConfigEditor() {
     const [yamlContent, setYamlContent] = useState('');
     const [loading, setLoading] = useState(true);
     const [saving, setSaving] = useState(false);
     const [error, setError] = useState<string | null>(null);
     const [success, setSuccess] = useState(false);
     
     useEffect(() => {
       loadConfig();
     }, []);
     
     const loadConfig = async () => {
       setLoading(true);
       try {
         const response = await fetch('/api/config/verification-file-whitelist');
         if (response.ok) {
           const data = await response.json();
           setYamlContent(data.yaml || '');
         }
       } catch (err) {
         setError('Failed to load configuration');
       } finally {
         setLoading(false);
       }
     };
     
     const handleSave = async () => {
       setSaving(true);
       setError(null);
       setSuccess(false);
       
       try {
         const response = await fetch('/api/config/verification-file-whitelist', {
           method: 'POST',
           headers: { 'Content-Type': 'application/json' },
           body: JSON.stringify({ yaml: yamlContent })
         });
         
         if (!response.ok) {
           const errorData = await response.json();
           throw new Error(errorData.detail || 'Failed to save configuration');
         }
         
         setSuccess(true);
         setTimeout(() => setSuccess(false), 3000);
       } catch (err) {
         setError(err instanceof Error ? err.message : 'Failed to save');
       } finally {
         setSaving(false);
       }
     };
     
     if (loading) {
       return <div>Loading configuration...</div>;
     }
     
     return (
       <div className="space-y-4">
         <Card className="bg-slate-800 border-slate-700">
           <CardHeader>
             <CardTitle>Verification File Whitelist Configuration</CardTitle>
             <p className="text-sm text-slate-400">
               Configure which files and categories are included in verification links.
             </p>
           </CardHeader>
           <CardContent className="space-y-4">
             {/* YAML Editor */}
             <div className="space-y-2">
               <label className="text-sm font-semibold">YAML Configuration</label>
               <Textarea
                 value={yamlContent}
                 onChange={(e) => setYamlContent(e.target.value)}
                 className="font-mono text-sm min-h-[500px] bg-slate-900 border-slate-700"
                 placeholder="# Verification File Whitelist Configuration&#10;..."
               />
             </div>
             
             {/* Actions */}
             <div className="flex gap-2">
               <Button onClick={handleSave} disabled={saving}>
                 <Save className="h-4 w-4 mr-2" />
                 {saving ? 'Saving...' : 'Save Configuration'}
               </Button>
               <Button onClick={loadConfig} variant="outline">
                 <RefreshCw className="h-4 w-4 mr-2" />
                 Reload
               </Button>
             </div>
             
             {/* Status Messages */}
             {error && (
               <div className="flex items-center gap-2 text-red-400">
                 <AlertCircle className="h-4 w-4" />
                 <span className="text-sm">{error}</span>
               </div>
             )}
             
             {success && (
               <div className="flex items-center gap-2 text-emerald-400">
                 <CheckCircle className="h-4 w-4" />
                 <span className="text-sm">Configuration saved successfully</span>
               </div>
             )}
           </CardContent>
         </Card>
         
         {/* Configuration Help */}
         <Card className="bg-slate-800 border-slate-700">
           <CardHeader>
             <CardTitle className="text-lg">Configuration Guide</CardTitle>
           </CardHeader>
           <CardContent className="text-sm text-slate-400 space-y-2">
             <p><strong>Categories:</strong> Define file categories (legal, financial, compliance, etc.)</p>
             <p><strong>File Types:</strong> Specify allowed file extensions and size limits</p>
             <p><strong>Subdirectories:</strong> Control which deal subdirectories are included</p>
             <p><strong>Required Categories:</strong> Categories that must be included in verification links</p>
           </CardContent>
         </Card>
       </div>
     );
   }
   ```

#### File-Level Task 6.1.3: Add Configuration Route and Sidebar Item
**File**: `client/src/router/Routes.tsx`

**Line-Level Subtasks**:
1. Add configuration route (after verification route):
   ```typescript
   {
     path: '/config/verification-files',
     element: <VerificationFileConfigEditor />
   }
   ```

**File**: `client/src/components/MainNavigation.tsx`

**Line-Level Subtasks**:
1. Add configuration sidebar item (after deals, ~line 91):
   ```typescript
   {
     id: 'verification-config',
     label: 'Verification Config',
     path: '/config/verification-files',
     icon: Settings,  // Import from lucide-react
     description: 'Configure file whitelist for verification links',
     requiredPermission: 'admin'  // Admin only
   }
   ```

#### File-Level Task 6.1.4: Create Default YAML Configuration File
**File**: `app/config/verification_file_whitelist.yaml` (NEW FILE)

**Line-Level Subtasks**:
1. Create default configuration (lines 1-80):
   ```yaml
   # Verification File Whitelist Configuration
   # Controls which files are included in verification links
   
   enabled_categories:
     - legal
     - financial
     - compliance
   
   file_types:
     allowed_extensions:
       - .pdf
       - .doc
       - .docx
       - .txt
       - .json
       - .xlsx
       - .csv
     max_file_size_mb: 50
   
   categories:
     legal:
       enabled: true
       required: true
       file_types:
         - .pdf
         - .doc
         - .docx
       description: "Legal documents (agreements, contracts)"
     
     financial:
       enabled: true
       required: false
       file_types:
         - .pdf
         - .xlsx
         - .csv
       description: "Financial statements and reports"
     
     compliance:
       enabled: true
       required: false
       file_types:
         - .pdf
         - .doc
       description: "Compliance and regulatory documents"
     
     supporting:
       enabled: false
       required: false
       file_types:
         - .pdf
         - .jpg
         - .png
       description: "Supporting documents and images"
   
   subdirectories:
     documents:
       enabled: true
       priority: 1
       description: "Main deal documents"
     
     extractions:
       enabled: true
       priority: 2
       description: "Extracted data files"
     
     generated:
       enabled: false
       priority: 3
       description: "Generated documents"
     
     notes:
       enabled: false
       priority: 4
       description: "Deal notes and comments"
   ```

---

## PROJECT 7: MetaMask Notarization (Continued)

### Activity 5.1: Notarization Service Implementation

**Priority**: P0 (Critical)  
**Estimated Time**: 3 days  
**Dependencies**: Activity 1.1, Activity 4.1

#### File-Level Task 5.1.1: Create NotarizationRecord Model
**File**: `app/db/models.py`

**Line-Level Subtasks**:
1. Add NotarizationRecord model (after VerificationRequest):
   ```python
   class NotarizationRecord(Base):
       """Notarization record for deal signing."""
       
       __tablename__ = "notarization_records"
       
       id = Column(Integer, primary_key=True, autoincrement=True)
       deal_id = Column(Integer, ForeignKey("deals.id", ondelete="CASCADE"), nullable=False, index=True)
       notarization_hash = Column(String(255), nullable=False)  # Hash of CDM payload
       required_signers = Column(JSONB, nullable=False)  # Array of wallet addresses
       signatures = Column(JSONB, nullable=True)  # Array of signature objects
       status = Column(String(20), default="pending", nullable=False, index=True)
       completed_at = Column(DateTime, nullable=True)
       cdm_event_id = Column(String(255), nullable=True)
       created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
       updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
   ```

#### File-Level Task 5.1.2: Create Notarization Service
**File**: `app/services/notarization_service.py` (NEW FILE)

**Line-Level Subtasks**:
1. Implement notarization service (lines 1-200):
   ```python
   """Service for managing deal notarization."""
   import hashlib
   import json
   from datetime import datetime
   from typing import List, Dict, Any, Optional
   from sqlalchemy.orm import Session
   from app.db.models import NotarizationRecord, Deal
   from app.utils.crypto_verification import verify_ethereum_signature
   from app.models.cdm_events import generate_cdm_notarization_event
   
   class NotarizationService:
       def __init__(self, db: Session):
           self.db = db
       
       def create_notarization_request(
           self,
           deal_id: int,
           required_signers: List[str]
       ) -> NotarizationRecord:
           """Create notarization request for deal."""
           deal = self.db.query(Deal).filter(Deal.id == deal_id).first()
           if not deal:
               raise ValueError(f"Deal {deal_id} not found")
           
           # Generate hash of CDM payload
           cdm_payload = self._get_deal_cdm_payload(deal)
           notarization_hash = hashlib.sha256(
               json.dumps(cdm_payload, sort_keys=True).encode()
           ).hexdigest()
           
           record = NotarizationRecord(
               deal_id=deal_id,
               notarization_hash=notarization_hash,
               required_signers=required_signers,
               signatures=[],
               status="pending"
           )
           self.db.add(record)
           self.db.commit()
           self.db.refresh(record)
           
           return record
       
       def generate_notarization_message(
           self,
           notarization: NotarizationRecord,
           signer_address: str
       ) -> str:
           """Generate message for signer to sign."""
           return f"""CreditNexus Notarization
           
Deal ID: {notarization.deal_id}
Notarization Hash: {notarization.notarization_hash}
Signer: {signer_address}
Timestamp: {datetime.utcnow().isoformat()}
           
By signing this message, you confirm your agreement to notarize this deal."""
       
       def verify_and_store_signature(
           self,
           notarization_id: int,
           wallet_address: str,
           signature: str,
           message: str
       ) -> NotarizationRecord:
           """Verify signature and store in notarization record."""
           # Verify signature
           is_valid = verify_ethereum_signature(
               message=message,
               signature=signature,
               wallet_address=wallet_address
           )
           
           if not is_valid:
               raise ValueError("Invalid signature")
           
           # Get notarization record
           record = self.db.query(NotarizationRecord).filter(
               NotarizationRecord.id == notarization_id
           ).first()
           
           if not record:
               raise ValueError(f"Notarization {notarization_id} not found")
           
           # Check if signer is required
           if wallet_address.lower() not in [s.lower() for s in record.required_signers]:
               raise ValueError("Signer not in required signers list")
           
           # Check if already signed
           existing_signatures = record.signatures or []
           if any(s.get("wallet_address", "").lower() == wallet_address.lower() 
                  for s in existing_signatures):
               raise ValueError("Already signed")
           
           # Add signature
           signature_data = {
               "wallet_address": wallet_address.lower(),
               "signature": signature,
               "signed_at": datetime.utcnow().isoformat(),
               "message": message
           }
           
           existing_signatures.append(signature_data)
           record.signatures = existing_signatures
           
           # Check if all required signers have signed
           if len(existing_signatures) >= len(record.required_signers):
               record.status = "completed"
               record.completed_at = datetime.utcnow()
               
               # Generate CDM event
               cdm_event = generate_cdm_notarization_event(
                   notarization_id=str(record.id),
                   deal_id=str(record.deal_id),
                   signers=existing_signatures,
                   notarization_hash=record.notarization_hash
               )
               record.cdm_event_id = cdm_event.get("meta", {}).get("globalKey", {}).get("assignedIdentifier", [{}])[0].get("identifier", {}).get("value", "")
           else:
               record.status = "signed"
           
           self.db.commit()
           self.db.refresh(record)
           
           return record
   ```

### Activity 5.2: Notarization API Endpoints

**Priority**: P0 (Critical)  
**Estimated Time**: 2 days  
**Dependencies**: Activity 5.1

#### File-Level Task 5.2.1: Add Notarization Endpoints
**File**: `app/api/routes.py`

**Line-Level Subtasks**:
1. Add notarization endpoints (after wallet auth, ~line 7876):
   ```python
   @router.post("/deals/{deal_id}/notarize")
   async def create_notarization_request(
       deal_id: int,
       required_signers: List[str],
       db: Session = Depends(get_db),
       current_user: User = Depends(require_auth)
   ):
       """Create notarization request for deal."""
       from app.services.notarization_service import NotarizationService
       
       service = NotarizationService(db)
       record = service.create_notarization_request(deal_id, required_signers)
       
       return {
           "status": "success",
           "notarization_id": record.id,
           "notarization_hash": record.notarization_hash
       }
   
   @router.get("/notarization/{notarization_id}/nonce")
   async def get_notarization_nonce(
       notarization_id: int,
       wallet_address: str,
       db: Session = Depends(get_db)
   ):
       """Get nonce and message for notarization signing."""
       from app.services.notarization_service import NotarizationService
       
       service = NotarizationService(db)
       record = db.query(NotarizationRecord).filter(
           NotarizationRecord.id == notarization_id
       ).first()
       
       if not record:
           raise HTTPException(404, "Notarization not found")
       
       message = service.generate_notarization_message(record, wallet_address)
       
       return {
           "message": message,
           "notarization_hash": record.notarization_hash
       }
   
   @router.post("/notarization/{notarization_id}/sign")
   async def sign_notarization(
       notarization_id: int,
       request: dict,  # {wallet_address, signature, message}
       db: Session = Depends(get_db)
   ):
       """Sign notarization with MetaMask signature."""
       from app.services.notarization_service import NotarizationService
       
       service = NotarizationService(db)
       record = service.verify_and_store_signature(
           notarization_id,
           request["wallet_address"],
           request["signature"],
           request["message"]
       )
       
       return {
           "status": "success",
           "notarization_status": record.status,
           "signatures_count": len(record.signatures or [])
       }
   ```

### Activity 5.3: Frontend MetaMask Notarization

**Priority**: P1 (High)  
**Estimated Time**: 3 days  
**Dependencies**: Activity 5.2

#### File-Level Task 5.3.1: Enhance MetaMask Hook for Notarization
**File**: `client/src/hooks/useMetaMask.ts` (NEW FILE or enhance existing)

**Line-Level Subtasks**:
1. Add notarization signing method (lines 1-100):
   ```typescript
   import { useWallet } from '@/context/WalletContext';
   
   export function useMetaMaskNotarization() {
     const { account, signMessage } = useWallet();
     
     const signNotarization = async (
       notarizationId: number,
       message: string
     ): Promise<string> => {
       if (!account) {
         throw new Error('Wallet not connected');
       }
       
       // Sign message with MetaMask
       const signature = await signMessage(message);
       
       // Send to backend
       const response = await fetch(`/api/notarization/${notarizationId}/sign`, {
         method: 'POST',
         headers: { 'Content-Type': 'application/json' },
         body: JSON.stringify({
           wallet_address: account,
           signature,
           message
         })
       });
       
       if (!response.ok) {
         throw new Error('Notarization signing failed');
       }
       
       return signature;
     };
     
     return { signNotarization };
   }
   ```

#### File-Level Task 5.3.2: Create Notarization Interface Component
**File**: `client/src/components/NotarizationInterface.tsx` (NEW FILE)

**Line-Level Subtasks**:
1. Create component (lines 1-200):
   ```typescript
   import { useState } from 'react';
   import { useMetaMaskNotarization } from '@/hooks/useMetaMask';
   import { Button } from '@/components/ui/button';
   
   export function NotarizationInterface({ dealId }: { dealId: number }) {
     const [loading, setLoading] = useState(false);
     const { signNotarization } = useMetaMaskNotarization();
     
     const handleNotarize = async () => {
       setLoading(true);
       try {
         // Get nonce and message
         const nonceResponse = await fetch(`/api/notarization/${dealId}/nonce`);
         const { message } = await nonceResponse.json();
         
         // Sign with MetaMask
         await signNotarization(dealId, message);
         
         // Success!
       } catch (err) {
         // Error handling
       } finally {
         setLoading(false);
       }
     };
     
     return (
       <Button onClick={handleNotarize} disabled={loading}>
         {loading ? 'Signing...' : 'Notarize Deal'}
       </Button>
     );
   }
   ```

---

## Integration & Testing

### Activity 6.1: End-to-End Integration

**Priority**: P0 (Critical)  
**Estimated Time**: 3 days

#### File-Level Task 6.1.1: Create Integration Test Suite
**File**: `tests/integration/test_metamask_hot_login.py` (NEW FILE)

**Line-Level Subtasks**:
1. Test hot login flow (lines 1-100):
   ```python
   """Integration tests for MetaMask hot login."""
   import pytest
   from fastapi.testclient import TestClient
   
   def test_metamask_hot_login_flow(client: TestClient):
       """Test complete hot login flow."""
       # 1. Simulate wallet connection
       wallet_address = "0x1234567890123456789012345678901234567890"
       
       # 2. Call auto-login endpoint
       response = client.post(
           "/api/auth/wallet/auto-login",
           json={"wallet_address": wallet_address}
       )
       
       # 3. Verify response
       assert response.status_code == 200
       data = response.json()
       assert data["status"] == "success"
       assert "access_token" in data
   ```

---

## Summary of File Changes

### New Files to Create (27 files)
1. `app/utils/crypto_verification.py`
2. `app/utils/ssl_config.py`
3. `app/utils/link_payload.py` (NEW - replaces verification_tokens.py)
4. `app/core/verification_file_config.py` (NEW - YAML config loader)
5. `app/middleware/ip_whitelist.py`
6. `app/services/remote_profile_service.py`
7. `app/services/verification_service.py`
8. `app/services/notarization_service.py`
9. `app/auth/remote_auth.py`
10. `app/api/remote_routes.py`
11. `app/config/verification_file_whitelist.yaml` (NEW - default config)
12. `client/src/hooks/useAutoAuth.ts`
13. `client/src/hooks/useMetaMask.ts`
14. `client/src/apps/verification/VerificationPage.tsx`
15. `client/src/apps/verification/VerificationDetails.tsx`
16. `client/src/apps/verification-config/VerificationFileConfigEditor.tsx` (NEW)
17. `client/src/components/NotarizationInterface.tsx`
18. `client/src/components/VerificationLinkCreator.tsx` (NEW - replaces VerificationLinkShare)
19. `scripts/create_remote_profile.py`
20. `scripts/start_remote_api.py`
21. `docs/verification-link-format.md` (NEW)
22. `tests/test_crypto_verification.py`
23. `tests/test_link_payload.py` (NEW)
24. `tests/test_verification_file_config.py` (NEW)
25. `tests/integration/test_metamask_hot_login.py`
26. `tests/integration/test_verification_workflow.py`
27. `tests/integration/test_file_whitelist.py` (NEW)

**Removed Files** (Messenger integration removed):
- `app/services/messenger/base.py`
- `app/services/messenger/email.py`
- `app/services/messenger/slack.py`
- `app/services/messenger/teams.py`
- `app/services/messenger/whatsapp.py`
- `app/services/messenger/factory.py`

### Files to Modify (15 files)
1. `app/core/config.py` - Add remote API and messenger config
2. `app/db/models.py` - Add RemoteAppProfile, VerificationRequest, NotarizationRecord
3. `app/api/routes.py` - Update wallet auth, add notarization endpoints
4. `app/models/cdm_events.py` - Add verification and notarization events
5. `app/services/deal_service.py` - Integrate verification creation
6. `server.py` - Add remote API server setup
7. `pyproject.toml` - Add web3, eth-account dependencies
8. `client/src/context/WalletContext.tsx` - Add session persistence
9. `client/src/App.tsx` - Integrate useAutoAuth hook
10. `client/src/router/Routes.tsx` - Add verification route
11. `client/package.json` - Add ethers.js dependency
12. `alembic/versions/XXXX_add_remote_verification_tables.py` - Migration
13. `alembic/versions/XXXX_add_notarization_tables.py` - Migration
14. `.env.example` - Add new environment variables
15. `README.md` - Update with new features

### Database Migrations (3 migrations)
1. `add_remote_app_profiles_table` - Remote app profiles
2. `add_verification_requests_table` - Verification requests
3. `add_notarization_records_table` - Notarization records
4. `add_verification_fields_to_deals` - Deal verification fields

---

## Timeline Summary

| Phase | Duration | Key Deliverables |
|-------|----------|------------------|
| **Phase 1: MetaMask Hot Login** | 2 weeks | Cryptographic verification, auto-login, enhanced signup |
| **Phase 2: Remote API Listener** | 2 weeks | SSL setup, IP whitelisting, profile-based auth |
| **Phase 3: Verification Workflow** | 2 weeks | Verification service, links, frontend interface |
| **Phase 4: Self-Contained Link Generation** | 1 week | Encrypted link payloads, self-contained links |
| **Phase 5: File Whitelist & Link Creation UI** | 1 week | YAML config, file selection UI, config editor |
| **Phase 6: MetaMask Notarization** | 2 weeks | Notarization service, signing flow, frontend |
| **Phase 7: Integration & Testing** | 1 week | E2E tests, security audit, documentation |

**Total**: 11 weeks

---

## Key Architectural Changes

### Removed: Messenger Integration
- **Rationale**: CreditNexus should NOT send messages/emails directly
- **Replacement**: Generate self-contained links that users can share via any channel
- **Benefits**: 
  - No dependency on email/Slack/Teams APIs
  - Users control how links are shared
  - Works with any communication channel
  - Simpler architecture

### Enhanced: Self-Contained Links with File References
- **Format**: `https://verify.creditnexus.app/verify/{encrypted_payload}`
- **Payload Contains**:
  - Verification ID
  - Complete deal data
  - Full CDM payload
  - Verifier information
  - **File references** (configurable via YAML whitelist)
  - Expiration timestamp
- **File Whitelisting**:
  - YAML-based configuration (`app/config/verification_file_whitelist.yaml`)
  - Configurable categories (legal, financial, compliance, supporting)
  - File type restrictions (.pdf, .doc, .docx, etc.)
  - Subdirectory filtering (documents, extractions, generated, notes)
  - Admin-configurable via UI editor
- **Security**: Fernet encryption with base64url encoding
- **Benefits**:
  - No database lookup required when link is accessed
  - All data embedded in link (including file metadata)
  - Works across machines/networks
  - Can be shared via any channel (email, Slack, Teams, WhatsApp, QR code, etc.)
  - Files accessible via download URLs in link payload

### Link Sharing Flow
1. User creates verification request
2. System generates self-contained link
3. User copies link (or uses share button)
4. User shares link via their preferred channel (email, Slack, etc.)
5. Verifier clicks link
6. System decrypts payload and displays verification UI
7. Verifier accepts/declines
8. System updates verification status

**CreditNexus Role**: Link generator only. No message sending.

---

---

## Summary of Architectural Changes

### Removed: Messenger Integration System
- **What was removed**: Email, Slack, Teams, WhatsApp messenger implementations
- **Why**: CreditNexus should NOT send messages directly. Users share links via their preferred channels.
- **Impact**: Simpler architecture, no external API dependencies, more flexible

### Added: Self-Contained Link Generation
- **What was added**: Encrypted link payloads containing all verification data
- **Format**: `https://verify.creditnexus.app/verify/{encrypted_payload}`
- **Payload includes**: Deal data, CDM payload, verifier info, expiration
- **Security**: Fernet encryption with base64url encoding
- **Benefits**: 
  - No database lookup required
  - Works across machines/networks
  - Can be shared via any channel
  - Self-contained (all data in link)

### Link Sharing Workflow
```
1. User creates verification request
   ↓
2. System generates self-contained encrypted link
   ↓
3. User copies link (UI provides copy/share buttons)
   ↓
4. User shares link via external channel:
   - Email (copy/paste)
   - Slack message
   - Teams chat
   - WhatsApp/SMS
   - QR code
   - Any other method
   ↓
5. Verifier receives link (via external channel)
   ↓
6. Verifier clicks link
   ↓
7. System decrypts payload (no DB lookup needed)
   ↓
8. Verification UI displays with all embedded data
   ↓
9. Verifier accepts/declines
   ↓
10. System updates verification status
```

### Key Files Changed
- **Removed**: All `app/services/messenger/*` files
- **Added**: 
  - `app/utils/link_payload.py` (encrypted payload generation with file references)
  - `app/core/verification_file_config.py` (YAML-based file whitelist loader)
  - `app/config/verification_file_whitelist.yaml` (default configuration)
  - `client/src/components/VerificationLinkCreator.tsx` (link creation UI with file selection)
  - `client/src/apps/verification-config/VerificationFileConfigEditor.tsx` (YAML config editor)
- **Enhanced**: 
  - `app/services/verification_service.py` (link generation with embedded data and files)
  - `client/src/components/MainNavigation.tsx` (added "Verification Config" sidebar item)
  - `client/src/router/Routes.tsx` (added config route)

### Configuration Changes
- **Removed**: All `MESSENGER_*` environment variables
- **Added**: 
  - `LINK_ENCRYPTION_KEY` (Fernet key for link encryption)
  - `VERIFICATION_BASE_URL` (base URL for verification links)
  - `VERIFICATION_FILE_CONFIG_PATH` (optional, defaults to `app/config/verification_file_whitelist.yaml`)
- **New YAML Config File**: `app/config/verification_file_whitelist.yaml`
  - Editable via UI (admin only)
  - Controls file categories, types, and subdirectories
  - Hot-reloadable (optional)

---

---

## New Features Summary

### 1. Configurable File Sharing in Verification Links
- **File References**: Verification links can include references to deal documents
- **YAML Whitelist**: File inclusion controlled via `verification_file_whitelist.yaml`
- **Categories**: Legal, financial, compliance, supporting (configurable)
- **File Types**: Configurable allowed extensions (.pdf, .doc, .docx, etc.)
- **Subdirectories**: Control which deal subdirectories are included
- **User Selection**: UI allows users to select which files/categories to include

### 2. Link Creation UI Component
- **File Selection Interface**: Checkboxes for categories and individual documents
- **Real-time Preview**: Shows which files will be included
- **Copy/Share Buttons**: Easy link sharing
- **Integration**: Embedded in deal verification workflow

### 3. YAML Configuration Editor
- **Admin Interface**: Sidebar item "Verification Config" (admin only)
- **YAML Editor**: Full YAML editing with syntax validation
- **Live Reload**: Optional hot-reload on config changes
- **Default Config**: Ships with sensible defaults
- **Validation**: YAML syntax validation before saving

### 4. File Access in Verification Links
- **Download URLs**: File references include download URLs
- **Authentication**: File access controlled via authentication
- **Metadata**: File size, category, subdirectory included in link
- **No Database Lookup**: All file info embedded in encrypted payload

### Configuration Example

```yaml
# app/config/verification_file_whitelist.yaml
enabled_categories:
  - legal
  - financial
  - compliance

categories:
  legal:
    enabled: true
    required: true
    file_types: [.pdf, .doc, .docx]
  
  financial:
    enabled: true
    required: false
    file_types: [.pdf, .xlsx, .csv]

subdirectories:
  documents:
    enabled: true
    priority: 1
  extractions:
    enabled: true
    priority: 2
```

### UI Components Added
1. **VerificationLinkCreator** - Link creation with file selection
2. **VerificationFileConfigEditor** - YAML configuration editor
3. **Sidebar Navigation Item** - "Verification Config" (admin only)

### API Endpoints Added
1. `GET /api/config/verification-file-categories` - Get enabled categories
2. `GET /api/config/verification-file-whitelist` - Get full config
3. `POST /api/config/verification-file-whitelist` - Update config (admin)
4. `POST /api/verification/{id}/generate-link` - Generate link with file selection

---

**Last Updated**: 2024-12-XX  
**Version**: 2.2 (Enhanced - File Sharing, YAML Config, UI Components)  
**Author**: CreditNexus Architecture Team
