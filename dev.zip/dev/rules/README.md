# CreditNexus Cursor Rules

This directory contains comprehensive Cursor rules for CreditNexus development patterns and best practices.

## Rule Files

### Core Architecture Rules
- **service-layer.md** - Service layer pattern for business logic encapsulation
- **agents.md** - AI agent patterns for specialized tasks (extraction, verification, classification)
- **chains.md** - LangChain chain patterns for LLM-based extraction and processing
- **error-handling.md** - Error handling and logging patterns throughout the application
- **audit-compliance.md** - Audit logging and compliance requirements
- **background-tasks.md** - Background task and async processing patterns
- **file-storage.md** - File storage and management patterns

### Existing Rules (in `.cursor/rules/`)
- **api-routing.mdc** - FastAPI routing patterns and API design
- **architecture.mdc** - System architecture and design principles
- **cdm-compliance.mdc** - FINOS CDM compliance requirements
- **data-validation.mdc** - Pydantic validation patterns
- **database-orm.mdc** - SQLAlchemy 2.0 patterns
- **frontend.mdc** - React/TypeScript frontend patterns
- **llm-client.mdc** - LLM client abstraction patterns
- **policy-engine.mdc** - Policy engine integration patterns
- **remote-verification.mdc** - Remote verification and MetaMask patterns
- **green-finance.mdc** - Green finance and enhanced satellite verification patterns

## Usage

These rules are designed to guide development and ensure consistency across the CreditNexus codebase. They should be referenced when:

1. Implementing new features
2. Refactoring existing code
3. Onboarding new developers
4. Reviewing code changes

## Implementation Status

Many rules include implementation status notes indicating:
- ✅ **Implemented** - Feature exists and is working
- ⚠️ **Partially Implemented** - Feature exists but needs completion
- ❌ **Not Implemented** - Feature is planned but not yet built

Refer to implementation plans in `dev/` directory for detailed implementation guidance.
