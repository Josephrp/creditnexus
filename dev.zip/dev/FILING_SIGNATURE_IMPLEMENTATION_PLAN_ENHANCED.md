# CreditNexus Filing & Digital Signature Implementation Plan (Enhanced)

## Executive Summary

This document provides an enhanced implementation plan for integrating automated filing and digital signature functionality into CreditNexus. **Key Design Decisions:**

1. ✅ **DigiSigner API** selected for digital signatures (free tier available)
2. ✅ **Companies House API** for UK filings (free API)
3. ✅ **Manual Filing UI** for US, France, and Germany (no third-party APIs)
4. ✅ **UI-based filing workflow** with pre-filled forms and tracking
5. ✅ **LangChain AI Integration** for filing requirement evaluation and form generation (see `dev/FILING_SIGNATURE_LANGCHAIN_INTEGRATION.md`)

**Priority**: High  
**Estimated Timeline**: 10-12 weeks (includes LangChain integration)  
**Complexity**: High

**Related Documents**:
- `dev/FILING_SIGNATURE_LANGCHAIN_INTEGRATION.md` - Complete LangChain chains, prompts, and Pydantic models
- `dev/FILING_SIGNATURE_API_INVENTORY.md` - API inventory and selection rationale
- `dev/FILING_COMPLIANCE_RULES.md` - Jurisdiction-specific compliance rules

---

## Table of Contents

1. [Design Decisions](#design-decisions)
2. [Current State Assessment](#current-state-assessment)
3. [Architecture Overview](#architecture-overview)
4. [Implementation Projects](#implementation-projects)
5. [UI Components Design](#ui-components-design)
6. [API Integration Details](#api-integration-details)
7. [Testing Strategy](#testing-strategy)
8. [Deployment Plan](#deployment-plan)

---

## Design Decisions

### Digital Signature Provider: DigiSigner

**Rationale**:
- Free tier available for development/testing
- ESIGN, UETA, eIDAS compliant
- Simple REST API integration
- Cost-effective for production ($9-29/month)
- Good documentation and support

**API Details**:
- Base URL: `https://api.digisigner.com/v1`
- Authentication: `X-DigiSigner-API-Key` header
- Rate Limits: 100 req/min (free), 1000 req/min (paid)

### Filing Approach

**UK (Companies House)**:
- ✅ Direct API integration (free)
- Automated filing submission
- Real-time status tracking

**US (SEC EDGAR)**:
- ✅ Manual filing via UI
- Pre-filled form data (AI-generated via LangChain)
- Submission tracking
- Status monitoring

**France (AMF/Court)**:
- ✅ Manual filing via UI
- French language support
- Pre-filled form data (AI-generated via LangChain)
- Submission tracking

**Germany (BaFin/Register)**:
- ✅ Manual filing via UI
- German language support
- Pre-filled form data (AI-generated via LangChain)
- Submission tracking

### AI-Assisted Features (LangChain Integration)

**Filing Requirement Evaluation**:
- ✅ AI-powered filing requirement detection from CDM data
- ✅ Automatic deadline calculation and priority assignment
- ✅ Missing field identification
- ✅ Compliance status evaluation

**Form Data Generation**:
- ✅ AI-generated pre-filled forms for manual filings
- ✅ Jurisdiction-specific field mapping (US, FR, DE)
- ✅ Multi-language support (English, French, German)
- ✅ Automatic submission URL generation

**Signature Request Generation**:
- ✅ AI-assisted signer detection from CDM parties
- ✅ Automatic signing workflow determination (parallel/sequential)
- ✅ Expiration and reminder configuration

---

## Current State Assessment

### ✅ What We Have

1. **Document Generation System**
   - `DocumentGenerationService` for LMA template generation
   - `GeneratedDocument` model for tracking generated documents
   - CDM data extraction and validation

2. **Policy Engine**
   - `PolicyService` for policy evaluation
   - Policy rule loading from YAML files
   - CDM-compliant policy decisions

3. **Workflow System**
   - `Workflow` model for document approval
   - Workflow state transitions (DRAFT → UNDER_REVIEW → APPROVED → PUBLISHED)
   - Event triggers on state changes

4. **Verifier Patterns**
   - `app/agents/verifier.py` for geospatial verification
   - Async verification functions
   - Structured verification results

5. **Frontend Components**
   - React 18 with TypeScript
   - shadcn/ui components
   - Tailwind CSS styling
   - Existing patterns: `DealDetail`, `DocumentGenerator`, `PolicyEditor`

### ❌ What's Missing

1. **Digital Signature Integration**
   - No DigiSigner API integration
   - No signature request/status tracking
   - No signed document storage

2. **Filing System Integration**
   - No filing requirement evaluation
   - No Companies House API integration
   - No manual filing UI
   - No deadline tracking

3. **Jurisdiction-Specific Logic**
   - No jurisdiction-based filing rules
   - No multi-language support (FR, DE)
   - No country-specific form templates

4. **Compliance Monitoring**
   - No automated compliance checking
   - No deadline alerts
   - No filing status tracking

---

## Architecture Overview

### System Components

```
┌─────────────────────────────────────────────────────────────┐
│                    Document Generation                       │
│                  (Existing System)                           │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              Filing Requirement Evaluation                   │
│                                                              │
│  - PolicyService.evaluate_filing_requirements()            │
│  - Filing compliance rules (YAML)                          │
│  - Jurisdiction-based logic                                │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              Digital Signature Workflow (DigiSigner)         │
│                                                              │
│  - SignatureService.request_signature()                     │
│  - DigiSigner API integration                               │
│  - Signature status tracking                                │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              Filing Submission Workflow                      │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  UK: Companies House API (Automated)                │  │
│  └──────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  US/FR/DE: Manual Filing UI                         │  │
│  │  - Pre-filled forms                                 │  │
│  │  - Document preparation                             │  │
│  │  - Submission tracking                              │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              Compliance Monitoring                           │
│                                                              │
│  - Deadline tracking                                        │
│  - Compliance verifiers                                     │
│  - Alert system                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Implementation Projects

### PROJECT 0: LangChain Integration (AI-Assisted Filing & Signatures)

**Priority**: P0 (Critical - Foundation)  
**Estimated Time**: 5 days  
**Dependencies**: None  
**Reference**: See `dev/FILING_SIGNATURE_LANGCHAIN_INTEGRATION.md` for complete details

#### Activity 0.1: Create Pydantic Models for Filing/Signature Chains

**File**: `app/models/filing_requirements.py` (NEW)

**Line-Level Subtasks**:

1. Create new file `app/models/filing_requirements.py`:
   - Import required types: `List`, `Optional`, `Dict`, `Any`, `datetime`, `BaseModel`, `Field`
   - Create `FilingRequirement` model (lines 1-20):
     ```python
     class FilingRequirement(BaseModel):
         authority: str = Field(..., description="Filing authority")
         jurisdiction: str = Field(..., description="Jurisdiction code")
         agreement_type: str = Field(..., description="Type of agreement")
         filing_system: str = Field(..., description="Filing system")
         deadline: datetime = Field(..., description="Filing deadline")
         required_fields: List[str] = Field(default_factory=list)
         api_available: bool = Field(default=False)
         api_endpoint: Optional[str] = Field(None)
         penalty: Optional[str] = Field(None)
         language_requirement: Optional[str] = Field(None)
         form_type: Optional[str] = Field(None)
         priority: str = Field(default="medium")
     ```
   - Create `FilingRequirementEvaluation` model (lines 22-30):
     ```python
     class FilingRequirementEvaluation(BaseModel):
         required_filings: List[FilingRequirement] = Field(default_factory=list)
         compliance_status: str = Field(..., description="'compliant', 'non_compliant', 'pending'")
         missing_fields: List[str] = Field(default_factory=list)
         deadline_alerts: List[Dict[str, Any]] = Field(default_factory=list)
         trace_id: str = Field(..., description="Policy evaluation trace ID")
         metadata: Dict[str, Any] = Field(default_factory=dict)
     ```

**File**: `app/models/filing_forms.py` (NEW)

**Line-Level Subtasks**:

1. Create new file `app/models/filing_forms.py`:
   - Import required types
   - Create `FilingFormField` model (lines 1-10):
     ```python
     class FilingFormField(BaseModel):
         field_name: str = Field(..., description="Form field name")
         field_value: Any = Field(..., description="Field value")
         field_type: str = Field(..., description="Field type")
         required: bool = Field(default=True)
         validation_rules: Optional[Dict[str, Any]] = Field(None)
         help_text: Optional[str] = Field(None)
     ```
   - Create `FilingFormData` model (lines 12-22):
     ```python
     class FilingFormData(BaseModel):
         jurisdiction: str = Field(..., description="Jurisdiction code")
         authority: str = Field(..., description="Filing authority")
         form_type: str = Field(..., description="Form type")
         fields: List[FilingFormField] = Field(default_factory=list)
         document_references: List[str] = Field(default_factory=list)
         submission_url: Optional[str] = Field(None)
         instructions: Optional[str] = Field(None)
         language: str = Field(default="en")
     ```

**File**: `app/models/signature_requests.py` (NEW)

**Line-Level Subtasks**:

1. Create new file `app/models/signature_requests.py`:
   - Import required types
   - Create `Signer` model (lines 1-8):
     ```python
     class Signer(BaseModel):
         name: str = Field(..., description="Signer full name")
         email: str = Field(..., description="Signer email address")
         role: str = Field(..., description="Signer role")
         signing_order: int = Field(default=0)
         required: bool = Field(default=True)
     ```
   - Create `SignatureRequestGeneration` model (lines 10-18):
     ```python
     class SignatureRequestGeneration(BaseModel):
         signers: List[Signer] = Field(default_factory=list)
         signing_workflow: str = Field(default="parallel")
         expiration_days: int = Field(default=30)
         reminder_enabled: bool = Field(default=True)
         reminder_days: List[int] = Field(default_factory=lambda: [7, 3, 1])
         message: Optional[str] = Field(None)
         metadata: Dict[str, Any] = Field(default_factory=dict)
     ```

#### Activity 0.2: Create Filing Requirement Evaluation Chain

**File**: `app/chains/filing_requirement_chain.py` (NEW)

**Line-Level Subtasks**:

1. Create new file `app/chains/filing_requirement_chain.py`:
   - Import required modules (lines 1-15):
     ```python
     import logging
     from typing import Optional, Dict, Any
     from pydantic import ValidationError
     from langchain_core.language_models import BaseChatModel
     from langchain_core.prompts import ChatPromptTemplate
     from app.core.llm_client import get_chat_model
     from app.models.filing_requirements import FilingRequirementEvaluation
     from app.models.cdm import CreditAgreement
     ```
   - Create `create_filing_requirement_chain()` function (lines 17-30):
     ```python
     def create_filing_requirement_chain() -> BaseChatModel:
         llm = get_chat_model(temperature=0)
         structured_llm = llm.with_structured_output(FilingRequirementEvaluation)
         return structured_llm
     ```
   - Create `create_filing_requirement_prompt()` function (lines 32-120):
     - System prompt with jurisdiction rules (US, UK, FR, DE)
     - User prompt template with CDM data variable
     - Return `ChatPromptTemplate.from_messages([...])`
   - Create `evaluate_filing_requirements()` function (lines 122-180):
     - Implement retry logic with validation feedback
     - Use `prompt | structured_llm` pattern
     - Handle `ValidationError` and other exceptions
     - Return `FilingRequirementEvaluation` instance

#### Activity 0.3: Create Filing Form Generation Chain

**File**: `app/chains/filing_form_generation_chain.py` (NEW)

**Line-Level Subtasks**:

1. Create new file `app/chains/filing_form_generation_chain.py`:
   - Import required modules (similar to Activity 0.2)
   - Create `create_filing_form_chain()` function (lines 17-25):
     ```python
     def create_filing_form_chain() -> BaseChatModel:
         llm = get_chat_model(temperature=0)
         structured_llm = llm.with_structured_output(FilingFormData)
         return structured_llm
     ```
   - Create `create_filing_form_prompt()` function (lines 27-100):
     - System prompt with jurisdiction-specific form mappings (US SEC, FR AMF, DE BaFin)
     - User prompt template with CDM data and filing requirement
     - Return `ChatPromptTemplate.from_messages([...])`
   - Create `generate_filing_form_data()` function (lines 102-160):
     - Implement retry logic
     - Map CDM data to form fields
     - Return `FilingFormData` instance

#### Activity 0.4: Create Signature Request Generation Chain

**File**: `app/chains/signature_request_chain.py` (NEW)

**Line-Level Subtasks**:

1. Create new file `app/chains/signature_request_chain.py`:
   - Import required modules
   - Create `create_signature_request_chain()` function (lines 17-25):
     ```python
     def create_signature_request_chain() -> BaseChatModel:
         llm = get_chat_model(temperature=0)
         structured_llm = llm.with_structured_output(SignatureRequestGeneration)
         return structured_llm
     ```
   - Create `create_signature_request_prompt()` function (lines 27-80):
     - System prompt with signer identification rules
     - User prompt template with CDM data
     - Return `ChatPromptTemplate.from_messages([...])`
   - Create `generate_signature_request()` function (lines 82-150):
     - Implement retry logic
     - Extract signers from CDM parties
     - Determine signing workflow (parallel/sequential)
     - Return `SignatureRequestGeneration` instance

#### Activity 0.5: Create Prompt Templates

**File**: `app/prompts/templates/filing.py` (NEW)

**Line-Level Subtasks**:

1. Create new file `app/prompts/templates/filing.py`:
   - Import `ChatPromptTemplate` (line 1)
   - Create `FILING_REQUIREMENT_EVALUATION_PROMPT` (lines 3-10)
   - Create `FILING_FORM_GENERATION_PROMPT` (lines 12-19)
   - Export `FILING_PROMPTS` dictionary (lines 21-24)

**File**: `app/prompts/templates/signature.py` (NEW)

**Line-Level Subtasks**:

1. Create new file `app/prompts/templates/signature.py`:
   - Import `ChatPromptTemplate` (line 1)
   - Create `SIGNATURE_REQUEST_GENERATION_PROMPT` (lines 3-10)
   - Export `SIGNATURE_PROMPTS` dictionary (lines 12-15)

#### Activity 0.6: Update PromptLoader

**File**: `app/prompts/templates/loader.py`

**Line-Level Subtasks**:

1. Add filing and signature to `PROMPT_MODULE_MAP` (around line 23):
   ```python
   "Filing": "app.prompts.templates.filing",
   "Signature": "app.prompts.templates.signature",
   ```

#### Activity 0.7: Add Configuration Settings

**File**: `app/core/config.py`

**Line-Level Subtasks**:

1. Add LangChain configuration fields to `Settings` class (around line 200):
   ```python
   FILING_CHAIN_TEMPERATURE: float = Field(default=0.0)
   SIGNATURE_CHAIN_TEMPERATURE: float = Field(default=0.0)
   FILING_CHAIN_MAX_RETRIES: int = Field(default=3)
   SIGNATURE_CHAIN_MAX_RETRIES: int = Field(default=3)
   ```

#### Activity 0.8: Create Unit Tests

**File**: `tests/test_filing_requirement_chain.py` (NEW)

**Line-Level Subtasks**:

1. Create test file with:
   - `test_evaluate_filing_requirements_us()` - Test US SEC filing detection
   - `test_evaluate_filing_requirements_uk()` - Test UK Companies House detection
   - `test_evaluate_filing_requirements_fr()` - Test France AMF detection
   - `test_evaluate_filing_requirements_de()` - Test Germany BaFin detection

**File**: `tests/test_filing_form_generation_chain.py` (NEW)

**Line-Level Subtasks**:

1. Create test file with:
   - `test_generate_filing_form_data_us()` - Test US SEC form generation
   - `test_generate_filing_form_data_fr()` - Test France AMF form generation
   - `test_generate_filing_form_data_de()` - Test Germany BaFin form generation

**File**: `tests/test_signature_request_chain.py` (NEW)

**Line-Level Subtasks**:

1. Create test file with:
   - `test_generate_signature_request_parallel()` - Test parallel signing workflow
   - `test_generate_signature_request_sequential()` - Test sequential signing workflow
   - `test_generate_signature_request_signers()` - Test signer extraction

---

### PROJECT 1: Database Schema Extensions

**Priority**: P0 (Critical)  
**Estimated Time**: 3 days  
**Dependencies**: None

#### Activity 1.1: Create DocumentSignature Model

**File**: `app/db/models.py`

**Line-Level Subtasks**:

1. Add `DocumentSignature` class after `GeneratedDocument` class (around line 810):
   ```python
   class DocumentSignature(Base):
       """Tracks digital signatures for documents."""
       
       __tablename__ = "document_signatures"
       
       id = Column(Integer, primary_key=True, autoincrement=True)
       document_id = Column(Integer, ForeignKey("documents.id"), nullable=False, index=True)
       generated_document_id = Column(Integer, ForeignKey("generated_documents.id"), nullable=True, index=True)
       
       # Signature provider info
       signature_provider = Column(String(50), nullable=False, default="digisigner")  # "digisigner"
       signature_request_id = Column(String(255), nullable=False, unique=True, index=True)
       signature_status = Column(String(50), nullable=False, index=True)  # "pending", "completed", "declined", "expired"
       
       # Signers
       signers = Column(JSONB, nullable=False)  # [{"name": "...", "email": "...", "role": "...", "signed_at": "..."}]
       
       # Signature metadata
       signature_provider_data = Column(JSONB, nullable=True)  # DigiSigner-specific response data
       signed_document_url = Column(Text, nullable=True)  # URL to signed document from DigiSigner
       signed_document_path = Column(Text, nullable=True)  # Local path if downloaded
       
       # Timestamps
       requested_at = Column(DateTime, default=datetime.utcnow, nullable=False)
       completed_at = Column(DateTime, nullable=True)
       expires_at = Column(DateTime, nullable=True)
       
       # Relationships
       document = relationship("Document", back_populates="signatures")
       generated_document = relationship("GeneratedDocument", back_populates="signatures")
       
       def to_dict(self):
           """Convert model to dictionary."""
           return {
               "id": self.id,
               "document_id": self.document_id,
               "generated_document_id": self.generated_document_id,
               "signature_provider": self.signature_provider,
               "signature_request_id": self.signature_request_id,
               "signature_status": self.signature_status,
               "signers": self.signers,
               "signature_provider_data": self.signature_provider_data,
               "signed_document_url": self.signed_document_url,
               "signed_document_path": self.signed_document_path,
               "requested_at": self.requested_at.isoformat() if self.requested_at else None,
               "completed_at": self.completed_at.isoformat() if self.completed_at else None,
               "expires_at": self.expires_at.isoformat() if self.expires_at else None,
           }
   ```

2. Add `signatures` relationship to `Document` class (around line 267):
   ```python
   signatures = relationship("DocumentSignature", back_populates="document", cascade="all, delete-orphan")
   ```

3. Add `signatures` relationship to `GeneratedDocument` class (around line 792):
   ```python
   signatures = relationship("DocumentSignature", back_populates="generated_document", cascade="all, delete-orphan")
   ```

#### Activity 1.2: Create DocumentFiling Model

**File**: `app/db/models.py`

**Line-Level Subtasks**:

1. Add `DocumentFiling` class after `DocumentSignature` class:
   ```python
   class DocumentFiling(Base):
       """Tracks regulatory filings for documents."""
       
       __tablename__ = "document_filings"
       
       id = Column(Integer, primary_key=True, autoincrement=True)
       document_id = Column(Integer, ForeignKey("documents.id"), nullable=False, index=True)
       generated_document_id = Column(Integer, ForeignKey("generated_documents.id"), nullable=True, index=True)
       deal_id = Column(Integer, ForeignKey("deals.id"), nullable=True, index=True)
       
       # Filing metadata
       agreement_type = Column(String(100), nullable=False, index=True)  # "facility_agreement", "disclosure", etc.
       jurisdiction = Column(String(50), nullable=False, index=True)  # "US", "UK", "FR", "DE", etc.
       filing_authority = Column(String(255), nullable=False)  # "SEC", "Companies House", "AMF", etc.
       
       # Filing system info
       filing_system = Column(String(50), nullable=False)  # "companies_house_api", "manual_ui", etc.
       filing_reference = Column(String(255), nullable=True, unique=True, index=True)  # External filing ID
       filing_status = Column(String(50), nullable=False, index=True)  # "pending", "submitted", "accepted", "rejected"
       
       # Filing payload (for API submissions) or form data (for manual UI)
       filing_payload = Column(JSONB, nullable=True)  # Data sent to filing system or prepared for UI
       filing_response = Column(JSONB, nullable=True)  # Response from filing system
       
       # Filing URLs
       filing_url = Column(Text, nullable=True)  # URL to view filing
       confirmation_url = Column(Text, nullable=True)  # Confirmation/receipt URL
       manual_submission_url = Column(Text, nullable=True)  # URL to manual filing portal (for UI guidance)
       
       # Manual filing tracking
       submitted_by = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)  # User who submitted manually
       submitted_at = Column(DateTime, nullable=True)  # When manually submitted
       submission_notes = Column(Text, nullable=True)  # Notes from manual submission
       
       # Error handling
       error_message = Column(Text, nullable=True)
       retry_count = Column(Integer, default=0, nullable=False)
       
       # Deadline tracking
       deadline = Column(DateTime, nullable=True, index=True)
       
       # Timestamps
       filed_at = Column(DateTime, nullable=True)
       created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
       updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
       
       # Relationships
       document = relationship("Document", back_populates="filings")
       generated_document = relationship("GeneratedDocument", back_populates="filings")
       deal = relationship("Deal", back_populates="filings")
       submitted_by_user = relationship("User", foreign_keys=[submitted_by])
       
       def to_dict(self):
           """Convert model to dictionary."""
           return {
               "id": self.id,
               "document_id": self.document_id,
               "generated_document_id": self.generated_document_id,
               "deal_id": self.deal_id,
               "agreement_type": self.agreement_type,
               "jurisdiction": self.jurisdiction,
               "filing_authority": self.filing_authority,
               "filing_system": self.filing_system,
               "filing_reference": self.filing_reference,
               "filing_status": self.filing_status,
               "filing_payload": self.filing_payload,
               "filing_response": self.filing_response,
               "filing_url": self.filing_url,
               "confirmation_url": self.confirmation_url,
               "manual_submission_url": self.manual_submission_url,
               "submitted_by": self.submitted_by,
               "submitted_at": self.submitted_at.isoformat() if self.submitted_at else None,
               "submission_notes": self.submission_notes,
               "error_message": self.error_message,
               "retry_count": self.retry_count,
               "deadline": self.deadline.isoformat() if self.deadline else None,
               "filed_at": self.filed_at.isoformat() if self.filed_at else None,
               "created_at": self.created_at.isoformat() if self.created_at else None,
               "updated_at": self.updated_at.isoformat() if self.updated_at else None,
           }
   ```

2. Add `filings` relationship to `Document` class (around line 267):
   ```python
   filings = relationship("DocumentFiling", back_populates="document", cascade="all, delete-orphan")
   ```

3. Add `filings` relationship to `GeneratedDocument` class (around line 792):
   ```python
   filings = relationship("DocumentFiling", back_populates="generated_document", cascade="all, delete-orphan")
   ```

4. Add `filings` relationship to `Deal` class (around line 1152):
   ```python
   filings = relationship("DocumentFiling", back_populates="deal", cascade="all, delete-orphan")
   ```

#### Activity 1.3: Create Alembic Migration

**File**: `alembic/versions/XXXX_add_filing_signature_tables.py`

**Line-Level Subtasks**:

1. Create migration file with upgrade() and downgrade() functions (see previous implementation plan for full migration code)

---

### PROJECT 2: Policy Engine Extensions

**Priority**: P0 (Critical)  
**Estimated Time**: 5 days  
**Dependencies**: PROJECT 1

*(Implementation details same as previous plan - see POLICY_ENGINE_FILING_EXTENSIONS.md)*

---

### PROJECT 3: Digital Signature Service (DigiSigner)

**Priority**: P0 (Critical)  
**Estimated Time**: 5 days  
**Dependencies**: PROJECT 1

#### Activity 3.1: Create SignatureService with DigiSigner Integration

**File**: `app/services/signature_service.py`

**Line-Level Subtasks**:

1. Create new file with complete SignatureService class (see enhanced version above)

2. Implement `request_signature()` method:
   ```python
   def request_signature(
       self,
       document_id: int,
       signers: List[Dict[str, str]],
       signature_provider: str = "digisigner",
       expires_in_days: int = 30,
       subject: Optional[str] = None,
       message: Optional[str] = None
   ) -> DocumentSignature:
       """
       Request signatures for a document via DigiSigner API.
       
       Args:
           document_id: Document ID to sign
           signers: List of signers [{"name": "...", "email": "...", "role": "..."}]
           signature_provider: Signature provider (default: "digisigner")
           expires_in_days: Days until signature request expires
           subject: Email subject (optional)
           message: Email message (optional)
           
       Returns:
           DocumentSignature instance
       """
       # 1. Load document
       document = self.db.query(Document).filter(Document.id == document_id).first()
       if not document:
           raise ValueError(f"Document {document_id} not found")
       
       # 2. Get document file path
       document_path = self._get_document_path(document)
       if not document_path or not Path(document_path).exists():
           raise ValueError(f"Document file not found: {document_path}")
       
       # 3. Upload document to DigiSigner
       document_url = self._upload_document_to_digisigner(document_path)
       
       # 4. Create signature request via DigiSigner API
       request_payload = {
           "document_id": document_url,  # Or document ID from upload response
           "signers": [
               {
                   "email": signer["email"],
                   "name": signer["name"],
                   "role": signer.get("role", "Signer"),
                   "signing_order": idx + 1 if len(signers) > 1 else None
               }
               for idx, signer in enumerate(signers)
           ],
           "subject": subject or "Please sign the document",
           "message": message or "Please review and sign the attached document",
           "expires_in_days": expires_in_days
       }
       
       response = requests.post(
           f"{self.base_url}/documents/send",
           headers=self._get_headers(),
           json=request_payload,
           timeout=30
       )
       
       self._handle_api_error(response)
       response_data = response.json()
       
       # 5. Create DocumentSignature record
       signature = DocumentSignature(
           document_id=document_id,
           signature_provider=signature_provider,
           signature_request_id=response_data["signature_request_id"],
           signature_status="pending",
           signers=signers,
           signature_provider_data=response_data,
           expires_at=datetime.utcnow() + timedelta(days=expires_in_days)
       )
       
       self.db.add(signature)
       self.db.commit()
       self.db.refresh(signature)
       
       logger.info(f"Created DigiSigner signature request {signature.signature_request_id} for document {document_id}")
       return signature
   ```

3. Integrate LangChain signature request generation (optional AI-assisted signer detection):
   ```python
   from app.chains.signature_request_chain import generate_signature_request
   
   def request_signature(
       self,
       document_id: int,
       signers: Optional[List[Dict[str, str]]] = None,
       auto_detect_signers: bool = True,  # NEW: Use AI to detect signers
       signature_provider: str = "digisigner",
       expires_in_days: int = 30,
       urgency: str = "standard"
   ) -> DocumentSignature:
       """Request signatures with optional AI-assisted signer detection."""
       # Load document and CDM data
       document = self.db.query(Document).filter(Document.id == document_id).first()
       
       # Use AI chain to detect signers if not provided
       if auto_detect_signers and not signers:
           from app.models.cdm import CreditAgreement
           credit_agreement = CreditAgreement(**document.source_cdm_data)
           
           signature_config = generate_signature_request(
               credit_agreement=credit_agreement,
               document_type="facility_agreement",
               urgency=urgency
           )
           
           signers = [
               {
                   "name": signer.name,
                   "email": signer.email,
                   "role": signer.role
               }
               for signer in signature_config.signers
           ]
           
           expires_in_days = signature_config.expiration_days
       
       # Continue with DigiSigner API integration...
   ```

4. Implement `check_signature_status()` method:
   ```python
   def check_signature_status(self, signature_request_id: str) -> Dict[str, Any]:
       """Check status of signature request via DigiSigner API."""
       response = requests.get(
           f"{self.base_url}/documents/{signature_request_id}",
           headers=self._get_headers(),
           timeout=30
       )
       
       self._handle_api_error(response)
       return response.json()
   ```

4. Implement `download_signed_document()` method:
   ```python
   def download_signed_document(self, signature_request_id: str, save_path: Optional[Path] = None) -> bytes:
       """Download signed document from DigiSigner."""
       response = requests.get(
           f"{self.base_url}/documents/{signature_request_id}/download",
           headers=self._get_headers(),
           timeout=60  # Longer timeout for file downloads
       )
       
       self._handle_api_error(response)
       return response.content
   ```

5. Implement helper methods:
   ```python
   def _get_document_path(self, document: Document) -> Optional[str]:
       """Get document file path."""
       # Try to get from document version
       if document.current_version_id:
           version = self.db.query(DocumentVersion).filter(
               DocumentVersion.id == document.current_version_id
           ).first()
           if version and version.file_path:
               return version.file_path
       
       # Try to get from file storage
       if document.deal_id:
           deal = self.db.query(Deal).filter(Deal.id == document.deal_id).first()
           if deal:
               return self.file_storage.get_document_path(
                   user_id=deal.applicant_id,
                   deal_id=deal.deal_id,
                   document_id=document.id
               )
       
       return None
   
   def _upload_document_to_digisigner(self, document_path: str) -> str:
       """Upload document to DigiSigner and return document ID."""
       with open(document_path, 'rb') as f:
           files = {'file': (Path(document_path).name, f, 'application/pdf')}
           response = requests.post(
               f"{self.base_url}/documents",
               headers={"X-DigiSigner-API-Key": self.api_key.get_secret_value() if hasattr(self.api_key, 'get_secret_value') else str(self.api_key)},
               files=files,
               timeout=60
           )
       
       self._handle_api_error(response)
       response_data = response.json()
       return response_data["document_id"]
   ```

#### Activity 3.2: Add Configuration Settings

**File**: `app/core/config.py`

**Line-Level Subtasks**:

1. Add DigiSigner configuration (around line 100, after other API settings):
   ```python
   # DigiSigner API Configuration
   DIGISIGNER_API_KEY: Optional[SecretStr] = Field(
       default=None,
       description="DigiSigner API key for digital signatures"
   )
   DIGISIGNER_BASE_URL: str = Field(
       default="https://api.digisigner.com/v1",
       description="DigiSigner API base URL"
   )
   DIGISIGNER_WEBHOOK_SECRET: Optional[SecretStr] = Field(
       default=None,
       description="DigiSigner webhook secret for signature status updates"
   )
   ```

---

### PROJECT 4: Filing Service (Companies House + Manual UI)

**Priority**: P0 (Critical)  
**Estimated Time**: 7 days  
**Dependencies**: PROJECT 1, PROJECT 2

#### Activity 4.1: Create FilingService

**File**: `app/services/filing_service.py`

**Line-Level Subtasks**:

1. Create new file with FilingService class:
   ```python
   """
   Filing Service for CreditNexus.
   
   Handles:
   - Companies House API integration (UK)
   - Manual filing UI preparation (US, FR, DE)
   - Filing status tracking
   """
   
   import logging
   import requests
   from typing import List, Dict, Any, Optional
   from datetime import datetime
   from sqlalchemy.orm import Session
   
   from app.db.models import Document, DocumentFiling, Deal
   from app.core.config import settings
   from app.services.policy_service import PolicyService, FilingRequirement
   
   logger = logging.getLogger(__name__)
   
   
   class FilingService:
       """Service for managing regulatory filings."""
       
       def __init__(self, db: Session):
           """
           Initialize filing service.
           
           Args:
               db: Database session
           """
           self.db = db
           self.companies_house_api_key = settings.COMPANIES_HOUSE_API_KEY
           self.companies_house_base_url = "https://api.company-information.service.gov.uk"
           self.policy_service = PolicyService(get_policy_engine())
       
       def determine_filing_requirements(
           self,
           document_id: int,
           agreement_type: str,
           jurisdiction: str,
           deal_id: Optional[int] = None,
           use_ai_evaluation: bool = True  # NEW: Use LangChain AI chain
       ) -> List[FilingRequirement]:
           """Determine what needs to be filed and where using AI-assisted evaluation."""
           document = self.db.query(Document).filter(Document.id == document_id).first()
           if not document:
               raise ValueError(f"Document {document_id} not found")
           
           # Load CDM data
           from app.models.cdm import CreditAgreement
           credit_agreement = CreditAgreement(**document.source_cdm_data)
           
           # Use LangChain AI chain for filing requirement evaluation
           if use_ai_evaluation:
               from app.chains.filing_requirement_chain import evaluate_filing_requirements
               
               evaluation = evaluate_filing_requirements(
                   credit_agreement=credit_agreement,
                   document_id=document_id,
                   deal_id=deal_id,
                   agreement_type=agreement_type
               )
               
               return evaluation.required_filings
           else:
               # Fallback to PolicyService (if not using AI)
               decision = self.policy_service.evaluate_filing_requirements(
                   credit_agreement=credit_agreement,
                   document_id=document_id,
                   deal_id=deal_id
               )
               return decision.required_filings
       
       def file_document_automatically(
           self,
           document_id: int,
           filing_requirement: FilingRequirement
       ) -> DocumentFiling:
           """File a document automatically via API (UK only)."""
           if filing_requirement.filing_system != "companies_house_api":
               raise ValueError(f"Automatic filing not supported for {filing_requirement.filing_system}")
           
           # Companies House API integration
           return self._file_companies_house(document_id, filing_requirement)
       
       def prepare_manual_filing(
           self,
           document_id: int,
           filing_requirement: FilingRequirement
       ) -> DocumentFiling:
           """Prepare a manual filing with AI-generated pre-filled form data."""
           # 1. Load document and CDM data
           document = self.db.query(Document).filter(Document.id == document_id).first()
           if not document:
               raise ValueError(f"Document {document_id} not found")
           
           from app.models.cdm import CreditAgreement
           credit_agreement = CreditAgreement(**document.source_cdm_data)
           
           # 2. Use LangChain AI chain to generate pre-filled form data
           from app.chains.filing_form_generation_chain import generate_filing_form_data
           
           form_data = generate_filing_form_data(
               credit_agreement=credit_agreement,
               filing_requirement=filing_requirement,
               document_id=document_id,
               deal_id=document.deal_id
           )
           
           # 3. Create DocumentFiling record with pre-filled form data
           filing = DocumentFiling(
               document_id=document_id,
               deal_id=document.deal_id,
               agreement_type=filing_requirement.agreement_type,
               jurisdiction=filing_requirement.jurisdiction,
               filing_authority=filing_requirement.authority,
               filing_system="manual_ui",
               filing_status="pending",
               filing_payload=form_data.model_dump(),  # Store pre-filled form data
               manual_submission_url=form_data.submission_url,
               deadline=filing_requirement.deadline
           )
           
           self.db.add(filing)
           self.db.commit()
           self.db.refresh(filing)
           
           logger.info(f"Prepared manual filing for document {document_id}: {filing_requirement.authority}")
           return filing
       
       def _file_companies_house(
           self,
           document_id: int,
           filing_requirement: FilingRequirement
       ) -> DocumentFiling:
           """File with Companies House API."""
           # Implementation for Companies House API
           pass
   ```

#### Activity 4.2: Companies House API Integration

**File**: `app/services/filing_service.py`

**Line-Level Subtasks**:

1. Implement `_file_companies_house()` method (around line 150):
   ```python
   def _file_companies_house(
       self,
       document_id: int,
       filing_requirement: FilingRequirement
   ) -> DocumentFiling:
       """
       File charge with Companies House API.
       
       Args:
           document_id: Document ID
           filing_requirement: FilingRequirement object
           
       Returns:
           DocumentFiling instance
       """
       # 1. Load document and CDM data
       document = self.db.query(Document).filter(Document.id == document_id).first()
       if not document:
           raise ValueError(f"Document {document_id} not found")
       
       # 2. Extract company number from CDM data
       # Assuming borrower has UK company number in CDM
       company_number = self._extract_company_number(document)
       if not company_number:
           raise ValueError("UK company number not found in document data")
       
       # 3. Prepare charge filing payload
       charge_data = {
           "charge_code": "MR01",  # Charge creation form
           "charge_creation_date": document.agreement_date.isoformat() if document.agreement_date else datetime.utcnow().date().isoformat(),
           "charge_description": self._generate_charge_description(document),
           "persons_entitled": self._extract_lenders(document),
           "secured_amount": {
               "amount": float(document.total_commitment) if document.total_commitment else 0,
               "currency": document.currency or "GBP"
           }
       }
       
       # 4. Submit to Companies House API
       import base64
       auth_string = base64.b64encode(
           f"{self.companies_house_api_key.get_secret_value() if hasattr(self.companies_house_api_key, 'get_secret_value') else str(self.companies_house_api_key)}:".encode()
       ).decode()
       
       response = requests.post(
           f"{self.companies_house_base_url}/company/{company_number}/charges",
           headers={
               "Authorization": f"Basic {auth_string}",
               "Content-Type": "application/json"
           },
           json=charge_data,
           timeout=30
       )
       
       if not response.ok:
           error_msg = f"Companies House API error: {response.status_code} - {response.text}"
           logger.error(error_msg)
           raise ValueError(error_msg)
       
       response_data = response.json()
       
       # 5. Create DocumentFiling record
       filing = DocumentFiling(
           document_id=document_id,
           deal_id=document.deal_id,
           agreement_type=filing_requirement.agreement_type,
           jurisdiction="UK",
           filing_authority="Companies House",
           filing_system="companies_house_api",
           filing_reference=response_data.get("transaction_id") or response_data.get("filing_id"),
           filing_status="submitted",
           filing_payload=charge_data,
           filing_response=response_data,
           filing_url=response_data.get("filing_url"),
           confirmation_url=response_data.get("confirmation_url"),
           filed_at=datetime.utcnow(),
           deadline=filing_requirement.deadline
       )
       
       self.db.add(filing)
       self.db.commit()
       self.db.refresh(filing)
       
       logger.info(f"Filed charge with Companies House for document {document_id}: {filing.filing_reference}")
       return filing
   ```

2. Implement helper methods (around line 250):
   ```python
   def _extract_company_number(self, document: Document) -> Optional[str]:
       """Extract UK company number from document CDM data."""
       # Try to get from document version CDM data
       if document.current_version_id:
           version = self.db.query(DocumentVersion).filter(
               DocumentVersion.id == document.current_version_id
           ).first()
           if version and version.cdm_data:
               # Extract from parties with UK jurisdiction
               parties = version.cdm_data.get("parties", [])
               for party in parties:
                   if party.get("jurisdiction") == "UK" and party.get("company_number"):
                       return party["company_number"]
       
       # Try to get from document metadata
       if document.borrower_lei:
           # Could query Companies House API to get company number from LEI
           # For now, return None
           pass
       
       return None
   
   def _generate_charge_description(self, document: Document) -> str:
       """Generate charge description from document."""
       return f"Charge securing credit facility agreement dated {document.agreement_date or 'N/A'}"
   
   def _extract_lenders(self, document: Document) -> List[Dict[str, str]]:
       """Extract lender information from document."""
       # Extract from CDM parties with Lender role
       lenders = []
       if document.current_version_id:
           version = self.db.query(DocumentVersion).filter(
               DocumentVersion.id == document.current_version_id
           ).first()
           if version and version.cdm_data:
               parties = version.cdm_data.get("parties", [])
               for party in parties:
                   if "Lender" in party.get("roles", []):
                       lenders.append({
                           "name": party.get("name", ""),
                           "lei": party.get("lei")
                       })
       return lenders
   ```

3. Implement `prepare_manual_filing()` method (around line 300):
   ```python
   def prepare_manual_filing(
       self,
       document_id: int,
       filing_requirement: FilingRequirement
   ) -> DocumentFiling:
       """
       Prepare a manual filing with pre-filled form data.
       
       Args:
           document_id: Document ID
           filing_requirement: FilingRequirement object
           
       Returns:
           DocumentFiling instance with pre-filled data
       """
       # 1. Load document
       document = self.db.query(Document).filter(Document.id == document_id).first()
       if not document:
           raise ValueError(f"Document {document_id} not found")
       
       # 2. Generate pre-filled form data based on jurisdiction
       form_data = self._generate_form_data(document, filing_requirement)
       
       # 3. Get manual submission URL
       submission_url = self._get_manual_submission_url(filing_requirement)
       
       # 4. Create DocumentFiling record
       filing = DocumentFiling(
           document_id=document_id,
           deal_id=document.deal_id,
           agreement_type=filing_requirement.agreement_type,
           jurisdiction=filing_requirement.jurisdiction,
           filing_authority=filing_requirement.authority,
           filing_system="manual_ui",
           filing_status="pending",
           filing_payload=form_data,
           manual_submission_url=submission_url,
           deadline=filing_requirement.deadline
       )
       
       self.db.add(filing)
       self.db.commit()
       self.db.refresh(filing)
       
       logger.info(f"Prepared manual filing for document {document_id}: {filing_requirement.authority}")
       return filing
   
   def _generate_form_data(self, document: Document, requirement: FilingRequirement) -> Dict[str, Any]:
       """Generate pre-filled form data based on jurisdiction."""
       form_data = {}
       
       if requirement.jurisdiction == "US":
           form_data = {
               "form_type": "8-K",
               "company_name": document.borrower_name,
               "agreement_date": document.agreement_date.isoformat() if document.agreement_date else None,
               "total_commitment": str(document.total_commitment) if document.total_commitment else None,
               "currency": document.currency
           }
       elif requirement.jurisdiction == "FR":
           form_data = {
               "company_name": document.borrower_name,
               "agreement_date": document.agreement_date.isoformat() if document.agreement_date else None,
               "total_commitment": str(document.total_commitment) if document.total_commitment else None,
               "currency": document.currency
           }
       elif requirement.jurisdiction == "DE":
           form_data = {
               "company_name": document.borrower_name,
               "agreement_date": document.agreement_date.isoformat() if document.agreement_date else None,
               "total_commitment": str(document.total_commitment) if document.total_commitment else None,
               "currency": document.currency
           }
       
       return form_data
   
   def _get_manual_submission_url(self, requirement: FilingRequirement) -> str:
       """Get manual submission portal URL for filing authority."""
       urls = {
           "SEC": "https://www.sec.gov/edgar/searchedgar/companysearch.html",
           "AMF": "https://www.amf-france.org/en/your-requests/declarations",
           "BaFin": "https://www.bafin.de/EN/Aufsicht/Unternehmen/Unternehmen_node_en.html",
           "Tribunal de Commerce": "https://www.infogreffe.fr/",
           "Handelsregister": "https://www.handelsregister.de/"
       }
       return urls.get(requirement.authority, "")
   ```

4. Implement `update_manual_filing_status()` method (around line 400):
   ```python
   def update_manual_filing_status(
       self,
       filing_id: int,
       filing_reference: str,
       submission_notes: Optional[str] = None,
       submitted_by: Optional[int] = None
   ) -> DocumentFiling:
       """
       Update manual filing status after user submits via external portal.
       
       Args:
           filing_id: DocumentFiling ID
           filing_reference: External filing reference from portal
           submission_notes: Optional notes from user
           submitted_by: User ID who submitted
           
       Returns:
           Updated DocumentFiling instance
       """
       filing = self.db.query(DocumentFiling).filter(DocumentFiling.id == filing_id).first()
       if not filing:
           raise ValueError(f"Filing {filing_id} not found")
       
       filing.filing_status = "submitted"
       filing.filing_reference = filing_reference
       filing.submitted_by = submitted_by
       filing.submitted_at = datetime.utcnow()
       filing.submission_notes = submission_notes
       
       self.db.commit()
       self.db.refresh(filing)
       
       logger.info(f"Updated manual filing {filing_id} status to submitted: {filing_reference}")
       return filing
   ```

---

### PROJECT 5: Manual Filing UI Components

**Priority**: P0 (Critical)  
**Estimated Time**: 6 days  
**Dependencies**: PROJECT 4

#### Activity 5.1: Create FilingRequirementsPanel Component

**File**: `client/src/components/FilingRequirementsPanel.tsx`

**Line-Level Subtasks**:

1. Create component file and imports (lines 1-30):
   ```typescript
   import { useState, useEffect } from 'react';
   import { fetchWithAuth } from '@/context/AuthContext';
   import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
   import { Button } from '@/components/ui/button';
   import { Badge } from '@/components/ui/badge';
   import { Alert, AlertDescription } from '@/components/ui/alert';
   import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
   import {
     FileText,
     Clock,
     CheckCircle2,
     AlertCircle,
     ExternalLink,
     Calendar,
     Building2,
     Loader2,
     ChevronRight
   } from 'lucide-react';
   ```

2. Define TypeScript interfaces (lines 31-60):
   ```typescript
   interface FilingRequirement {
     id: number;
     authority: string;
     filing_system: string
     deadline: string
     filing_status: string
     jurisdiction: string
     agreement_type: string
     api_available: boolean
     manual_submission_url?: string
     days_remaining?: number
     urgency?: 'critical' | 'high' | 'medium' | 'low'
   }
   
   interface FilingRequirementsPanelProps {
     documentId: number
     dealId?: number
     onFilingSubmitted?: () => void
   }
   ```

3. Create main component function (lines 61-120):
   ```typescript
   export function FilingRequirementsPanel({ 
     documentId, 
     dealId,
     onFilingSubmitted 
   }: FilingRequirementsPanelProps) {
     const [requirements, setRequirements] = useState<FilingRequirement[]>([]);
     const [loading, setLoading] = useState(true);
     const [error, setError] = useState<string | null>(null);
     const [selectedJurisdiction, setSelectedJurisdiction] = useState<string | 'all'>('all');
     const [selectedStatus, setSelectedStatus] = useState<string | 'all'>('all');
     
     useEffect(() => {
       fetchFilingRequirements();
     }, [documentId, dealId]);
     
     const fetchFilingRequirements = async () => {
       setLoading(true);
       setError(null);
       try {
         const response = await fetchWithAuth(
           `/api/documents/${documentId}/filing/requirements${dealId ? `?deal_id=${dealId}` : ''}`
         );
         if (!response.ok) throw new Error('Failed to fetch filing requirements');
         const data = await response.json();
         setRequirements(data.required_filings || []);
       } catch (err) {
         setError(err instanceof Error ? err.message : 'Failed to load requirements');
       } finally {
         setLoading(false);
       }
     };
   ```

4. Add render logic with status badges and actions (lines 121-250):
   ```typescript
     const getStatusBadge = (status: string) => {
       const variants = {
         pending: { variant: 'secondary' as const, icon: Clock, label: 'Pending' },
         submitted: { variant: 'default' as const, icon: CheckCircle2, label: 'Submitted' },
         accepted: { variant: 'default' as const, icon: CheckCircle2, label: 'Accepted' },
         rejected: { variant: 'destructive' as const, icon: AlertCircle, label: 'Rejected' }
       };
       const config = variants[status as keyof typeof variants] || variants.pending;
       return <Badge variant={config.variant}>{config.label}</Badge>;
     };
     
     const getUrgencyBadge = (urgency?: string, daysRemaining?: number) => {
       if (!urgency || !daysRemaining) return null;
       const colors = {
         critical: 'bg-red-500/20 text-red-300',
         high: 'bg-orange-500/20 text-orange-300',
         medium: 'bg-yellow-500/20 text-yellow-300',
         low: 'bg-blue-500/20 text-blue-300'
       };
       return (
         <Badge className={colors[urgency as keyof typeof colors] || colors.low}>
           {daysRemaining} day{daysRemaining !== 1 ? 's' : ''} remaining
         </Badge>
       );
     };
     
     const handleFileAutomatically = async (filingId: number) => {
       // Companies House API filing
       try {
         const response = await fetchWithAuth(
           `/api/filings/${filingId}/submit-automatic`,
           { method: 'POST' }
         );
         if (!response.ok) throw new Error('Filing submission failed');
         await fetchFilingRequirements();
         onFilingSubmitted?.();
       } catch (err) {
         setError(err instanceof Error ? err.message : 'Filing failed');
       }
     };
     
     const handlePrepareManualFiling = (filingId: number) => {
       // Open manual filing form modal
       // Implementation in Activity 5.2
     };
   ```

5. Add JSX return with filtering and list (lines 251-350):
   ```typescript
     const filteredRequirements = requirements.filter(req => {
       if (selectedJurisdiction !== 'all' && req.jurisdiction !== selectedJurisdiction) return false;
       if (selectedStatus !== 'all' && req.filing_status !== selectedStatus) return false;
       return true;
     });
     
     return (
       <Card>
         <CardHeader>
           <CardTitle className="flex items-center gap-2">
             <FileText className="h-5 w-5" />
             Filing Requirements
           </CardTitle>
         </CardHeader>
         <CardContent>
           {/* Filters */}
           <div className="flex gap-4 mb-4">
             <select 
               value={selectedJurisdiction} 
               onChange={(e) => setSelectedJurisdiction(e.target.value)}
               className="px-3 py-2 border rounded"
             >
               <option value="all">All Jurisdictions</option>
               <option value="US">United States</option>
               <option value="UK">United Kingdom</option>
               <option value="FR">France</option>
               <option value="DE">Germany</option>
             </select>
             <select 
               value={selectedStatus} 
               onChange={(e) => setSelectedStatus(e.target.value)}
               className="px-3 py-2 border rounded"
             >
               <option value="all">All Statuses</option>
               <option value="pending">Pending</option>
               <option value="submitted">Submitted</option>
               <option value="accepted">Accepted</option>
               <option value="rejected">Rejected</option>
             </select>
           </div>
           
           {/* Requirements List */}
           {loading ? (
             <div className="flex items-center justify-center py-8">
               <Loader2 className="h-6 w-6 animate-spin" />
             </div>
           ) : filteredRequirements.length === 0 ? (
             <Alert>
               <AlertDescription>No filing requirements found</AlertDescription>
             </Alert>
           ) : (
             <div className="space-y-4">
               {filteredRequirements.map((req) => (
                 <Card key={req.id} className="p-4">
                   <div className="flex items-start justify-between">
                     <div className="flex-1">
                       <div className="flex items-center gap-2 mb-2">
                         <Building2 className="h-4 w-4" />
                         <span className="font-semibold">{req.authority}</span>
                         {getStatusBadge(req.filing_status)}
                         {getUrgencyBadge(req.urgency, req.days_remaining)}
                       </div>
                       <div className="text-sm text-muted-foreground space-y-1">
                         <div>Jurisdiction: {req.jurisdiction}</div>
                         <div>Deadline: {new Date(req.deadline).toLocaleDateString()}</div>
                         {req.filing_system === 'manual_ui' && (
                           <div className="text-orange-500">Manual filing required</div>
                         )}
                       </div>
                     </div>
                     <div className="flex gap-2">
                       {req.api_available && req.filing_status === 'pending' && (
                         <Button 
                           size="sm" 
                           onClick={() => handleFileAutomatically(req.id)}
                         >
                           File Automatically
                         </Button>
                       )}
                       {req.filing_system === 'manual_ui' && req.filing_status === 'pending' && (
                         <Button 
                           size="sm" 
                           variant="outline"
                           onClick={() => handlePrepareManualFiling(req.id)}
                         >
                           Prepare Filing
                         </Button>
                       )}
                       <Button size="sm" variant="ghost">
                         <ExternalLink className="h-4 w-4" />
                       </Button>
                     </div>
                   </div>
                 </Card>
               ))}
             </div>
           )}
         </CardContent>
       </Card>
     );
   }
   ```
   ```typescript
   /**
    * FilingRequirementsPanel - Displays filing requirements for a document
    * 
    * Features:
    * - List of required filings
    * - Deadline tracking
    * - Status indicators
    * - Action buttons (File Now, Prepare, View Status)
    */
   
   import { useState, useEffect } from 'react';
   import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
   import { Button } from '@/components/ui/button';
   import { Badge } from '@/components/ui/badge';
   import { Alert, AlertDescription } from '@/components/ui/alert';
   import {
     FileText,
     Clock,
     CheckCircle2,
     AlertCircle,
     ExternalLink,
     Calendar,
     Building2
   } from 'lucide-react';
   
   interface FilingRequirement {
     id: number;
     authority: string;
     filing_system: string;
     deadline: string;
     filing_status: string;
     jurisdiction: string;
     agreement_type: string;
     api_available: boolean;
     manual_submission_url?: string;
   }
   
   interface FilingRequirementsPanelProps {
     documentId: number;
     dealId?: number;
   }
   
   export function FilingRequirementsPanel({ documentId, dealId }: FilingRequirementsPanelProps) {
     const [requirements, setRequirements] = useState<FilingRequirement[]>([]);
     const [loading, setLoading] = useState(true);
     const [error, setError] = useState<string | null>(null);
     
     // Implementation...
   }
   ```

2. Add filing status badges with color coding
3. Add deadline countdown display
4. Add action buttons for each filing requirement

#### Activity 5.2: Create ManualFilingForm Component

**File**: `client/src/components/ManualFilingForm.tsx`

**Line-Level Subtasks**:

1. Create component file with imports (lines 1-40):
   ```typescript
   import { useState, useEffect } from 'react';
   import { fetchWithAuth } from '@/context/AuthContext';
   import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
   import { Button } from '@/components/ui/button';
   import { Input } from '@/components/ui/input';
   import { Label } from '@/components/ui/label';
   import { Textarea } from '@/components/ui/textarea';
   import { Alert, AlertDescription } from '@/components/ui/alert';
   import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
   import {
     FileText,
     Upload,
     ExternalLink,
     CheckCircle2,
     AlertCircle,
     Loader2
   } from 'lucide-react';
   ```

2. Define interfaces and component props (lines 41-80):
   ```typescript
   interface FilingFormData {
     // US SEC Fields
     form_type?: string;  // 8-K, 10-Q, 10-K
     company_name?: string;
     company_cik?: string;
     agreement_date?: string;
     total_commitment?: string;
     currency?: string;
     
     // UK Companies House Fields
     company_number?: string;
     charge_description?: string;
     secured_amount?: string;
     
     // France AMF Fields
     company_siren?: string;
     investment_percentage?: string;
     sector_classification?: string;
     
     // Germany BaFin Fields
     company_hrb?: string;
     investment_amount?: string;
   }
   
   interface ManualFilingFormProps {
     filingId: number;
     filingRequirement: FilingRequirement;
     isOpen: boolean;
     onClose: () => void;
     onSubmitted: () => void;
   }
   ```

3. Create form component with jurisdiction-specific fields (lines 81-200):
   ```typescript
   export function ManualFilingForm({
     filingId,
     filingRequirement,
     isOpen,
     onClose,
     onSubmitted
   }: ManualFilingFormProps) {
     const [formData, setFormData] = useState<FilingFormData>({});
     const [loading, setLoading] = useState(false);
     const [submitting, setSubmitting] = useState(false);
     const [error, setError] = useState<string | null>(null);
     const [attachments, setAttachments] = useState<File[]>([]);
     
     useEffect(() => {
       if (isOpen) {
         loadPreFilledData();
       }
     }, [isOpen, filingId]);
     
     const loadPreFilledData = async () => {
       setLoading(true);
       try {
         const response = await fetchWithAuth(`/api/filings/${filingId}/prepare`);
         if (!response.ok) throw new Error('Failed to load filing data');
         const data = await response.json();
         setFormData(data.form_data || {});
       } catch (err) {
         setError(err instanceof Error ? err.message : 'Failed to load data');
       } finally {
         setLoading(false);
       }
     };
     
     const handleSubmit = async () => {
       setSubmitting(true);
       setError(null);
       try {
         const formDataToSend = new FormData();
         Object.entries(formData).forEach(([key, value]) => {
           if (value) formDataToSend.append(key, String(value));
         });
         attachments.forEach((file, idx) => {
           formDataToSend.append(`attachment_${idx}`, file);
         });
         
         const response = await fetchWithAuth(
           `/api/filings/${filingId}/submit-manual`,
           {
             method: 'POST',
             body: formDataToSend
           }
         );
         
         if (!response.ok) throw new Error('Submission failed');
         onSubmitted();
         onClose();
       } catch (err) {
         setError(err instanceof Error ? err.message : 'Submission failed');
       } finally {
         setSubmitting(false);
       }
     };
   ```

4. Add jurisdiction-specific form rendering (lines 201-350):
   ```typescript
     const renderUSForm = () => (
       <div className="space-y-4">
         <div>
           <Label>Form Type</Label>
           <select 
             value={formData.form_type || ''}
             onChange={(e) => setFormData({...formData, form_type: e.target.value})}
             className="w-full px-3 py-2 border rounded"
           >
             <option value="">Select form type</option>
             <option value="8-K">8-K (Material Event)</option>
             <option value="10-Q">10-Q (Quarterly Report)</option>
             <option value="10-K">10-K (Annual Report)</option>
           </select>
         </div>
         <div>
           <Label>Company Name</Label>
           <Input 
             value={formData.company_name || ''}
             onChange={(e) => setFormData({...formData, company_name: e.target.value})}
           />
         </div>
         <div>
           <Label>CIK Number</Label>
           <Input 
             value={formData.company_cik || ''}
             onChange={(e) => setFormData({...formData, company_cik: e.target.value})}
           />
         </div>
         <div>
           <Label>Agreement Date</Label>
           <Input 
             type="date"
             value={formData.agreement_date || ''}
             onChange={(e) => setFormData({...formData, agreement_date: e.target.value})}
           />
         </div>
         <div>
           <Label>Total Commitment</Label>
           <Input 
             value={formData.total_commitment || ''}
             onChange={(e) => setFormData({...formData, total_commitment: e.target.value})}
           />
         </div>
       </div>
     );
     
     const renderFRForm = () => (
       <div className="space-y-4">
         <div>
           <Label>Numéro SIREN</Label>
           <Input 
             value={formData.company_siren || ''}
             onChange={(e) => setFormData({...formData, company_siren: e.target.value})}
           />
         </div>
         <div>
           <Label>Pourcentage d'investissement</Label>
           <Input 
             type="number"
             value={formData.investment_percentage || ''}
             onChange={(e) => setFormData({...formData, investment_percentage: e.target.value})}
           />
         </div>
         <div>
           <Label>Classification du secteur</Label>
           <select 
             value={formData.sector_classification || ''}
             onChange={(e) => setFormData({...formData, sector_classification: e.target.value})}
             className="w-full px-3 py-2 border rounded"
           >
             <option value="">Sélectionner un secteur</option>
             <option value="defense">Défense</option>
             <option value="energy">Énergie</option>
             <option value="water">Eau</option>
             <option value="transport">Transport</option>
           </select>
         </div>
       </div>
     );
     
     const renderDEForm = () => (
       <div className="space-y-4">
         <div>
           <Label>HRB Nummer</Label>
           <Input 
             value={formData.company_hrb || ''}
             onChange={(e) => setFormData({...formData, company_hrb: e.target.value})}
           />
         </div>
         <div>
           <Label>Investitionsbetrag</Label>
           <Input 
             type="number"
             value={formData.investment_amount || ''}
             onChange={(e) => setFormData({...formData, investment_amount: e.target.value})}
           />
         </div>
       </div>
     );
   ```

5. Add JSX return with dialog and form (lines 351-450):
   ```typescript
     return (
       <Dialog open={isOpen} onOpenChange={onClose}>
         <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
           <DialogHeader>
             <DialogTitle className="flex items-center gap-2">
               <FileText className="h-5 w-5" />
               Manual Filing: {filingRequirement.authority}
             </DialogTitle>
           </DialogHeader>
           
           {loading ? (
             <div className="flex items-center justify-center py-8">
               <Loader2 className="h-6 w-6 animate-spin" />
             </div>
           ) : (
             <div className="space-y-6">
               {/* External Portal Link */}
               {filingRequirement.manual_submission_url && (
                 <Alert>
                   <ExternalLink className="h-4 w-4" />
                   <AlertDescription>
                     <a 
                       href={filingRequirement.manual_submission_url} 
                       target="_blank" 
                       rel="noopener noreferrer"
                       className="text-blue-500 hover:underline"
                     >
                       Open {filingRequirement.authority} filing portal
                     </a>
                   </AlertDescription>
                 </Alert>
               )}
               
               {/* Jurisdiction-Specific Form */}
               {filingRequirement.jurisdiction === 'US' && renderUSForm()}
               {filingRequirement.jurisdiction === 'FR' && renderFRForm()}
               {filingRequirement.jurisdiction === 'DE' && renderDEForm()}
               
               {/* File Attachments */}
               <div>
                 <Label>Supporting Documents</Label>
                 <div className="mt-2">
                   <input
                     type="file"
                     multiple
                     onChange={(e) => setAttachments(Array.from(e.target.files || []))}
                     className="w-full"
                   />
                 </div>
               </div>
               
               {/* Submission Notes */}
               <div>
                 <Label>Submission Notes</Label>
                 <Textarea 
                   placeholder="Add any notes about this filing submission..."
                   rows={3}
                 />
               </div>
               
               {error && (
                 <Alert variant="destructive">
                   <AlertCircle className="h-4 w-4" />
                   <AlertDescription>{error}</AlertDescription>
                 </Alert>
               )}
               
               {/* Actions */}
               <div className="flex justify-end gap-2">
                 <Button variant="outline" onClick={onClose}>Cancel</Button>
                 <Button 
                   onClick={handleSubmit} 
                   disabled={submitting}
                 >
                   {submitting ? (
                     <>
                       <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                       Submitting...
                     </>
                   ) : (
                     <>
                       <CheckCircle2 className="h-4 w-4 mr-2" />
                       Mark as Submitted
                     </>
                   )}
                 </Button>
               </div>
             </div>
           )}
         </DialogContent>
       </Dialog>
     );
   }
   ```

#### Activity 5.3: Create FilingStatusDashboard Component

**File**: `client/src/components/FilingStatusDashboard.tsx`

**Line-Level Subtasks**:

1. Create dashboard component showing all filings for a deal/document
2. Add filtering by jurisdiction, status, deadline
3. Add export functionality for filing reports

---

### PROJECT 6: API Endpoints

**Priority**: P0 (Critical)  
**Estimated Time**: 4 days  
**Dependencies**: PROJECT 3, PROJECT 4, PROJECT 5

#### Activity 6.1: Add Signature Endpoints

**File**: `app/api/routes.py`

**Line-Level Subtasks**:

1. Add signature request endpoint (around line 9500):
   ```python
   @router.post("/documents/{document_id}/signatures/request")
   async def request_document_signature(
       document_id: int,
       signers: List[Dict[str, str]],
       expires_in_days: int = 30,
       db: Session = Depends(get_db),
       current_user: User = Depends(require_auth)
   ):
       """Request signatures for a document via DigiSigner."""
       from app.services.signature_service import SignatureService
       
       signature_service = SignatureService(db)
       signature = signature_service.request_signature(
           document_id=document_id,
           signers=signers,
           expires_in_days=expires_in_days
       )
       
       return {
           "status": "success",
           "signature": signature.to_dict()
       }
   ```

2. Add signature status endpoint
3. Add signature download endpoint
4. Add webhook endpoint for DigiSigner status updates

#### Activity 6.2: Add Filing Endpoints

**Line-Level Subtasks**:

1. Add filing requirement evaluation endpoint
2. Add Companies House filing submission endpoint (automated)
3. Add manual filing preparation endpoint
4. Add manual filing submission tracking endpoint
5. Add filing status endpoint
6. Add deadline alerts endpoint

---

### PROJECT 7: Verifiers Implementation

**Priority**: P1 (High)  
**Estimated Time**: 3 days  
**Dependencies**: PROJECT 2, PROJECT 3, PROJECT 4

*(Implementation details same as VERIFIER_DESIGN_PATTERNS.md)*

---

### PROJECT 8: Background Tasks

**Priority**: P1 (High)  
**Estimated Time**: 2 days  
**Dependencies**: PROJECT 5

#### Activity 8.1: Create Deadline Monitoring Task

**File**: `app/services/background_tasks.py`

**Line-Level Subtasks**:

1. Add scheduled task for deadline checking (daily at 9 AM)
2. Add task for signature status updates (hourly)
3. Add task for filing status verification (daily)

---

### PROJECT 9: Frontend Integration

**Priority**: P1 (High)  
**Estimated Time**: 5 days  
**Dependencies**: PROJECT 6

#### Activity 9.1: Integrate Filing UI into Document Views

**File**: `client/src/components/DealDetail.tsx`

**Line-Level Subtasks**:

1. Add "Filing Requirements" tab to DealDetail component
2. Integrate FilingRequirementsPanel component
3. Add filing status indicators to document list

#### Activity 9.2: Add Signature UI to Document Generator

**File**: `client/src/apps/document-generator/DocumentGenerator.tsx`

**Line-Level Subtasks**:

1. Add signature request button after document generation
2. Add signature status display
3. Add signed document download

---

## UI Components Design

### Filing Requirements Panel

**Location**: Document/Deal detail view  
**Features**:
- List of required filings with status badges
- Deadline countdown (critical/high/medium urgency)
- Action buttons:
  - "File Automatically" (UK - Companies House)
  - "Prepare Filing" (US, FR, DE - opens manual form)
  - "View Status" (all)
- Jurisdiction filter
- Status filter (pending/submitted/accepted/rejected)

### Manual Filing Form

**Location**: Modal/Dialog  
**Features**:
- Pre-filled form fields from CDM data
- Jurisdiction-specific fields:
  - US: SEC form fields (8-K, 10-Q, etc.)
  - FR: AMF form fields (French language)
  - DE: BaFin form fields (German language)
- Document attachment
- Submission notes
- External portal link (opens in new tab)
- Submission tracking

### Filing Status Dashboard

**Location**: Standalone page or tab  
**Features**:
- All filings for deals/documents
- Filtering and sorting
- Export to CSV/PDF
- Deadline alerts
- Compliance status overview

---

## API Integration Details

### DigiSigner API Integration

**Base URL**: `https://api.digisigner.com/v1`  
**Authentication**: `X-DigiSigner-API-Key` header

**Key Endpoints**:
- `POST /documents` - Upload document
- `POST /documents/{id}/send` - Send for signature
- `GET /documents/{id}` - Get status
- `GET /documents/{id}/download` - Download signed document
- `POST /webhooks` - Register webhook

**Error Handling**:
- Retry logic for transient errors
- Rate limiting handling
- Webhook verification

### Companies House API Integration

**Base URL**: `https://api.company-information.service.gov.uk`  
**Authentication**: Basic Auth with API key

**Key Endpoints**:
- `POST /company/{company_number}/charges` - File charge
- `GET /company/{company_number}/charges` - Get charges
- `GET /company/{company_number}` - Get company info

---

## Testing Strategy

### Unit Tests
- SignatureService methods
- FilingService methods
- PolicyService filing methods
- Verifier functions

### Integration Tests
- DigiSigner API integration (mock)
- Companies House API integration (test environment)
- End-to-end signature workflow
- End-to-end filing workflow (UK automated)
- Manual filing UI workflow

### Manual Testing
- DigiSigner free tier integration
- Companies House API (test environment)
- Manual filing form (all jurisdictions)
- Deadline alerts

---

## Deployment Plan

### Phase 1: Foundation (Weeks 1-2)
- Database schema changes
- Policy engine extensions
- Basic services

### Phase 2: API Integration (Weeks 3-4)
- DigiSigner API integration
- Companies House API integration
- Manual filing preparation

### Phase 3: UI Development (Weeks 5-6)
- Filing requirements panel
- Manual filing form
- Filing status dashboard

### Phase 4: Automation (Weeks 7-8)
- Verifier implementation
- Background task scheduling
- Alert system

### Phase 5: Testing & Deployment (Weeks 9-10)
- Integration testing
- User acceptance testing
- Production deployment

---

**Document Status**: ✅ Enhanced Complete  
**Ready for**: Implementation
