# LLM Client Abstraction Implementation Plan

## Executive Summary

This document outlines the plan to abstract OpenAI client usage in CreditNexus with an OpenAI-compatible client interface that supports multiple inference backends (OpenAI, vLLM, HuggingFace Inference API). The abstraction will maintain compatibility with LangChain while allowing runtime configuration of the LLM provider.

## Current State Analysis

### OpenAI Usage Locations

The following modules directly instantiate `ChatOpenAI` from `langchain_openai`:

1. **`app/chains/extraction_chain.py`**
   - `create_extraction_chain()` - Main extraction chain
   - Uses: `ChatOpenAI(model="gpt-4o", temperature=0, api_key=...)`

2. **`app/chains/map_reduce_chain.py`**
   - `create_partial_extraction_chain()` - Partial extraction for map phase
   - `create_reducer_chain()` - Reducer for reduce phase
   - Both use: `ChatOpenAI(model="gpt-4o", temperature=0, api_key=...)`

3. **`app/agents/analyzer.py`**
   - `create_spt_extraction_chain()` - SPT extraction
   - `create_address_extraction_chain()` - Address extraction
   - `get_embeddings_model()` - Returns `OpenAIEmbeddings`
   - All use: `ChatOpenAI(model="gpt-4o", temperature=0, api_key=...)` or `OpenAIEmbeddings(api_key=..., model="text-embedding-3-small")`

### Current Configuration Pattern

- **Location**: `app/core/config.py`
- **Pattern**: Pydantic `BaseSettings` with `.env` file loading
- **Current Settings**: 
  - `OPENAI_API_KEY: SecretStr` (required)
  - `SENTINELHUB_KEY: SecretStr` (optional)
  - `SENTINELHUB_SECRET: SecretStr` (optional)
- **Initialization**: Global `settings = Settings()` object instantiated at module import

### Design Patterns Identified

1. **Factory Functions**: `create_*_chain()` functions that return configured LLM instances
2. **Global Settings**: Single `settings` object accessed across modules
3. **FastAPI Lifespan**: `@asynccontextmanager` in `server.py` for startup/shutdown
4. **No Dependency Injection**: Direct imports and instantiation, no DI container

## Proposed Architecture

### 1. LangChain-Based Client Factory

**Location**: `app/core/llm_client.py`

Leverage LangChain's built-in provider support and `init_chat_model()` function for unified initialization:

```python
from langchain_core.language_models import BaseChatModel
from langchain_core.embeddings import Embeddings
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_huggingface import HuggingFaceEmbeddings
from typing import Optional, Union

def create_chat_model(
    provider: str,
    model: str,
    temperature: float = 0,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    **kwargs
) -> BaseChatModel:
    """
    Create a LangChain chat model using the specified provider.
    
    Uses LangChain's native provider support:
    - OpenAI: Uses langchain_openai.ChatOpenAI
    - vLLM: Uses ChatOpenAI with base_url pointing to vLLM server
    - HuggingFace: Uses ChatOpenAI with HF Inference Providers API endpoint
    
    Args:
        provider: One of 'openai', 'vllm', 'huggingface'
        model: Model identifier (e.g., 'gpt-4o', 'meta-llama/Llama-2-7b-chat-hf')
        temperature: Sampling temperature
        api_key: API key for authentication
        base_url: Base URL for API (required for vLLM, optional for others)
        **kwargs: Additional provider-specific arguments
    
    Returns:
        BaseChatModel instance compatible with LangChain
    """
    if provider == "openai":
        return ChatOpenAI(
            model=model,
            temperature=temperature,
            api_key=api_key,
            **kwargs
        )
    elif provider == "vllm":
        if not base_url:
            raise ValueError("VLLM_BASE_URL is required for vLLM provider")
        # vLLM exposes OpenAI-compatible API at /v1/chat/completions
        return ChatOpenAI(
            model=model,
            temperature=temperature,
            base_url=base_url.rstrip('/') + '/v1',  # Ensure /v1 suffix
            api_key=api_key,  # Optional, for auth if vLLM server requires it
            **kwargs
        )
    elif provider == "huggingface":
        # HuggingFace Inference Providers API uses OpenAI-compatible endpoint
        # Format: router.huggingface.co/{provider}/v3/openai/chat/completions
        if not api_key:
            raise ValueError("HUGGINGFACE_API_KEY is required for HuggingFace provider")
        
        # Extract provider from model if in format "provider/model-name"
        # Otherwise use default HF endpoint
        if base_url:
            hf_base_url = base_url
        else:
            # Default to HuggingFace Inference Providers router
            # For direct HF models, use: https://api-inference.huggingface.co/v1
            # For HF Inference Providers (Cohere, fal, etc.), use router endpoint
            hf_base_url = "https://api-inference.huggingface.co/v1"
        
        return ChatOpenAI(
            model=model,
            temperature=temperature,
            base_url=hf_base_url,
            api_key=api_key,
            **kwargs
        )
    else:
        raise ValueError(f"Unsupported provider: {provider}")


def create_embeddings_model(
    provider: str,
    model: str,
    api_key: Optional[str] = None,
    **kwargs
) -> Embeddings:
    """
    Create a LangChain embeddings model using the specified provider.
    
    Args:
        provider: One of 'openai', 'huggingface'
        model: Model identifier
        api_key: API key for authentication
        **kwargs: Additional provider-specific arguments
    
    Returns:
        Embeddings instance compatible with LangChain
    """
    if provider == "openai":
        return OpenAIEmbeddings(
            model=model,
            openai_api_key=api_key,
            **kwargs
        )
    elif provider == "huggingface":
        # Use langchain_huggingface for native HF embeddings support
        try:
            from langchain_huggingface import HuggingFaceEmbeddings
            return HuggingFaceEmbeddings(
                model_name=model,
                **kwargs
            )
        except ImportError:
            # Fallback: Use OpenAI-compatible endpoint if langchain_huggingface not available
            from langchain_openai import OpenAIEmbeddings
            return OpenAIEmbeddings(
                model=model,
                base_url="https://api-inference.huggingface.co/v1",
                openai_api_key=api_key,
                **kwargs
            )
    else:
        raise ValueError(f"Unsupported embeddings provider: {provider}")
```

### 2. Provider-Specific Details

#### 2.1 OpenAI (Default)
- **Package**: `langchain-openai` (already in requirements)
- **Implementation**: Direct use of `ChatOpenAI` and `OpenAIEmbeddings`
- **Configuration**: Requires `OPENAI_API_KEY`
- **Model Format**: `"gpt-4o"`, `"gpt-4-turbo"`, etc.

#### 2.2 vLLM
- **Package**: Uses `langchain-openai` with custom `base_url`
- **Implementation**: vLLM exposes OpenAI-compatible API at `/v1/chat/completions`
- **Configuration**: Requires `VLLM_BASE_URL` (e.g., `http://localhost:8000`)
- **Model Format**: HuggingFace model ID (e.g., `"meta-llama/Llama-2-7b-chat-hf"`)
- **Note**: vLLM server must be running and accessible
- **Example**: `base_url="http://localhost:8000"` → uses `http://localhost:8000/v1/chat/completions`

#### 2.3 HuggingFace Inference API
- **Package**: `langchain-openai` (for chat) or `langchain-huggingface` (for embeddings)
- **Implementation**: 
  - **Direct HF Models**: Use `ChatOpenAI` with `base_url="https://api-inference.huggingface.co/v1"`
  - **Inference Providers**: Use router endpoint `router.huggingface.co/{provider}/v3/openai/chat/completions`
  - **Embeddings**: Use `HuggingFaceEmbeddings` from `langchain-huggingface` or OpenAI-compatible endpoint
- **Configuration**: Requires `HUGGINGFACE_API_KEY` (HF token)
- **Model Format**: 
  - Direct HF models: `"meta-llama/Meta-Llama-3-8B-Instruct"`
  - Provider models: `"cohere/command-r-plus"` (when using router endpoint)
- **Inference Providers**: Access multiple providers via router:
  - **Cohere**: `router.huggingface.co/cohere/v3/openai`
  - **fal**: `router.huggingface.co/fal/v3/openai`
  - **Replicate**: `router.huggingface.co/replicate/v3/openai`
  - **Together AI**: `router.huggingface.co/together/v3/openai`
  - All use same HF token for authentication

### 3. Configuration Extension

**Location**: `app/core/config.py`

Extend `Settings` class with LLM provider configuration and policy engine settings:

```python
from enum import Enum
from pathlib import Path
from typing import Optional, List
from pydantic import SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

class LLMProvider(str, Enum):
    OPENAI = "openai"
    VLLM = "vllm"
    HUGGINGFACE = "huggingface"

class Settings(BaseSettings):
    # Existing settings...
    OPENAI_API_KEY: SecretStr
    
    # New LLM provider settings
    LLM_PROVIDER: LLMProvider = LLMProvider.OPENAI
    LLM_MODEL: str = "gpt-4o"  # Default model name
    LLM_TEMPERATURE: float = 0.0
    
    # vLLM-specific settings
    VLLM_BASE_URL: Optional[str] = None  # e.g., "http://localhost:8000/v1"
    VLLM_API_KEY: Optional[SecretStr] = None  # Optional, for auth
    
    # HuggingFace-specific settings
    HUGGINGFACE_API_KEY: Optional[SecretStr] = None
    HUGGINGFACE_BASE_URL: Optional[str] = None  # Defaults to https://api-inference.huggingface.co/v1
    # For HuggingFace Inference Providers (Cohere, fal, etc.):
    # Use HUGGINGFACE_BASE_URL=router.huggingface.co/{provider}/v3/openai
    
    # Embeddings settings
    EMBEDDINGS_MODEL: str = "text-embedding-3-small"
    EMBEDDINGS_PROVIDER: Optional[LLMProvider] = None  # If None, uses LLM_PROVIDER
    
    # Policy Engine Configuration
    POLICY_ENABLED: bool = True  # Feature flag to enable/disable policy engine
    POLICY_RULES_DIR: Path = Path("app/policies")  # Directory containing YAML policy files
    POLICY_RULES_PATTERN: str = "*.yaml"  # File pattern for policy rule files
    POLICY_ENGINE_VENDOR: Optional[str] = None  # Policy engine implementation (e.g., "aspasia", "custom")
    POLICY_AUTO_RELOAD: bool = False  # Auto-reload policies on file change (development only)
    
    @field_validator('LLM_PROVIDER', mode='before')
    @classmethod
    def validate_llm_provider(cls, v):
        """Validate LLM provider configuration."""
        if isinstance(v, str):
            try:
                return LLMProvider(v.lower())
            except ValueError:
                raise ValueError(f"Invalid LLM_PROVIDER: {v}. Must be one of: {[p.value for p in LLMProvider]}")
        return v
    
    @field_validator('POLICY_RULES_DIR', mode='before')
    @classmethod
    def validate_policy_rules_dir(cls, v):
        """Convert string path to Path object."""
        if isinstance(v, str):
            return Path(v)
        return v
    
    def get_policy_rules_files(self) -> List[Path]:
        """
        Get list of policy rule YAML files from configured directory.
        
        Returns:
            List of Path objects for policy rule files
        """
        if not self.POLICY_ENABLED:
            return []
        
        rules_dir = Path(self.POLICY_RULES_DIR)
        if not rules_dir.exists():
            return []
        
        # Find all YAML files matching the pattern
        pattern = self.POLICY_RULES_PATTERN
        rule_files = list(rules_dir.glob(pattern))
        
        # Also check for .yml extension
        if pattern.endswith('.yaml'):
            rule_files.extend(rules_dir.glob(pattern.replace('.yaml', '.yml')))
        
        return sorted(rule_files)  # Sort for deterministic loading order
```

### 3.1 Policy Configuration Loader

**Location**: `app/core/policy_config.py` (NEW FILE)

Create a module for loading and managing policy configurations from YAML files:

```python
"""
Policy configuration loader for Credit Nexus.

Loads policy rules from YAML files in a configured directory and provides
a unified interface for policy engine initialization.
"""

import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
import yaml
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

from app.core.config import Settings

logger = logging.getLogger(__name__)


class PolicyConfigLoader:
    """
    Loads and manages policy rule configurations from YAML files.
    
    Supports:
    - Loading multiple YAML files from a directory
    - Merging rules from multiple files
    - Hot-reloading on file changes (optional)
    - Validation of rule structure
    """
    
    def __init__(self, settings: Settings):
        """
        Initialize policy configuration loader.
        
        Args:
            settings: Application settings containing policy configuration
        """
        self.settings = settings
        self.rules_dir = Path(settings.POLICY_RULES_DIR)
        self.pattern = settings.POLICY_RULES_PATTERN
        self._rules_cache: Optional[str] = None
        self._observer: Optional[Observer] = None
        
    def load_all_rules(self) -> str:
        """
        Load all policy rules from YAML files in the configured directory.
        
        Rules are loaded in alphabetical order by filename and merged into
        a single YAML string. Files can contain:
        - Single rule definitions
        - Multiple rules in a list
        - Rule imports/references
        
        Returns:
            Combined YAML string containing all rules from all files
            
        Raises:
            ValueError: If no policy files found or invalid YAML structure
        """
        rule_files = self.settings.get_policy_rules_files()
        
        if not rule_files:
            logger.warning(f"No policy rule files found in {self.rules_dir}")
            return ""
        
        logger.info(f"Loading policy rules from {len(rule_files)} file(s)")
        
        all_rules: List[Dict[str, Any]] = []
        
        for rule_file in rule_files:
            try:
                rules = self._load_rules_from_file(rule_file)
                all_rules.extend(rules)
                logger.debug(f"Loaded {len(rules)} rule(s) from {rule_file.name}")
            except Exception as e:
                logger.error(f"Failed to load rules from {rule_file}: {e}")
                raise ValueError(f"Error loading policy rules from {rule_file}: {e}")
        
        # Convert merged rules back to YAML
        combined_yaml = yaml.dump(all_rules, default_flow_style=False, sort_keys=False)
        
        # Cache the result
        self._rules_cache = combined_yaml
        
        logger.info(f"Successfully loaded {len(all_rules)} total policy rule(s)")
        return combined_yaml
    
    def _load_rules_from_file(self, file_path: Path) -> List[Dict[str, Any]]:
        """
        Load rules from a single YAML file.
        
        Args:
            file_path: Path to YAML file
            
        Returns:
            List of rule dictionaries
            
        Raises:
            yaml.YAMLError: If file contains invalid YAML
            ValueError: If file structure is invalid
        """
        with open(file_path, 'r', encoding='utf-8') as f:
            content = yaml.safe_load(f)
        
        if content is None:
            return []
        
        # Handle both single rule and list of rules
        if isinstance(content, dict):
            # Single rule
            return [content]
        elif isinstance(content, list):
            # List of rules
            return content
        else:
            raise ValueError(f"Invalid rule file structure in {file_path}: expected dict or list")
    
    def validate_rules(self, rules_yaml: str) -> bool:
        """
        Validate policy rules YAML structure.
        
        Args:
            rules_yaml: YAML string containing policy rules
            
        Returns:
            True if valid, raises ValueError if invalid
        """
        try:
            rules = yaml.safe_load(rules_yaml)
            if rules is None:
                return True  # Empty rules are valid
            
            if not isinstance(rules, list):
                raise ValueError("Policy rules must be a list")
            
            for i, rule in enumerate(rules):
                if not isinstance(rule, dict):
                    raise ValueError(f"Rule {i} must be a dictionary")
                
                # Validate required fields
                if "name" not in rule:
                    raise ValueError(f"Rule {i} missing required field: name")
                if "action" not in rule:
                    raise ValueError(f"Rule {i} missing required field: action")
                if "priority" not in rule:
                    raise ValueError(f"Rule {i} missing required field: priority")
                
                # Validate action values
                if rule["action"] not in ["allow", "block", "flag"]:
                    raise ValueError(f"Rule {i} has invalid action: {rule['action']}")
            
            return True
        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML in policy rules: {e}")
    
    def start_file_watcher(self, callback: callable) -> None:
        """
        Start watching policy files for changes (hot-reload).
        
        Only enabled if POLICY_AUTO_RELOAD is True (development mode).
        
        Args:
            callback: Function to call when files change
        """
        if not self.settings.POLICY_AUTO_RELOAD:
            return
        
        if not self.rules_dir.exists():
            logger.warning(f"Policy rules directory does not exist: {self.rules_dir}")
            return
        
        class PolicyFileHandler(FileSystemEventHandler):
            def __init__(self, loader: PolicyConfigLoader, callback: callable):
                self.loader = loader
                self.callback = callback
            
            def on_modified(self, event):
                if event.is_directory:
                    return
                if event.src_path.endswith(('.yaml', '.yml')):
                    logger.info(f"Policy file changed: {event.src_path}")
                    try:
                        self.callback()
                    except Exception as e:
                        logger.error(f"Error reloading policies: {e}")
        
        self._observer = Observer()
        self._observer.schedule(
            PolicyFileHandler(self, callback),
            str(self.rules_dir),
            recursive=False
        )
        self._observer.start()
        logger.info(f"Started file watcher for policy rules in {self.rules_dir}")
    
    def stop_file_watcher(self) -> None:
        """Stop watching policy files for changes."""
        if self._observer:
            self._observer.stop()
            self._observer.join()
            logger.info("Stopped policy file watcher")
    
    def get_rules_metadata(self) -> Dict[str, Any]:
        """
        Get metadata about loaded policy rules.
        
        Returns:
            Dictionary with rule counts, file information, etc.
        """
        rule_files = self.settings.get_policy_rules_files()
        
        metadata = {
            "rules_dir": str(self.rules_dir),
            "pattern": self.pattern,
            "files_count": len(rule_files),
            "files": [str(f.name) for f in rule_files],
            "cached": self._rules_cache is not None
        }
        
        if self._rules_cache:
            try:
                rules = yaml.safe_load(self._rules_cache)
                if isinstance(rules, list):
                    metadata["rules_count"] = len(rules)
                    metadata["rule_names"] = [r.get("name", "unnamed") for r in rules]
            except Exception:
                pass
        
        return metadata
```

### 3.2 Policy Engine Initialization

**Location**: `app/services/policy_service.py` (or `app/core/policy_engine.py`)

Initialize policy engine with rules loaded from YAML files:

```python
"""
Policy engine initialization and configuration.
"""

import logging
from typing import Optional
from pathlib import Path

from app.core.config import Settings
from app.core.policy_config import PolicyConfigLoader
from app.services.policy_engine_interface import PolicyEngineInterface

logger = logging.getLogger(__name__)

# Global policy engine instance
_policy_engine: Optional[PolicyEngineInterface] = None
_policy_config_loader: Optional[PolicyConfigLoader] = None


def init_policy_engine(settings: Settings) -> None:
    """
    Initialize policy engine with rules loaded from YAML files.
    
    This is called once at application startup. It:
    1. Creates PolicyConfigLoader instance
    2. Loads all policy rules from YAML files
    3. Validates rule structure
    4. Initializes policy engine with rules
    5. Optionally starts file watcher for hot-reload
    
    Args:
        settings: Application settings
        
    Raises:
        ValueError: If policy configuration is invalid
        RuntimeError: If policy engine initialization fails
    """
    global _policy_engine, _policy_config_loader
    
    if not settings.POLICY_ENABLED:
        logger.info("Policy engine is disabled (POLICY_ENABLED=false)")
        return
    
    try:
        # Create policy config loader
        _policy_config_loader = PolicyConfigLoader(settings)
        
        # Load all rules from YAML files
        rules_yaml = _policy_config_loader.load_all_rules()
        
        if not rules_yaml:
            logger.warning("No policy rules loaded - policy engine will use default allow behavior")
            rules_yaml = """
- name: default_allow
  when: {}
  action: allow
  priority: 0
"""
        
        # Validate rules
        _policy_config_loader.validate_rules(rules_yaml)
        
        # Initialize policy engine (vendor-agnostic interface)
        # This would be implemented based on selected vendor
        from app.services.policy_engine_factory import create_policy_engine
        _policy_engine = create_policy_engine(
            vendor=settings.POLICY_ENGINE_VENDOR or "default"
        )
        
        # Load rules into engine
        _policy_engine.load_rules(rules_yaml)
        
        logger.info(f"Policy engine initialized with {len(yaml.safe_load(rules_yaml))} rule(s)")
        
        # Start file watcher if auto-reload enabled
        if settings.POLICY_AUTO_RELOAD:
            _policy_config_loader.start_file_watcher(_reload_policy_rules)
            logger.info("Policy auto-reload enabled")
        
    except Exception as e:
        logger.error(f"Failed to initialize policy engine: {e}")
        if settings.POLICY_ENABLED:
            raise RuntimeError(f"Policy engine initialization failed: {e}") from e


def _reload_policy_rules() -> None:
    """Reload policy rules from YAML files (called by file watcher)."""
    global _policy_engine, _policy_config_loader
    
    if not _policy_config_loader or not _policy_engine:
        return
    
    try:
        logger.info("Reloading policy rules...")
        rules_yaml = _policy_config_loader.load_all_rules()
        _policy_config_loader.validate_rules(rules_yaml)
        _policy_engine.load_rules(rules_yaml)
        logger.info("Policy rules reloaded successfully")
    except Exception as e:
        logger.error(f"Failed to reload policy rules: {e}")


def get_policy_engine() -> Optional[PolicyEngineInterface]:
    """
    Get the global policy engine instance.
    
    Returns:
        PolicyEngineInterface instance or None if disabled
    """
    return _policy_engine


def get_policy_config_loader() -> Optional[PolicyConfigLoader]:
    """
    Get the policy configuration loader instance.
    
    Returns:
        PolicyConfigLoader instance or None if disabled
    """
    return _policy_config_loader
```

### 4. Client Initialization at Startup

**Location**: `app/core/llm_client.py`

Create configuration-based factory functions that use settings:

```python
from app.core.config import Settings
from langchain_core.language_models import BaseChatModel
from langchain_core.embeddings import Embeddings

# Global configuration (set at startup)
_llm_config: Optional[dict] = None

def init_llm_config(settings: Settings) -> None:
    """
    Initialize global LLM configuration from settings.
    This is called once at application startup.
    """
    global _llm_config
    
    # Validate provider-specific settings
    if settings.LLM_PROVIDER == "vllm" and not settings.VLLM_BASE_URL:
        raise ValueError("VLLM_BASE_URL is required when LLM_PROVIDER=vllm")
    
    if settings.LLM_PROVIDER == "huggingface" and not settings.HUGGINGFACE_API_KEY:
        raise ValueError("HUGGINGFACE_API_KEY is required when LLM_PROVIDER=huggingface")
    
    _llm_config = {
        "provider": settings.LLM_PROVIDER.value,
        "model": settings.LLM_MODEL,
        "temperature": settings.LLM_TEMPERATURE,
        "api_key": _get_api_key_for_provider(settings),
        "base_url": _get_base_url_for_provider(settings),
    }
    
    # Embeddings configuration
    embeddings_provider = settings.EMBEDDINGS_PROVIDER or settings.LLM_PROVIDER
    _llm_config["embeddings"] = {
        "provider": embeddings_provider.value if hasattr(embeddings_provider, 'value') else embeddings_provider,
        "model": settings.EMBEDDINGS_MODEL,
        "api_key": _get_embeddings_api_key(settings, embeddings_provider),
    }


def _get_api_key_for_provider(settings: Settings) -> Optional[str]:
    """Get the appropriate API key for the configured provider."""
    if settings.LLM_PROVIDER == "openai":
        return settings.OPENAI_API_KEY.get_secret_value()
    elif settings.LLM_PROVIDER == "vllm":
        return settings.VLLM_API_KEY.get_secret_value() if settings.VLLM_API_KEY else None
    elif settings.LLM_PROVIDER == "huggingface":
        return settings.HUGGINGFACE_API_KEY.get_secret_value() if settings.HUGGINGFACE_API_KEY else None
    return None


def _get_base_url_for_provider(settings: Settings) -> Optional[str]:
    """Get the appropriate base URL for the configured provider."""
    if settings.LLM_PROVIDER == "vllm":
        return settings.VLLM_BASE_URL
    elif settings.LLM_PROVIDER == "huggingface":
        return settings.HUGGINGFACE_BASE_URL
    return None


def _get_embeddings_api_key(settings: Settings, provider) -> Optional[str]:
    """Get API key for embeddings provider."""
    if provider == "openai" or (hasattr(provider, 'value') and provider.value == "openai"):
        return settings.OPENAI_API_KEY.get_secret_value()
    elif provider == "huggingface" or (hasattr(provider, 'value') and provider.value == "huggingface"):
        return settings.HUGGINGFACE_API_KEY.get_secret_value() if settings.HUGGINGFACE_API_KEY else None
    return None


def get_chat_model(model: Optional[str] = None, temperature: Optional[float] = None, **kwargs) -> BaseChatModel:
    """
    Get a chat model instance using the global configuration.
    
    This is the main function to use throughout the codebase instead of
    directly instantiating ChatOpenAI.
    
    Args:
        model: Override default model (uses LLM_MODEL from config if not provided)
        temperature: Override default temperature (uses LLM_TEMPERATURE from config if not provided)
        **kwargs: Additional arguments passed to the model constructor
    
    Returns:
        BaseChatModel instance ready to use
    """
    if _llm_config is None:
        raise RuntimeError("LLM configuration not initialized. Call init_llm_config() at startup.")
    
    return create_chat_model(
        provider=_llm_config["provider"],
        model=model or _llm_config["model"],
        temperature=temperature if temperature is not None else _llm_config["temperature"],
        api_key=_llm_config["api_key"],
        base_url=_llm_config["base_url"],
        **kwargs
    )


def get_embeddings_model(model: Optional[str] = None, **kwargs) -> Embeddings:
    """
    Get an embeddings model instance using the global configuration.
    
    Args:
        model: Override default model (uses EMBEDDINGS_MODEL from config if not provided)
        **kwargs: Additional arguments passed to the embeddings constructor
    
    Returns:
        Embeddings instance ready to use
    """
    if _llm_config is None:
        raise RuntimeError("LLM configuration not initialized. Call init_llm_config() at startup.")
    
    embeddings_config = _llm_config["embeddings"]
    return create_embeddings_model(
        provider=embeddings_config["provider"],
        model=model or embeddings_config["model"],
        api_key=embeddings_config["api_key"],
        **kwargs
    )
```

**Location**: `server.py`

Add initialization to lifespan handler for both LLM client and policy engine:

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler for startup/shutdown events."""
    from app.core.config import settings
    
    # Initialize LLM client configuration
    from app.core.llm_client import init_llm_config
    try:
        init_llm_config(settings)
        logger.info(f"LLM client configured: provider={settings.LLM_PROVIDER.value}, model={settings.LLM_MODEL}")
    except Exception as e:
        logger.error(f"Failed to initialize LLM client configuration: {e}")
        raise
    
    # Initialize Policy Engine with YAML rule loading
    from app.services.policy_service import init_policy_engine, get_policy_config_loader
    try:
        init_policy_engine(settings)
        if settings.POLICY_ENABLED:
            config_loader = get_policy_config_loader()
            if config_loader:
                metadata = config_loader.get_rules_metadata()
                logger.info(
                    f"Policy engine initialized: {metadata.get('rules_count', 0)} rule(s) "
                    f"from {metadata.get('files_count', 0)} file(s)"
                )
    except Exception as e:
        logger.error(f"Failed to initialize policy engine: {e}")
        if settings.POLICY_ENABLED:
            raise  # Fail fast if policy is required
    
    # Existing database initialization...
    if os.environ.get("DATABASE_URL"):
        try:
            from app.db import init_db
            init_db()
            logger.info("Database tables initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize database: {e}")
    
    yield
    
    # Cleanup
    if settings.POLICY_ENABLED:
        from app.services.policy_service import get_policy_config_loader
        config_loader = get_policy_config_loader()
        if config_loader:
            config_loader.stop_file_watcher()
    
    logger.info("Shutting down application...")
```

### 5. Refactoring Existing Code

Replace direct `ChatOpenAI` instantiation with factory functions that use the global client:

**Before** (`app/chains/extraction_chain.py`):
```python
def create_extraction_chain() -> ChatOpenAI:
    llm = ChatOpenAI(
        model="gpt-4o",
        temperature=0,
        api_key=settings.OPENAI_API_KEY.get_secret_value()
    )
    return llm.with_structured_output(ExtractionResult)
```

**After**:
```python
def create_extraction_chain() -> BaseChatModel:
    from app.core.llm_client import get_chat_model
    
    # Use global configuration - model and temperature come from settings
    llm = get_chat_model()
    return llm.with_structured_output(ExtractionResult)
```

**Alternative with overrides**:
```python
def create_extraction_chain() -> BaseChatModel:
    from app.core.llm_client import get_chat_model
    from app.core.config import settings
    
    # Override model or temperature if needed
    llm = get_chat_model(
        model=settings.LLM_MODEL,  # Optional: uses default from config if not provided
        temperature=0  # Optional: override temperature
    )
    return llm.with_structured_output(ExtractionResult)
```

Apply similar changes to:
- `app/chains/map_reduce_chain.py`
- `app/agents/analyzer.py`

## Implementation Steps

### Phase 1: Core Abstraction (Priority: High)

1. **Create `app/core/llm_client.py`**
   - Implement `create_chat_model()` factory function for all providers
   - Implement `create_embeddings_model()` factory function
   - Implement `init_llm_config()` for startup configuration
   - Implement `get_chat_model()` and `get_embeddings_model()` for runtime access
   - Handle provider-specific configuration (vLLM base_url, HF router endpoints, etc.)

2. **Extend `app/core/config.py`**
   - Add `LLMProvider` enum
   - Add LLM configuration fields to `Settings`
   - Add policy engine configuration fields to `Settings`
   - Add `get_policy_rules_files()` method
   - Add validation logic

3. **Create `app/core/policy_config.py`** (NEW)
   - Implement `PolicyConfigLoader` class
   - Implement YAML file loading and merging
   - Implement rule validation
   - Implement file watcher for hot-reload (optional)
   - Add `get_rules_metadata()` for status reporting

4. **Update Policy Engine Initialization**
   - Create or update `app/services/policy_service.py`
   - Add `init_policy_engine()` function
   - Add `get_policy_engine()` function
   - Integrate with `PolicyConfigLoader`

5. **Update `server.py`**
   - Add LLM client initialization to lifespan handler
   - Add policy engine initialization to lifespan handler
   - Add cleanup for file watcher
   - Add error handling and logging

### Phase 2: Refactoring (Priority: High)

4. **Refactor `app/chains/extraction_chain.py`**
   - Update `create_extraction_chain()` to use `get_chat_model()`
   - Replace `ChatOpenAI` return type with `BaseChatModel` (from `langchain_core`)

5. **Refactor `app/chains/map_reduce_chain.py`**
   - Update `create_partial_extraction_chain()` to use `get_chat_model()`
   - Update `create_reducer_chain()` to use `get_chat_model()`
   - Replace `ChatOpenAI` return types with `BaseChatModel`

6. **Refactor `app/agents/analyzer.py`**
   - Update `create_spt_extraction_chain()` to use `get_chat_model()`
   - Update `create_address_extraction_chain()` to use `get_chat_model()`
   - Update `get_embeddings_model()` to use `get_embeddings_model()` from llm_client
   - Replace `ChatOpenAI` and `OpenAIEmbeddings` return types with `BaseChatModel` and `Embeddings`

### Phase 3: Testing & Documentation (Priority: Medium)

7. **Create unit tests**
   - Test each client implementation
   - Test factory function
   - Test configuration loading

8. **Update documentation**
   - Add `.env` example with all LLM provider options
   - Document configuration options
   - Add migration guide

9. **Update `requirements.txt`**
   - Add optional dependencies for vLLM/HuggingFace if needed
   - Note: vLLM and HuggingFace can work via OpenAI-compatible endpoints

## Configuration Examples

### OpenAI (Default) with Policy Engine
```env
# LLM Configuration
LLM_PROVIDER=openai
LLM_MODEL=gpt-4o
LLM_TEMPERATURE=0
OPENAI_API_KEY=sk-...
EMBEDDINGS_MODEL=text-embedding-3-small

# Policy Engine Configuration
POLICY_ENABLED=true
POLICY_RULES_DIR=app/policies
POLICY_RULES_PATTERN=*.yaml
POLICY_ENGINE_VENDOR=default
POLICY_AUTO_RELOAD=false
```


### HuggingFace Inference API (Direct)
```env
LLM_PROVIDER=huggingface
LLM_MODEL=meta-llama/Meta-Llama-3-8B-Instruct
LLM_TEMPERATURE=0
HUGGINGFACE_API_KEY=hf_...
HUGGINGFACE_BASE_URL=https://api-inference.huggingface.co/v1  # Optional, defaults to this
EMBEDDINGS_MODEL=sentence-transformers/all-MiniLM-L6-v2
EMBEDDINGS_PROVIDER=huggingface
```

### HuggingFace Inference Providers (Cohere, fal, Replicate, etc.)
```env
LLM_PROVIDER=huggingface
LLM_MODEL=cohere/command-r-plus  # Provider/model format
LLM_TEMPERATURE=0
HUGGINGFACE_API_KEY=hf_...
HUGGINGFACE_BASE_URL=https://router.huggingface.co/cohere/v3/openai  # Router endpoint
EMBEDDINGS_MODEL=text-embedding-3-small
EMBEDDINGS_PROVIDER=openai  # Can use different provider for embeddings
```

### vLLM (Local Server) with Policy Engine
```env
# LLM Configuration
LLM_PROVIDER=vllm
LLM_MODEL=meta-llama/Llama-2-7b-chat-hf
LLM_TEMPERATURE=0
VLLM_BASE_URL=http://localhost:8000  # vLLM server URL (without /v1)
VLLM_API_KEY=optional-auth-key  # Optional, if vLLM server requires auth
EMBEDDINGS_MODEL=text-embedding-3-small
EMBEDDINGS_PROVIDER=openai  # vLLM doesn't provide embeddings, use OpenAI

# Policy Engine Configuration
POLICY_ENABLED=true
POLICY_RULES_DIR=app/policies
POLICY_RULES_PATTERN=*.yaml
POLICY_ENGINE_VENDOR=default
POLICY_AUTO_RELOAD=true  # Enable hot-reload for development
```

## Policy Configuration Details

### Policy Rules Directory Structure

Policy rules are loaded from YAML files in the configured directory. The default structure:

```
app/
└── policies/
    ├── regulatory_compliance.yaml    # Regulatory rules (MiCA, Basel III, FATF)
    ├── trade_execution.yaml          # Trade-specific rules
    ├── loan_asset.yaml               # Loan asset securitization rules
    ├── terms_change.yaml             # Terms change rules
    └── default_allow.yaml            # Default allow rule (lowest priority)
```

### Policy Rule File Format

Each YAML file can contain one or more policy rules:

**Example: `app/policies/regulatory_compliance.yaml`**
```yaml
# Regulatory Compliance Rules
# These rules enforce MiCA, Basel III, and FATF requirements

- name: block_sanctioned_parties
  when:
    any:
      - field: originator.lei
        op: in
        value: ["SANCTIONED_LEI_LIST"]
      - field: beneficiary.lei
        op: in
        value: ["SANCTIONED_LEI_LIST"]
  action: block
  priority: 100
  description: "Block any transaction involving sanctioned entities"

- name: flag_high_risk_jurisdiction
  when:
    any:
      - field: originator.jurisdiction
        op: in
        value: ["HighRiskCountryList"]
      - field: beneficiary.jurisdiction
        op: in
        value: ["HighRiskCountryList"]
  action: flag
  priority: 50
  description: "Flag transactions involving high-risk jurisdictions"
```

**Example: `app/policies/trade_execution.yaml`**
```yaml
# Trade Execution Rules

- name: block_unhosted_wallets
  when:
    all:
      - field: transaction_type
        op: eq
        value: "trade_execution"
      - field: originator.kyc_status
        op: eq
        value: false
  action: block
  priority: 90
  description: "Block trades from unhosted (non-KYC) wallets"

- name: flag_high_value_transfer
  when:
    all:
      - field: transaction_type
        op: eq
        value: "trade_execution"
      - field: amount
        op: gt
        value: 100000
      - field: currency
        op: eq
        value: "EUR"
  action: flag
  priority: 40
  description: "Flag high-value EUR transfers for review"
```

### Policy Configuration Options

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `POLICY_ENABLED` | bool | `true` | Enable/disable policy engine |
| `POLICY_RULES_DIR` | Path | `app/policies` | Directory containing YAML policy files |
| `POLICY_RULES_PATTERN` | str | `*.yaml` | File pattern for policy rule files (supports `*.yaml`, `*.yml`) |
| `POLICY_ENGINE_VENDOR` | str | `None` | Policy engine implementation vendor (e.g., "aspasia", "custom") |
| `POLICY_AUTO_RELOAD` | bool | `false` | Auto-reload policies on file change (development only) |

### Policy Rules Loading Behavior

1. **File Discovery**: All YAML files matching the pattern in `POLICY_RULES_DIR` are discovered
2. **Loading Order**: Files are loaded in alphabetical order by filename
3. **Rule Merging**: Rules from all files are merged into a single rule set
4. **Validation**: All rules are validated for structure and required fields
5. **Error Handling**: If any file fails to load, initialization fails (fail-fast)

### Hot-Reload (Development Mode)

When `POLICY_AUTO_RELOAD=true`:
- File watcher monitors the policy rules directory
- Changes to YAML files trigger automatic rule reload
- Policy engine is updated with new rules without restart
- Useful for development and testing

**Note**: Hot-reload should be disabled in production for stability.

### Policy Rules File Organization

Recommended organization:

1. **By Domain**: Separate files for different regulatory domains
   - `regulatory_compliance.yaml` - MiCA, Basel III, FATF
   - `trade_execution.yaml` - Trade-specific rules
   - `loan_asset.yaml` - Asset securitization rules

2. **By Priority**: Group rules by priority level
   - `high_priority_rules.yaml` - Priority 80-100 (BLOCK actions)
   - `medium_priority_rules.yaml` - Priority 30-79 (FLAG actions)
   - `default_rules.yaml` - Priority 0-29 (ALLOW actions)

3. **By Transaction Type**: Separate files for different transaction types
   - `facility_creation.yaml` - Rules for facility creation
   - `trade_execution.yaml` - Rules for trade execution
   - `loan_asset.yaml` - Rules for loan asset securitization

### Policy Rules Validation

Rules are validated at startup for:
- **Structure**: Must be a list of rule dictionaries
- **Required Fields**: `name`, `action`, `priority` must be present
- **Action Values**: Must be one of `"allow"`, `"block"`, `"flag"`
- **Priority**: Must be a numeric value
- **Condition Structure**: `when` clause must be valid condition tree

### Policy Engine Integration

The policy engine is initialized at startup and:
1. Loads all rules from YAML files
2. Validates rule structure
3. Initializes policy engine with rules
4. Makes engine available via `get_policy_engine()` function
5. Optionally starts file watcher for hot-reload

**Usage in Code**:
```python
from app.services.policy_service import get_policy_engine

# Get policy engine instance
policy_engine = get_policy_engine()

if policy_engine:
    # Evaluate transaction
    result = policy_engine.evaluate(transaction_dict)
    decision = result["decision"]  # "ALLOW", "BLOCK", or "FLAG"
```

## HuggingFace Inference Providers Details

### Router-Based Access

HuggingFace Inference Providers allows access to multiple LLM providers through a unified router endpoint:

**Endpoint Format**: `https://router.huggingface.co/{provider}/v3/openai/chat/completions`

**Supported Providers**:
- **Cohere**: High-performance models like `command-r-plus`, `command-r`
- **fal**: Fast inference with models like `fal-ai/llama-v3-70b-instruct`
- **Replicate**: Access to various open-source models
- **Together AI**: Fast inference for open models

**Advantages**:
- Single authentication (HF token)
- Unified API interface (OpenAI-compatible)
- No need for provider-specific API keys
- Easy switching between providers

**Configuration Example**:
```python
# For Cohere via HF Router
base_url = "https://router.huggingface.co/cohere/v3/openai"
model = "cohere/command-r-plus"
api_key = "hf_..."  # HF token

# For fal via HF Router
base_url = "https://router.huggingface.co/fal/v3/openai"
model = "fal-ai/llama-v3-70b-instruct"
api_key = "hf_..."  # Same HF token
```

### Direct HuggingFace Models

For models hosted directly on HuggingFace:
- **Endpoint**: `https://api-inference.huggingface.co/v1`
- **Models**: Any model from HuggingFace Hub that supports chat completions
- **Example**: `meta-llama/Meta-Llama-3-8B-Instruct`

## LangChain Integration Details

### Using LangChain's Provider Support

LangChain provides a unified interface through `BaseChatModel` and `Embeddings` base classes. Our abstraction leverages this by:

1. **Unified Interface**: All providers return `BaseChatModel` instances, ensuring compatibility with LangChain chains, prompts, and tools.

2. **Provider-Specific Packages**: While LangChain has separate packages (`langchain-openai`, `langchain-anthropic`, etc.), we use `langchain-openai` for all OpenAI-compatible endpoints, which includes:
   - Native OpenAI API
   - vLLM (OpenAI-compatible)
   - HuggingFace Inference API (OpenAI-compatible)
   - Any other OpenAI-compatible endpoint

3. **Embeddings**: For embeddings, we prefer native packages when available:
   - `langchain-huggingface.HuggingFaceEmbeddings` for HF models
   - `langchain-openai.OpenAIEmbeddings` for OpenAI models
   - Fallback to OpenAI-compatible endpoint for HF if `langchain-huggingface` not installed

### Model Initialization Pattern

Instead of using LangChain's `init_chat_model()` (which requires string format like `"openai:gpt-4o"`), we use direct instantiation with provider-specific configuration. This gives us:
- Better control over configuration
- Clearer error messages
- Easier debugging
- Type safety with Pydantic settings

However, the abstraction is designed to be compatible with LangChain's patterns, so future migration to `init_chat_model()` would be straightforward.

## Technical Considerations

### OpenAI Compatibility

Both vLLM and HuggingFace Inference API provide OpenAI-compatible endpoints:
- **vLLM**: Exposes `/v1/chat/completions` endpoint compatible with OpenAI API
  - Server runs at `http://localhost:8000` (or custom port)
  - API endpoint: `http://localhost:8000/v1/chat/completions`
  - Uses `ChatOpenAI` with `base_url="http://localhost:8000/v1"`
  
- **HuggingFace Direct Inference**: Provides OpenAI-compatible endpoint
  - Base URL: `https://api-inference.huggingface.co/v1`
  - Uses `ChatOpenAI` with `base_url` and HF token as `api_key`
  
- **HuggingFace Inference Providers**: Router-based access to multiple providers
  - Router endpoint: `https://router.huggingface.co/{provider}/v3/openai/chat/completions`
  - Supports: Cohere, fal, Replicate, Together AI, etc.
  - Uses `ChatOpenAI` with router `base_url` and HF token as `api_key`

This means we can use `langchain_openai.ChatOpenAI` with different `base_url` values, maintaining full LangChain compatibility without needing provider-specific LangChain packages (though `langchain-huggingface` is available for embeddings).

### Embeddings Support

- **OpenAI**: `OpenAIEmbeddings` from `langchain_openai`
  - Models: `text-embedding-3-small`, `text-embedding-3-large`, `text-embedding-ada-002`
  - Dimension: 1536 (ada-002) or 3072 (embedding-3-large)
  
- **HuggingFace**: 
  - **Preferred**: `HuggingFaceEmbeddings` from `langchain_huggingface` (native support)
  - **Fallback**: `OpenAIEmbeddings` with HF Inference API endpoint (OpenAI-compatible)
  - Models: `sentence-transformers/all-MiniLM-L6-v2`, `BAAI/bge-large-en-v1.5`, etc.
  
- **vLLM**: Does not provide embeddings endpoint
  - **Solution**: Use separate embeddings provider (typically OpenAI or HuggingFace)
  - Configure via `EMBEDDINGS_PROVIDER` setting

### Error Handling

- Validate configuration at startup
- Provide clear error messages for missing configuration
- Fallback to OpenAI if provider initialization fails (with warning)

### Performance Considerations

- **Client Instances**: Lightweight (just configuration), created on-demand
- **Connection Pooling**: Handled automatically by `httpx` (used by LangChain)
- **Embeddings Caching**: Consider implementing caching for frequently used embeddings
- **Model Loading**: vLLM models are loaded once at server startup (not per-request)
- **HF Inference**: Uses serverless inference, no local model loading needed

### Error Handling & Validation

- **Startup Validation**: All required configuration validated at application startup
- **Provider-Specific Errors**: Clear error messages indicating missing configuration
- **Fallback Behavior**: Can fallback to OpenAI if provider initialization fails (with warning)
- **Type Safety**: Pydantic settings ensure type validation at startup

### Security Considerations

- **API Keys**: Stored as `SecretStr` in Pydantic settings (not logged)
- **Base URLs**: Validated to prevent SSRF attacks (if needed)
- **Token Management**: HF tokens and OpenAI keys stored securely

## File Structure

```
app/
├── core/
│   ├── __init__.py
│   ├── config.py              # Extended with LLM and policy settings
│   ├── llm_client.py          # NEW: LLM client abstraction
│   └── policy_config.py       # NEW: Policy configuration loader
├── services/
│   ├── policy_service.py      # Policy engine initialization
│   ├── policy_engine_interface.py  # Vendor-agnostic interface
│   └── policy_engine_factory.py     # Factory for policy engines
├── policies/                   # NEW: Policy rules directory
│   ├── regulatory_compliance.yaml
│   ├── trade_execution.yaml
│   ├── loan_asset.yaml
│   └── default_allow.yaml
├── chains/
│   ├── extraction_chain.py      # Refactored to use get_chat_model()
│   └── map_reduce_chain.py       # Refactored to use get_chat_model()
└── agents/
    └── analyzer.py                # Refactored to use get_chat_model()

server.py                         # Updated lifespan handler
```

## Migration Path

1. **Backward Compatibility**: Keep existing code working during transition
2. **Gradual Migration**: Refactor one module at a time
3. **Default Behavior**: If `LLM_PROVIDER` not set, default to OpenAI (current behavior)
4. **Testing**: Test each provider configuration before full deployment

## Dependencies

### Required (Already Present)
- `langchain-openai>=0.1.0` - For OpenAI and OpenAI-compatible endpoints (vLLM, HF)
- `pydantic-settings>=2.0.0` - For configuration management
- `langchain-core` - Core LangChain abstractions (BaseChatModel, Embeddings)

### Recommended (For Better HuggingFace Support)
- `langchain-huggingface` - Native HuggingFace embeddings support (optional, has fallback)
  - Provides `HuggingFaceEmbeddings` class
  - Better performance and features for HF embeddings models
  - Can be added later without breaking changes

### Required (For Policy Configuration)
- `pyyaml>=6.0` - For loading and parsing YAML policy rule files
- `watchdog>=3.0` - For file watching and hot-reload (optional, only if POLICY_AUTO_RELOAD=true)

### Optional (For Direct Provider Access)
- `huggingface_hub` - For HuggingFace API access (optional, LangChain handles this)
- `openai` - Direct OpenAI SDK (already included via langchain-openai)

### Not Required
- vLLM Python package - vLLM runs as a separate server, accessed via HTTP API
- Provider-specific LangChain packages - We use OpenAI-compatible endpoints via `langchain-openai`

## Success Criteria

1. ✅ All existing functionality works with OpenAI provider (no regression)
2. ✅ Can switch to vLLM by changing environment variables
3. ✅ Can switch to HuggingFace by changing environment variables
4. ✅ Configuration validated at startup with clear error messages
5. ✅ No breaking changes to existing API endpoints
6. ✅ Code follows existing patterns (factory functions, global settings)
7. ✅ Policy rules loaded from YAML files at startup
8. ✅ Policy engine initialized with loaded rules
9. ✅ Hot-reload works for policy rules (when enabled)
10. ✅ Policy configuration validated with clear error messages

## Next Steps

1. Review and approve this plan
2. Implement Phase 1 (Core Abstraction + Policy Configuration)
3. Create `app/policies/` directory with example YAML files
4. Test with OpenAI provider (ensure no regression)
5. Test policy engine initialization with YAML files
6. Test policy hot-reload (development mode)
7. Test with vLLM provider (if available)
8. Test with HuggingFace provider
9. Complete Phase 2 (Refactoring)
10. Complete Phase 3 (Testing & Documentation)

## Policy Configuration Examples

### Minimal Policy Rules File

**`app/policies/default_allow.yaml`**
```yaml
# Default allow rule (lowest priority)
- name: default_allow
  when: {}
  action: allow
  priority: 0
  description: "Default allow for all transactions not caught by other rules"
```

### Complete Policy Rules File

**`app/policies/regulatory_compliance.yaml`**
```yaml
# Regulatory Compliance Rules
# Enforces MiCA, Basel III, and FATF requirements

- name: block_sanctioned_parties
  when:
    any:
      - field: originator.lei
        op: in
        value: ["SANCTIONED_LEI_LIST"]
      - field: beneficiary.lei
        op: in
        value: ["SANCTIONED_LEI_LIST"]
  action: block
  priority: 100
  description: "Block any transaction involving sanctioned entities"

- name: flag_high_risk_jurisdiction
  when:
    any:
      - field: originator.jurisdiction
        op: in
        value: ["HighRiskCountryList"]
      - field: beneficiary.jurisdiction
        op: in
        value: ["HighRiskCountryList"]
  action: flag
  priority: 50
  description: "Flag transactions involving high-risk jurisdictions"

- name: block_invalid_esg_claims
  when:
    all:
      - field: sustainability_linked
        op: eq
        value: true
      - field: esg_kpi_targets
        op: eq
        value: []
  action: block
  priority: 80
  description: "Block sustainability-linked loans without KPI targets"
```

### Environment Configuration

**`.env` file with full configuration:**
```env
# LLM Configuration
LLM_PROVIDER=openai
LLM_MODEL=gpt-4o
LLM_TEMPERATURE=0
OPENAI_API_KEY=sk-...

# Embeddings Configuration
EMBEDDINGS_MODEL=text-embedding-3-small
EMBEDDINGS_PROVIDER=openai

# Policy Engine Configuration
POLICY_ENABLED=true
POLICY_RULES_DIR=app/policies
POLICY_RULES_PATTERN=*.yaml
POLICY_ENGINE_VENDOR=default
POLICY_AUTO_RELOAD=false

# Database (existing)
DATABASE_URL=postgresql://...
```

### Development Configuration

**`.env.development` file:**
```env
# Enable hot-reload for policy rules during development
POLICY_AUTO_RELOAD=true
POLICY_RULES_DIR=app/policies

# Use local vLLM server
LLM_PROVIDER=vllm
LLM_MODEL=meta-llama/Llama-2-7b-chat-hf
VLLM_BASE_URL=http://localhost:8000
```

### Production Configuration

**`.env.production` file:**
```env
# Disable hot-reload in production
POLICY_AUTO_RELOAD=false
POLICY_RULES_DIR=app/policies

# Use OpenAI in production
LLM_PROVIDER=openai
LLM_MODEL=gpt-4o
OPENAI_API_KEY=sk-...
```

