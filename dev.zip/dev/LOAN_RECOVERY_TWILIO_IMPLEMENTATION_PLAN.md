# Loan Recovery & Twilio Integration Implementation Plan

## Executive Summary

This document outlines the complete implementation plan for integrating Twilio SMS/voice communication into CreditNexus for automated loan recovery workflows. The feature will enable proactive borrower communication when loans default or come into infraction, with a dedicated sidebar interface for managing recovery operations.

**Key Features:**
- Automated SMS/voice reminders for defaulted loans
- Loan recovery sidebar tab with default tracking
- Integration with deal flow timeline events
- User profile management for borrower contacts
- Configurable recovery workflows with escalation paths
- CDM-compliant event tracking for all recovery actions

---

## Project 1: Twilio Service Integration

### Objective
Create a robust Twilio service layer that abstracts SMS and voice communication, following CreditNexus service layer patterns.

### Activities

#### Activity 1.1: Twilio Configuration & Setup
**Priority**: P0  
**Estimated Time**: 1 day

**File-Level Tasks:**

1. **Update `app/core/config.py`**
   - Add Twilio configuration settings
   - Line-Level Sub-Tasks:
     - Add `TWILIO_ENABLED: bool = False` flag
     - Add `TWILIO_ACCOUNT_SID: Optional[SecretStr] = None`
     - Add `TWILIO_AUTH_TOKEN: Optional[SecretStr] = None`
     - Add `TWILIO_PHONE_NUMBER: Optional[str] = None` (sender number)
     - Add `TWILIO_SMS_ENABLED: bool = True`
     - Add `TWILIO_VOICE_ENABLED: bool = True`
     - Add `TWILIO_WEBHOOK_URL: Optional[str] = None` (for status callbacks)
     - Add validator to ensure credentials are present if enabled

2. **Update `pyproject.toml`**
   - Add Twilio Python SDK dependency
   - Line-Level Sub-Tasks:
     - Add `twilio = "^8.10.0"` to dependencies
     - Update lock file with `uv lock`

3. **Create `.env.example` updates**
   - Document Twilio environment variables
   - Line-Level Sub-Tasks:
     - Add `TWILIO_ENABLED=false`
     - Add `TWILIO_ACCOUNT_SID=your_account_sid`
     - Add `TWILIO_AUTH_TOKEN=your_auth_token`
     - Add `TWILIO_PHONE_NUMBER=+1234567890`
     - Add `TWILIO_WEBHOOK_URL=https://your-domain.com/api/twilio/webhook`

#### Activity 1.2: Twilio Service Implementation
**Priority**: P0  
**Estimated Time**: 2 days

**File-Level Tasks:**

1. **Create `app/services/twilio_service.py`**
   - Implement Twilio service class
   - Line-Level Sub-Tasks:
     - Import `twilio.rest.Client` and `twilio.twiml.voice_response`
     - Create `TwilioService` class with `__init__` method
     - Initialize Twilio client in `__init__` using config settings
     - Add `send_sms(phone_number: str, message: str, status_callback: Optional[str] = None) -> Dict[str, Any]` method
       - Validate phone number format (E.164)
       - Call `client.messages.create()` with from, to, body, status_callback
       - Return dict with `message_sid`, `status`, `error_code` if any
       - Handle `TwilioRestException` and log errors
     - Add `make_voice_call(phone_number: str, message: str, status_callback: Optional[str] = None) -> Dict[str, Any]` method
       - Validate phone number format
       - Use TwiML to generate voice message
       - Call `client.calls.create()` with from, to, url (TwiML), status_callback
       - Return dict with `call_sid`, `status`, `error_code` if any
     - Add `get_message_status(message_sid: str) -> Dict[str, Any]` method
       - Fetch message status from Twilio API
       - Return status, error_code, date_sent, date_updated
     - Add `get_call_status(call_sid: str) -> Dict[str, Any]` method
       - Fetch call status from Twilio API
       - Return status, duration, start_time, end_time
     - Add `validate_phone_number(phone_number: str) -> bool` method
       - Use regex to validate E.164 format
       - Return True if valid, False otherwise
     - Add comprehensive error handling with logging
     - Add type hints for all methods
     - Add docstrings following CreditNexus patterns

2. **Create `app/services/twilio_service.py` - TwiML Generation**
   - Add TwiML response generation for voice calls
   - Line-Level Sub-Tasks:
     - Add `generate_twiml_response(message: str, language: str = "en-US") -> str` method
       - Use `VoiceResponse()` from twilio.twiml
       - Add `Say` verb with message and language
       - Return XML string
     - Add `generate_twiml_with_options(message: str, gather_digits: bool = False) -> str` method
       - Support interactive voice responses
       - Add `Gather` verb if gather_digits is True
       - Return XML string

#### Activity 1.3: Twilio Webhook Handler
**Priority**: P1  
**Estimated Time**: 1 day

**File-Level Tasks:**

1. **Create `app/api/twilio_routes.py`**
   - Add FastAPI routes for Twilio webhooks
   - Line-Level Sub-Tasks:
     - Import FastAPI router, Request, Form
     - Create router with prefix `/api/twilio`
     - Add `@router.post("/webhook/sms")` endpoint
       - Accept POST with Form data (MessageSid, From, To, Body, Status)
       - Update `RecoveryAction` status in database
       - Log webhook event
       - Return 200 OK with empty response
     - Add `@router.post("/webhook/voice")` endpoint
       - Accept POST with Form data (CallSid, From, To, CallStatus, Duration)
       - Update `RecoveryAction` status in database
       - Log webhook event
       - Return 200 OK with empty response
     - Add `@router.post("/webhook/status")` endpoint
       - Accept POST with Form data (MessageSid/CallSid, MessageStatus/CallStatus)
       - Update `RecoveryAction` status in database
       - Return TwiML response if needed
     - Add authentication/validation (verify Twilio signature)
     - Add error handling and logging

2. **Update `app/api/routes.py`**
   - Register Twilio routes
   - Line-Level Sub-Tasks:
     - Import `twilio_routes` router
     - Add `app.include_router(twilio_routes.router)` in main FastAPI app initialization

---

## Project 2: Loan Recovery Database Models

### Objective
Create database models to track loan defaults, infractions, recovery actions, and borrower contact information.

### Activities

#### Activity 2.1: Database Schema Design
**Priority**: P0  
**Estimated Time**: 1 day

**File-Level Tasks:**

1. **Update `app/db/models.py`**
   - Add new models for loan recovery
   - Line-Level Sub-Tasks:
     - Add `LoanDefault` model class
       - `id: Mapped[int]` (primary key)
       - `loan_id: Mapped[str]` (foreign key to LoanAsset or Deal)
       - `deal_id: Mapped[Optional[int]]` (ForeignKey to Deal)
       - `default_type: Mapped[str]` (payment_default, covenant_breach, infraction)
       - `default_date: Mapped[datetime]` (when default occurred)
       - `default_reason: Mapped[Optional[str]]` (description)
       - `amount_overdue: Mapped[Optional[Decimal]]` (if payment default)
       - `days_past_due: Mapped[int]` (calculated field)
       - `severity: Mapped[str]` (low, medium, high, critical)
       - `status: Mapped[str]` (open, in_recovery, resolved, written_off)
       - `resolved_at: Mapped[Optional[datetime]]`
       - `cdm_events: Mapped[Optional[dict]]` (JSONB for CDM events)
       - `metadata: Mapped[Optional[dict]]` (JSONB for additional data)
       - `created_at: Mapped[datetime]`
       - `updated_at: Mapped[datetime]`
       - Add relationship to `Deal`
       - Add `to_dict()` method
     - Add `RecoveryAction` model class
       - `id: Mapped[int]` (primary key)
       - `loan_default_id: Mapped[int]` (ForeignKey to LoanDefault)
       - `action_type: Mapped[str]` (sms_reminder, voice_call, email, escalation, legal_notice)
       - `communication_method: Mapped[str]` (sms, voice, email)
       - `recipient_phone: Mapped[Optional[str]]`
       - `recipient_email: Mapped[Optional[str]]`
       - `message_template: Mapped[str]` (template name or custom message)
       - `message_content: Mapped[str]` (actual message sent)
       - `twilio_message_sid: Mapped[Optional[str]]` (for SMS)
       - `twilio_call_sid: Mapped[Optional[str]]` (for voice)
       - `status: Mapped[str]` (pending, sent, delivered, failed, responded)
       - `scheduled_at: Mapped[Optional[datetime]]` (for scheduled actions)
       - `sent_at: Mapped[Optional[datetime]]`
       - `delivered_at: Mapped[Optional[datetime]]`
       - `response_received_at: Mapped[Optional[datetime]]`
       - `error_message: Mapped[Optional[str]]`
       - `created_by: Mapped[Optional[int]]` (ForeignKey to User)
       - `metadata: Mapped[Optional[dict]]` (JSONB)
       - `created_at: Mapped[datetime]`
       - `updated_at: Mapped[datetime]`
       - Add relationship to `LoanDefault` and `User`
       - Add `to_dict()` method
     - Add `BorrowerContact` model class
       - `id: Mapped[int]` (primary key)
       - `deal_id: Mapped[int]` (ForeignKey to Deal)
       - `user_id: Mapped[Optional[int]]` (ForeignKey to User if borrower is a user)
       - `contact_name: Mapped[str]` (borrower name)
       - `phone_number: Mapped[Optional[str]]` (E.164 format)
       - `email: Mapped[Optional[str]]`
       - `preferred_contact_method: Mapped[str]` (sms, voice, email)
       - `contact_preferences: Mapped[Optional[dict]]` (JSONB: timezone, preferred_hours, etc.)
       - `is_primary: Mapped[bool]` (default True)
       - `is_active: Mapped[bool]` (default True)
       - `metadata: Mapped[Optional[dict]]` (JSONB)
       - `created_at: Mapped[datetime]`
       - `updated_at: Mapped[datetime]`
       - Add relationship to `Deal` and `User`
       - Add `to_dict()` method

2. **Create Alembic Migration**
   - Generate migration for new tables
   - Line-Level Sub-Tasks:
     - Run `alembic revision --autogenerate -m "add_loan_recovery_tables"`
     - Review generated migration file
     - Add indexes for `loan_id`, `deal_id`, `default_date`, `status` fields
     - Add check constraints for `severity`, `status` enum values
     - Test migration up and down

#### Activity 2.2: CDM Event Integration
**Priority**: P0  
**Estimated Time**: 1 day

**File-Level Tasks:**

1. **Update `app/models/cdm_events.py`**
   - Add CDM event generators for recovery actions
   - Line-Level Sub-Tasks:
     - Add `generate_cdm_recovery_action()` function
       - Create CDM `Observation` event for recovery action
       - Include `eventType: "RecoveryAction"`
       - Include `eventDate`, `meta.globalKey`
       - Include `observationType: "LoanDefault"`
       - Include `relatedEventIdentifier` linking to loan default
       - Return CDM-compliant JSON
     - Add `generate_cdm_loan_default()` function
       - Create CDM `Observation` event for loan default
       - Include default type, amount, date
       - Link to loan/facility via `relatedEventIdentifier`
       - Return CDM-compliant JSON

---

## Project 3: Loan Recovery Service

### Objective
Create a service layer to manage loan recovery workflows, default detection, and automated communication triggers.

### Activities

#### Activity 3.1: Default Detection Service
**Priority**: P0  
**Estimated Time**: 2 days

**File-Level Tasks:**

1. **Create `app/services/loan_recovery_service.py`**
   - Implement loan recovery service
   - Line-Level Sub-Tasks:
     - Import dependencies (Session, Deal, LoanAsset, PaymentSchedule, PaymentEvent, etc.)
     - Create `LoanRecoveryService` class with `__init__(db: Session)`
     - Add `detect_payment_defaults(deal_id: Optional[int] = None) -> List[LoanDefault]` method
       - Query `PaymentSchedule` for status="pending" and `scheduled_date < now()`
       - For each overdue payment:
         - Calculate `days_past_due = (now() - scheduled_date).days`
         - Determine `severity` based on days past due (1-7: low, 8-30: medium, 31-60: high, 60+: critical)
         - Check if `LoanDefault` already exists for this payment
         - If not, create new `LoanDefault` record
         - Generate CDM event for default
         - Store CDM event in `cdm_events` JSONB field
       - Return list of detected defaults
     - Add `detect_covenant_breaches(deal_id: Optional[int] = None) -> List[LoanDefault]` method
       - Query `LoanAsset` for `risk_status = "BREACH"`
       - Check if breach is new (compare `last_verified_at` with existing defaults)
       - Create `LoanDefault` with `default_type = "covenant_breach"`
       - Generate CDM event
       - Return list of breaches
     - Add `get_active_defaults(deal_id: Optional[int] = None, status: Optional[str] = None) -> List[LoanDefault]` method
       - Query `LoanDefault` with filters
       - Filter by `status != "resolved"` if status not specified
       - Return list of active defaults
     - Add `get_defaults_by_severity(severity: str, deal_id: Optional[int] = None) -> List[LoanDefault]` method
       - Query defaults filtered by severity
       - Return list

2. **Add Recovery Workflow Logic**
   - Implement automated recovery action triggers
   - Line-Level Sub-Tasks:
     - Add `trigger_recovery_actions(default_id: int, action_types: Optional[List[str]] = None) -> List[RecoveryAction]` method
       - Get `LoanDefault` by ID
       - Get `BorrowerContact` for deal
       - Determine action types based on severity and days past due:
         - Days 1-3: SMS reminder only
         - Days 4-7: SMS + voice call
         - Days 8-30: Escalated SMS/voice + email
         - Days 31+: All methods + legal notice flag
       - For each action type:
         - Create `RecoveryAction` record with status="pending"
         - Schedule action based on business hours (if configured)
         - If immediate, call `execute_recovery_action()`
       - Return list of created actions
     - Add `execute_recovery_action(action_id: int) -> RecoveryAction` method
       - Get `RecoveryAction` by ID
       - Get `LoanDefault` and `BorrowerContact`
       - Generate message content from template
       - Based on `communication_method`:
         - If SMS: Call `twilio_service.send_sms()`
         - If voice: Call `twilio_service.make_voice_call()`
       - Update `RecoveryAction` with `twilio_message_sid` or `twilio_call_sid`
       - Update status to "sent"
       - Set `sent_at` timestamp
       - Generate CDM event for recovery action
       - Return updated action
     - Add `process_scheduled_actions() -> Dict[str, Any]` method
       - Query `RecoveryAction` with status="pending" and `scheduled_at <= now()`
       - For each action, call `execute_recovery_action()`
       - Return summary with counts of processed actions

#### Activity 3.2: Message Template Service
**Priority**: P1  
**Estimated Time**: 1 day

**File-Level Tasks:**

1. **Create `app/services/recovery_template_service.py`**
   - Implement message template management
   - Line-Level Sub-Tasks:
     - Create `RecoveryTemplateService` class
     - Add `get_template(template_name: str, default_type: str, severity: str) -> str` method
       - Load template from `app/templates/recovery/` directory
       - Template files: `sms_payment_reminder.txt`, `voice_payment_reminder.txt`, etc.
       - Use Jinja2 for templating
       - Replace variables: `{{borrower_name}}`, `{{loan_id}}`, `{{amount_overdue}}`, `{{days_past_due}}`, `{{due_date}}`
       - Return rendered message
     - Add `generate_custom_message(default: LoanDefault, contact: BorrowerContact, action_type: str) -> str` method
       - Generate message based on default details
       - Include loan information, amount, due date
       - Include payment instructions
       - Return formatted message

2. **Create Template Files**
   - Create message templates
   - Line-Level Sub-Tasks:
     - Create `app/templates/recovery/sms_payment_reminder.txt`
       - Template: "Hi {{borrower_name}}, your loan {{loan_id}} payment of ${{amount_overdue}} is {{days_past_due}} days overdue. Please pay by {{due_date}}. Contact us at [phone]."
     - Create `app/templates/recovery/voice_payment_reminder.txt`
       - Template: "Hello {{borrower_name}}, this is a reminder that your loan payment of ${{amount_overdue}} is {{days_past_due}} days overdue. Please contact us immediately at [phone] to arrange payment."
     - Create `app/templates/recovery/sms_escalation.txt`
       - Template for escalated cases
     - Create `app/templates/recovery/voice_escalation.txt`
       - Template for escalated voice calls

---

## Project 4: API Endpoints

### Objective
Create REST API endpoints for loan recovery operations, following CreditNexus API patterns.

### Activities

#### Activity 4.1: Recovery API Routes
**Priority**: P0  
**Estimated Time**: 2 days

**File-Level Tasks:**

1. **Create `app/api/recovery_routes.py`**
   - Implement recovery API endpoints
   - Line-Level Sub-Tasks:
     - Import FastAPI dependencies (router, Depends, HTTPException, etc.)
     - Import Pydantic models for request/response
     - Create router with prefix `/api/recovery`
     - Add `@router.get("/defaults")` endpoint
       - Query params: `deal_id`, `status`, `severity`, `page`, `limit`
       - Call `loan_recovery_service.get_active_defaults()`
       - Return paginated list of defaults
       - Add authentication: `Depends(get_current_user)`
     - Add `@router.post("/defaults/detect")` endpoint
       - Body: `{deal_id: Optional[int]}`
       - Call `loan_recovery_service.detect_payment_defaults()` and `detect_covenant_breaches()`
       - Return list of detected defaults
       - Add audit logging: `log_audit_action(db, AuditAction.CREATE, "loan_default", ...)`
     - Add `@router.get("/defaults/{default_id}")` endpoint
       - Get default by ID
       - Return default details with related recovery actions
     - Add `@router.post("/defaults/{default_id}/actions")` endpoint
       - Body: `{action_types: Optional[List[str]]}`
       - Call `loan_recovery_service.trigger_recovery_actions()`
       - Return list of created actions
     - Add `@router.get("/actions")` endpoint
       - Query params: `default_id`, `status`, `deal_id`, `page`, `limit`
       - Return paginated list of recovery actions
     - Add `@router.post("/actions/{action_id}/execute")` endpoint
       - Manually trigger action execution
       - Call `loan_recovery_service.execute_recovery_action()`
       - Return updated action
     - Add `@router.get("/actions/{action_id}")` endpoint
       - Get action by ID with status details
     - Add `@router.post("/actions/scheduled/process")` endpoint
       - Process all scheduled actions (background task)
       - Call `loan_recovery_service.process_scheduled_actions()`
       - Return summary
     - Add `@router.get("/contacts")` endpoint
       - Query params: `deal_id`
       - Return list of borrower contacts for deal(s)
     - Add `@router.post("/contacts")` endpoint
       - Body: `BorrowerContactCreate` model
       - Create new borrower contact
       - Return created contact
     - Add `@router.put("/contacts/{contact_id}")` endpoint
       - Update borrower contact
       - Return updated contact
     - Add error handling with appropriate HTTP status codes
     - Add comprehensive logging

2. **Create Pydantic Models**
   - Create request/response models
   - Line-Level Sub-Tasks:
     - Create `app/models/recovery_models.py`
     - Add `LoanDefaultResponse` model (Pydantic)
       - Fields matching `LoanDefault` database model
       - Include `recovery_actions: List[RecoveryActionResponse]`
     - Add `RecoveryActionResponse` model
       - Fields matching `RecoveryAction` database model
     - Add `BorrowerContactResponse` model
       - Fields matching `BorrowerContact` database model
     - Add `RecoveryActionCreate` model (for creating actions)
     - Add `BorrowerContactCreate` model
     - Add `DetectDefaultsRequest` model
       - `deal_id: Optional[int]`

3. **Update `app/api/routes.py`**
   - Register recovery routes
   - Line-Level Sub-Tasks:
     - Import `recovery_routes` router
     - Add `app.include_router(recovery_routes.router)` in main app

---

## Project 5: Background Task Integration

### Objective
Integrate loan recovery with background task system for automated default detection and action processing.

### Activities

#### Activity 5.1: Background Task Implementation
**Priority**: P1  
**Estimated Time**: 1 day

**File-Level Tasks:**

1. **Update `app/services/background_tasks.py` (or create if doesn't exist)**
   - Add recovery background tasks
   - Line-Level Sub-Tasks:
     - Import `LoanRecoveryService`, `get_db`
     - Add `@background_task` decorator or similar
     - Add `detect_loan_defaults_task()` function
       - Get database session
       - Initialize `LoanRecoveryService`
       - Call `detect_payment_defaults()` and `detect_covenant_breaches()`
       - Log results
     - Add `process_recovery_actions_task()` function
       - Get database session
       - Initialize `LoanRecoveryService`
       - Call `process_scheduled_actions()`
       - Log results

2. **Update Background Task Scheduler**
   - Schedule recovery tasks
   - Line-Level Sub-Tasks:
     - Add daily task for default detection (runs at 9 AM)
     - Add hourly task for processing scheduled actions
     - Configure in task scheduler configuration

---

## Project 6: Frontend - Loan Recovery Sidebar

### Objective
Create a sidebar component for loan recovery management with default tracking, loan selection, and user profile management.

### Activities

#### Activity 6.1: Recovery Sidebar Component
**Priority**: P0  
**Estimated Time**: 3 days

**File-Level Tasks:**

1. **Create `client/src/components/LoanRecoverySidebar.tsx`**
   - Implement recovery sidebar component
   - Line-Level Sub-Tasks:
     - Import React hooks (useState, useEffect, useCallback)
     - Import UI components (Card, Button, Badge, etc. from shadcn/ui)
     - Import icons (AlertCircle, Phone, MessageSquare, etc. from lucide-react)
     - Create `LoanRecoverySidebar` functional component
     - Add state management:
       - `defaults: LoanDefault[]`
       - `selectedDefault: LoanDefault | null`
       - `recoveryActions: RecoveryAction[]`
       - `loading: boolean`
       - `error: string | null`
     - Add `useEffect` to fetch defaults on mount
       - Call `/api/recovery/defaults` endpoint
       - Update `defaults` state
     - Add `handleSelectDefault(default: LoanDefault)` function
       - Set `selectedDefault`
       - Fetch recovery actions for default
       - Call `/api/recovery/actions?default_id=${default.id}`
     - Add `handleTriggerAction(actionType: string)` function
       - Call `/api/recovery/defaults/${selectedDefault.id}/actions`
       - Refresh actions list
     - Add `handleExecuteAction(actionId: number)` function
       - Call `/api/recovery/actions/${actionId}/execute`
       - Update action status
     - Render sidebar UI:
       - Header with "Loan Recovery" title and badge showing count of active defaults
       - Filters section (deal filter, severity filter, status filter)
       - Defaults list:
         - Card for each default showing:
           - Loan ID / Deal ID
           - Default type badge (payment_default, covenant_breach)
           - Severity badge (color-coded: low=yellow, medium=orange, high=red, critical=dark red)
           - Days past due
           - Amount overdue (if payment default)
           - Status badge
           - Click handler to select default
       - Selected default details panel (when default selected):
         - Default information card
         - Recovery actions list with status
         - Action buttons (Send SMS, Make Call, etc.)
         - Action history timeline
     - Add loading states and error handling
     - Use Tailwind CSS for styling (dark theme to match CreditNexus)

2. **Create `client/src/types/recovery.ts`**
   - Define TypeScript types
   - Line-Level Sub-Tasks:
     - Add `LoanDefault` interface
       - `id: number`
       - `loan_id: string`
       - `deal_id: number | null`
       - `default_type: string`
       - `default_date: string`
       - `default_reason: string | null`
       - `amount_overdue: number | null`
       - `days_past_due: number`
       - `severity: 'low' | 'medium' | 'high' | 'critical'`
       - `status: string`
       - `recovery_actions?: RecoveryAction[]`
     - Add `RecoveryAction` interface
       - `id: number`
       - `action_type: string`
       - `communication_method: string`
       - `status: string`
       - `message_content: string`
       - `sent_at: string | null`
       - `delivered_at: string | null`
     - Add `BorrowerContact` interface
       - `id: number`
       - `deal_id: number`
       - `contact_name: string`
       - `phone_number: string | null`
       - `email: string | null`
       - `preferred_contact_method: string`

#### Activity 6.2: Integration with Deal Detail Page
**Priority**: P0  
**Estimated Time**: 1 day

**File-Level Tasks:**

1. **Update `client/src/components/DealDetail.tsx`**
   - Add recovery tab to deal detail page
   - Line-Level Sub-Tasks:
     - Import `LoanRecoverySidebar` component
     - Add "Recovery" tab to tab navigation
     - Add `activeTab === 'recovery'` condition
     - Render `LoanRecoverySidebar` component filtered by `dealId`
     - Pass `dealId` as prop to sidebar

2. **Update `client/src/components/DesktopAppLayout.tsx`**
   - Add recovery sidebar to main layout
   - Line-Level Sub-Tasks:
     - Add recovery sidebar app to `sidebarApps` array
     - Add route `/app/loan-recovery`
     - Add icon (AlertTriangle or similar)
     - Add description: "Loan Recovery & Default Management"

---

## Project 7: Deal Timeline Integration

### Objective
Integrate loan recovery events into the deal flow timeline to show defaults and recovery actions at appropriate event times.

### Activities

#### Activity 7.1: Timeline Event Generation
**Priority**: P0  
**Estimated Time**: 1 day

**File-Level Tasks:**

1. **Update `app/services/deal_service.py`**
   - Add recovery events to timeline
   - Line-Level Sub-Tasks:
     - Update `get_deal_timeline()` method
     - Query `LoanDefault` for deal
       - For each default, add timeline event:
         - `event_type: "loan_default"`
         - `timestamp: default.default_date`
         - `data: {default_type, severity, amount_overdue, days_past_due}`
         - `status: "warning"` or `"failure"` based on severity
     - Query `RecoveryAction` for defaults
       - For each action, add timeline event:
         - `event_type: "recovery_action"`
         - `timestamp: action.sent_at or action.created_at`
         - `data: {action_type, communication_method, status, message_content}`
         - `status: "success"` if delivered, `"pending"` if pending, `"failure"` if failed
     - Merge recovery events with existing timeline events
     - Sort by timestamp

2. **Update `client/src/components/DealTimeline.tsx`**
   - Add recovery event rendering
   - Line-Level Sub-Tasks:
     - Update `formatEventType()` function
       - Add case for `"loan_default"` → "Loan Default"
       - Add case for `"recovery_action"` → "Recovery Action"
     - Update event icon mapping
       - `loan_default` → AlertCircle icon (red)
       - `recovery_action` → Phone or MessageSquare icon (blue/green)
     - Update event card rendering
       - For loan defaults: Show severity badge, amount, days past due
       - For recovery actions: Show action type, method, status

---

## Project 8: User Profile Management

### Objective
Create UI for managing borrower contact information and preferences.

### Activities

#### Activity 8.1: Borrower Contact Management UI
**Priority**: P1  
**Estimated Time**: 2 days

**File-Level Tasks:

1. **Create `client/src/components/BorrowerContactManager.tsx`**
   - Implement contact management component
   - Line-Level Sub-Tasks:
     - Create functional component with props: `dealId: number`
     - Add state: `contacts: BorrowerContact[]`, `editingContact: BorrowerContact | null`
     - Add `useEffect` to fetch contacts on mount
       - Call `/api/recovery/contacts?deal_id=${dealId}`
     - Add `handleCreateContact()` function
       - Show form modal
       - Call `/api/recovery/contacts` POST
       - Refresh contacts list
     - Add `handleUpdateContact(contactId: number)` function
       - Show edit form
       - Call `/api/recovery/contacts/${contactId}` PUT
       - Refresh contacts list
     - Render UI:
       - List of contacts with name, phone, email
       - Edit/Delete buttons
       - "Add Contact" button
       - Form modal for create/edit
     - Add phone number validation (E.164 format)
     - Add email validation

2. **Integrate with Deal Detail**
   - Add contact management to deal detail page
   - Line-Level Sub-Tasks:
     - Add `BorrowerContactManager` to deal detail overview tab
     - Pass `dealId` prop

---

## Project 9: Testing & Documentation

### Objective
Create comprehensive tests and documentation for loan recovery features.

### Activities

#### Activity 9.1: Unit Tests
**Priority**: P1  
**Estimated Time**: 2 days

**File-Level Tasks:**

1. **Create `tests/test_twilio_service.py`**
   - Test Twilio service methods
   - Line-Level Sub-Tasks:
     - Mock Twilio client
     - Test `send_sms()` with valid/invalid phone numbers
     - Test `make_voice_call()` with valid/invalid phone numbers
     - Test error handling for Twilio exceptions
     - Test phone number validation

2. **Create `tests/test_loan_recovery_service.py`**
   - Test recovery service methods
   - Line-Level Sub-Tasks:
     - Test `detect_payment_defaults()` with mock payment schedules
     - Test `trigger_recovery_actions()` with different severity levels
     - Test `execute_recovery_action()` with SMS and voice
     - Test CDM event generation

3. **Create `tests/test_recovery_api.py`**
   - Test API endpoints
   - Line-Level Sub-Tasks:
     - Test GET `/api/recovery/defaults` with filters
     - Test POST `/api/recovery/defaults/detect`
     - Test POST `/api/recovery/defaults/{id}/actions`
     - Test authentication and authorization

#### Activity 9.2: Integration Tests
**Priority**: P1  
**Estimated Time**: 1 day

**File-Level Tasks:**

1. **Create `tests/test_recovery_integration.py`**
   - Test end-to-end recovery workflow
   - Line-Level Sub-Tasks:
     - Create test deal with payment schedule
     - Simulate payment default
     - Trigger recovery actions
     - Verify SMS/voice calls (mocked)
     - Verify timeline events

#### Activity 9.3: Documentation
**Priority**: P1  
**Estimated Time**: 1 day

**File-Level Tasks:**

1. **Create `docs/guides/loan-recovery.md`**
   - Document loan recovery feature
   - Line-Level Sub-Tasks:
     - Overview of feature
     - Configuration instructions (Twilio setup)
     - API endpoint documentation
     - Frontend usage guide
     - Troubleshooting section

---

## Implementation Timeline

### Phase 1: Foundation (Week 1)
- Project 1: Twilio Service Integration
- Project 2: Database Models
- Project 3: Loan Recovery Service (basic)

### Phase 2: Core Features (Week 2)
- Project 3: Loan Recovery Service (complete)
- Project 4: API Endpoints
- Project 6: Frontend Sidebar (basic)

### Phase 3: Integration (Week 3)
- Project 6: Frontend Sidebar (complete)
- Project 7: Deal Timeline Integration
- Project 8: User Profile Management

### Phase 4: Polish & Testing (Week 4)
- Project 5: Background Tasks
- Project 9: Testing & Documentation
- Bug fixes and refinements

---

## Configuration Checklist

### Environment Variables
- [ ] `TWILIO_ENABLED=true`
- [ ] `TWILIO_ACCOUNT_SID=...`
- [ ] `TWILIO_AUTH_TOKEN=...`
- [ ] `TWILIO_PHONE_NUMBER=+1234567890`
- [ ] `TWILIO_WEBHOOK_URL=https://your-domain.com/api/twilio/webhook`

### Twilio Account Setup
- [ ] Create Twilio account
- [ ] Purchase phone number
- [ ] Configure webhook URLs
- [ ] Test SMS sending
- [ ] Test voice calls

### Database Migration
- [ ] Run Alembic migration for recovery tables
- [ ] Verify table creation
- [ ] Create indexes

### Background Tasks
- [ ] Configure default detection task (daily)
- [ ] Configure action processing task (hourly)
- [ ] Test task execution

---

## Success Criteria

1. ✅ Automated detection of payment defaults and covenant breaches
2. ✅ Automated SMS/voice reminders triggered based on severity
3. ✅ Recovery sidebar displays all active defaults with filtering
4. ✅ Recovery actions visible in deal timeline
5. ✅ Borrower contact management functional
6. ✅ CDM events generated for all recovery actions
7. ✅ Webhook handlers update action status in real-time
8. ✅ Background tasks process defaults and actions automatically
9. ✅ Comprehensive test coverage (>80%)
10. ✅ Documentation complete

---

## Risk Mitigation

### Risks
1. **Twilio API rate limits**: Implement rate limiting and queuing
2. **Phone number validation**: Strict E.164 format validation
3. **Webhook security**: Verify Twilio request signatures
4. **Message delivery failures**: Retry logic and error handling
5. **Compliance (TCPA)**: Ensure opt-in/opt-out mechanisms

### Mitigation Strategies
- Add rate limiting to Twilio service calls
- Implement retry logic with exponential backoff
- Add comprehensive error logging
- Create admin dashboard for monitoring recovery actions
- Add compliance checks for communication preferences

---

## Future Enhancements

1. **Email Integration**: Add email reminders via SendGrid/Mailgun
2. **Interactive Voice Response (IVR)**: Allow borrowers to make payments via phone
3. **Payment Links**: Generate secure payment links in SMS
4. **Multi-language Support**: Support multiple languages for messages
5. **Analytics Dashboard**: Track recovery success rates, response times
6. **Escalation Workflows**: Automated escalation to collections/legal
7. **Borrower Portal**: Self-service portal for payment and communication preferences

---

**Document Version**: 1.0  
**Last Updated**: 2024-12-XX  
**Author**: CreditNexus Development Team
